// packages/contracts/src/index.ts
var OfficeError = class extends Error {
  constructor(code, message2) {
    super(message2);
    this.code = code;
    this.name = "OfficeError";
  }
  code;
};
function assert(condition, code, message2) {
  if (!condition) throw new OfficeError(code, message2);
}
var EMU_PER_CSS_PIXEL = 9525;
var CELL_LIMITS = Object.freeze({ xls: Object.freeze({ rows: 65536, columns: 256 }), xlsx: Object.freeze({ rows: 1048576, columns: 16384 }) });
function assertCellAddress(row, column, format = "xlsx") {
  assert(Number.isInteger(row) && row > 0 && row <= CELL_LIMITS[format].rows && Number.isInteger(column) && column > 0 && column <= CELL_LIMITS[format].columns, "invalid", "Cell address is outside format limits");
}
function assertId(value) {
  assert(typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/.test(value), "invalid", "Invalid stable identifier");
}
function assertUnicode(value) {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code >= 55296 && code <= 56319) {
      const next = value.charCodeAt(++i);
      assert(next >= 56320 && next <= 57343, "invalid", "Unpaired Unicode surrogate");
    } else assert(code < 56320 || code > 57343, "invalid", "Unpaired Unicode surrogate");
  }
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}

// packages/core/src/resources.ts
var ROUND_CONSTANTS = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var rotate = (value, bits) => value >>> bits | value << 32 - bits;
function sha256(bytes, cancellation) {
  assert(bytes.length <= 512 * 1024 * 1024, "limit", "Digest input exceeds budget");
  cancellation?.throwIfCancelled();
  const state2 = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const words = new Uint32Array(64);
  const compress = (view2, offset) => {
    for (let i = 0; i < 16; i++) words[i] = view2.getUint32(offset + i * 4);
    for (let i = 16; i < 64; i++) {
      const first = words[i - 15];
      const second = words[i - 2];
      const small0 = rotate(first, 7) ^ rotate(first, 18) ^ first >>> 3;
      const small1 = rotate(second, 17) ^ rotate(second, 19) ^ second >>> 10;
      words[i] = words[i - 16] + small0 + words[i - 7] + small1 >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = state2;
    for (let i = 0; i < 64; i++) {
      const big1 = rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25);
      const choose = e & f ^ ~e & g;
      const first = h + big1 + choose + ROUND_CONSTANTS[i] + words[i] >>> 0;
      const big0 = rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22);
      const majority = a & b ^ a & c ^ b & c;
      const second = big0 + majority >>> 0;
      h = g;
      g = f;
      f = e;
      e = d + first >>> 0;
      d = c;
      c = b;
      b = a;
      a = first + second >>> 0;
    }
    for (const [index, value] of [a, b, c, d, e, f, g, h].entries()) state2[index] = state2[index] + value >>> 0;
  };
  const completeLength = Math.floor(bytes.length / 64) * 64;
  const input = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  for (let offset = 0; offset < completeLength; offset += 64) {
    if ((offset & 65535) === 0) cancellation?.throwIfCancelled();
    compress(input, offset);
  }
  const remainder = bytes.length - completeLength;
  const tailLength = remainder < 56 ? 64 : 128;
  const tail = new Uint8Array(tailLength);
  tail.set(bytes.subarray(completeLength));
  tail[remainder] = 128;
  const view = new DataView(tail.buffer);
  const bitLength = BigInt(bytes.length) * 8n;
  view.setUint32(tailLength - 8, Number(bitLength >> 32n));
  view.setUint32(tailLength - 4, Number(bitLength & 0xffffffffn));
  for (let offset = 0; offset < tailLength; offset += 64) compress(view, offset);
  cancellation?.throwIfCancelled();
  return Array.from(state2, (value) => value.toString(16).padStart(8, "0")).join("");
}

// packages/core/src/images.ts
var MAX_BYTES = 8 * 1024 * 1024;
var MAX_PIXELS = 4e7;
var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function dimensions(width, height) {
  assert(Number.isSafeInteger(width) && Number.isSafeInteger(height) && width > 0 && height > 0 && width <= 16384 && height <= 16384 && width * height <= MAX_PIXELS, "limit", "Image pixel budget exceeded");
}
function decodeImageBytes(value) {
  assert(typeof value === "string" && value.length > 0 && value.length % 4 === 0 && value.length <= Math.ceil(MAX_BYTES / 3) * 4, "limit", "Encoded image budget exceeded");
  const padding = value.endsWith("==") ? 2 : value.endsWith("=") ? 1 : 0;
  const length = value.length / 4 * 3 - padding;
  assert(length > 0 && length <= MAX_BYTES, "limit", "Image byte budget exceeded");
  const result = new Uint8Array(length);
  const table = new Int16Array(128).fill(-1);
  for (let i = 0; i < B64.length; i++) table[B64.charCodeAt(i)] = i;
  let out = 0;
  for (let i = 0; i < value.length; i += 4) {
    const last = i + 4 === value.length, a = table[value.charCodeAt(i)] ?? -1, b = table[value.charCodeAt(i + 1)] ?? -1;
    const c = last && padding === 2 ? 0 : table[value.charCodeAt(i + 2)] ?? -1, d = last && padding ? 0 : table[value.charCodeAt(i + 3)] ?? -1;
    assert(a >= 0 && b >= 0 && c >= 0 && d >= 0 && (!last || padding !== 2 || (b & 15) === 0) && (!last || padding !== 1 || (c & 3) === 0), "invalid", "Invalid or noncanonical image base64");
    const n = a * 262144 + b * 4096 + c * 64 + d;
    result[out++] = n >>> 16;
    if (out < length) result[out++] = n >>> 8 & 255;
    if (out < length) result[out++] = n & 255;
  }
  return result;
}
var crcTable = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let j = 0; j < 8; j++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
  crcTable[i] = c >>> 0;
}
function crc(bytes, start, end) {
  let c = 4294967295;
  for (let i = start; i < end; i++) c = crcTable[(c ^ bytes[i]) & 255] ^ c >>> 8;
  return (c ^ 4294967295) >>> 0;
}
function inspectImage(bytes) {
  assert(bytes instanceof Uint8Array && bytes.length >= 12 && bytes.length <= MAX_BYTES, "limit", "Invalid image byte length");
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if ([137, 80, 78, 71, 13, 10, 26, 10].every((b, i) => bytes[i] === b)) {
    let at = 8, count = 0, width = 0, height = 0, idat = false, ended = false;
    while (at < bytes.length) {
      assert(++count <= 4096 && at + 12 <= bytes.length, "invalid", "Invalid PNG chunk envelope");
      const n = v.getUint32(at);
      assert(n <= bytes.length - at - 12, "invalid", "Truncated PNG chunk");
      const type = String.fromCharCode(...bytes.subarray(at + 4, at + 8)), end = at + 8 + n;
      assert(/^[A-Za-z]{4}$/.test(type) && crc(bytes, at + 4, end) === v.getUint32(end), "invalid", "PNG chunk CRC or type mismatch");
      if (count === 1) {
        assert(type === "IHDR" && n === 13, "invalid", "Missing PNG IHDR");
        width = v.getUint32(at + 8);
        height = v.getUint32(at + 12);
        dimensions(width, height);
        const depth = bytes[at + 16], color = bytes[at + 17];
        assert((color === 0 ? [1, 2, 4, 8, 16].includes(depth) : color === 3 ? [1, 2, 4, 8].includes(depth) : [2, 4, 6].includes(color) && [8, 16].includes(depth)) && bytes[at + 18] === 0 && bytes[at + 19] === 0 && [0, 1].includes(bytes[at + 20]), "unsupported", "Unsupported PNG header");
      } else {
        assert(type !== "IHDR" && !["acTL", "fcTL", "fdAT", "iCCP", "zTXt", "iTXt", "eXIf"].includes(type), "unsupported", "Animated or compressed metadata PNG unsupported");
        if (type === "IDAT") idat = true;
        else if (type === "IEND") {
          assert(n === 0 && idat && end + 4 === bytes.length, "invalid", "Invalid PNG ending");
          ended = true;
        } else assert(type === "PLTE" || type[0] === type[0].toLowerCase(), "unsupported", "Unknown critical PNG chunk");
      }
      at = end + 4;
      if (ended) break;
    }
    assert(ended, "invalid", "PNG has no complete image");
    return { mimeType: "image/png", pixelWidth: width, pixelHeight: height };
  }
  if (bytes[0] === 255 && bytes[1] === 216) {
    let at = 2, width = 0, height = 0, scans = 0, markers = 0, scan = false;
    while (at < bytes.length) {
      assert(++markers <= 1e4, "limit", "JPEG marker budget exceeded");
      if (scan) {
        while (at < bytes.length && bytes[at] !== 255) at++;
        assert(at < bytes.length, "invalid", "Truncated JPEG scan");
      } else assert(bytes[at] === 255, "invalid", "Invalid JPEG marker");
      while (at < bytes.length && bytes[at] === 255) at++;
      assert(at < bytes.length, "invalid", "Truncated JPEG marker");
      const marker = bytes[at++];
      if (scan && (marker === 0 || marker >= 208 && marker <= 215)) continue;
      scan = false;
      if (marker === 217) {
        assert(at === bytes.length && width > 0 && height > 0 && scans > 0, "invalid", "Invalid JPEG ending");
        return { mimeType: "image/jpeg", pixelWidth: width, pixelHeight: height };
      }
      assert(marker !== 216 && marker !== 0 && at + 2 <= bytes.length, "invalid", "Invalid JPEG segment");
      const size = v.getUint16(at);
      assert(size >= 2 && size <= bytes.length - at, "invalid", "Truncated JPEG segment");
      if ([192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207].includes(marker)) {
        assert((marker === 192 || marker === 194) && !width && size >= 8 && bytes[at + 2] === 8, "unsupported", "Unsupported JPEG frame");
        height = v.getUint16(at + 3);
        width = v.getUint16(at + 5);
        dimensions(width, height);
        const components = bytes[at + 7];
        assert((components === 1 || components === 3) && size === 8 + components * 3, "unsupported", "Unsupported JPEG components");
      }
      if (marker === 225 || marker === 226) assert(false, "unsupported", "JPEG EXIF/ICC metadata needs an orientation/color adapter");
      if (marker === 218) {
        assert(width > 0 && ++scans <= 128, "invalid", "Invalid JPEG scan");
        scan = true;
      }
      at += size;
    }
    assert(false, "invalid", "JPEG has no complete ending");
  }
  assert(false, "unsupported", "Only PNG and JPEG image payloads are supported");
}
function validateImageResource(resource) {
  assert(resource !== null && typeof resource === "object", "invalid", "Invalid image resource");
  const r = resource;
  assertId(r.id);
  const bytes = decodeImageBytes(r.dataBase64), info = inspectImage(bytes);
  assert(r.id === "img-" + r.sha256 && r.sha256 === sha256(bytes) && r.byteLength === bytes.length && r.mimeType === info.mimeType && r.pixelWidth === info.pixelWidth && r.pixelHeight === info.pixelHeight, "invalid", "Image resource digest, type or dimensions mismatch");
}

// packages/core/src/model.ts
function assertPlainData(value, maxNodes = 1e6, maxDepth = 128) {
  const ancestors = /* @__PURE__ */ new Set();
  let nodes = 0;
  let textUnits = 0;
  const visit = (item, depth) => {
    assert(++nodes <= maxNodes && depth <= maxDepth, "limit", "Model resource budget exceeded");
    if (item === null || typeof item === "boolean") return;
    if (typeof item === "number") {
      assert(Number.isFinite(item), "invalid", "Non-finite model number");
      return;
    }
    if (typeof item === "string") {
      textUnits += item.length;
      assert(textUnits <= 64 * 1024 * 1024, "limit", "Model text budget exceeded");
      assertUnicode(item);
      return;
    }
    assert(Array.isArray(item) || isRecord(item), "invalid", "Model must contain only plain serializable data");
    assert(!ancestors.has(item), "invalid", "Cyclic model");
    ancestors.add(item);
    if (Array.isArray(item)) {
      assert(item.length <= maxNodes, "limit", "Model array budget exceeded");
      assert(Object.keys(item).length === item.length && Object.getOwnPropertyNames(item).length === item.length + 1 && Object.getOwnPropertySymbols(item).length === 0, "invalid", "Sparse or decorated model array");
      for (let i = 0; i < item.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(item, String(i));
        assert(descriptor && "value" in descriptor, "invalid", "Model accessors are forbidden");
        visit(descriptor.value, depth + 1);
      }
    } else {
      assert(Object.getOwnPropertySymbols(item).length === 0, "invalid", "Model symbols are forbidden");
      for (const name of Object.getOwnPropertyNames(item)) {
        assert(!["__proto__", "constructor", "prototype"].includes(name), "unsafe", "Unsafe model key");
        const descriptor = Object.getOwnPropertyDescriptor(item, name);
        assert(descriptor && "value" in descriptor && descriptor.enumerable, "invalid", "Model accessors and hidden properties are forbidden");
        visit(descriptor.value, depth + 1);
      }
    }
    ancestors.delete(item);
  };
  visit(value, 0);
}
function object(value, fields) {
  assert(isRecord(value), "invalid", "Expected model object");
  assert(Object.keys(value).every((key) => fields.includes(key)), "invalid", "Unknown model field");
  return value;
}
function list(value, min = 0) {
  assert(Array.isArray(value) && value.length >= min, "invalid", "Invalid model list");
  return value;
}
function text(value, max = 1e6, empty = true) {
  assert(typeof value === "string" && value.length <= max && (empty || value.length > 0), "invalid", "Invalid model text");
}
function integer(value, min = -Number.MAX_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER) {
  assert(typeof value === "number" && Number.isSafeInteger(value) && value >= min && value <= max, "invalid", "Invalid integer model value");
}
function bool(value) {
  assert(typeof value === "boolean", "invalid", "Invalid boolean model value");
}
function optionalId(value, known) {
  if (value !== void 0) {
    assertId(value);
    assert(Object.hasOwn(known, value), "invalid", "Missing model reference");
  }
}
function validateColor(value) {
  const item = object(value, ["kind", "red", "green", "blue", "alpha", "name", "tint"]);
  if (item.kind === "rgba") {
    assert(!("name" in item) && !("tint" in item), "invalid", "Unexpected RGBA fields");
    for (const key of ["red", "green", "blue", "alpha"]) integer(item[key], 0, 255);
  } else {
    assert(item.kind === "theme" && !["red", "green", "blue", "alpha"].some((key) => key in item), "invalid", "Invalid theme color");
    text(item.name, 128, false);
    if (item.tint !== void 0) assert(typeof item.tint === "number" && Number.isFinite(item.tint) && item.tint >= -1 && item.tint <= 1, "invalid", "Invalid color tint");
  }
}
function isDocumentLanguageTag(value) {
  if (typeof value !== "string" || !value.length || value.length > 128) return false;
  try {
    return Intl.getCanonicalLocales(value).length === 1;
  } catch {
    return false;
  }
}
function validateTextStyle(value) {
  const style = object(value, ["fontFamily", "fontAscii", "fontHighAnsi", "fontEastAsia", "fontComplex", "fontSize", "complexFontSize", "bold", "italic", "underline", "color", "alignment", "indent", "spaceBefore", "spaceAfter", "lineHeight", "lineMultiple", "minLineHeight", "keepNext", "keepLines", "outlineLevel", "widowControl", "language", "eastAsiaLanguage", "bidiLanguage", "runDirection", "paragraphDirection"]);
  for (const key of ["fontFamily", "fontAscii", "fontHighAnsi", "fontEastAsia", "fontComplex"]) if (style[key] !== void 0) {
    text(style[key], 512, false);
    assert(!/[\x00-\x1f\x7f]/.test(style[key]), "invalid", "Invalid font family");
  }
  if (style.fontSize !== void 0) integer(style.fontSize, 1, 12700 * 1638);
  if (style.complexFontSize !== void 0) integer(style.complexFontSize, 1, 12700 * 1638);
  if (style.lineMultiple !== void 0) integer(style.lineMultiple, 1, 31680);
  if (style.minLineHeight !== void 0) integer(style.minLineHeight, 0);
  assert(["lineHeight", "lineMultiple", "minLineHeight"].filter((k) => style[k] !== void 0).length <= 1, "invalid", "Conflicting line spacing modes");
  if (style.outlineLevel !== void 0) integer(style.outlineLevel, 0, 9);
  for (const key of ["keepNext", "keepLines", "widowControl"]) if (style[key] !== void 0) bool(style[key]);
  for (const key of ["bold", "italic", "underline"]) if (style[key] !== void 0) bool(style[key]);
  if (style.color !== void 0) validateColor(style.color);
  for (const key of ["language", "eastAsiaLanguage", "bidiLanguage"]) if (style[key] !== void 0) assert(isDocumentLanguageTag(style[key]), "invalid", "Invalid document language tag");
  for (const key of ["runDirection", "paragraphDirection"]) if (style[key] !== void 0) assert(style[key] === "ltr" || style[key] === "rtl", "invalid", "Invalid document direction");
  if (style.alignment !== void 0) assert(["start", "center", "end", "justify"].includes(String(style.alignment)), "invalid", "Invalid text alignment");
  if (style.indent !== void 0) integer(style.indent);
  for (const key of ["spaceBefore", "spaceAfter", "lineHeight"]) if (style[key] !== void 0) integer(style[key], 0);
}
function validateGeometry(value) {
  const geometry = object(value, ["x", "y", "width", "height", "rotation"]);
  integer(geometry.x);
  integer(geometry.y);
  integer(geometry.width, 0);
  integer(geometry.height, 0);
  integer(geometry.rotation);
  assert(Number.isSafeInteger(geometry.x + geometry.width) && Number.isSafeInteger(geometry.y + geometry.height), "invalid", "Geometry sum exceeds safe precision");
}
function validateDocument(value) {
  assertPlainData(value);
  assert(isRecord(value), "invalid", "Expected document");
  if (value.schemaVersion !== 1) throw new OfficeError("unsupported", "Unsupported document schema version");
  const fields = ["schemaVersion", "documentId", "title", "resources", "styles", "defaultTextStyle", "kind"];
  const model = object(value, [...fields, ...value.kind === "writer" ? ["sections", "defaultParagraphStyleId"] : value.kind === "sheets" ? ["dateSystem", "sheets"] : value.kind === "slides" ? ["size", "slides"] : []]);
  assertId(model.documentId);
  text(model.title, 1024, false);
  const ids = /* @__PURE__ */ new Set();
  const id = (candidate) => {
    assertId(candidate);
    assert(!ids.has(candidate), "invalid", "Duplicate stable node identifier");
    ids.add(candidate);
  };
  assert(isRecord(model.resources), "invalid", "Invalid resources");
  let resourceBytes = 0, packagedImageBytes = 0;
  for (const [key, item] of Object.entries(model.resources)) {
    assertId(key);
    const resource = object(item, ["id", "sha256", "mimeType", "byteLength", "dataBase64", "pixelWidth", "pixelHeight"]);
    assert(resource.id === key, "invalid", "Resource identifier mismatch");
    assert(typeof resource.sha256 === "string" && /^[a-f0-9]{64}$/.test(resource.sha256), "invalid", "Invalid resource digest");
    text(resource.mimeType, 255, false);
    assert(/^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/i.test(resource.mimeType), "invalid", "Invalid resource media type");
    integer(resource.byteLength, 0, 128 * 1024 * 1024);
    if (resource.dataBase64 !== void 0 || resource.pixelWidth !== void 0 || resource.pixelHeight !== void 0) {
      validateImageResource(resource);
      packagedImageBytes += resource.byteLength;
      assert(packagedImageBytes <= 16 * 1024 * 1024, "limit", "Packaged image budget exceeded");
    }
    resourceBytes += resource.byteLength;
    assert(resourceBytes <= 128 * 1024 * 1024, "limit", "Document resource budget exceeded");
  }
  assert(isRecord(model.styles), "invalid", "Invalid styles");
  const styles = model.styles;
  for (const [key, item] of Object.entries(styles)) {
    assertId(key);
    const style = object(item, ["id", "name", "basedOn", "kind", "toggles", "properties"]);
    assert(style.id === key, "invalid", "Style identifier mismatch");
    text(style.name, 512, false);
    optionalId(style.basedOn, styles);
    validateTextStyle(style.properties);
    if (style.kind !== void 0) assert(style.kind === "paragraph" || style.kind === "character", "invalid", "Invalid named style kind");
    if (style.toggles !== void 0) {
      assert(Array.isArray(style.toggles) && style.toggles.length <= 2 && new Set(style.toggles).size === style.toggles.length && style.toggles.every((k) => (k === "bold" || k === "italic") && !Object.hasOwn(style.properties, k)), "invalid", "Invalid named style toggle");
    }
    if (style.kind !== void 0 && style.basedOn !== void 0) {
      const parent2 = styles[String(style.basedOn)];
      assert(isRecord(parent2) && parent2.kind === style.kind, "invalid", "Named style inheritance crosses style kinds");
    }
    const path = /* @__PURE__ */ new Set([key]);
    let parent = style.basedOn;
    while (parent !== void 0) {
      assertId(parent);
      assert(!path.has(parent), "invalid", "Style inheritance cycle");
      path.add(parent);
      assert(path.size <= 128, "limit", "Style inheritance depth exceeded");
      const ancestor = styles[parent];
      assert(isRecord(ancestor), "invalid", "Missing parent style");
      parent = ancestor.basedOn;
    }
  }
  validateTextStyle(model.defaultTextStyle);
  const resources = model.resources;
  const run = (candidate, textOnly = false) => {
    const inline = object(candidate, ["id", "type", "text", "styleId", "style", "resourceId", "width", "height", "drawingName", "pictureName"]);
    id(inline.id);
    if (inline.type === "text") {
      assert(!["resourceId", "width", "height", "drawingName", "pictureName"].some((key) => key in inline), "invalid", "Unexpected text run fields");
      text(inline.text);
      optionalId(inline.styleId, styles);
      if (inline.styleId !== void 0) {
        const ref = styles[String(inline.styleId)];
        assert(isRecord(ref) && (ref.kind === void 0 || ref.kind === "character"), "invalid", "Text run requires a character style");
      }
      if (inline.style !== void 0) validateTextStyle(inline.style);
    } else if (inline.type === "image" && !textOnly) {
      assert(!["text", "style", "styleId"].some((key) => key in inline), "invalid", "Unexpected image fields");
      assert(inline.resourceId !== void 0, "invalid", "Missing image resource");
      optionalId(inline.resourceId, resources);
      integer(inline.width, 1);
      integer(inline.height, 1);
      if (inline.drawingName !== void 0) text(inline.drawingName, 512);
      if (inline.pictureName !== void 0) text(inline.pictureName, 512);
    } else {
      assert(!textOnly && (inline.type === "tab" || inline.type === "line-break") && Object.keys(inline).length === 2, "invalid", "Unsupported inline model");
    }
  };
  const block = (candidate, depth = 0) => {
    assert(depth <= 64, "limit", "Table nesting budget exceeded");
    const value2 = object(candidate, ["id", "type", "styleId", "style", "runs", "columnWidths", "rows", "cellPadding", "border"]);
    id(value2.id);
    if (value2.type === "paragraph") {
      assert(!["rows", "columnWidths", "cellPadding", "border"].some((k) => k in value2), "invalid", "Unexpected paragraph fields");
      optionalId(value2.styleId, styles);
      if (value2.styleId !== void 0) {
        const ref = styles[String(value2.styleId)];
        assert(isRecord(ref) && (ref.kind === void 0 || ref.kind === "paragraph"), "invalid", "Paragraph requires a paragraph style");
      }
      if (value2.style !== void 0) validateTextStyle(value2.style);
      list(value2.runs).forEach((item) => run(item));
    } else if (value2.type === "table") {
      assert(!["runs", "style", "styleId"].some((key) => key in value2), "invalid", "Unexpected table fields");
      const widths = list(value2.columnWidths, 1);
      widths.forEach((width) => integer(width, 1));
      assert(widths.length <= 64 && widths.reduce((sum, w) => sum + Number(w), 0) <= Number.MAX_SAFE_INTEGER, "limit", "Table width budget exceeded");
      if (value2.cellPadding !== void 0) {
        const pad = object(value2.cellPadding, ["top", "right", "bottom", "left"]);
        for (const key of ["top", "right", "bottom", "left"]) integer(pad[key], 0, 12700 * 144);
      }
      if (value2.border !== void 0) {
        const border = object(value2.border, ["width", "color"]);
        integer(border.width, 1, 12700 * 12);
        validateColor(border.color);
      }
      const rows = list(value2.rows, 1);
      assert(rows.length <= 500 && rows.length * widths.length <= 1e4, "limit", "Table cell budget exceeded");
      rows.forEach((candidate2) => {
        const row = object(candidate2, ["id", "cells"]);
        id(row.id);
        const cells = list(row.cells);
        assert(cells.length === widths.length, "invalid", "Non-rectangular table");
        cells.forEach((candidate3) => {
          const cell = object(candidate3, ["id", "blocks"]);
          id(cell.id);
          list(cell.blocks, 1).forEach((item) => block(item, depth + 1));
        });
      });
    } else assert(value2.type === "page-break" && Object.keys(value2).length === 2, "invalid", "Invalid writer block");
  };
  if (model.kind === "writer") {
    optionalId(model.defaultParagraphStyleId, styles);
    if (model.defaultParagraphStyleId !== void 0) {
      const ref = styles[String(model.defaultParagraphStyleId)];
      assert(isRecord(ref) && ref.kind === "paragraph", "invalid", "Default paragraph style must be a paragraph style");
    }
    const sections = list(model.sections, 1);
    assert(sections.length <= 128, "limit", "Writer section budget exceeded");
    sections.forEach((candidate) => {
      const section = object(candidate, ["id", "page", "blocks", "pageExtras"]);
      id(section.id);
      if (section.pageExtras !== void 0) {
        const extra = object(section.pageExtras, ["headerDistance", "footerDistance", "columnSpace", "docGridLinePitch"]);
        for (const n of Object.values(extra)) integer(n, 0, 31680 * 635);
      }
      const page = object(section.page, ["width", "height", "margins"]);
      integer(page.width, 1);
      integer(page.height, 1);
      const margins = object(page.margins, ["top", "right", "bottom", "left"]);
      integer(margins.top, 0);
      integer(margins.right, 0);
      integer(margins.bottom, 0);
      integer(margins.left, 0);
      assert(margins.left + margins.right < page.width && margins.top + margins.bottom < page.height, "invalid", "Margins leave no content area");
      list(section.blocks, 1).forEach((candidate2) => block(candidate2));
    });
  } else if (model.kind === "sheets") {
    assert(model.dateSystem === "1900" || model.dateSystem === "1904", "invalid", "Invalid workbook date system");
    const names = /* @__PURE__ */ new Set();
    list(model.sheets, 1).forEach((candidate) => {
      const sheet = object(candidate, ["id", "name", "cells", "rows", "columns", "merges", "view"]);
      id(sheet.id);
      text(sheet.name, 31, false);
      if (sheet.view !== void 0) {
        const view = object(sheet.view, ["rightToLeft", "frozenRows", "frozenColumns", "showGridLines"]);
        for (const field of ["rightToLeft", "showGridLines"]) if (view[field] !== void 0) bool(view[field]);
        if (view.frozenRows !== void 0) integer(view.frozenRows, 0, 1048575);
        if (view.frozenColumns !== void 0) integer(view.frozenColumns, 0, 16383);
      }
      assert(!/[\[\]:*?/\\\x00-\x1f]/.test(sheet.name) && !sheet.name.startsWith("'") && !sheet.name.endsWith("'"), "invalid", "Invalid sheet name");
      const name = sheet.name.toLowerCase();
      assert(!names.has(name), "invalid", "Duplicate sheet name");
      names.add(name);
      assert(isRecord(sheet.cells), "invalid", "Invalid sparse cell map");
      for (const [key, item] of Object.entries(sheet.cells)) {
        const match = /^([1-9]\d*):([1-9]\d*)$/.exec(key);
        assert(match, "invalid", "Invalid cell key");
        assertCellAddress(Number(match[1]), Number(match[2]));
        validateCell(item, styles);
      }
      for (const [key, max, size] of [["rows", 1048576, "height"], ["columns", 16384, "width"]]) {
        const dimensions3 = sheet[key];
        assert(isRecord(dimensions3), "invalid", "Invalid sheet dimensions");
        for (const [address, candidate2] of Object.entries(dimensions3)) {
          assert(/^[1-9]\d*$/.test(address), "invalid", "Invalid dimension address");
          integer(Number(address), 1, max);
          const dimension = object(candidate2, [size, "hidden"]);
          if (dimension[size] !== void 0) integer(dimension[size], 1);
          if (dimension.hidden !== void 0) bool(dimension.hidden);
        }
      }
      const merges = list(sheet.merges);
      assert(merges.length <= 1e4, "limit", "Merge budget exceeded");
      const validated = merges.map((candidate2) => {
        const merge = object(candidate2, ["row", "column", "rowCount", "columnCount"]);
        integer(merge.row, 1);
        integer(merge.column, 1);
        integer(merge.rowCount, 1);
        integer(merge.columnCount, 1);
        assertCellAddress(merge.row, merge.column);
        assertCellAddress(merge.row + merge.rowCount - 1, merge.column + merge.columnCount - 1);
        return merge;
      }).sort((a, b) => a.row - b.row);
      let active = [];
      for (const merge of validated) {
        active = active.filter((previous) => previous.row + previous.rowCount > merge.row);
        assert(!active.some((previous) => previous.column < merge.column + merge.columnCount && merge.column < previous.column + previous.columnCount), "invalid", "Overlapping merged ranges");
        active.push(merge);
      }
    });
  } else if (model.kind === "slides") {
    const size = object(model.size, ["width", "height"]);
    integer(size.width, 1);
    integer(size.height, 1);
    list(model.slides).forEach((candidate) => {
      const slide = object(candidate, ["id", "background", "shapes"]);
      id(slide.id);
      validateColor(slide.background);
      list(slide.shapes).forEach((candidate2) => {
        const shape = object(candidate2, ["id", "type", "geometry", "fill", "stroke", "runs", "resourceId"]);
        id(shape.id);
        validateGeometry(shape.geometry);
        if (shape.fill !== void 0) validateColor(shape.fill);
        if (shape.stroke !== void 0) {
          const stroke = object(shape.stroke, ["color", "width"]);
          validateColor(stroke.color);
          integer(stroke.width, 0);
        }
        if (shape.type === "text") {
          assert(!("resourceId" in shape), "invalid", "Unexpected text shape fields");
          list(shape.runs).forEach((item) => run(item, true));
        } else if (shape.type === "image") {
          assert(!("runs" in shape) && shape.resourceId !== void 0, "invalid", "Invalid image shape");
          optionalId(shape.resourceId, resources);
        } else assert(["rect", "ellipse", "line"].includes(String(shape.type)) && !("runs" in shape) && !("resourceId" in shape), "invalid", "Invalid shape type");
      });
    });
  } else throw new OfficeError("invalid", "Invalid document kind");
  return value;
}
function validateCell(value, styles = {}) {
  const cell = object(value, ["value", "styleId", "numberFormat", "style"]);
  optionalId(cell.styleId, styles);
  if (cell.style !== void 0) validateCellStyle(cell.style);
  if (cell.numberFormat !== void 0) text(cell.numberFormat, 1024);
  const item = object(cell.value, ["kind", "value", "source"]);
  if (item.kind === "blank") assert(Object.keys(item).length === 1, "invalid", "Blank cell has a payload");
  else if (item.kind === "formula") {
    assert(!("value" in item), "invalid", "Formula cache is not source content");
    text(item.source, 8192, false);
    assert(item.source.startsWith("=") && item.source.length > 1, "invalid", "Invalid formula source");
  } else {
    assert(!("source" in item), "invalid", "Unexpected cell source");
    if (item.kind === "string") text(item.value, 32767);
    else if (item.kind === "number") assert(typeof item.value === "number" && Number.isFinite(item.value), "invalid", "Invalid numeric cell");
    else if (item.kind === "boolean") bool(item.value);
    else assert(item.kind === "error" && ["#NULL!", "#DIV/0!", "#VALUE!", "#REF!", "#NAME?", "#NUM!", "#N/A"].includes(String(item.value)), "invalid", "Invalid cell value");
  }
}
function validateCellStyle(value) {
  assert(isRecord(value), "invalid", "Invalid cell style");
  const { fill, border, verticalAlignment, wrapText, ...font } = value;
  validateTextStyle(font);
  if (fill !== void 0) validateColor(fill);
  if (border !== void 0) {
    const edge = object(border, ["color", "width"]);
    validateColor(edge.color);
    integer(edge.width, 1, 12700 * 12);
  }
  if (verticalAlignment !== void 0) assert(["top", "center", "bottom"].includes(String(verticalAlignment)), "invalid", "Invalid vertical cell alignment");
  if (wrapText !== void 0) bool(wrapText);
}
function createDocument(kind, documentId, title = "Untitled") {
  assert(kind === "writer" || kind === "sheets" || kind === "slides", "invalid", "Invalid document kind");
  const base = { schemaVersion: 1, documentId, title, resources: {}, styles: {}, defaultTextStyle: { fontFamily: "sans-serif", fontSize: 152400 } };
  const document2 = kind === "writer" ? { ...base, kind, sections: [{ id: "section-1", page: { width: 756e4, height: 10692e3, margins: { top: 914400, right: 914400, bottom: 914400, left: 914400 } }, blocks: [{ id: "paragraph-1", type: "paragraph", runs: [{ id: "run-1", type: "text", text: "" }] }] }] } : kind === "sheets" ? { ...base, kind, dateSystem: "1900", sheets: [{ id: "sheet-1", name: "Sheet1", cells: {}, rows: {}, columns: {}, merges: [] }] } : { ...base, kind, size: { width: 12192e3, height: 6858e3 }, slides: [{ id: "slide-1", background: { kind: "rgba", red: 255, green: 255, blue: 255, alpha: 255 }, shapes: [] }] };
  return validateDocument(document2);
}
function cloneData(value) {
  if (Array.isArray(value)) return value.map(cloneData);
  if (isRecord(value)) return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, cloneData(item)]));
  return value;
}
function freezeData(value) {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const item of Object.values(value)) freezeData(item);
    Object.freeze(value);
  }
  return value;
}

// packages/core/src/session.ts
var EDITABLE_CAPABILITIES = Object.freeze({ canEdit: true, allowedFeatures: Object.freeze(["MOD-01", "MOD-03", "WRT-02", "WRT-03", "SHT-02", "SLD-02"]), diagnostics: Object.freeze([]) });
function sameData(a, b) {
  if (Object.is(a, b)) return true;
  if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((item, index) => sameData(item, b[index]));
  if (isRecord(a) && isRecord(b)) {
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every((key) => Object.hasOwn(b, key) && sameData(a[key], b[key]));
  }
  return false;
}
function validatePath(path) {
  assert(Array.isArray(path) && path.length > 0 && path.length <= 64, "invalid", "Invalid model path");
  for (const key of path) assert(typeof key === "string" && key.length > 0 && key.length <= 128 && !["__proto__", "constructor", "prototype"].includes(key) || typeof key === "number" && Number.isSafeInteger(key) && key >= 0, "unsafe", "Unsafe model path");
  assert(!["schemaVersion", "documentId", "kind"].includes(String(path[0])), "invalid", "Document identity cannot be changed by a command");
}
function assertOperation(value) {
  assert(isRecord(value), "invalid", "Invalid patch operation");
  validatePath(value.path);
  if (value.op === "set") {
    assert(Object.keys(value).length === 3 && Object.hasOwn(value, "value"), "invalid", "Invalid set patch");
    assertPlainData(value.value);
  } else if (value.op === "delete") assert(Object.keys(value).length === 2, "invalid", "Invalid delete patch");
  else {
    assert(value.op === "splice" && Object.keys(value).length === 5 && Number.isSafeInteger(value.index) && Number(value.index) >= 0 && Number.isSafeInteger(value.deleteCount) && Number(value.deleteCount) >= 0 && Array.isArray(value.items), "invalid", "Invalid splice patch");
    assertPlainData(value.items);
  }
}
function child(container, key) {
  assert(Array.isArray(container) || isRecord(container), "invalid", "Model path does not name a container");
  if (Array.isArray(container)) {
    assert(typeof key === "number" && key < container.length, "invalid", "Array path is out of bounds");
    return container[key];
  }
  assert(typeof key === "string" && Object.hasOwn(container, key), "invalid", "Model path does not exist");
  return container[key];
}
function atPath(root2, path) {
  let current = root2;
  for (const key of path) current = child(current, key);
  return current;
}
function replaceAt(root2, path, value, remove = false) {
  const [key, ...rest] = path;
  assert(key !== void 0 && (Array.isArray(root2) || isRecord(root2)), "invalid", "Invalid patch container");
  if (Array.isArray(root2)) {
    assert(typeof key === "number" && key < root2.length && (!remove || rest.length > 0), "invalid", "Array entries must be removed with splice");
    const copy2 = root2.slice();
    copy2[key] = rest.length ? replaceAt(child(root2, key), rest, value, remove) : value;
    return copy2;
  }
  assert(typeof key === "string", "invalid", "Object paths require string keys");
  const copy = { ...root2 };
  if (rest.length) copy[key] = replaceAt(child(root2, key), rest, value, remove);
  else if (remove) delete copy[key];
  else copy[key] = value;
  return copy;
}
function applyPatch(root2, patch) {
  if (patch.op === "splice") {
    const target = atPath(root2, patch.path);
    assert(Array.isArray(target), "invalid", "Splice target is not an array");
    assert(patch.index <= target.length && patch.deleteCount <= target.length - patch.index, "invalid", "Splice range is out of bounds");
    const removed = target.slice(patch.index, patch.index + patch.deleteCount);
    if (sameData(removed, patch.items)) return { document: root2 };
    const copy = target.slice(0, patch.index).concat(cloneData(patch.items), target.slice(patch.index + patch.deleteCount));
    return { document: replaceAt(root2, patch.path, copy), inverse: { op: "splice", path: patch.path, index: patch.index, deleteCount: patch.items.length, items: removed } };
  }
  const parentPath = patch.path.slice(0, -1);
  const key = patch.path[patch.path.length - 1];
  const parent = parentPath.length ? atPath(root2, parentPath) : root2;
  assert(isRecord(parent) || Array.isArray(parent), "invalid", "Invalid patch parent");
  if (Array.isArray(parent)) assert(typeof key === "number" && key < parent.length && patch.op !== "delete", "invalid", "Invalid array patch");
  else assert(typeof key === "string", "invalid", "Invalid object patch");
  const exists = Object.hasOwn(parent, key);
  const before = exists ? child(parent, key) : void 0;
  if (patch.op === "delete") {
    if (!exists) return { document: root2 };
    return { document: replaceAt(root2, patch.path, void 0, true), inverse: { op: "set", path: patch.path, value: before } };
  }
  if (exists && sameData(before, patch.value)) return { document: root2 };
  return { document: replaceAt(root2, patch.path, cloneData(patch.value)), inverse: exists ? { op: "set", path: patch.path, value: before } : { op: "delete", path: patch.path } };
}
function applyBatch(document2, operations) {
  let next = document2;
  const forward = [];
  const inverse = [];
  for (const operation of operations) {
    assertOperation(operation);
    const result = applyPatch(next, operation);
    if (result.inverse) {
      forward.push(cloneData(operation));
      inverse.unshift(result.inverse);
      next = result.document;
    }
  }
  if (sameData(document2, next)) return { document: document2, forward: [], inverse: [] };
  validateDocument(next);
  return { document: next, forward, inverse };
}
var DocumentSession = class {
  #document;
  #revision = 0;
  #contentCounter = 0;
  #contentId;
  #lastSavedContentId;
  #past = [];
  #future = [];
  #historyItems;
  #historyBytes;
  #capabilities;
  #saveCounter = 0;
  #activeSave;
  #closed = false;
  constructor(document2, options = {}) {
    this.#document = freezeData(cloneData(validateDocument(document2)));
    this.#contentId = `${this.#document.documentId}:content:0`;
    this.#lastSavedContentId = options.saved ? this.#contentId : null;
    this.#historyItems = options.historyItems ?? 200;
    this.#historyBytes = options.historyBytes ?? 64 * 1024 * 1024;
    assert(Number.isSafeInteger(this.#historyItems) && this.#historyItems >= 1 && this.#historyItems <= 1e5 && Number.isSafeInteger(this.#historyBytes) && this.#historyBytes > 0, "invalid", "Invalid history budget");
    this.#capabilities = freezeData(cloneData(options.capabilities ?? EDITABLE_CAPABILITIES));
    this.#validateCapabilities(this.#capabilities);
  }
  #validateCapabilities(capabilities) {
    assertPlainData(capabilities);
    assert(typeof capabilities.canEdit === "boolean" && Array.isArray(capabilities.allowedFeatures) && capabilities.allowedFeatures.every((id) => typeof id === "string" && /^[A-Z]+-\d+$/.test(id)) && Array.isArray(capabilities.diagnostics), "invalid", "Invalid session capabilities");
  }
  #assertOpen() {
    assert(!this.#closed, "conflict", "Document session is closed");
  }
  #assertEditable(featureId) {
    this.#assertOpen();
    assert(this.#capabilities.canEdit && this.#capabilities.allowedFeatures.includes(featureId), "unsupported", "This document does not allow that edit");
  }
  get documentId() {
    return this.#document.documentId;
  }
  get revision() {
    return this.#revision;
  }
  get contentId() {
    return this.#contentId;
  }
  get lastSavedContentId() {
    return this.#lastSavedContentId;
  }
  get dirty() {
    return this.#contentId !== this.#lastSavedContentId;
  }
  get canUndo() {
    return this.#past.length > 0 && this.#capabilities.canEdit && !this.#closed;
  }
  get canRedo() {
    return this.#future.length > 0 && this.#capabilities.canEdit && !this.#closed;
  }
  get saveState() {
    return this.#activeSave ? "saving" : "idle";
  }
  get capabilities() {
    return this.#capabilities;
  }
  get historyUsage() {
    const all = [...this.#past, ...this.#future];
    return { items: all.length, bytes: all.reduce((total, entry) => total + entry.bytes, 0) };
  }
  snapshot() {
    this.#assertOpen();
    return Object.freeze({ document: this.#document, revision: this.#revision, contentId: this.#contentId });
  }
  setCapabilities(capabilities) {
    this.#assertOpen();
    this.#validateCapabilities(capabilities);
    this.#capabilities = freezeData(cloneData(capabilities));
  }
  #result(changed, operations = [], inverse = []) {
    return freezeData({ changed, revision: this.#revision, contentId: this.#contentId, dirty: this.dirty, changedPaths: operations.map((operation) => [...operation.path]), inverse: cloneData(inverse) });
  }
  execute(command) {
    this.#assertOpen();
    assertPlainData(command);
    assert(isRecord(command) && Object.keys(command).length === 4 && command.documentId === this.documentId && command.expectedRevision === this.#revision, "conflict", "Command targets a stale or different document");
    assert(isRecord(command.payload), "invalid", "Invalid command payload");
    let featureId;
    let operations;
    if (command.type === "document.rename") {
      assert(Object.keys(command.payload).length === 1 && typeof command.payload.title === "string", "invalid", "Invalid rename command");
      featureId = "MOD-03";
      operations = [{ op: "set", path: ["title"], value: command.payload.title }];
    } else {
      assert(command.type === "model.patch" && Object.keys(command.payload).length === 2 && typeof command.payload.featureId === "string" && Array.isArray(command.payload.operations), "invalid", "Unknown command or invalid patch payload");
      featureId = command.payload.featureId;
      operations = command.payload.operations;
      assert(operations.length <= 1e4, "limit", "Command operation budget exceeded");
    }
    this.#assertEditable(featureId);
    const permittedRoots = { "MOD-01": ["resources", "styles", "defaultTextStyle"], "MOD-03": ["title"], "WRT-02": ["sections"], "WRT-03": ["sections", "resources"], "SHT-02": ["sheets", "dateSystem"], "SLD-02": ["slides", "size"] };
    const requiredKind = { "WRT-02": "writer", "WRT-03": "writer", "SHT-02": "sheets", "SLD-02": "slides" };
    assert(!requiredKind[featureId] || requiredKind[featureId] === this.#document.kind, "invalid", "Command feature does not match document kind");
    const newImages = /* @__PURE__ */ new Set();
    for (const operation of operations) {
      assertOperation(operation);
      assert(permittedRoots[featureId]?.includes(String(operation.path[0])), "unsupported", "Feature cannot modify that model region");
      if (featureId === "WRT-02") assert(operation.op === "set" && operation.path.length === 3 && operation.path[0] === "sections" && typeof operation.path[1] === "number" && operation.path[2] === "page", "unsupported", "Page command can only replace section page geometry");
      if (featureId === "WRT-03" && operation.path[0] === "resources") {
        assert(operation.op === "set" && operation.path.length === 2 && typeof operation.path[1] === "string", "unsupported", "Writer may only add an immutable image resource");
        validateImageResource(operation.value);
        const id = operation.path[1];
        assert(id === operation.value.id && !Object.hasOwn(this.#document.resources, id) && !newImages.has(id), "conflict", "Cannot replace an existing resource");
        newImages.add(id);
      }
    }
    const batch = applyBatch(this.#document, operations);
    if (batch.forward.length === 0) return this.#result(false);
    const bytes = new TextEncoder().encode(JSON.stringify([batch.forward, batch.inverse])).byteLength;
    assert(bytes <= this.#historyBytes, "limit", "Edit exceeds the undo history budget");
    const after = `${this.documentId}:content:${this.#contentCounter + 1}`;
    const entry = freezeData({ forward: batch.forward, inverse: batch.inverse, before: this.#contentId, after, bytes, featureId });
    this.#document = freezeData(batch.document);
    this.#revision++;
    this.#contentCounter++;
    this.#contentId = after;
    this.#future = [];
    this.#past.push(entry);
    while (this.#past.length > this.#historyItems || this.historyUsage.bytes > this.#historyBytes) this.#past.shift();
    return this.#result(true, batch.forward, batch.inverse);
  }
  undo(expectedRevision = this.#revision) {
    this.#assertOpen();
    assert(this.#capabilities.canEdit, "unsupported", "Read-only document");
    assert(expectedRevision === this.#revision, "conflict", "Stale undo request");
    const entry = this.#past[this.#past.length - 1];
    if (!entry) return this.#result(false);
    this.#assertEditable(entry.featureId);
    const batch = applyBatch(this.#document, entry.inverse);
    this.#document = freezeData(batch.document);
    this.#past.pop();
    this.#future.push(entry);
    this.#revision++;
    this.#contentId = entry.before;
    return this.#result(true, entry.inverse, entry.forward);
  }
  redo(expectedRevision = this.#revision) {
    this.#assertOpen();
    assert(this.#capabilities.canEdit, "unsupported", "Read-only document");
    assert(expectedRevision === this.#revision, "conflict", "Stale redo request");
    const entry = this.#future[this.#future.length - 1];
    if (!entry) return this.#result(false);
    this.#assertEditable(entry.featureId);
    const batch = applyBatch(this.#document, entry.forward);
    this.#document = freezeData(batch.document);
    this.#future.pop();
    this.#past.push(entry);
    this.#revision++;
    this.#contentId = entry.after;
    return this.#result(true, entry.forward, entry.inverse);
  }
  beginSave() {
    this.#assertOpen();
    assert(!this.#activeSave, "conflict", "A save is already in progress");
    const ticket = Object.freeze({ ...this.snapshot(), id: `${this.documentId}:save:${++this.#saveCounter}`, documentId: this.documentId });
    this.#activeSave = ticket;
    return ticket;
  }
  completeSave(ticket) {
    this.#assertOpen();
    assert(this.#activeSave === ticket, "conflict", "Save ticket is stale or belongs to another session");
    this.#lastSavedContentId = ticket.contentId;
    this.#activeSave = void 0;
  }
  cancelSave(ticket) {
    this.#assertOpen();
    assert(this.#activeSave === ticket, "conflict", "Save ticket is stale");
    this.#activeSave = void 0;
  }
  close() {
    this.#closed = true;
    this.#activeSave = void 0;
    this.#past = [];
    this.#future = [];
  }
};
function patchCommand(snapshot, featureId, operations) {
  assertId(snapshot.document.documentId);
  return { documentId: snapshot.document.documentId, expectedRevision: snapshot.revision, type: "model.patch", payload: { featureId, operations } };
}

// packages/sheets/src/intl-cache.ts
var formatters = /* @__PURE__ */ new Map();
var limit = 128;
function cached(key, create) {
  const existing = formatters.get(key);
  if (existing) {
    formatters.delete(key);
    formatters.set(key, existing);
    return existing;
  }
  const formatter = create();
  if (formatters.size >= limit) formatters.delete(formatters.keys().next().value);
  formatters.set(key, formatter);
  return formatter;
}
function numberFormatter(locale, options = {}) {
  return cached(`number:${locale}:${JSON.stringify(options)}`, () => new Intl.NumberFormat(locale, options));
}
function dateFormatter(locale, options) {
  return cached(`date:${locale}:${JSON.stringify(options)}`, () => new Intl.DateTimeFormat(locale, options));
}

// packages/sheets/src/formula.ts
var SUPPORTED_FUNCTIONS = Object.freeze(["SUM", "AVERAGE", "MIN", "MAX", "COUNT", "COUNTA", "IF", "AND", "OR", "NOT", "ROUND", "ABS"]);
var functions = new Set(SUPPORTED_FUNCTIONS);
function isSupportedFunction(name) {
  return functions.has(name.toUpperCase());
}
var FORMULA_ALIASES = Object.freeze({
  de: Object.freeze({ SUMME: "SUM", MITTELWERT: "AVERAGE", ANZAHL: "COUNT", ANZAHL2: "COUNTA", WENN: "IF", UND: "AND", ODER: "OR", NICHT: "NOT", RUNDEN: "ROUND" }),
  fr: Object.freeze({ SOMME: "SUM", MOYENNE: "AVERAGE", NB: "COUNT", NBVAL: "COUNTA", SI: "IF", ET: "AND", OU: "OR", NON: "NOT", ARRONDI: "ROUND" })
});
function columnName(column) {
  assertCellAddress(1, column);
  let text2 = "";
  for (let current = column; current; current = Math.floor((current - 1) / 26)) text2 = String.fromCharCode(65 + (current - 1) % 26) + text2;
  return text2;
}
function columnNumber(name) {
  assert(/^[A-Za-z]{1,3}$/.test(name), "invalid", "Invalid column label");
  let result = 0;
  for (const ch of name.toUpperCase()) result = result * 26 + ch.charCodeAt(0) - 64;
  assertCellAddress(1, result);
  return result;
}
var separatorsCache = /* @__PURE__ */ new Map();
function formulaSeparators(locale) {
  const found = separatorsCache.get(locale);
  if (found) return found;
  const decimal = numberFormatter(locale, { useGrouping: false }).formatToParts(1.1).find((p) => p.type === "decimal")?.value ?? ".";
  const result = Object.freeze({ decimal, argument: decimal === "," ? ";" : "," });
  if (separatorsCache.size >= 128) separatorsCache.delete(separatorsCache.keys().next().value);
  separatorsCache.set(locale, result);
  return result;
}
var errorPattern = /^(?:#NULL!|#DIV\/0!|#VALUE!|#REF!|#NAME\?|#NUM!|#N\/A)/i;
function lex(source, options) {
  assert(source.startsWith("=") && source.length > 1 && source.length <= 8192, "invalid", "Invalid formula length or prefix");
  const separators = options.mode === "regional" ? formulaSeparators(options.locale ?? "en-US") : { decimal: ".", argument: "," };
  const tokens = [];
  const max = options.maxTokens ?? 8192;
  assert(Number.isInteger(max) && max > 0 && max <= 32768, "invalid", "Invalid token budget");
  const push = (kind, text2) => {
    assert(tokens.length < max, "limit", "Formula token budget exceeded");
    tokens.push({ kind, text: text2 });
  };
  for (let index = 1; index < source.length; ) {
    options.cancellation?.throwIfCancelled();
    const ch = source[index];
    if (/\s/u.test(ch)) {
      index++;
      continue;
    }
    if (ch === '"' || ch === "'") {
      const quote = ch;
      index++;
      let text2 = "";
      let closed = false;
      while (index < source.length) {
        const c = source[index++];
        if (c === quote) {
          if (source[index] === quote) {
            text2 += quote;
            index++;
          } else {
            closed = true;
            break;
          }
        } else text2 += c;
      }
      assert(closed, "invalid", "Unterminated formula literal");
      push(quote === '"' ? "string" : "quoted", text2);
      continue;
    }
    if (ch === "#") {
      const match = errorPattern.exec(source.slice(index));
      assert(match, "unsupported", "Unsupported error or spilled reference");
      push("error", match[0].toUpperCase());
      index += match[0].length;
      continue;
    }
    if (/[0-9]/.test(ch) || ch === separators.decimal && /[0-9]/.test(source[index + 1] ?? "")) {
      const start = index;
      let decimal = false;
      while (index < source.length && (/[0-9]/.test(source[index]) || !decimal && source[index] === separators.decimal)) {
        if (source[index] === separators.decimal) decimal = true;
        index++;
      }
      if (/[Ee]/.test(source[index] ?? "") && /^[Ee][+-]?\d/.test(source.slice(index))) {
        index++;
        if (/[+-]/.test(source[index] ?? "")) index++;
        while (/\d/.test(source[index] ?? "")) index++;
      }
      const text2 = source.slice(start, index).replace(separators.decimal, ".");
      assert(Number.isFinite(Number(text2)), "invalid", "Non-finite formula literal");
      push("number", text2);
      continue;
    }
    if (/[\p{L}_$\\]/u.test(ch)) {
      const start = index++;
      while (index < source.length && /[\p{L}\p{N}_.$\\]/u.test(source[index])) index++;
      push("word", source.slice(start, index));
      continue;
    }
    const pair = source.slice(index, index + 2);
    if (["<>", "<=", ">="].includes(pair)) {
      push("symbol", pair);
      index += 2;
      continue;
    }
    if (ch === separators.argument) {
      push("symbol", ",");
      index++;
      continue;
    }
    assert("+-*/^&=<>%():!".includes(ch), "unsupported", "Unsupported formula syntax");
    push("symbol", ch);
    index++;
  }
  tokens.push({ kind: "end", text: "" });
  return tokens;
}
var precedence = { "=": 1, "<>": 1, "<": 1, ">": 1, "<=": 1, ">=": 1, "&": 2, "+": 3, "-": 3, "*": 4, "/": 4, "^": 5 };
function parseFormula(source, options = {}) {
  const tokens = lex(source, options);
  let cursor = 0;
  const maxDepth = options.maxDepth ?? 128;
  assert(Number.isInteger(maxDepth) && maxDepth >= 1 && maxDepth <= 256, "invalid", "Invalid formula depth budget");
  const peek = () => tokens[cursor];
  const take = () => tokens[cursor++];
  const expect = (text2) => {
    assert(take().text === text2, "invalid", "Unexpected formula token");
  };
  const reference = (token, sheet) => {
    const match = /^(\$?)([A-Za-z]{1,3})(\$?)([1-9]\d*)$/.exec(token.text);
    if (!match) return void 0;
    const row = Number(match[4]), column = columnNumber(match[2]);
    assertCellAddress(row, column);
    return { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row, column, rowAbsolute: !!match[3], columnAbsolute: !!match[1] };
  };
  const parseReference = (first, sheet) => {
    const start = reference(first, sheet);
    if (start) {
      if (peek().text !== ":") return start;
      take();
      let endToken2 = take();
      let endSheet = sheet;
      if (peek().text === "!") {
        assert(endToken2.kind === "word" || endToken2.kind === "quoted", "invalid", "Invalid range sheet");
        endSheet = endToken2.text;
        take();
        endToken2 = take();
      }
      const end = reference(endToken2, endSheet);
      assert(end, "unsupported", "Unsupported range endpoint");
      assert((end.sheet ?? sheet) === sheet, "unsupported", "Three-dimensional range is unsupported");
      return { kind: "range", start, end };
    }
    if (peek().text !== ":") return void 0;
    const col = /^(\$?)([A-Za-z]{1,3})$/.exec(first.text), row = /^(\$?)([1-9]\d*)$/.exec(first.text);
    assert(col || row, "unsupported", "Unsupported reference range");
    take();
    const endToken = take();
    if (col) {
      const other2 = /^(\$?)([A-Za-z]{1,3})$/.exec(endToken.text);
      assert(other2, "invalid", "Invalid whole column range");
      return { kind: "range", axis: "columns", start: { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row: 1, column: columnNumber(col[2]), rowAbsolute: false, columnAbsolute: !!col[1] }, end: { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row: 1048576, column: columnNumber(other2[2]), rowAbsolute: false, columnAbsolute: !!other2[1] } };
    }
    const other = /^(\$?)([1-9]\d*)$/.exec(endToken.text);
    assert(other, "invalid", "Invalid whole row range");
    const firstRow = Number(row[2]), lastRow = Number(other[2]);
    assertCellAddress(firstRow, 1);
    assertCellAddress(lastRow, 1);
    return { kind: "range", axis: "rows", start: { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row: firstRow, column: 1, rowAbsolute: !!row[1], columnAbsolute: false }, end: { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row: lastRow, column: 16384, rowAbsolute: !!other[1], columnAbsolute: false } };
  };
  const primary = (depth) => {
    assert(depth <= maxDepth, "limit", "Formula AST depth exceeded");
    options.cancellation?.throwIfCancelled();
    const token = take();
    if (token.text === "+" || token.text === "-") return { kind: "unary", operator: token.text, operand: primary(depth + 1) };
    if (token.text === "(") {
      const value = expression(1, depth + 1);
      expect(")");
      return value;
    }
    if (token.kind === "string") return { kind: "string", value: token.text };
    if (token.kind === "error") return { kind: "error", value: token.text };
    if ((token.kind === "word" || token.kind === "quoted") && peek().text === "!") {
      take();
      const ref2 = parseReference(take(), token.text);
      assert(ref2, "unsupported", "Only cell and range sheet references are supported");
      return ref2;
    }
    if (token.kind === "word" && peek().text === "(") {
      take();
      const args = [];
      if (peek().text !== ")") {
        while (true) {
          assert(args.length < 255, "limit", "Function argument budget exceeded");
          args.push(peek().text === "," || peek().text === ")" ? { kind: "missing" } : expression(1, depth + 1));
          if (peek().text !== ",") break;
          take();
        }
      }
      expect(")");
      const upper = token.text.toUpperCase();
      const name = options.mode === "regional" ? FORMULA_ALIASES[(options.locale ?? "en-US").split("-")[0]]?.[upper] ?? upper : upper;
      return { kind: "call", name, args };
    }
    const ref = parseReference(token);
    if (ref) return ref;
    if (token.kind === "number") return { kind: "number", value: Number(token.text) };
    if (token.kind === "word" && /^(TRUE|FALSE)$/i.test(token.text)) return { kind: "boolean", value: token.text.toUpperCase() === "TRUE" };
    throw new OfficeError("unsupported", "Unsupported named reference or formula token");
  };
  const expression = (minimum, depth) => {
    assert(depth <= maxDepth, "limit", "Formula AST depth exceeded");
    let left = primary(depth);
    while (peek().text === "%") {
      take();
      left = { kind: "unary", operator: "%", operand: left };
    }
    while (peek().kind === "symbol" && (precedence[peek().text] ?? 0) >= minimum) {
      const operator = take().text;
      const right = expression(precedence[operator] + 1, depth + 1);
      left = { kind: "binary", operator, left, right };
    }
    return left;
  };
  const ast = expression(1, 1);
  assert(peek().kind === "end", "unsupported", "Unsupported trailing formula syntax");
  walkFormula(ast, () => {
  }, maxDepth);
  return ast;
}
function walkFormula(ast, visit, maxDepth = 128) {
  const stack = [{ node: ast, depth: 1 }];
  let count = 0;
  while (stack.length) {
    const { node, depth } = stack.pop();
    assert(depth <= maxDepth && ++count <= 8192, "limit", "Formula AST budget exceeded");
    visit(node);
    if (node.kind === "binary") stack.push({ node: node.right, depth: depth + 1 }, { node: node.left, depth: depth + 1 });
    else if (node.kind === "unary") stack.push({ node: node.operand, depth: depth + 1 });
    else if (node.kind === "call") for (let i = node.args.length - 1; i >= 0; i--) stack.push({ node: node.args[i], depth: depth + 1 });
  }
}
function formulaIsSupported(ast) {
  let supported = true;
  walkFormula(ast, (n) => {
    if (n.kind === "call" && !isSupportedFunction(n.name)) supported = false;
  });
  return supported;
}
function refText(ref, includeSheet = true) {
  return `${includeSheet && ref.sheet !== void 0 ? `'${ref.sheet.replaceAll("'", "''")}'!` : ""}${ref.columnAbsolute ? "$" : ""}${columnName(ref.column)}${ref.rowAbsolute ? "$" : ""}${ref.row}`;
}
function serializeFormula(ast) {
  walkFormula(ast, () => {
  });
  const part = (node) => {
    switch (node.kind) {
      case "number":
        assert(Number.isFinite(node.value), "invalid", "Invalid formula number");
        return String(node.value);
      case "string":
        return `"${node.value.replaceAll('"', '""')}"`;
      case "boolean":
        return node.value ? "TRUE" : "FALSE";
      case "error":
        return node.value;
      case "missing":
        return "";
      case "reference":
        return refText(node);
      case "range": {
        const prefix = node.start.sheet === void 0 ? "" : `'${node.start.sheet.replaceAll("'", "''")}'!`;
        if (node.axis === "columns") return `${prefix}${node.start.columnAbsolute ? "$" : ""}${columnName(node.start.column)}:${node.end.columnAbsolute ? "$" : ""}${columnName(node.end.column)}`;
        if (node.axis === "rows") return `${prefix}${node.start.rowAbsolute ? "$" : ""}${node.start.row}:${node.end.rowAbsolute ? "$" : ""}${node.end.row}`;
        return `${refText(node.start)}:${refText(node.end, node.end.sheet !== node.start.sheet)}`;
      }
      case "unary":
        return node.operator === "%" ? `(${part(node.operand)})%` : `${node.operator}(${part(node.operand)})`;
      case "binary":
        return `(${part(node.left)}${node.operator}${part(node.right)})`;
      case "call":
        return `${node.name.toUpperCase()}(${node.args.map(part).join(",")})`;
    }
  };
  const source = `=${part(ast)}`;
  assert(source.length <= 8192, "limit", "Serialized formula exceeds length limit");
  return source;
}
function localizeFormula(source, locale) {
  const ast = parseFormula(source);
  const aliases = FORMULA_ALIASES[locale.split("-")[0]] ?? {};
  walkFormula(ast, (n) => {
    if (n.kind === "call") n.name = Object.entries(aliases).find(([, canonical3]) => canonical3 === n.name)?.[0] ?? n.name;
  });
  const canonical2 = serializeFormula(ast), separators = formulaSeparators(locale);
  let out = "", quoted = "";
  for (let i = 0; i < canonical2.length; i++) {
    const ch = canonical2[i];
    if (quoted) {
      out += ch;
      if (ch === quoted) {
        if (canonical2[i + 1] === quoted) out += canonical2[++i];
        else quoted = "";
      }
    } else if (ch === '"' || ch === "'") {
      quoted = ch;
      out += ch;
    } else if (ch === ",") out += separators.argument;
    else if (ch === "." && /\d/.test(canonical2[i - 1] ?? "") && /\d/.test(canonical2[i + 1] ?? "")) out += separators.decimal;
    else out += ch;
  }
  return out;
}

// packages/sheets/src/calculation.ts
function calculationKey(sheetId, row, column) {
  return `${sheetId}!${row}:${column}`;
}
var blank = Object.freeze({ kind: "blank" });

// packages/sheets/src/formatting.ts
var dayMilliseconds = 864e5;
function utcDate(year, month, day) {
  const date = /* @__PURE__ */ new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  date.setUTCHours(0, 0, 0, 0);
  return date;
}
function dateToSerial(year, month, day, dateSystem = "1900") {
  assert([year, month, day].every(Number.isInteger) && year >= 1 && year <= 9999 && month >= 1 && month <= 12 && day >= 1 && day <= 31, "invalid", "Invalid calendar date");
  if (dateSystem === "1900" && year === 1900 && month === 2 && day === 29) return 60;
  const date = utcDate(year, month, day);
  assert(date.getUTCFullYear() === year && date.getUTCMonth() + 1 === month && date.getUTCDate() === day, "invalid", "Invalid calendar date");
  if (dateSystem === "1904") return (date.getTime() - utcDate(1904, 1, 1).getTime()) / dayMilliseconds;
  const serial = (date.getTime() - utcDate(1899, 12, 31).getTime()) / dayMilliseconds;
  return serial >= 60 ? serial + 1 : serial;
}
function serialToDate(serial, dateSystem = "1900") {
  assert(Number.isFinite(serial) && serial >= 0 && serial <= (dateSystem === "1904" ? 295700399999999e-8 : 295846599999999e-8), "invalid", "Excel date is outside supported display range");
  let whole = Math.floor(serial), ms = Math.round((serial - whole) * dayMilliseconds);
  if (ms === dayMilliseconds) {
    whole++;
    ms = 0;
  }
  const fictitiousLeapDay = dateSystem === "1900" && whole === 60;
  const date = dateSystem === "1904" ? new Date(utcDate(1904, 1, 1).getTime() + whole * dayMilliseconds) : new Date(utcDate(1899, 12, 31).getTime() + (whole > 60 ? whole - 1 : fictitiousLeapDay ? 59 : whole) * dayMilliseconds);
  return { year: date.getUTCFullYear(), month: date.getUTCMonth() + 1, day: fictitiousLeapDay ? 29 : date.getUTCDate(), hour: Math.floor(ms / 36e5), minute: Math.floor(ms / 6e4) % 60, second: Math.floor(ms / 1e3) % 60, millisecond: ms % 1e3, fictitiousLeapDay };
}
var numericRegions = /* @__PURE__ */ new Map();
function numericRegion(locale) {
  const found = numericRegions.get(locale);
  if (found) return found;
  const parts = numberFormatter(locale).formatToParts(123456789e-2);
  const data = { decimal: formulaSeparators(locale).decimal, group: parts.find((p) => p.type === "group")?.value, digits: new Map(Array.from({ length: 10 }, (_, d) => [numberFormatter(locale, { useGrouping: false }).format(d), String(d)])) };
  if (numericRegions.size >= 128) numericRegions.delete(numericRegions.keys().next().value);
  numericRegions.set(locale, data);
  return data;
}
function numericInput(text2, options) {
  let normalized = text2, percent = false;
  if (normalized.endsWith("%")) {
    percent = true;
    normalized = normalized.slice(0, -1).trim();
  }
  if (options.mode === "regional") {
    const locale = options.locale ?? "en-US", { decimal, group, digits } = numericRegion(locale);
    normalized = [...normalized].map((c) => digits.get(c) ?? c).join("");
    if (group && normalized.includes(group)) {
      const sign = /^[+-]/.test(normalized) ? normalized[0] : "", unsigned = sign ? normalized.slice(1) : normalized;
      const chunks = unsigned.split(decimal);
      if (chunks.length > 2 || chunks[1]?.includes(group)) return void 0;
      const integer2 = chunks[0], raw = integer2.split(group).join("");
      if (!/^\d+$/.test(raw)) return void 0;
      const canonical2 = numberFormatter(locale, { maximumFractionDigits: 0 }).format(Number(raw));
      const mapped = [...canonical2].map((c) => digits.get(c) ?? c).join("");
      if (mapped !== integer2) return void 0;
      normalized = sign + raw + (chunks[1] !== void 0 ? "." + chunks[1] : "");
    } else if (decimal !== ".") {
      if (normalized.includes(".")) return void 0;
      normalized = normalized.replace(decimal, ".");
    }
  }
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(normalized)) return void 0;
  const value = Number(normalized) / (percent ? 100 : 1);
  assert(Number.isFinite(value), "invalid", "Numeric input is outside binary64 range");
  return value;
}
function parseCellInput(input, options = {}) {
  assert(input.length <= 32767, "limit", "Cell text length exceeded");
  if (options.type === "text" || input.startsWith("'")) return { kind: "string", value: input.startsWith("'") && options.type !== "text" ? input.slice(1) : input };
  const text2 = input.trim();
  if (text2 === "") return input === "" ? { kind: "blank" } : { kind: "string", value: input };
  if (text2.startsWith("=")) {
    const ast = parseFormula(text2, options);
    return { kind: "formula", source: options.mode === "regional" ? serializeFormula(ast) : text2 };
  }
  if (options.type === "date") {
    const date = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/.exec(text2);
    assert(date, "invalid", "Use unambiguous ISO date input");
    const hour = Number(date[4] ?? 0), minute = Number(date[5] ?? 0), second = Number(date[6] ?? 0);
    assert(hour <= 23 && minute <= 59 && second <= 59, "invalid", "Invalid date time");
    return { kind: "number", value: dateToSerial(Number(date[1]), Number(date[2]), Number(date[3]), options.dateSystem) + (hour * 3600 + minute * 60 + second) / 86400 };
  }
  const value = numericInput(text2, options);
  if (value !== void 0) return { kind: "number", value };
  assert(options.type !== "number", "invalid", "Ambiguous or invalid regional number");
  if (/^(TRUE|FALSE)$/i.test(text2)) return { kind: "boolean", value: text2.toUpperCase() === "TRUE" };
  if (/^(#NULL!|#DIV\/0!|#VALUE!|#REF!|#NAME\?|#NUM!|#N\/A)$/i.test(text2)) return { kind: "error", value: text2.toUpperCase() };
  return { kind: "string", value: input };
}
function cellFromInput(input, options = {}, before) {
  const value = parseCellInput(input, options);
  const numberFormat = options.type === "date" ? /[ T]\d\d:/.test(input) ? "yyyy-mm-dd hh:mm:ss" : "yyyy-mm-dd" : value.kind === "number" && input.trim().endsWith("%") ? "0.00%" : before?.numberFormat;
  return { ...before, value, ...numberFormat !== void 0 ? { numberFormat } : {} };
}
function splitSections(code) {
  const sections = [];
  let text2 = "", quote = false, escaped = false;
  for (const ch of code) {
    if (escaped) {
      text2 += ch;
      escaped = false;
    } else if (ch === "\\") {
      text2 += ch;
      escaped = true;
    } else if (ch === '"') {
      quote = !quote;
      text2 += ch;
    } else if (ch === ";" && !quote) {
      sections.push(text2);
      text2 = "";
    } else text2 += ch;
  }
  sections.push(text2);
  return sections;
}
function unquoted(code) {
  return code.replace(/"(?:[^"]|"")*"/g, "").replace(/\\./g, "").replace(/\[[^\]]*\]/g, "");
}
function literal(code) {
  return code.replace(/\[\$([^\]\-]+)(?:-[0-9a-f]+)?\]/gi, "$1").replace(/"([^"]*)"/g, "$1").replace(/\\(.)/g, "$1").replace(/_.|\*./g, "").replace(/\[[^\]]*\]/g, "");
}
function isSupportedNumberFormat(format = "General") {
  if (format === "General" || format === "@") return true;
  const clean = unquoted(format);
  if ((clean.match(/\.[0#]+/g) ?? []).some((part) => part.length > 21)) return false;
  if (/\[(?:[<>=][^\]]*|[hms]+)\]/i.test(format) || /\?/.test(clean)) return false;
  if (/[ymdhs]/i.test(clean)) return !/[^ymdhsapm0:/ .,+\-()]/i.test(clean);
  return !/[^0#.,%Ee+\-();$€£¥₹₩₽@ ]/.test(clean);
}
function formatDate(serial, code, options) {
  if (serial < 0 || serial > (options.dateSystem === "1904" ? 295700399999999e-8 : 295846599999999e-8)) return "########";
  const date = serialToDate(serial, options.dateSystem), locale = options.locale ?? "en-US", native = utcDate(date.year, date.month, date.fictitiousLeapDay ? 28 : date.day), hasPeriod = /AM\/PM/i.test(code);
  const pad = (n, count = 2) => numberFormatter(locale, { useGrouping: false, minimumIntegerDigits: count, maximumFractionDigits: 0 }).format(n);
  const tokens = code.match(/"[^"]*"|\\.|AM\/PM|yyyy|yy|mmmm|mmm|mm|m|dddd|ddd|dd|d|hh|h|ss|s|\.0+|[^ymdhs]/gi) ?? [];
  return tokens.map((token, index) => {
    if (token.startsWith('"') || token.startsWith("\\")) return literal(token);
    const t = token.toLowerCase();
    if (t === "yyyy") return pad(date.year, 4);
    if (t === "yy") return pad(date.year % 100);
    if (t === "am/pm") return date.hour >= 12 ? "PM" : "AM";
    if (/^h{1,2}$/.test(t)) return pad(hasPeriod ? date.hour % 12 || 12 : date.hour, t.length);
    if (/^s{1,2}$/.test(t)) return pad(date.second, t.length);
    if (/^d{1,2}$/.test(t)) return pad(date.day, t.length);
    if (t === "ddd" || t === "dddd") return dateFormatter(locale, { weekday: t === "ddd" ? "short" : "long", timeZone: "UTC", calendar: "gregory" }).format(native);
    if (t === "mmm" || t === "mmmm") return dateFormatter(locale, { month: t === "mmm" ? "short" : "long", timeZone: "UTC", calendar: "gregory" }).format(native);
    if (/^m{1,2}$/.test(t)) {
      const before = tokens.slice(0, index).filter((s) => /[a-z]/i.test(s)).at(-1) ?? "", after = tokens.slice(index + 1).find((s) => /[a-z]/i.test(s)) ?? "";
      const minutes = /^h/i.test(before) || /^s/i.test(after);
      return pad(minutes ? date.minute : date.month, t.length);
    }
    if (/^\.0+$/.test(t)) return formulaSeparators(locale).decimal + pad(date.millisecond, 3).slice(0, t.length - 1).padEnd(t.length - 1, "0");
    return token;
  }).join("");
}
function formatCellValue(value, numberFormat = "General", options = {}) {
  if (value.kind === "blank") return "";
  if (value.kind === "string") {
    const sections2 = splitSections(numberFormat);
    return sections2.length > 3 ? literal(sections2[3] ?? "").replace(/@/g, () => value.value) : value.value;
  }
  if (value.kind === "boolean") return value.value ? "TRUE" : "FALSE";
  if (value.kind === "error") return value.value;
  const locale = options.locale ?? "en-US", n = value.value;
  if (numberFormat === "General" || numberFormat === "@" || !isSupportedNumberFormat(numberFormat)) return numberFormatter(locale, { maximumSignificantDigits: 15, useGrouping: false }).format(n);
  const sections = splitSections(numberFormat);
  let code = sections[n < 0 && sections.length > 1 ? 1 : n === 0 && sections.length > 2 ? 2 : 0] ?? "";
  code = code.replace(/\[(?:Black|Blue|Cyan|Green|Magenta|Red|White|Yellow|Color\d+)\]/gi, "");
  if (/[ymdhs]/i.test(unquoted(code))) return formatDate(n, code, options);
  const tokens = code.match(/"[^"]*"|\[[^\]]*\]|\\.|[^]/g) ?? [];
  const isPlaceholder = (token) => /^[0#]$/.test(token);
  const first = tokens.findIndex(isPlaceholder);
  let last = tokens.length - 1;
  while (last >= 0 && !isPlaceholder(tokens[last])) last--;
  if (first < 0) return literal(code);
  let tail = last + 1, scale = 0;
  while (tokens[tail] === ",") {
    scale++;
    tail++;
  }
  const body = tokens.slice(first, last + 1).join(""), percentCount = (unquoted(code).match(/%/g) ?? []).length;
  const magnitude = Math.abs(n) * 100 ** percentCount / 1e3 ** scale;
  if (!Number.isFinite(magnitude)) return "########";
  const decimalPart = body.split(".")[1]?.split(/[Ee]/)[0] ?? "", minimumFractionDigits = (decimalPart.match(/0/g) ?? []).length, maximumFractionDigits = (decimalPart.match(/[0#]/g) ?? []).length;
  assert(maximumFractionDigits <= 20, "unsupported", "Number format precision exceeds display budget");
  let formatted;
  if (/[Ee][+-]?0+/.test(body)) {
    const [coefficient, exponent] = magnitude.toExponential(maximumFractionDigits).split("e");
    const sign = Number(exponent) >= 0 ? "+" : "-", exponentDigits = body.split(/[Ee][+-]?/)[1]?.length ?? 2;
    formatted = numberFormatter(locale, { minimumFractionDigits, maximumFractionDigits, useGrouping: false }).format(Number(coefficient)) + "E" + sign + String(Math.abs(Number(exponent))).padStart(exponentDigits, "0");
  } else formatted = numberFormatter(locale, { minimumFractionDigits, maximumFractionDigits, minimumIntegerDigits: Math.max(1, Math.min(21, (body.split(".")[0].replaceAll(",", "").match(/0/g) ?? []).length)), useGrouping: body.split(".")[0].includes(",") }).format(magnitude);
  const negative = n < 0 && sections.length < 2 ? "-" : "";
  return negative + literal(tokens.slice(0, first).join("")) + formatted + literal(tokens.slice(tail).join(""));
}
function formatCell(cell, calculation, options = {}) {
  if (!cell) return "";
  if (cell.value.kind !== "formula") return formatCellValue(cell.value, cell.numberFormat, options);
  return calculation?.value ? formatCellValue(calculation.value, cell.numberFormat, options) : cell.value.source;
}

// packages/sheets/src/commands.ts
function cellKey(row, column) {
  assertCellAddress(row, column);
  return `${row}:${column}`;
}
function assertCellRange(range, maxCells = Number.MAX_SAFE_INTEGER) {
  assertCellAddress(range.row, range.column);
  assert(Number.isSafeInteger(range.rowCount) && range.rowCount > 0 && Number.isSafeInteger(range.columnCount) && range.columnCount > 0, "invalid", "Invalid cell range");
  assertCellAddress(range.row + range.rowCount - 1, range.column + range.columnCount - 1);
  assert(range.rowCount * range.columnCount <= maxCells, "limit", "Selected cell operation exceeds budget");
}
var inside = (range, row, column) => row >= range.row && row < range.row + range.rowCount && column >= range.column && column < range.column + range.columnCount;
var overlap = (a, b) => a.row < b.row + b.rowCount && b.row < a.row + a.rowCount && a.column < b.column + b.columnCount && b.column < a.column + a.columnCount;
var contains = (a, b) => inside(a, b.row, b.column) && inside(a, b.row + b.rowCount - 1, b.column + b.columnCount - 1);
function book(snapshot) {
  assert(snapshot.document.kind === "sheets", "invalid", "Expected sheets document");
  return snapshot.document;
}
function sheetIndex(snapshot, id) {
  const index = book(snapshot).sheets.findIndex((s) => s.id === id);
  assert(index >= 0, "invalid", "Sheet does not exist");
  return index;
}
function edit(snapshot, operations) {
  return patchCommand(snapshot, "SHT-02", operations);
}
function cellsCommand(snapshot, index, cells) {
  return edit(snapshot, [{ op: "set", path: ["sheets", index, "cells"], value: cells }]);
}
function assertEditableCoordinate(sheet, row, column) {
  const merged = sheet.merges.find((m) => inside(m, row, column));
  assert(!merged || row === merged.row && column === merged.column, "unsupported", "Edit the merged cell anchor");
}
function setCells(snapshot, sheetId, edits) {
  assert(edits.length <= 1e5, "limit", "Cell edit budget exceeded");
  const index = sheetIndex(snapshot, sheetId), sheet = book(snapshot).sheets[index], keys = /* @__PURE__ */ new Set();
  if (edits.length <= 16) return edit(snapshot, edits.map((e) => {
    const key = cellKey(e.row, e.column);
    assert(!keys.has(key), "invalid", "Duplicate cell in edit batch");
    keys.add(key);
    assertEditableCoordinate(sheet, e.row, e.column);
    return e.cell === null ? { op: "delete", path: ["sheets", index, "cells", key] } : { op: "set", path: ["sheets", index, "cells", key], value: e.cell };
  }));
  const cells = { ...sheet.cells };
  for (const e of edits) {
    const key = cellKey(e.row, e.column);
    assert(!keys.has(key), "invalid", "Duplicate cell in edit batch");
    keys.add(key);
    assertEditableCoordinate(sheet, e.row, e.column);
    if (e.cell === null) delete cells[key];
    else cells[key] = e.cell;
  }
  return cellsCommand(snapshot, index, cells);
}
function checkedAst(source) {
  const ast = parseFormula(source);
  assert(formulaIsSupported(ast), "unsupported", "Unknown formulas prevent structural edits");
  return ast;
}
function transform(ast, ref, range) {
  if (ast.kind === "reference") return ref(ast);
  if (ast.kind === "range") {
    if (range) return range(ast);
    const a = ref(ast.start), b = ref(ast.end);
    return a.kind !== "reference" || b.kind !== "reference" ? { kind: "error", value: "#REF!" } : { ...ast, start: a, end: b };
  }
  if (ast.kind === "binary") return { ...ast, left: transform(ast.left, ref, range), right: transform(ast.right, ref, range) };
  if (ast.kind === "unary") return { ...ast, operand: transform(ast.operand, ref, range) };
  if (ast.kind === "call") return { ...ast, args: ast.args.map((a) => transform(a, ref, range)) };
  return ast;
}
function rewrite(sheets, apply) {
  return sheets.map((sheet) => {
    const cells = {};
    for (const [key, cell] of Object.entries(sheet.cells)) {
      if (cell.value.kind === "formula") {
        const ast = checkedAst(cell.value.source), after = apply(ast, sheet);
        const same = JSON.stringify(ast) === JSON.stringify(after);
        cells[key] = { ...cloneData(cell), value: { kind: "formula", source: same ? cell.value.source : serializeFormula(after) } };
      } else cells[key] = cloneData(cell);
    }
    return { ...cloneData(sheet), cells };
  });
}
function setSheets(snapshot, sheets) {
  return edit(snapshot, [{ op: "set", path: ["sheets"], value: sheets }]);
}
function renameSheet(snapshot, sheetId, name) {
  const index = sheetIndex(snapshot, sheetId), old = book(snapshot).sheets[index].name.toLowerCase();
  const sheets = rewrite(book(snapshot).sheets, (ast) => transform(ast, (r) => r.sheet?.toLowerCase() === old ? { ...r, sheet: name } : r));
  sheets[index].name = name;
  return setSheets(snapshot, sheets);
}
function addSheet(snapshot, name, id, index) {
  const document2 = book(snapshot);
  const sheets = rewrite(document2.sheets, (ast) => ast);
  let next = 1;
  while (sheets.some((s) => s.id === `sheet-${next}`)) next++;
  const identifier = id ?? `sheet-${next}`, target = index ?? sheets.length;
  assert(Number.isInteger(target) && target >= 0 && target <= sheets.length, "invalid", "Invalid sheet insertion index");
  assert(!sheets.some((s) => s.id === identifier), "invalid", "Duplicate sheet ID");
  sheets.splice(target, 0, { id: identifier, name, cells: {}, rows: {}, columns: {}, merges: [] });
  return setSheets(snapshot, sheets);
}
function deleteSheet(snapshot, sheetId) {
  const document2 = book(snapshot), index = sheetIndex(snapshot, sheetId);
  assert(document2.sheets.length > 1, "invalid", "A workbook must retain one sheet");
  const old = document2.sheets[index].name.toLowerCase();
  const sheets = rewrite(document2.sheets.filter((s) => s.id !== sheetId), (ast) => transform(ast, (r) => r.sheet?.toLowerCase() === old ? { kind: "error", value: "#REF!" } : r));
  return setSheets(snapshot, sheets);
}
function moveSheet(snapshot, sheetId, index) {
  const previous = sheetIndex(snapshot, sheetId), sheets = rewrite(book(snapshot).sheets, (ast) => ast);
  assert(Number.isInteger(index) && index >= 0 && index < sheets.length, "invalid", "Invalid sheet order");
  const [sheet] = sheets.splice(previous, 1);
  sheets.splice(index, 0, sheet);
  return setSheets(snapshot, sheets);
}
function shiftInterval(first, last, start, count, removing) {
  if (!removing) return [first >= start ? first + count : first, last >= start ? last + count : last];
  const end = start + count - 1;
  if (last < start) return [first, last];
  if (first > end) return [first - count, last - count];
  if (first >= start && last <= end) return void 0;
  const a = first < start ? first : start, b = last > end ? last - count : start - 1;
  return a <= b ? [a, b] : void 0;
}
function dimensions2(snapshot, sheetId, axis, start, count, removing) {
  const index = sheetIndex(snapshot, sheetId), target = book(snapshot).sheets[index], dimension = axis === "rows" ? "row" : "column", size = axis === "rows" ? "rowCount" : "columnCount", maximum = axis === "rows" ? 1048576 : 16384;
  assert(Number.isSafeInteger(start) && start >= 1 && Number.isSafeInteger(count) && count >= 1 && start + count - 1 <= maximum, "invalid", "Invalid row or column operation");
  const refers = (ref, sheet2) => ref.sheet === void 0 ? sheet2.id === sheetId : ref.sheet.toLowerCase() === target.name.toLowerCase();
  const sheets = rewrite(book(snapshot).sheets, (ast, sheet2) => transform(ast, (r) => {
    if (!refers(r, sheet2)) return r;
    const value = r[dimension];
    if (removing && value >= start && value < start + count) return { kind: "error", value: "#REF!" };
    const next = value >= start ? value + (removing ? -count : count) : value;
    return next > maximum ? { kind: "error", value: "#REF!" } : { ...r, [dimension]: next };
  }, (r) => {
    if (!refers(r.start, sheet2) || r.axis === "columns" && axis === "rows" || r.axis === "rows" && axis === "columns") return r;
    const backwards = r.start[dimension] > r.end[dimension], bounds = shiftInterval(Math.min(r.start[dimension], r.end[dimension]), Math.max(r.start[dimension], r.end[dimension]), start, count, removing);
    if (!bounds || bounds[1] > maximum) return { kind: "error", value: "#REF!" };
    return { ...r, start: { ...r.start, [dimension]: bounds[backwards ? 1 : 0] }, end: { ...r.end, [dimension]: bounds[backwards ? 0 : 1] } };
  }));
  const sheet = sheets[index], cells = {};
  for (const [key, cell] of Object.entries(sheet.cells)) {
    const [row, column] = key.split(":").map(Number), value = axis === "rows" ? row : column;
    if (removing && value >= start && value < start + count) continue;
    const next = value >= start ? value + (removing ? -count : count) : value;
    assert(next <= maximum, "unsupported", "Insertion would discard cells at the sheet boundary");
    cells[cellKey(axis === "rows" ? next : row, axis === "columns" ? next : column)] = cell;
  }
  sheet.cells = cells;
  const metadata = {};
  for (const [key, value] of Object.entries(sheet[axis])) {
    const at = Number(key);
    if (removing && at >= start && at < start + count) continue;
    const next = at >= start ? at + (removing ? -count : count) : at;
    assert(next <= maximum, "unsupported", "Insertion would discard dimension metadata");
    metadata[String(next)] = value;
  }
  sheet[axis] = metadata;
  sheet.merges = sheet.merges.flatMap((merge) => {
    const bounds = shiftInterval(merge[dimension], merge[dimension] + merge[size] - 1, start, count, removing);
    if (!bounds) return [];
    assert(bounds[1] <= maximum, "unsupported", "Insertion would discard a merged range");
    return [{ ...merge, [dimension]: bounds[0], [size]: bounds[1] - bounds[0] + 1 }];
  }).filter((m) => m.rowCount * m.columnCount > 1);
  if (sheet.view) {
    const field = axis === "rows" ? "frozenRows" : "frozenColumns", value = sheet.view[field];
    if (value !== void 0 && start <= value) sheet.view[field] = removing ? Math.max(start - 1, value - count) : Math.min(maximum - 1, value + count);
  }
  return setSheets(snapshot, sheets);
}
function insertRows(snapshot, sheetId, start, count = 1) {
  return dimensions2(snapshot, sheetId, "rows", start, count, false);
}
function deleteRows(snapshot, sheetId, start, count = 1) {
  return dimensions2(snapshot, sheetId, "rows", start, count, true);
}
function insertColumns(snapshot, sheetId, start, count = 1) {
  return dimensions2(snapshot, sheetId, "columns", start, count, false);
}
function deleteColumns(snapshot, sheetId, start, count = 1) {
  return dimensions2(snapshot, sheetId, "columns", start, count, true);
}
function mergeCells(snapshot, sheetId, range) {
  assertCellRange(range);
  assert(range.rowCount * range.columnCount > 1, "invalid", "A merge needs at least two cells");
  const index = sheetIndex(snapshot, sheetId), sheet = book(snapshot).sheets[index];
  assert(!sheet.merges.some((m) => overlap(m, range)), "unsupported", "Merged ranges overlap");
  for (const [key, cell] of Object.entries(sheet.cells)) {
    const [row, column] = key.split(":").map(Number);
    if (inside(range, row, column) && (row !== range.row || column !== range.column)) assert(cell.value.kind === "blank", "unsupported", "Merge would discard a value");
  }
  return edit(snapshot, [{ op: "set", path: ["sheets", index, "merges"], value: [...sheet.merges, range] }]);
}
function unmergeCells(snapshot, sheetId, range) {
  assertCellRange(range);
  const index = sheetIndex(snapshot, sheetId), sheet = book(snapshot).sheets[index];
  assert(sheet.merges.every((m) => !overlap(m, range) || contains(range, m)), "unsupported", "Select the complete merged range");
  return edit(snapshot, [{ op: "set", path: ["sheets", index, "merges"], value: sheet.merges.filter((m) => !overlap(m, range)) }]);
}
function shiftFormula(source, rowDelta, columnDelta) {
  const ast = checkedAst(source);
  const shifted = transform(ast, (r) => {
    const row = r.row + (r.rowAbsolute ? 0 : rowDelta), column = r.column + (r.columnAbsolute ? 0 : columnDelta);
    return row < 1 || row > 1048576 || column < 1 || column > 16384 ? { kind: "error", value: "#REF!" } : { ...r, row, column };
  }, (range) => {
    const shift = (r) => ({ ...r, row: r.row + (r.rowAbsolute || range.axis === "columns" ? 0 : rowDelta), column: r.column + (r.columnAbsolute || range.axis === "rows" ? 0 : columnDelta) });
    const a = shift(range.start), b = shift(range.end);
    if ([a, b].some((r) => r.row < 1 || r.row > 1048576 || r.column < 1 || r.column > 16384)) return { kind: "error", value: "#REF!" };
    return { ...range, start: a, end: b };
  });
  return serializeFormula(shifted);
}
function copyCells(snapshot, sourceSheetId, range, targetSheetId, row, column) {
  assertCellRange(range, 1e5);
  assertCellRange({ row, column, rowCount: range.rowCount, columnCount: range.columnCount });
  const source = book(snapshot).sheets[sheetIndex(snapshot, sourceSheetId)], targetIndex = sheetIndex(snapshot, targetSheetId), target = book(snapshot).sheets[targetIndex], destination = { ...range, row, column };
  assert(source.merges.every((m) => !overlap(m, range) || contains(range, m)), "unsupported", "Select entire merged cells to copy");
  assert(target.merges.every((m) => !overlap(m, destination) || contains(destination, m)), "unsupported", "Paste intersects part of a merged cell");
  const cells = { ...target.cells };
  for (const key of Object.keys(cells)) {
    const [r, c] = key.split(":").map(Number);
    if (inside(destination, r, c)) delete cells[key];
  }
  for (const [key, cell] of Object.entries(source.cells)) {
    const [r, c] = key.split(":").map(Number);
    if (!inside(range, r, c)) continue;
    cells[cellKey(r + row - range.row, c + column - range.column)] = cell.value.kind === "formula" ? { ...cell, value: { kind: "formula", source: shiftFormula(cell.value.source, row - range.row, column - range.column) } } : cell;
  }
  const merges = [...target.merges.filter((m) => !overlap(m, destination)), ...source.merges.filter((m) => contains(range, m)).map((m) => ({ ...m, row: m.row + row - range.row, column: m.column + column - range.column }))];
  return edit(snapshot, [{ op: "set", path: ["sheets", targetIndex, "cells"], value: cells }, { op: "set", path: ["sheets", targetIndex, "merges"], value: merges }]);
}
function clearCells(snapshot, sheetId, range) {
  assertCellRange(range);
  const index = sheetIndex(snapshot, sheetId), cells = { ...book(snapshot).sheets[index].cells };
  for (const [key, cell] of Object.entries(cells)) {
    const [row, column] = key.split(":").map(Number);
    if (!inside(range, row, column)) continue;
    if (Object.keys(cell).length === 1) delete cells[key];
    else cells[key] = { ...cell, value: { kind: "blank" } };
  }
  return cellsCommand(snapshot, index, cells);
}
function formatCells(snapshot, sheetId, range, format) {
  assertCellRange(range, 1e5);
  const index = sheetIndex(snapshot, sheetId), sheet = book(snapshot).sheets[index], cells = { ...sheet.cells };
  for (let r = range.row; r < range.row + range.rowCount; r++) for (let c = range.column; c < range.column + range.columnCount; c++) {
    const key = cellKey(r, c), before = cells[key] ?? { value: { kind: "blank" } };
    cells[key] = { ...before, ...format.style !== void 0 ? { style: { ...before.style, ...format.style } } : {}, ...format.numberFormat !== void 0 ? { numberFormat: format.numberFormat } : {} };
  }
  return cellsCommand(snapshot, index, cells);
}
function setDimensions(snapshot, sheetId, axis, start, count, dimension) {
  const index = sheetIndex(snapshot, sheetId), maximum = axis === "rows" ? 1048576 : 16384;
  assert(Number.isSafeInteger(start) && start >= 1 && Number.isSafeInteger(count) && count > 0 && count <= 1e5 && start + count - 1 <= maximum, "invalid", "Invalid dimension selection");
  assert(axis === "rows" ? dimension.width === void 0 : dimension.height === void 0, "invalid", "Wrong dimension property");
  const values = { ...book(snapshot).sheets[index][axis] };
  for (let i = start; i < start + count; i++) values[String(i)] = { ...values[String(i)], ...dimension };
  return edit(snapshot, [{ op: "set", path: ["sheets", index, axis], value: values }]);
}
function fillCells(snapshot, sheetId, range, direction) {
  assertCellRange(range, 1e5);
  const index = sheetIndex(snapshot, sheetId), sheet = book(snapshot).sheets[index];
  assert(!sheet.merges.some((m) => overlap(m, range)), "unsupported", "Unmerge the fill range first");
  const cells = { ...sheet.cells };
  for (let r = range.row; r < range.row + range.rowCount; r++) for (let c = range.column; c < range.column + range.columnCount; c++) {
    const sr = direction === "down" ? range.row : r, sc = direction === "right" ? range.column : c, source = sheet.cells[cellKey(sr, sc)], key = cellKey(r, c);
    if (!source) delete cells[key];
    else cells[key] = source.value.kind === "formula" ? { ...source, value: { kind: "formula", source: shiftFormula(source.value.source, r - sr, c - sc) } } : source;
  }
  return cellsCommand(snapshot, index, cells);
}
function parseTsv(text2) {
  assert(text2.length <= 8 * 1024 * 1024, "limit", "Clipboard text budget exceeded");
  const rows = [];
  let row = [], field = "", quoted = false, closed = false, count = 0;
  const nextField = () => {
    assert(++count <= 1e5 && field.length <= 32767, "limit", "Clipboard cell budget exceeded");
    row.push(field);
    field = "";
    closed = false;
  };
  const nextRow = () => {
    nextField();
    rows.push(row);
    row = [];
  };
  for (let i = 0; i < text2.length; i++) {
    const ch = text2[i];
    if (quoted) {
      if (ch === '"') {
        if (text2[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          quoted = false;
          closed = true;
        }
      } else field += ch;
      continue;
    }
    if (ch === '"' && field === "" && !closed) {
      quoted = true;
      continue;
    }
    if (ch === "	") {
      nextField();
      continue;
    }
    if (ch === "\r" || ch === "\n") {
      if (ch === "\r" && text2[i + 1] === "\n") i++;
      nextRow();
      continue;
    }
    assert(!closed, "invalid", "Unexpected text after quoted clipboard cell");
    field += ch;
  }
  assert(!quoted, "invalid", "Unterminated clipboard field");
  if (field.length || row.length || !rows.length || !/[\r\n]$/.test(text2)) nextRow();
  const width = rows.reduce((max, row2) => Math.max(max, row2.length), 0);
  assert(width * rows.length <= 1e5, "limit", "Rectangular clipboard cell budget exceeded");
  for (const row2 of rows) while (row2.length < width) row2.push("");
  return rows;
}
function pasteTsv(snapshot, sheetId, row, column, text2, options = {}) {
  const matrix = parseTsv(text2);
  assertCellRange({ row, column, rowCount: matrix.length, columnCount: matrix[0].length }, 1e5);
  const sheet = book(snapshot).sheets[sheetIndex(snapshot, sheetId)], edits = [];
  for (let r = 0; r < matrix.length; r++) for (let c = 0; c < matrix[r].length; c++) {
    const text3 = matrix[r][c], key = cellKey(row + r, column + c), previous = sheet.cells[key];
    edits.push({ row: row + r, column: column + c, cell: cellFromInput(text3, options, previous) });
  }
  return setCells(snapshot, sheetId, edits);
}
function exportTsv(document2, sheetId, range, options = {}) {
  assertCellRange(range, 1e5);
  const sheet = document2.sheets.find((s) => s.id === sheetId);
  assert(sheet, "invalid", "Sheet does not exist");
  const rows = [];
  const quote = (text2) => /[\t\r\n"]/.test(text2) ? `"${text2.replaceAll('"', '""')}"` : text2;
  for (let r = range.row; r < range.row + range.rowCount; r++) {
    const cells = [];
    for (let c = range.column; c < range.column + range.columnCount; c++) {
      const cell = sheet.cells[cellKey(r, c)];
      const text2 = !cell ? "" : cell.value.kind === "formula" && options.formulas ? cell.value.source : formatCell(cell, options.calculation?.get(sheetId, r, c), { dateSystem: document2.dateSystem });
      cells.push(quote(text2));
    }
    rows.push(cells.join("	"));
  }
  return rows.join("\r\n");
}

// packages/ui/src/sheets-geometry.ts
var GridAxis = class {
  constructor(count, defaultSize, overrides, size) {
    this.count = count;
    this.defaultSize = defaultSize;
    let delta = 0;
    for (const [index, dimension] of Object.entries(overrides).map(([key, value]) => [Number(key), value]).sort((a, b) => a[0] - b[0])) {
      if (index < 1 || index > count) continue;
      const value = dimension.hidden ? 0 : dimension[size] === void 0 ? defaultSize : dimension[size] / 9525;
      delta += value - defaultSize;
      this.#indices.push(index);
      this.#deltas.push(delta);
    }
  }
  count;
  defaultSize;
  #indices = [];
  #deltas = [];
  start(index) {
    let lo = 0, hi = this.#indices.length;
    while (lo < hi) {
      const middle = lo + hi >>> 1;
      if (this.#indices[middle] < index) lo = middle + 1;
      else hi = middle;
    }
    return (index - 1) * this.defaultSize + (lo ? this.#deltas[lo - 1] : 0);
  }
  size(index) {
    return this.start(index + 1) - this.start(index);
  }
  get total() {
    return this.start(this.count + 1);
  }
  at(offset) {
    let lo = 1, hi = this.count;
    while (lo < hi) {
      const middle = Math.floor((lo + hi) / 2);
      if (this.start(middle + 1) <= offset) lo = middle + 1;
      else hi = middle;
    }
    return lo;
  }
  visible(offset, length, limit2 = 200) {
    const result = [];
    let index = this.at(Math.max(0, offset));
    const end = Math.max(0, offset) + length;
    while (index <= this.count && this.start(index) < end && result.length < limit2) {
      if (this.size(index) > 0) {
        result.push(index);
        index++;
      } else {
        const next = this.at(this.start(index) + 1e-5);
        index = Math.max(index + 1, next);
      }
    }
    return result;
  }
};
function columnLabel(column) {
  let value = "";
  while (column > 0) {
    column--;
    value = String.fromCharCode(65 + column % 26) + value;
    column = Math.floor(column / 26);
  }
  return value;
}
function cellLabel(row, column) {
  return columnLabel(column) + row;
}

// packages/ui/src/sheets-workspace.ts
var running;
var requestId = 0;
var copied;
function releaseSheetCalculation(documentId) {
  if (!running || documentId && running.documentId !== documentId) return;
  running.worker.terminate();
  clearTimeout(running.timer);
  running.state.calculating = false;
  running = void 0;
}
function recalculate(host, state2, force = false) {
  const snapshot = host.snapshot();
  if (snapshot.document.kind !== "sheets") return;
  if (host.readOnly && state2.unsupportedFormulas?.length) {
    releaseSheetCalculation();
    state2.calculation = new Map((state2.cachedValues ?? []).map(([key, value]) => [key, { state: "unsupported", reason: "unsupported-syntax", value }]));
    state2.calculatedRevision = snapshot.revision;
    state2.calculating = false;
    state2.calculationError = false;
    return;
  }
  if (!force && state2.calculatedRevision === snapshot.revision) return;
  if (running?.documentId === snapshot.document.documentId && running.revision === snapshot.revision && running.busy) return;
  if (running && (running.documentId !== snapshot.document.documentId || running.busy || force)) releaseSheetCalculation();
  if (!running) {
    const worker = new Worker(new URL("./sheets-recalc-worker.js", import.meta.url), { type: "module" });
    running = { worker, documentId: snapshot.document.documentId, request: 0, revision: -1, busy: false, state: state2 };
  }
  const current = running, id = ++requestId;
  current.request = id;
  current.revision = snapshot.revision;
  current.busy = true;
  current.state = state2;
  state2.calculating = true;
  state2.calculationError = false;
  current.worker.onmessage = (event) => {
    if (running !== current || event.data.id !== id || event.data.revision !== snapshot.revision) return;
    clearTimeout(current.timer);
    current.busy = false;
    state2.calculating = false;
    if (host.snapshot().revision === snapshot.revision) {
      state2.calculationError = !event.data.ok;
      state2.calculatedRevision = event.data.ok ? snapshot.revision : void 0;
      if (event.data.ok) state2.calculation = new Map(event.data.cells);
    }
    state2.onCalculation?.();
  };
  current.worker.onerror = () => {
    if (running !== current) return;
    releaseSheetCalculation();
    state2.calculationError = true;
    state2.onCalculation?.();
  };
  current.timer = setTimeout(() => {
    if (running !== current || !current.busy) return;
    releaseSheetCalculation();
    state2.calculationError = true;
    state2.onCalculation?.();
  }, 12e3);
  current.worker.postMessage({ id, revision: snapshot.revision, document: snapshot.document, cachedValues: state2.cachedValues, cachedSources: state2.cachedSources });
}
var styleColor = (color) => color?.kind === "rgba" ? `rgba(${color.red},${color.green},${color.blue},${color.alpha / 255})` : "var(--text)";
var rgb = (value) => ({ kind: "rgba", red: parseInt(value.slice(1, 3), 16), green: parseInt(value.slice(3, 5), 16), blue: parseInt(value.slice(5, 7), 16), alpha: 255 });
function colorHex(color, fallback) {
  return color?.kind === "rgba" ? "#" + [color.red, color.green, color.blue].map((x) => x.toString(16).padStart(2, "0")).join("") : fallback;
}
function rangeOf(state2) {
  return { row: Math.min(state2.row, state2.anchorRow), column: Math.min(state2.column, state2.anchorColumn), rowCount: Math.abs(state2.row - state2.anchorRow) + 1, columnCount: Math.abs(state2.column - state2.anchorColumn) + 1 };
}
function contains2(range, row, column) {
  return row >= range.row && row < range.row + range.rowCount && column >= range.column && column < range.column + range.columnCount;
}
function sheetsWorkspace(host, state2) {
  const snapshot = host.snapshot();
  if (snapshot.document.kind !== "sheets") throw new OfficeError("invalid", "Expected a workbook");
  const model = snapshot.document;
  if (state2.cachedValues && !state2.cachedSources) state2.cachedSources = model.sheets.flatMap((s) => Object.entries(s.cells).filter(([, cell]) => cell.value.kind === "formula").map(([key, cell]) => [s.id + "!" + key, cell.value.kind === "formula" ? cell.value.source : ""]));
  const sheet = model.sheets.find((x) => x.id === state2.sheetId) ?? model.sheets[0];
  state2.sheetId = sheet.id;
  const opaque = new Set(state2.unsupportedFormulas ?? []);
  const limits = host.format === "xls" ? { rows: 65536, columns: 256 } : { rows: 1048576, columns: 16384 };
  state2.row = Math.max(1, Math.min(state2.row, limits.rows));
  state2.column = Math.max(1, Math.min(state2.column, limits.columns));
  state2.anchorRow = Math.max(1, Math.min(state2.anchorRow, limits.rows));
  state2.anchorColumn = Math.max(1, Math.min(state2.anchorColumn, limits.columns));
  const t = host.t, root2 = document.createElement("section");
  root2.className = "sheets-workspace";
  root2.id = "sheets-workspace";
  const make = (tag, value = "", className = "") => {
    const node = document.createElement(tag);
    node.textContent = value;
    if (className) node.className = className;
    return node;
  };
  const guard = (action) => {
    try {
      if (!flush()) return;
      action();
    } catch (error) {
      host.error(error);
    }
  };
  const changed = (command) => {
    if (host.readOnly) return false;
    const ok = host.execute(command);
    if (ok) {
      state2.calculatedRevision = void 0;
      host.render();
    }
    return ok;
  };
  const button = (key, id, action, disabled = Boolean(host.readOnly)) => {
    const node = make("button", t(key));
    node.type = "button";
    node.id = id;
    node.disabled = disabled;
    node.onclick = () => guard(action);
    return node;
  };
  const label = (key, control) => {
    const wrapper = make("label");
    wrapper.append(make("span", t(key)), control);
    control.setAttribute("aria-label", t(key));
    return wrapper;
  };
  const toolbar = make("div", "", "sheets-formatbar");
  toolbar.setAttribute("aria-label", t("sheetFormatting"));
  const selectionRange = () => {
    let range = rangeOf(state2), changed2 = true;
    while (changed2) {
      changed2 = false;
      for (const merge of sheet.merges) {
        if (merge.row >= range.row + range.rowCount || range.row >= merge.row + merge.rowCount || merge.column >= range.column + range.columnCount || range.column >= merge.column + merge.columnCount) continue;
        const row = Math.min(range.row, merge.row), column = Math.min(range.column, merge.column), rowEnd = Math.max(range.row + range.rowCount, merge.row + merge.rowCount), columnEnd = Math.max(range.column + range.columnCount, merge.column + merge.columnCount);
        if (row !== range.row || column !== range.column || rowEnd !== range.row + range.rowCount || columnEnd !== range.column + range.columnCount) {
          range = { row, column, rowCount: rowEnd - row, columnCount: columnEnd - column };
          changed2 = true;
        }
      }
    }
    return range;
  };
  const selected = sheet.cells[`${state2.row}:${state2.column}`];
  const currentStyle = () => {
    const cell = sheet.cells[`${state2.row}:${state2.column}`];
    return { ...cell?.styleId ? model.styles[cell.styleId]?.properties : {}, ...cell?.style };
  };
  const selectedStyle = currentStyle();
  for (const [key, property, id] of [["writerBold", "bold", "sheet-bold"], ["writerItalic", "italic", "sheet-italic"], ["writerUnderline", "underline", "sheet-underline"]]) {
    const b = button(key, id, () => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { style: { [property]: !currentStyle()[property] } })));
    b.setAttribute("aria-pressed", String(Boolean(selectedStyle[property])));
    toolbar.append(b);
  }
  const family = make("input");
  family.value = selectedStyle.fontFamily ?? model.defaultTextStyle.fontFamily ?? "Arial";
  family.id = "sheet-font";
  family.maxLength = 128;
  family.disabled = Boolean(host.readOnly);
  family.onchange = () => guard(() => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { style: { fontFamily: family.value } })));
  toolbar.append(label("writerFontFamily", family));
  const fontSize = make("input");
  fontSize.type = "number";
  fontSize.min = "1";
  fontSize.max = "409";
  fontSize.step = ".5";
  fontSize.value = String((selectedStyle.fontSize ?? model.defaultTextStyle.fontSize ?? 139700) / 12700);
  fontSize.id = "sheet-font-size";
  fontSize.disabled = Boolean(host.readOnly);
  fontSize.onchange = () => guard(() => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { style: { fontSize: Math.round(Number(fontSize.value) * 12700) } })));
  toolbar.append(label("writerFontSize", fontSize));
  for (const [key, property, id, fallback] of [["writerTextColor", "color", "sheet-text-color", "#222735"], ["sheetFillColor", "fill", "sheet-fill-color", "#ffffff"]]) {
    const picker = make("input");
    picker.type = "color";
    picker.id = id;
    picker.value = colorHex(selectedStyle[property], fallback);
    picker.disabled = Boolean(host.readOnly);
    picker.onchange = () => guard(() => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { style: { [property]: rgb(picker.value) } })));
    toolbar.append(label(key, picker));
  }
  for (const [key, value, id] of [["writerAlignLeft", "start", "sheet-align-start"], ["writerAlignCenter", "center", "sheet-align-center"], ["writerAlignRight", "end", "sheet-align-end"]]) toolbar.append(button(key, id, () => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { style: { alignment: value } }))));
  toolbar.append(button("sheetWrap", "sheet-wrap", () => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { style: { wrapText: !currentStyle().wrapText } }))));
  toolbar.append(button("sheetBorder", "sheet-border", () => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { style: { border: { width: 9525, color: { kind: "rgba", red: 110, green: 120, blue: 135, alpha: 255 } } } }))));
  root2.append(toolbar);
  const second = make("div", "", "sheets-formatbar");
  const formats = make("select");
  formats.id = "sheet-number-format";
  formats.disabled = Boolean(host.readOnly);
  for (const [key, value] of [["sheetGeneral", "General"], ["sheetNumber", "0.00"], ["sheetPercent", "0.00%"], ["sheetCurrency", "$#,##0.00"], ["sheetDate", "yyyy-mm-dd"], ["sheetTime", "hh:mm:ss"], ["sheetScientific", "0.00E+00"]]) {
    const option = make("option", t(key));
    option.value = value;
    formats.append(option);
  }
  if (selected?.numberFormat && !Array.from(formats.options).some((x) => x.value === selected.numberFormat)) {
    const option = make("option", selected.numberFormat);
    option.value = selected.numberFormat;
    formats.append(option);
  }
  formats.value = selected?.numberFormat ?? "General";
  formats.onchange = () => guard(() => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { numberFormat: formats.value })));
  second.append(label("sheetNumberFormat", formats));
  const custom = make("input");
  custom.id = "sheet-custom-format";
  custom.value = selected?.numberFormat ?? "General";
  custom.maxLength = 1024;
  custom.disabled = Boolean(host.readOnly);
  custom.onchange = () => guard(() => changed(formatCells(host.snapshot(), sheet.id, selectionRange(), { numberFormat: custom.value })));
  second.append(label("sheetCustomFormat", custom));
  const mode = make("select");
  mode.id = "sheet-formula-mode";
  for (const [value, key] of [["canonical", "sheetCanonical"], ["regional", "sheetRegional"]]) {
    const o = make("option", t(key));
    o.value = value;
    mode.append(o);
  }
  mode.value = state2.inputMode;
  mode.onchange = () => {
    if (!flush()) {
      mode.value = state2.inputMode;
      return;
    }
    state2.inputMode = mode.value;
    host.render();
  };
  second.append(label("sheetFormulaMode", mode));
  second.append(button("sheetMerge", "sheet-merge", () => changed(mergeCells(host.snapshot(), sheet.id, selectionRange()))), button("sheetUnmerge", "sheet-unmerge", () => changed(unmergeCells(host.snapshot(), sheet.id, selectionRange()))));
  second.append(button("sheetClear", "sheet-clear", () => changed(clearCells(host.snapshot(), sheet.id, selectionRange()))), button("sheetFillDown", "sheet-fill-down", () => changed(fillCells(host.snapshot(), sheet.id, selectionRange(), "down"))), button("sheetFillRight", "sheet-fill-right", () => changed(fillCells(host.snapshot(), sheet.id, selectionRange(), "right"))));
  root2.append(second);
  const controls2 = make("details", "", "sheets-advanced");
  controls2.append(make("summary", t("sheetManage")));
  const management = make("div", "", "sheets-formatbar");
  const sheetName = make("input");
  sheetName.id = "sheet-name";
  sheetName.value = sheet.name;
  sheetName.maxLength = 31;
  sheetName.disabled = Boolean(host.readOnly);
  management.append(label("sheetName", sheetName));
  management.append(button("sheetRename", "sheet-rename", () => changed(renameSheet(host.snapshot(), sheet.id, sheetName.value))), button("sheetDelete", "sheet-delete", () => {
    state2.row = state2.anchorRow = state2.column = state2.anchorColumn = 1;
    changed(deleteSheet(host.snapshot(), sheet.id));
  }), button("sheetMoveLeft", "sheet-move-left", () => changed(moveSheet(host.snapshot(), sheet.id, Math.max(0, model.sheets.findIndex((s) => s.id === sheet.id) - 1)))), button("sheetMoveRight", "sheet-move-right", () => changed(moveSheet(host.snapshot(), sheet.id, Math.min(model.sheets.length - 1, model.sheets.findIndex((s) => s.id === sheet.id) + 1)))));
  for (const [key, id, fn, axis] of [["sheetInsertRows", "sheet-insert-rows", insertRows, "rows"], ["sheetDeleteRows", "sheet-delete-rows", deleteRows, "rows"], ["sheetInsertColumns", "sheet-insert-columns", insertColumns, "columns"], ["sheetDeleteColumns", "sheet-delete-columns", deleteColumns, "columns"]]) management.append(button(key, id, () => {
    const range = selectionRange();
    changed(fn(host.snapshot(), sheet.id, axis === "rows" ? range.row : range.column, axis === "rows" ? range.rowCount : range.columnCount));
  }));
  for (const [key, id, axis, size, defaultPx] of [["sheetRowHeight", "sheet-row-height", "rows", "height", 24], ["sheetColumnWidth", "sheet-column-width", "columns", "width", 104]]) {
    const input = make("input");
    input.type = "number";
    input.id = id;
    input.min = "2";
    input.max = "2000";
    input.step = "1";
    const current = axis === "rows" ? sheet.rows[state2.row] : sheet.columns[state2.column];
    input.value = String(Math.round((current?.[size] ?? defaultPx * 9525) / 9525));
    input.disabled = Boolean(host.readOnly);
    input.onchange = () => guard(() => {
      const range = selectionRange();
      changed(setDimensions(host.snapshot(), sheet.id, axis, axis === "rows" ? range.row : range.column, axis === "rows" ? range.rowCount : range.columnCount, { [size]: Math.round(Number(input.value) * EMU_PER_CSS_PIXEL) }));
    });
    management.append(label(key, input));
  }
  const dates = make("select");
  dates.id = "sheet-date-system";
  dates.disabled = Boolean(host.readOnly);
  for (const system of ["1900", "1904"]) {
    const o = make("option", system);
    o.value = system;
    dates.append(o);
  }
  dates.value = model.dateSystem;
  dates.onchange = () => guard(() => changed(patchCommand(host.snapshot(), "SHT-02", [{ op: "set", path: ["dateSystem"], value: dates.value }])));
  management.append(label("sheetDateSystem", dates));
  const updateView = (patch) => {
    const snap = host.snapshot();
    if (snap.document.kind !== "sheets") return;
    const index = snap.document.sheets.findIndex((s) => s.id === sheet.id);
    changed(patchCommand(snap, "SHT-02", [{ op: "set", path: ["sheets", index, "view"], value: { ...sheet.view, ...patch } }]));
  };
  management.append(button("sheetFreeze", "sheet-freeze", () => updateView({ frozenRows: state2.row - 1, frozenColumns: state2.column - 1 })), button("sheetUnfreeze", "sheet-unfreeze", () => updateView({ frozenRows: 0, frozenColumns: 0 })), button("sheetRtl", "sheet-rtl", () => updateView({ rightToLeft: !sheet.view?.rightToLeft })), button("sheetShowGrid", "sheet-grid-lines", () => updateView({ showGridLines: sheet.view?.showGridLines === false })));
  controls2.append(management);
  root2.append(controls2);
  const bar = make("div", "", "sheets-formula-bar");
  const address = make("input");
  address.id = "sheets-address";
  address.setAttribute("aria-label", t("sheetAddress"));
  address.spellcheck = false;
  const formula = make("input");
  formula.id = "sheets-formula";
  formula.setAttribute("aria-label", t("sheetFormula"));
  formula.dir = "auto";
  formula.spellcheck = false;
  formula.autocomplete = "off";
  formula.readOnly = Boolean(host.readOnly);
  bar.append(address, make("span", "\u0192x", "sheets-fx"), formula);
  root2.append(bar);
  const scroll = make("div", "", "sheets-scroll");
  scroll.id = "sheets-scroll";
  scroll.dataset.rtl = String(Boolean(sheet.view?.rightToLeft));
  scroll.tabIndex = 0;
  scroll.dir = "ltr";
  scroll.setAttribute("role", "grid");
  scroll.setAttribute("aria-label", t("sheetGrid"));
  scroll.setAttribute("aria-rowcount", String(limits.rows));
  scroll.setAttribute("aria-colcount", String(limits.columns));
  scroll.setAttribute("aria-multiselectable", "true");
  scroll.setAttribute("aria-readonly", String(Boolean(host.readOnly)));
  const plane = make("div", "", "sheets-plane");
  scroll.append(plane);
  root2.append(scroll);
  const rows = new GridAxis(limits.rows, 24, sheet.rows, "height"), columns = new GridAxis(limits.columns, 104, sheet.columns, "width");
  const headerWidth = 46, headerHeight = 26;
  const totalHeight = Math.min(3e7, rows.total + headerHeight), totalWidth = Math.min(3e7, columns.total + headerWidth);
  plane.style.height = totalHeight + "px";
  plane.style.width = totalWidth + "px";
  const displayRowScale = (rows.total + headerHeight) / totalHeight, displayColScale = (columns.total + headerWidth) / totalWidth;
  const layer = make("div", "", "sheets-cell-layer");
  plane.append(layer);
  const renderedCells = /* @__PURE__ */ new Map();
  const rowHeaders = /* @__PURE__ */ new Map(), columnHeaders = /* @__PURE__ */ new Map();
  const corner = make("div", "", "sheets-corner");
  corner.style.width = headerWidth + "px";
  corner.style.height = headerHeight + "px";
  layer.append(corner);
  const editor = make("input");
  editor.id = "sheets-cell-editor";
  editor.className = "sheets-cell-editor";
  editor.hidden = true;
  editor.dir = "auto";
  editor.spellcheck = false;
  editor.autocomplete = "off";
  plane.append(editor);
  const bottom = make("div", "", "sheets-bottom");
  const sheetTabs = make("div", "", "sheet-tabs");
  sheetTabs.setAttribute("role", "tablist");
  for (const current of model.sheets) {
    const b = make("button", current.name);
    b.type = "button";
    b.dataset.sheetId = current.id;
    b.setAttribute("role", "tab");
    b.setAttribute("aria-selected", String(current.id === sheet.id));
    b.onclick = () => {
      if (host.composing() || !flush()) return;
      state2.sheetId = current.id;
      state2.row = state2.column = state2.anchorRow = state2.anchorColumn = 1;
      state2.scrollLeft = state2.scrollTop = 0;
      host.render();
    };
    sheetTabs.append(b);
  }
  const add = button("sheetAdd", "sheet-add", () => {
    let number = model.sheets.length + 1;
    let name = "Sheet" + number;
    while (model.sheets.some((x) => x.name.toLowerCase() === name.toLowerCase())) name = "Sheet" + ++number;
    const id = crypto.randomUUID();
    state2.sheetId = id;
    state2.row = state2.column = state2.anchorRow = state2.anchorColumn = 1;
    state2.scrollTop = state2.scrollLeft = 0;
    changed(addSheet(host.snapshot(), name, id));
  });
  sheetTabs.append(add);
  bottom.append(sheetTabs);
  root2.append(bottom);
  const status = make("div", "", "sheets-status");
  status.setAttribute("aria-live", "polite");
  const selectedSummary = make("span"), calcStatus = make("span");
  status.append(selectedSummary, calcStatus, button("sheetRecalculate", "sheet-recalculate", () => {
    state2.calculatedRevision = void 0;
    recalculate(host, state2, true);
    paint();
  }, false), button("sheetCancelCalculation", "sheet-cancel-calculation", () => {
    releaseSheetCalculation();
    state2.calculationError = true;
    paint();
  }, false));
  root2.append(status, make("p", t(host.readOnly ? "sheetSourceProtected" : "sheetHelp"), "muted sheets-help"));
  let editing = false, formulaDirty = false, frame = 0, dragging = false, summaryKey = "", controlsKey = "";
  const options = () => ({ mode: state2.inputMode, locale: host.locale(), dateSystem: model.dateSystem });
  const rangeAddress = () => {
    const range = selectionRange(), first = cellLabel(range.row, range.column);
    return range.rowCount === 1 && range.columnCount === 1 ? first : first + ":" + cellLabel(range.row + range.rowCount - 1, range.column + range.columnCount - 1);
  };
  const cellSource = () => {
    const value = sheet.cells[`${state2.row}:${state2.column}`]?.value;
    if (!value || value.kind === "blank") return "";
    if (value.kind === "string") return "'" + value.value;
    if (value.kind === "formula") {
      if (state2.inputMode === "regional") {
        try {
          return localizeFormula(value.source, host.locale());
        } catch {
          return value.source;
        }
      }
      return value.source;
    }
    if (value.kind === "number" && state2.inputMode === "regional") return String(value.value).replace(".", formulaSeparators(host.locale()).decimal);
    return String(value.value);
  };
  const activeMerge = () => sheet.merges.find((m) => contains2(m, state2.row, state2.column));
  function applyInput(value, advance) {
    if (host.readOnly) return true;
    try {
      const old = sheet.cells[`${state2.row}:${state2.column}`], isDate = Boolean(old?.numberFormat && /[ymd]/i.test(old.numberFormat) && /^\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?$/.test(value));
      const unchanged = value === cellSource();
      const cell = unchanged ? void 0 : cellFromInput(value, { ...options(), ...isDate ? { type: "date" } : {} }, old);
      if (cell && !host.execute(setCells(host.snapshot(), sheet.id, [{ row: state2.row, column: state2.column, cell }]))) return false;
      editing = false;
      formulaDirty = false;
      editor.hidden = true;
      if (!unchanged) state2.calculatedRevision = void 0;
      if (advance) {
        if (advance === "Enter") state2.row = Math.min(limits.rows, state2.row + (activeMerge()?.rowCount ?? 1));
        else state2.column = Math.max(1, Math.min(limits.columns, state2.column + (advance === "BackTab" ? -1 : activeMerge()?.columnCount ?? 1)));
        state2.anchorRow = state2.row;
        state2.anchorColumn = state2.column;
      }
      host.render();
      queueMicrotask(() => {
        if (host.isCurrent()) document.querySelector("#sheets-scroll")?.focus();
      });
      return true;
    } catch (error) {
      host.error(error);
      return false;
    }
  }
  function flush() {
    if (host.composing()) return false;
    const input = editing ? editor : formulaDirty ? formula : void 0;
    if (!input) return true;
    const accepted = applyInput(input.value);
    if (!accepted) input.focus();
    return accepted;
  }
  state2.flush = flush;
  function beginEdit(initial) {
    if (host.readOnly) return;
    editing = true;
    formulaDirty = false;
    editor.value = initial ?? cellSource();
    editor.hidden = false;
    editor.setAttribute("aria-label", cellLabel(state2.row, state2.column));
    positionEditor();
    editor.focus();
    if (initial === void 0) editor.select();
    else editor.setSelectionRange(editor.value.length, editor.value.length);
  }
  function positionEditor() {
    const merge = activeMerge(), row = merge?.row ?? state2.row, col = merge?.column ?? state2.column;
    const x = screenX(col), y = screenY(row);
    editor.style.left = x + "px";
    editor.style.top = y + "px";
    editor.style.width = Math.max(80, columns.start(col + (merge?.columnCount ?? 1)) - columns.start(col)) + "px";
    editor.style.height = Math.max(24, rows.start(row + (merge?.rowCount ?? 1)) - rows.start(row)) + "px";
  }
  function scrollToCell() {
    const top = rows.start(state2.row), left = columns.start(state2.column), height = scroll.clientHeight - headerHeight, width = scroll.clientWidth - headerWidth;
    const y = scroll.scrollTop * displayRowScale, x = scroll.scrollLeft * displayColScale;
    if (top < y) scroll.scrollTop = top / displayRowScale;
    else if (top + rows.size(state2.row) > y + height) scroll.scrollTop = (top + rows.size(state2.row) - height) / displayRowScale;
    if (left < x) scroll.scrollLeft = left / displayColScale;
    else if (left + columns.size(state2.column) > x + width) scroll.scrollLeft = (left + columns.size(state2.column) - width) / displayColScale;
    state2.scrollTop = scroll.scrollTop;
    state2.scrollLeft = scroll.scrollLeft;
  }
  function select(row, col, extend = false, ensure = true) {
    state2.row = Math.max(1, Math.min(row, limits.rows));
    state2.column = Math.max(1, Math.min(col, limits.columns));
    const merged = sheet.merges.find((m) => contains2(m, state2.row, state2.column));
    if (merged) {
      state2.row = merged.row;
      state2.column = merged.column;
    }
    if (!extend) {
      state2.anchorRow = state2.row;
      state2.anchorColumn = state2.column;
    }
    if (ensure) scrollToCell();
    paint();
  }
  function screenX(col, offset = scroll.scrollLeft) {
    const base = columns.start(col);
    const fixed = col <= (sheet.view?.frozenColumns ?? 0);
    return headerWidth + (fixed ? base + offset : base - offset * (displayColScale - 1));
  }
  function screenY(row, offset = scroll.scrollTop) {
    const base = rows.start(row);
    const fixed = row <= (sheet.view?.frozenRows ?? 0);
    return headerHeight + (fixed ? base + offset : base - offset * (displayRowScale - 1));
  }
  const visualStyle = (node, cell) => {
    const style = { ...model.defaultTextStyle, ...cell?.styleId ? model.styles[cell.styleId]?.properties : {}, ...cell?.style };
    node.style.fontFamily = style.fontFamily ?? "sans-serif";
    node.style.fontSize = Math.min(200, (style.fontSize ?? 139700) / 9525) + "px";
    node.style.fontWeight = style.bold ? "700" : "400";
    node.style.fontStyle = style.italic ? "italic" : "normal";
    node.style.textDecoration = style.underline ? "underline" : "none";
    node.style.color = style.color ? styleColor(style.color) : "var(--text)";
    if (style.fill) node.style.backgroundColor = styleColor(style.fill);
    if (style.alignment) node.style.textAlign = style.alignment;
    if (style.wrapText) {
      node.style.whiteSpace = "pre-wrap";
      node.style.overflowWrap = "anywhere";
    }
    if (style.border) node.style.border = Math.max(0.5, style.border.width / 9525) + "px solid " + styleColor(style.border.color);
    node.style.alignContent = style.verticalAlignment === "top" ? "start" : style.verticalAlignment === "center" ? "center" : "end";
  };
  function paint() {
    if (!root2.isConnected) return;
    const scrollTop = scroll.scrollTop, scrollLeft = scroll.scrollLeft, height = scroll.clientHeight, width = scroll.clientWidth;
    const y = scrollTop * displayRowScale, x = scrollLeft * displayColScale;
    const frozenRows = sheet.view?.frozenRows ?? 0, frozenColumns = sheet.view?.frozenColumns ?? 0;
    const fixedRows = rows.visible(0, Math.min(height / 2, 200), 40).filter((r) => r <= frozenRows), fixedColumns = columns.visible(0, Math.min(width / 2, 400), 20).filter((c) => c <= frozenColumns);
    const visibleRows = [.../* @__PURE__ */ new Set([...fixedRows, ...rows.visible(y, height, 160)])].filter((r) => rows.size(r) > 0);
    const visibleColumns = [.../* @__PURE__ */ new Set([...fixedColumns, ...columns.visible(x, width, 60)])].filter((c) => columns.size(c) > 0);
    const fragment = document.createDocumentFragment(), range = selectionRange();
    let count = 0, sum = 0;
    const activeId = "sheet-cell-" + state2.row + "-" + state2.column;
    const painted = /* @__PURE__ */ new Set();
    const drawCell = (row, column, merge) => {
      const key = `${row}:${column}`;
      if (painted.has(key)) return;
      painted.add(key);
      const cell = sheet.cells[key], formulaKey = calculationKey(sheet.id, row, column), isOpaque = opaque.has(formulaKey), result = cell?.value.kind === "formula" || isOpaque ? state2.calculation?.get(formulaKey) : void 0;
      let rendered = renderedCells.get(key);
      const created = !rendered;
      if (!rendered) {
        const node = make("div", "", "sheets-cell");
        rendered = { node };
        renderedCells.set(key, rendered);
        node.id = "sheet-cell-" + row + "-" + column;
        node.dataset.row = String(row);
        node.dataset.column = String(column);
        node.dataset.address = cellLabel(row, column);
        node.setAttribute("role", "gridcell");
        node.setAttribute("aria-rowindex", String(row));
        node.setAttribute("aria-colindex", String(column));
        node.setAttribute("aria-label", cellLabel(row, column));
        node.dir = "auto";
        if (merge) {
          node.setAttribute("aria-rowspan", String(merge.rowCount));
          node.setAttribute("aria-colspan", String(merge.columnCount));
        }
        node.style.width = columns.start(column + (merge?.columnCount ?? 1)) - columns.start(column) + "px";
        node.style.height = rows.start(row + (merge?.rowCount ?? 1)) - rows.start(row) + "px";
        if (row <= frozenRows || column <= frozenColumns) node.classList.add("frozen");
        if (row <= frozenRows && column <= frozenColumns) node.classList.add("frozen-intersection");
        if (sheet.view?.showGridLines === false) node.classList.add("no-grid");
        visualStyle(node, cell);
        fragment.append(node);
      }
      const current = rendered.node, left = screenX(column, scrollLeft) + "px", top = screenY(row, scrollTop) + "px", selected2 = String(contains2(range, row, column));
      if (current.style.left !== left) current.style.left = left;
      if (current.style.top !== top) current.style.top = top;
      if (current.getAttribute("aria-selected") !== selected2) current.setAttribute("aria-selected", selected2);
      current.classList.toggle("active", row === state2.row && column === state2.column);
      if (created || rendered.result !== result || rendered.revision !== state2.calculatedRevision) {
        current.title = "";
        delete current.dataset.calculationState;
        if (isOpaque) {
          current.textContent = result?.value ? formatCellValue(result.value, "General", { locale: host.locale(), dateSystem: model.dateSystem }) : "\u2026";
          current.title = t("sheetUnsupported");
          current.dataset.calculationState = "unsupported";
        } else if (cell?.value.kind === "formula" && !result) {
          current.textContent = "\u2026";
          current.title = t("sheetFormulaPending");
          current.dataset.calculationState = "stale";
        } else {
          current.textContent = formatCell(cell, result, { locale: host.locale(), dateSystem: model.dateSystem });
          if (result) {
            current.dataset.calculationState = state2.calculatedRevision === snapshot.revision ? result.state : "stale";
            if (state2.calculatedRevision !== snapshot.revision) current.title = t("sheetStale");
            else if (result.state !== "valid") current.title = t(result.state === "unsupported" ? "sheetUnsupported" : result.state === "stale" ? "sheetStale" : "sheetCalcError");
          }
        }
        current.classList.toggle("number", cell?.value.kind === "number" || result?.value?.kind === "number");
        current.classList.toggle("cell-error", cell?.value.kind === "error" || result?.state === "error");
        rendered.result = result;
        rendered.revision = state2.calculatedRevision;
      }
    };
    for (const row of visibleRows) for (const column of visibleColumns) {
      const merge = sheet.merges.find((m) => contains2(m, row, column));
      if (merge) drawCell(merge.row, merge.column, merge);
      else drawCell(row, column);
    }
    for (const [key, rendered] of renderedCells) if (!painted.has(key)) {
      rendered.node.remove();
      renderedCells.delete(key);
    }
    for (const row of visibleRows) {
      let header = rowHeaders.get(row);
      if (!header) {
        header = make("div", String(row), "sheets-row-header");
        header.style.width = headerWidth + "px";
        header.style.height = rows.size(row) + "px";
        header.dataset.headerRow = String(row);
        header.setAttribute("role", "rowheader");
        rowHeaders.set(row, header);
        fragment.append(header);
      }
      header.style.left = scrollLeft + "px";
      header.style.top = screenY(row, scrollTop) + "px";
    }
    for (const column of visibleColumns) {
      let header = columnHeaders.get(column);
      if (!header) {
        header = make("div", columnLabel(column), "sheets-column-header");
        header.style.width = columns.size(column) + "px";
        header.style.height = headerHeight + "px";
        header.dataset.headerColumn = String(column);
        header.setAttribute("role", "columnheader");
        columnHeaders.set(column, header);
        fragment.append(header);
      }
      header.style.top = scrollTop + "px";
      header.style.left = screenX(column, scrollLeft) + "px";
    }
    for (const [row, header] of rowHeaders) if (!visibleRows.includes(row)) {
      header.remove();
      rowHeaders.delete(row);
    }
    for (const [column, header] of columnHeaders) if (!visibleColumns.includes(column)) {
      header.remove();
      columnHeaders.delete(column);
    }
    corner.style.left = scrollLeft + "px";
    corner.style.top = scrollTop + "px";
    layer.append(fragment);
    if (painted.has(state2.row + ":" + state2.column)) scroll.setAttribute("aria-activedescendant", activeId);
    else scroll.removeAttribute("aria-activedescendant");
    address.value = rangeAddress();
    if (!formulaDirty && !editing) formula.value = cellSource();
    const selectionKey = state2.row + ":" + state2.column;
    if (controlsKey !== selectionKey) {
      controlsKey = selectionKey;
      const style = currentStyle(), cell = sheet.cells[selectionKey];
      for (const [id, key] of [["sheet-bold", "bold"], ["sheet-italic", "italic"], ["sheet-underline", "underline"]]) root2.querySelector("#" + id)?.setAttribute("aria-pressed", String(Boolean(style[key])));
      family.value = style.fontFamily ?? model.defaultTextStyle.fontFamily ?? "Arial";
      fontSize.value = String((style.fontSize ?? model.defaultTextStyle.fontSize ?? 139700) / 12700);
      const fg = root2.querySelector("#sheet-text-color"), bg = root2.querySelector("#sheet-fill-color");
      if (fg) fg.value = colorHex(style.color, "#222735");
      if (bg) bg.value = colorHex(style.fill, "#ffffff");
      custom.value = cell?.numberFormat ?? "General";
      if (!Array.from(formats.options).some((o) => o.value === custom.value)) {
        const option = make("option", custom.value);
        option.value = custom.value;
        formats.append(option);
      }
      formats.value = custom.value;
      const rh = root2.querySelector("#sheet-row-height"), cw = root2.querySelector("#sheet-column-width");
      if (rh) rh.value = String(Math.round((sheet.rows[state2.row]?.height ?? 24 * 9525) / 9525));
      if (cw) cw.value = String(Math.round((sheet.columns[state2.column]?.width ?? 104 * 9525) / 9525));
    }
    const summarySignature = rangeAddress() + ":" + state2.calculatedRevision;
    if (summarySignature !== summaryKey) {
      const aggregate = (row, column, cell) => {
        if (!cell) return;
        const result = state2.calculation?.get(calculationKey(sheet.id, row, column)), value = cell.value.kind === "formula" ? state2.calculatedRevision === snapshot.revision && result?.state === "valid" ? result.value : void 0 : cell.value;
        if (value?.kind === "number") {
          count++;
          sum += value.value;
        }
      };
      if (range.rowCount * range.columnCount <= 1e4) {
        for (let row = range.row; row < range.row + range.rowCount; row++) for (let column = range.column; column < range.column + range.columnCount; column++) aggregate(row, column, sheet.cells[row + ":" + column]);
      } else for (const [key, cell] of Object.entries(sheet.cells)) {
        const [row, column] = key.split(":").map(Number);
        if (contains2(range, row, column)) aggregate(row, column, cell);
      }
      selectedSummary.textContent = t("sheetPosition", { address: rangeAddress() }) + " \xB7 " + t("sheetSelectionSummary", { count: new Intl.NumberFormat(host.locale()).format(count), sum: new Intl.NumberFormat(host.locale(), { maximumFractionDigits: 10 }).format(sum) });
      summaryKey = summarySignature;
    }
    calcStatus.textContent = t(host.readOnly && opaque.size ? "sheetUnsupported" : state2.calculating ? "sheetCalculating" : state2.calculationError ? "sheetCalcError" : "sheetCalculated");
    root2.dataset.calculatedRevision = String(state2.calculatedRevision ?? -1);
    root2.dataset.calculating = String(Boolean(state2.calculating));
    if (editing) positionEditor();
  }
  function schedule() {
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      paint();
    });
  }
  scroll.onscroll = () => {
    state2.scrollTop = scroll.scrollTop;
    state2.scrollLeft = scroll.scrollLeft;
    schedule();
  };
  scroll.onpointerdown = (event) => {
    if (event.target === editor || host.composing()) return;
    if (!flush()) {
      event.preventDefault();
      return;
    }
    const node = event.target.closest("[data-row],[data-header-row],[data-header-column]");
    if (!node) return;
    event.preventDefault();
    scroll.focus();
    dragging = true;
    if (node.dataset.headerRow) {
      select(Number(node.dataset.headerRow), 1, false, false);
      state2.column = limits.columns;
      paint();
      dragging = false;
    } else if (node.dataset.headerColumn) {
      select(1, Number(node.dataset.headerColumn), false, false);
      state2.row = limits.rows;
      paint();
      dragging = false;
    } else select(Number(node.dataset.row), Number(node.dataset.column), event.shiftKey, false);
  };
  scroll.onpointermove = (event) => {
    if (!dragging || !event.buttons) return;
    const node = event.target.closest("[data-row]");
    if (node) select(Number(node.dataset.row), Number(node.dataset.column), true, false);
  };
  scroll.onpointerup = () => {
    dragging = false;
  };
  scroll.onpointerleave = () => {
    dragging = false;
  };
  scroll.ondblclick = (event) => {
    const node = event.target.closest("[data-row]");
    if (node) beginEdit();
  };
  const move = (key, extend = false) => {
    const merge = activeMerge();
    let row = state2.row, column = state2.column;
    if (sheet.view?.rightToLeft && key === "ArrowLeft") key = "ArrowRight";
    else if (sheet.view?.rightToLeft && key === "ArrowRight") key = "ArrowLeft";
    if (key === "ArrowDown" || key === "Enter") row += merge?.rowCount ?? 1;
    else if (key === "ArrowUp") row--;
    else if (key === "ArrowRight" || key === "Tab") column += merge?.columnCount ?? 1;
    else if (key === "ArrowLeft") column--;
    else if (key === "Home") column = 1;
    else if (key === "PageDown") row += Math.max(1, Math.floor(scroll.clientHeight / 24) - 2);
    else if (key === "PageUp") row -= Math.max(1, Math.floor(scroll.clientHeight / 24) - 2);
    select(row, column, extend);
  };
  const clear = () => {
    changed(clearCells(host.snapshot(), sheet.id, selectionRange()));
  };
  scroll.onkeydown = (event) => {
    if (event.target === editor || host.composing()) return;
    if (event.ctrlKey || event.metaKey) {
      if (event.key.toLowerCase() === "a") {
        event.preventDefault();
        state2.anchorRow = state2.anchorColumn = 1;
        state2.row = limits.rows;
        state2.column = limits.columns;
        paint();
      }
      return;
    }
    if (["ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight", "Home", "PageDown", "PageUp", "Tab", "Enter"].includes(event.key)) {
      event.preventDefault();
      move(event.shiftKey && event.key === "Tab" ? "ArrowLeft" : event.key, event.shiftKey && event.key !== "Tab");
    } else if (event.key === "F2") {
      event.preventDefault();
      beginEdit();
    } else if (event.key === "Delete" || event.key === "Backspace") {
      event.preventDefault();
      guard(clear);
    } else if (event.key.length === 1 && !event.altKey) {
      event.preventDefault();
      beginEdit(event.key);
    }
  };
  for (const input of [editor, formula]) {
    input.addEventListener("compositionstart", () => host.setComposing(true));
    input.addEventListener("compositionend", () => {
      host.setComposing(false);
      if (input === formula) formulaDirty = true;
    });
    input.onkeydown = (event) => {
      if (event.isComposing || host.composing()) return;
      if (event.key === "Escape") {
        event.preventDefault();
        editing = false;
        formulaDirty = false;
        editor.hidden = true;
        formula.value = cellSource();
        scroll.focus();
      } else if (event.key === "Enter" || event.key === "Tab") {
        event.preventDefault();
        applyInput(input.value, input === editor ? event.key === "Tab" && event.shiftKey ? "BackTab" : event.key : void 0);
      }
    };
    input.onblur = (event) => {
      if (host.composing()) return;
      if (event.relatedTarget instanceof Node && root2.contains(event.relatedTarget)) return;
      if (input === editor && editing) flush();
      else if (input === formula && formulaDirty) flush();
    };
  }
  formula.oninput = () => {
    formulaDirty = true;
  };
  editor.oninput = () => {
    formula.value = editor.value;
  };
  address.onchange = () => guard(() => {
    const match = /^\$?([A-Za-z]{1,3})\$?([1-9][0-9]*)(?::\$?([A-Za-z]{1,3})\$?([1-9][0-9]*))?$/.exec(address.value.trim());
    if (!match) throw new OfficeError("invalid", t("sheetInputInvalid"));
    const col = (s) => [...s.toUpperCase()].reduce((n, c3) => n * 26 + c3.charCodeAt(0) - 64, 0);
    const r = Number(match[2]), c = col(match[1]), r2 = Number(match[4] ?? match[2]), c2 = col(match[3] ?? match[1]);
    if (Math.max(r, r2) > limits.rows || Math.max(c, c2) > limits.columns) throw new OfficeError("limit", "Selection exceeds workbook format limits");
    select(r, c, false);
    select(r2, c2, true);
    scroll.focus();
  });
  address.onkeydown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      address.dispatchEvent(new Event("change"));
    } else if (event.key === "Escape") {
      address.value = rangeAddress();
      scroll.focus();
    }
  };
  scroll.oncopy = (event) => {
    if (editing || !event.clipboardData) return;
    guard(() => {
      const range = selectionRange();
      let clipboardModel = model;
      if (host.readOnly && opaque.size) {
        const cached2 = {};
        for (const key of opaque) {
          if (!key.startsWith(sheet.id + "!")) continue;
          const value = state2.calculation?.get(key)?.value;
          if (value) cached2[key.slice(sheet.id.length + 1)] = { value };
        }
        clipboardModel = { ...clipboardModel, sheets: clipboardModel.sheets.map((s) => s.id === sheet.id ? { ...s, cells: { ...s.cells, ...cached2 } } : s) };
      }
      const values = exportTsv(clipboardModel, sheet.id, range, { calculation: { cells: state2.calculation ?? /* @__PURE__ */ new Map(), computedCells: 0, steps: 0, get: (sid, r, c) => {
        const value = clipboardModel.sheets.find((x) => x.id === sid)?.cells[`${r}:${c}`]?.value;
        return value?.kind === "formula" ? state2.calculation?.get(calculationKey(sid, r, c)) ?? { state: "stale" } : { state: "valid", value: value ?? { kind: "blank" } };
      } } });
      event.clipboardData.setData("text/plain", values);
      const nonce = crypto.randomUUID();
      copied = { nonce, documentId: model.documentId, contentId: snapshot.contentId, sheetId: sheet.id, range };
      event.clipboardData.setData("application/x-office-ex-sheets-range", nonce);
      event.preventDefault();
    });
  };
  scroll.onpaste = (event) => {
    if (editing || host.readOnly || !event.clipboardData) return;
    event.preventDefault();
    guard(() => {
      const marker = event.clipboardData.getData("application/x-office-ex-sheets-range");
      if (copied && marker === copied.nonce && copied.documentId === model.documentId && copied.contentId === host.snapshot().contentId) changed(copyCells(host.snapshot(), copied.sheetId, copied.range, sheet.id, state2.row, state2.column));
      else changed(pasteTsv(host.snapshot(), sheet.id, state2.row, state2.column, event.clipboardData.getData("text/plain"), options()));
    });
  };
  state2.onCalculation = () => {
    if (root2.isConnected && host.isCurrent()) paint();
  };
  const observer = new ResizeObserver(() => {
    if (!root2.isConnected) {
      observer.disconnect();
      return;
    }
    schedule();
  });
  observer.observe(scroll);
  queueMicrotask(() => {
    if (!root2.isConnected) return;
    scroll.scrollTop = state2.scrollTop;
    scroll.scrollLeft = state2.scrollLeft;
    recalculate(host, state2);
    paint();
  });
  return root2;
}

// packages/i18n/src/catalogs.ts
var english = {
  "open": "Open file",
  "newDraft": "New draft",
  "recent": "RECENT FILES",
  "local": "Local workspace \xB7 Offline first",
  "settings": "Settings",
  "workspace": "Workspace",
  "undo": "Undo",
  "redo": "Redo",
  "saveAs": "Save As",
  "save": "Save",
  "ready": "Ready",
  "theme": "Appearance",
  "system": "System",
  "light": "Light",
  "dark": "Dark",
  "language": "Language",
  "clearRecent": "Clear recent files",
  "settingsNote": "Settings and recovery snapshots stay on this computer.",
  "welcome": "A place for your documents.",
  "welcomeSub": "Independent desktop office suite. This M3 preview includes document and spreadsheet editing within supported format profiles.",
  "newHeading": "Create a local draft",
  "draftHint": "Internal draft format \xB7 .oex",
  "writer": "Document",
  "sheets": "Spreadsheet",
  "slides": "Presentation",
  "writerSub": "Write and format documents",
  "sheetsSub": "Cells, formulas and formatting",
  "slidesSub": "Presentation scene preview",
  "dropTitle": "Open a file, or drop it here",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX drafts",
  "choose": "Choose file",
  "boundary": "Supported DOC/DOCX documents and XLS/XLSX workbooks can be edited and saved. Other files remain read-only and can be copied exactly. Full compatibility is still in development.",
  "formats": "Format infrastructure",
  "containerReady": "Container connected",
  "modern": "Modern formats",
  "legacy": "Legacy formats",
  "draft": "Local drafts",
  "noRecent": "No recent files",
  "untitled": "Untitled",
  "draftLabel": "Office EX draft",
  "readOnly": "Read only \xB7 Structure inspection",
  "unsaved": "Unsaved",
  "saved": "Saved",
  "reading": "Inspecting file structure\u2026",
  "cancel": "Cancel",
  "close": "Close",
  "cancelled": "Operation cancelled",
  "snapshot": "Snapshot",
  "revision": "Revision",
  "savedNote": "Saved successfully",
  "draftNote": "OEX drafts use an internal format. For Office files, create a DOC/DOCX document or XLS/XLSX workbook with the supported features.",
  "textLabel": "Draft text",
  "cellsLabel": "Spreadsheet cells",
  "cellsNote": "Edit cells, formulas and formatting. Value types and the workbook date system are preserved when saving supported formats.",
  "slideLabel": "Scene & hit-test preview",
  "addShape": "Add rectangle",
  "shapeNote": "Click a shape to test coordinates. The full editor arrives in M4.",
  "parts": "Package parts / streams",
  "part": "Part",
  "size": "Size",
  "digest": "SHA-256",
  "version": "Format version",
  "format": "Detected format",
  "copy": "Save exact copy",
  "pending": "Semantic adapter pending",
  "recoveries": "Recoverable drafts",
  "restore": "Recover a copy",
  "discard": "Discard",
  "recoveryNote": "Recovery creates a new unsaved copy and preserves the source file.",
  "recoveryCorrupt": "Corrupt recovery snapshots were isolated and not loaded.",
  "recovered": "Recovered as a new draft",
  "working": "Working",
  "diagnostics": "Compatibility report",
  "noEntries": "No container parts to display.",
  "emptySlide": "Empty slide",
  "clearDone": "Recent file history cleared",
  "draftTitle": "Document title",
  "limitTabs": "At most 32 tabs can be open",
  "stage": "Independent development \xB7 Writer and Sheets",
  "partialDirectorySync": "File saved; this filesystem did not provide directory sync guarantees.",
  "savedMaintenanceWarning": "File saved, but recovery or recent-file bookkeeping could not be updated.",
  "homeLabel": "Office EX home",
  "mainNav": "Main navigation",
  "documents": "Documents",
  "documentActions": "Document actions",
  "previewTag": "M3 \xB7 DEVELOPMENT PREVIEW",
  "eyebrow": "OFFICE EX / YOUR LOCAL WORKSPACE",
  "region": "Regional formats",
  "documentLanguage": "New document language (preference)",
  "documentLanguageNote": "New Writer documents use this text language. Existing files are unchanged; other editors will adopt it later.",
  "regionSample": "Regional format preview",
  "history": "History",
  "canvas": "Canvas",
  "entriesLimited": "{count} entries; first 500 shown.",
  "menuFile": "File",
  "menuEdit": "Edit",
  "menuView": "View",
  "menuNewWriter": "New document draft",
  "menuNewSheets": "New spreadsheet draft",
  "menuNewSlides": "New presentation draft",
  "menuOpen": "Open\u2026",
  "menuSaveAs": "Save As\u2026",
  "menuCloseTab": "Close tab",
  "menuCut": "Cut",
  "menuCopy": "Copy",
  "menuPaste": "Paste",
  "menuSelectAll": "Select All",
  "menuFullscreen": "Toggle Full Screen",
  "menuResetZoom": "Reset Zoom",
  "menuZoomIn": "Zoom In",
  "menuZoomOut": "Zoom Out",
  "officeFiles": "Office documents / Office EX drafts",
  "allFiles": "All files",
  "originalFormat": "Original file format",
  "replaceTarget": "Replace the existing target?",
  "replace": "Replace",
  "saveBeforeClose": "Save changes before closing?",
  "discardChanges": "Discard changes",
  "openFailed": "Unable to open file",
  "windowFailed": "Unable to open window",
  "finishComposition": "Finish the current input before changing language.",
  "oneDroppedFile": "Open one dropped file at a time.",
  "errorInvalid": "Invalid file or request.",
  "errorUnsupported": "This feature or format is not supported yet.",
  "errorUnsafe": "The operation was blocked for safety.",
  "errorLimit": "The operation exceeds a resource limit.",
  "errorConflict": "The document or target has changed.",
  "errorIo": "The file operation failed.",
  "errorInternal": "An internal error occurred.",
  "diagUnknown": "An unrecognized compatibility diagnostic was reported.",
  "diagSemanticPending": "Container inspection only. Editable document semantics have not been imported.",
  "diagMacrosDisabled": "Macro-related content detected. Macros do not execute; bytes are retained only in exact copies.",
  "diagSignedReadOnly": "Signed file: inspection only. Signature validity is not asserted.",
  "diagExternalDisabled": "External relationships are recorded; no external content is loaded.",
  "diagStrictReadOnly": "Strict OOXML identified; semantic reading/writing is unverified.",
  "diagEncryptedUnsupported": "Encrypted container identified. Decryption and editing are unavailable.",
  "diagExtensionMismatch": "The extension differs from the detected content.",
  "writerFormatting": "Text formatting",
  "writerEditNote": "Edit paragraphs and select text to format it. Enter splits a paragraph; Shift+Enter adds a line break.",
  "writerPagePreview": "Page preview",
  "writerEstimated": "Estimated page layout. Click the page to locate text. Print fidelity is not yet verified.",
  "writerPreviousPage": "Previous page",
  "writerNextPage": "Next page",
  "writerPageNumber": "Page {current} / {total}",
  "writerLayoutLimits": "Some typography or layout features are approximated.",
  "writerPreviewUnavailable": "Preview unavailable for this content or layout limit. Source content is unchanged.",
  "writerBold": "Bold",
  "writerItalic": "Italic",
  "writerUnderline": "Underline",
  "writerAlignLeft": "Align left",
  "writerAlignCenter": "Center",
  "writerAlignRight": "Align right",
  "writerSplit": "Split paragraph",
  "writerPageBreak": "Page break after paragraph",
  "writerUnsupportedBlock": "This block is not editable in this preview.",
  "docxNew": "New DOCX document",
  "docxDocument": "DOCX document",
  "docxNote": "Limited DOCX profile: text, direct formatting, supported named styles, fixed rectangular tables, embedded inline PNG/JPEG pictures and basic layout. Complex documents remain read-only.",
  "writerFontFamily": "Font",
  "writerFontSize": "Size (pt)",
  "writerTextColor": "Text color",
  "writerParagraphStyle": "Paragraph style",
  "writerCharacterStyle": "Character style",
  "writerChooseStyle": "Choose a style",
  "writerTable": "Table",
  "writerTableRows": "Rows",
  "writerTableColumns": "Columns",
  "writerInsertTable": "Insert table",
  "writerAddRow": "Add row below",
  "writerDeleteRow": "Delete row",
  "writerAddColumn": "Add column right",
  "writerDeleteColumn": "Delete column",
  "writerColumnWidth": "Column width (pt)",
  "writerTableBorder": "Table borders",
  "writerDeleteTable": "Delete table",
  "writerCell": "Cell {row}, {column}",
  "writerInsertImage": "Insert image",
  "writerImage": "Image",
  "writerImageWidth": "Image width (pt)",
  "writerRemoveImage": "Remove image",
  "writerPaper": "Paper size",
  "writerCustomPaper": "Custom",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "Page orientation",
  "writerPortrait": "Portrait",
  "writerLandscape": "Landscape",
  "writerPageWidth": "Page width (pt)",
  "writerPageHeight": "Page height (pt)",
  "writerMarginTop": "Top margin (pt)",
  "writerMarginRight": "Right margin (pt)",
  "writerMarginBottom": "Bottom margin (pt)",
  "writerMarginLeft": "Left margin (pt)",
  "writerApplyPage": "Apply page settings",
  "writerIndent": "Indent (pt)",
  "writerSpaceBefore": "Before (pt)",
  "writerSpaceAfter": "After (pt)",
  "writerLineHeight": "Line height (pt; 0 = auto)",
  "writerInsertInlineImage": "Insert image at caret",
  "writerInlineImageNote": "The object marker represents an inline image. Use its picture controls to resize or remove it.",
  "writerContinuous": "Edit continuous text",
  "writerExitContinuous": "Back to paragraph editor",
  "writerContinuousNote": "Select, copy, cut, paste or format across adjacent text paragraphs. Tables, page breaks, sections and image paragraphs are selection boundaries. New pasted lines become paragraphs.",
  "writerSection": "Section",
  "writerSectionNumber": "Section {number}",
  "writerSectionBreak": "Next-page section break",
  "writerTextLanguage": "Text language (BCP 47)",
  "writerParagraphDirection": "Paragraph direction",
  "writerLtr": "Left to right",
  "writerRtl": "Right to left",
  "docNew": "New DOC",
  "docDocument": "Word 97\u20132003 document",
  "docNote": "Limited DOC editing: Unicode text, basic styles and one section. Unsupported DOC files remain read-only; tables and pictures cannot be saved in this profile.",
  "docTextPreview": "Read-only main-story text preview, not the complete document layout. Saving a copy preserves the original bytes.",
  "convertDoc": "Convert to DOC",
  "convertDocx": "Convert to DOCX",
  "conversionBoundary": "Conversion requires a document containing only supported structures; opaque parts are preserved in the source, not discarded.",
  "writerPageEdit": "Edit on page",
  "writerExitPageEdit": "Back to tools",
  "writerNativePageNote": "Edit on the page using native browser text shaping. Drag to select; copy and paste retain supported Office EX formatting and images. Page fidelity is not yet verified against Word."
};
var simplified = {
  "open": "\u6253\u5F00\u6587\u4EF6",
  "newDraft": "\u65B0\u5EFA\u8349\u7A3F",
  "recent": "\u6700\u8FD1\u6253\u5F00",
  "local": "\u672C\u5730\u5DE5\u4F5C \xB7 \u79BB\u7EBF\u4F18\u5148",
  "settings": "\u8BBE\u7F6E",
  "workspace": "\u5DE5\u4F5C\u53F0",
  "undo": "\u64A4\u9500",
  "redo": "\u91CD\u505A",
  "saveAs": "\u53E6\u5B58\u4E3A",
  "save": "\u4FDD\u5B58",
  "ready": "\u5C31\u7EEA",
  "theme": "\u5916\u89C2",
  "system": "\u8DDF\u968F\u7CFB\u7EDF",
  "light": "\u6D45\u8272",
  "dark": "\u6DF1\u8272",
  "language": "\u8BED\u8A00",
  "clearRecent": "\u6E05\u9664\u6700\u8FD1\u6587\u4EF6\u8BB0\u5F55",
  "settingsNote": "\u8BBE\u7F6E\u548C\u6062\u590D\u5FEB\u7167\u4EC5\u4FDD\u5B58\u5728\u672C\u673A\u3002",
  "welcome": "\u4F60\u7684\u6587\u6863\uFF0C\u4ECE\u8FD9\u91CC\u5F00\u59CB\u3002",
  "welcomeSub": "\u81EA\u4E3B\u5F00\u53D1\u7684\u684C\u9762\u529E\u516C\u5957\u4EF6\u3002M3 \u9884\u89C8\u7248\u63D0\u4F9B\u5DF2\u652F\u6301\u683C\u5F0F\u8303\u56F4\u5185\u7684\u6587\u6863\u548C\u7535\u5B50\u8868\u683C\u7F16\u8F91\u3002",
  "newHeading": "\u521B\u5EFA\u672C\u5730\u8349\u7A3F",
  "draftHint": "\u5185\u90E8\u8349\u7A3F\u683C\u5F0F \xB7 .oex",
  "writer": "\u6587\u5B57\u6587\u6863",
  "sheets": "\u7535\u5B50\u8868\u683C",
  "slides": "\u6F14\u793A\u6587\u7A3F",
  "writerSub": "\u64B0\u5199\u6587\u6863\u4E0E\u8BBE\u7F6E\u683C\u5F0F",
  "sheetsSub": "\u5355\u5143\u683C\u3001\u516C\u5F0F\u4E0E\u683C\u5F0F",
  "slidesSub": "\u6F14\u793A\u6587\u7A3F\u573A\u666F\u9884\u89C8",
  "dropTitle": "\u6253\u5F00\u6216\u62D6\u5165\u4E00\u4E2A\u6587\u4EF6",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX \u8349\u7A3F",
  "choose": "\u9009\u62E9\u6587\u4EF6",
  "boundary": "\u5DF2\u652F\u6301\u7684 DOC/DOCX \u6587\u6863\u548C XLS/XLSX \u5DE5\u4F5C\u7C3F\u53EF\u7F16\u8F91\u5E76\u4FDD\u5B58\u3002\u5176\u4ED6\u6587\u4EF6\u4EE5\u53EA\u8BFB\u65B9\u5F0F\u6253\u5F00\uFF0C\u53EF\u4FDD\u5B58\u5B8C\u5168\u4E00\u81F4\u7684\u526F\u672C\u3002\u5B8C\u6574\u517C\u5BB9\u6027\u4ECD\u5728\u5F00\u53D1\u4E2D\u3002",
  "formats": "\u683C\u5F0F\u57FA\u7840\u8BBE\u65BD",
  "containerReady": "\u5BB9\u5668\u5DF2\u63A5\u5165",
  "modern": "\u73B0\u4EE3\u683C\u5F0F",
  "legacy": "\u65E7\u7248\u683C\u5F0F",
  "draft": "\u672C\u5730\u8349\u7A3F",
  "noRecent": "\u6682\u65E0\u6700\u8FD1\u6587\u4EF6",
  "untitled": "\u672A\u547D\u540D",
  "draftLabel": "Office EX \u8349\u7A3F",
  "readOnly": "\u53EA\u8BFB \xB7 \u7ED3\u6784\u68C0\u67E5",
  "unsaved": "\u672A\u4FDD\u5B58",
  "saved": "\u5DF2\u4FDD\u5B58",
  "reading": "\u6B63\u5728\u68C0\u67E5\u6587\u4EF6\u7ED3\u6784\u2026",
  "cancel": "\u53D6\u6D88",
  "close": "\u5173\u95ED",
  "cancelled": "\u64CD\u4F5C\u5DF2\u53D6\u6D88",
  "snapshot": "\u5FEB\u7167",
  "revision": "\u7248\u672C",
  "savedNote": "\u4FDD\u5B58\u5B8C\u6210",
  "draftNote": "OEX \u8349\u7A3F\u4F7F\u7528\u5185\u90E8\u683C\u5F0F\u3002\u9700\u8981 Office \u6587\u4EF6\u65F6\uFF0C\u8BF7\u65B0\u5EFA\u5305\u542B\u5DF2\u652F\u6301\u529F\u80FD\u7684 DOC/DOCX \u6587\u6863\u6216 XLS/XLSX \u5DE5\u4F5C\u7C3F\u3002",
  "textLabel": "\u8349\u7A3F\u6587\u672C",
  "cellsLabel": "\u7535\u5B50\u8868\u683C\u5355\u5143\u683C",
  "cellsNote": "\u7F16\u8F91\u5355\u5143\u683C\u3001\u516C\u5F0F\u548C\u683C\u5F0F\uFF1B\u4EE5\u5DF2\u652F\u6301\u683C\u5F0F\u4FDD\u5B58\u65F6\uFF0C\u4FDD\u7559\u6570\u503C\u7C7B\u578B\u548C\u5DE5\u4F5C\u7C3F\u65E5\u671F\u7CFB\u7EDF\u3002",
  "slideLabel": "\u573A\u666F\u4E0E\u547D\u4E2D\u6D4B\u8BD5\u9884\u89C8",
  "addShape": "\u6DFB\u52A0\u77E9\u5F62",
  "shapeNote": "\u70B9\u51FB\u56FE\u5F62\u53EF\u9A8C\u8BC1\u5750\u6807\u547D\u4E2D\uFF1B\u5B8C\u6574\u7F16\u8F91\u5668\u5728 M4 \u5B9E\u73B0\u3002",
  "parts": "\u5305\u90E8\u4EF6 / \u6D41",
  "part": "\u90E8\u4EF6",
  "size": "\u5927\u5C0F",
  "digest": "SHA-256",
  "version": "\u683C\u5F0F\u7248\u672C",
  "format": "\u8BC6\u522B\u683C\u5F0F",
  "copy": "\u539F\u6837\u53E6\u5B58",
  "pending": "\u8BED\u4E49\u9002\u914D\u5C1A\u672A\u5B9E\u73B0",
  "recoveries": "\u53EF\u6062\u590D\u7684\u8349\u7A3F",
  "restore": "\u6062\u590D\u526F\u672C",
  "discard": "\u653E\u5F03",
  "recoveryNote": "\u6062\u590D\u4E3A\u672A\u4FDD\u5B58\u7684\u65B0\u526F\u672C\uFF1B\u539F\u6587\u4EF6\u4FDD\u6301\u4E0D\u53D8\u3002",
  "recoveryCorrupt": "\u6709\u635F\u574F\u7684\u6062\u590D\u5FEB\u7167\uFF0C\u5DF2\u9694\u79BB\uFF0C\u672A\u8F7D\u5165\u3002",
  "recovered": "\u5DF2\u6062\u590D\u4E3A\u65B0\u8349\u7A3F",
  "working": "\u5904\u7406\u4E2D",
  "diagnostics": "\u517C\u5BB9\u6027\u62A5\u544A",
  "noEntries": "\u6CA1\u6709\u53EF\u5C55\u793A\u7684\u5BB9\u5668\u90E8\u4EF6\u3002",
  "emptySlide": "\u7A7A\u767D\u5E7B\u706F\u7247",
  "clearDone": "\u5DF2\u6E05\u9664\u6700\u8FD1\u6587\u4EF6\u8BB0\u5F55",
  "draftTitle": "\u6587\u6863\u6807\u9898",
  "limitTabs": "\u6700\u591A\u540C\u65F6\u6253\u5F00 32 \u4E2A\u6807\u7B7E",
  "stage": "\u81EA\u4E3B\u5F00\u53D1 \xB7 Writer \u548C Sheets",
  "partialDirectorySync": "\u6587\u4EF6\u5DF2\u4FDD\u5B58\uFF1B\u5F53\u524D\u6587\u4EF6\u7CFB\u7EDF\u672A\u63D0\u4F9B\u76EE\u5F55\u540C\u6B65\u4FDD\u8BC1\u3002",
  "savedMaintenanceWarning": "\u6587\u4EF6\u5DF2\u4FDD\u5B58\uFF0C\u4F46\u6062\u590D\u8BB0\u5F55\u6216\u6700\u8FD1\u6587\u4EF6\u8BB0\u5F55\u6E05\u7406\u5931\u8D25\u3002",
  "homeLabel": "Office EX \u9996\u9875",
  "mainNav": "\u4E3B\u5BFC\u822A",
  "documents": "\u6587\u6863",
  "documentActions": "\u6587\u6863\u64CD\u4F5C",
  "previewTag": "M3 \xB7 \u5F00\u53D1\u9884\u89C8\u7248",
  "eyebrow": "OFFICE EX / \u672C\u5730\u5DE5\u4F5C\u7A7A\u95F4",
  "region": "\u5730\u533A\u683C\u5F0F",
  "documentLanguage": "\u65B0\u5EFA\u6587\u6863\u8BED\u8A00\uFF08\u504F\u597D\uFF09",
  "documentLanguageNote": "\u65B0\u5EFA Writer \u6587\u6863\u4F7F\u7528\u6B64\u6587\u5B57\u8BED\u8A00\u3002\u73B0\u6709\u6587\u4EF6\u4FDD\u6301\u4E0D\u53D8\uFF1B\u5176\u4ED6\u7F16\u8F91\u5668\u5C06\u5728\u540E\u7EED\u9636\u6BB5\u63A5\u5165\u3002",
  "regionSample": "\u5730\u533A\u683C\u5F0F\u9884\u89C8",
  "history": "\u5386\u53F2",
  "canvas": "\u753B\u5E03",
  "entriesLimited": "\u5171 {count} \u9879\uFF0C\u4EC5\u663E\u793A\u524D 500 \u9879\u3002",
  "menuFile": "\u6587\u4EF6",
  "menuEdit": "\u7F16\u8F91",
  "menuView": "\u89C6\u56FE",
  "menuNewWriter": "\u65B0\u5EFA\u6587\u5B57\u8349\u7A3F",
  "menuNewSheets": "\u65B0\u5EFA\u8868\u683C\u8349\u7A3F",
  "menuNewSlides": "\u65B0\u5EFA\u6F14\u793A\u8349\u7A3F",
  "menuOpen": "\u6253\u5F00\u2026",
  "menuSaveAs": "\u53E6\u5B58\u4E3A\u2026",
  "menuCloseTab": "\u5173\u95ED\u6807\u7B7E",
  "menuCut": "\u526A\u5207",
  "menuCopy": "\u590D\u5236",
  "menuPaste": "\u7C98\u8D34",
  "menuSelectAll": "\u5168\u9009",
  "menuFullscreen": "\u5207\u6362\u5168\u5C4F",
  "menuResetZoom": "\u91CD\u7F6E\u7F29\u653E",
  "menuZoomIn": "\u653E\u5927",
  "menuZoomOut": "\u7F29\u5C0F",
  "officeFiles": "Office \u6587\u6863 / Office EX \u8349\u7A3F",
  "allFiles": "\u6240\u6709\u6587\u4EF6",
  "originalFormat": "\u539F\u59CB\u6587\u4EF6\u683C\u5F0F",
  "replaceTarget": "\u66FF\u6362\u5DF2\u6709\u76EE\u6807\u6587\u4EF6\uFF1F",
  "replace": "\u66FF\u6362",
  "saveBeforeClose": "\u5173\u95ED\u524D\u4FDD\u5B58\u4FEE\u6539\uFF1F",
  "discardChanges": "\u653E\u5F03\u4FEE\u6539",
  "openFailed": "\u6587\u4EF6\u65E0\u6CD5\u6253\u5F00",
  "windowFailed": "\u7A97\u53E3\u65E0\u6CD5\u6253\u5F00",
  "finishComposition": "\u8BF7\u5148\u5B8C\u6210\u5F53\u524D\u8F93\u5165\uFF0C\u518D\u5207\u6362\u8BED\u8A00\u3002",
  "oneDroppedFile": "\u4E00\u6B21\u53EA\u80FD\u62D6\u5165\u4E00\u4E2A\u6587\u4EF6\u3002",
  "errorInvalid": "\u6587\u4EF6\u6216\u8BF7\u6C42\u65E0\u6548\u3002",
  "errorUnsupported": "\u6682\u4E0D\u652F\u6301\u6B64\u529F\u80FD\u6216\u683C\u5F0F\u3002",
  "errorUnsafe": "\u4E3A\u4FDD\u62A4\u6570\u636E\uFF0C\u5DF2\u963B\u6B62\u6B64\u64CD\u4F5C\u3002",
  "errorLimit": "\u64CD\u4F5C\u8D85\u51FA\u8D44\u6E90\u9650\u5236\u3002",
  "errorConflict": "\u6587\u6863\u6216\u76EE\u6807\u5DF2\u53D1\u751F\u53D8\u5316\u3002",
  "errorIo": "\u6587\u4EF6\u64CD\u4F5C\u5931\u8D25\u3002",
  "errorInternal": "\u53D1\u751F\u5185\u90E8\u9519\u8BEF\u3002",
  "diagUnknown": "\u68C0\u6D4B\u5230\u672A\u8BC6\u522B\u7684\u517C\u5BB9\u6027\u8BCA\u65AD\u3002",
  "diagSemanticPending": "\u5F53\u524D\u4EC5\u68C0\u67E5\u5BB9\u5668\u7ED3\u6784\uFF1B\u5C1A\u672A\u5BFC\u5165\u53EF\u7F16\u8F91\u7684\u6587\u6863\u8BED\u4E49\u3002",
  "diagMacrosDisabled": "\u68C0\u6D4B\u5230\u5B8F\u76F8\u5173\u5185\u5BB9\uFF1B\u5B8F\u4E0D\u4F1A\u6267\u884C\uFF0C\u539F\u59CB\u5185\u5BB9\u4EC5\u968F\u539F\u6837\u526F\u672C\u4FDD\u7559\u3002",
  "diagSignedReadOnly": "\u7B7E\u540D\u6587\u4EF6\u4EC5\u4F5C\u7ED3\u6784\u68C0\u67E5\uFF1B\u4E0D\u4FEE\u6539\u7B7E\u540D\u6216\u58F0\u79F0\u7B7E\u540D\u6709\u6548\u3002",
  "diagExternalDisabled": "\u5916\u90E8\u5173\u7CFB\u5DF2\u8BB0\u5F55\uFF1B\u4E0D\u4F1A\u8FDE\u63A5\u6216\u52A0\u8F7D\u5916\u90E8\u5185\u5BB9\u3002",
  "diagStrictReadOnly": "\u5DF2\u8BC6\u522B Strict OOXML\uFF1B\u8BED\u4E49\u8BFB\u5199\u5C1A\u672A\u9A8C\u8BC1\u3002",
  "diagEncryptedUnsupported": "\u5DF2\u8BC6\u522B\u52A0\u5BC6\u5BB9\u5668\uFF1B\u6B64\u9636\u6BB5\u4E0D\u89E3\u5BC6\u3001\u4E0D\u7F16\u8F91\u3002",
  "diagExtensionMismatch": "\u6587\u4EF6\u6269\u5C55\u540D\u4E0E\u68C0\u6D4B\u5230\u7684\u5185\u5BB9\u4E0D\u4E00\u81F4\u3002",
  "writerFormatting": "\u6587\u5B57\u683C\u5F0F",
  "writerEditNote": "\u5728\u7F16\u8F91\u533A\u4FEE\u6539\u6BB5\u843D\uFF0C\u9009\u4E2D\u6587\u5B57\u540E\u8BBE\u7F6E\u683C\u5F0F\u3002Enter \u5206\u6BB5\uFF0CShift+Enter \u6362\u884C\u3002",
  "writerPagePreview": "\u5206\u9875\u9884\u89C8",
  "writerEstimated": "\u5F53\u524D\u4E3A\u4F30\u7B97\u5206\u9875\u9884\u89C8\uFF0C\u70B9\u51FB\u9875\u9762\u53EF\u5B9A\u4F4D\u6587\u672C\uFF0C\u5C1A\u672A\u9A8C\u8BC1\u6253\u5370\u7CBE\u5EA6\u3002",
  "writerPreviousPage": "\u4E0A\u4E00\u9875",
  "writerNextPage": "\u4E0B\u4E00\u9875",
  "writerPageNumber": "\u7B2C {current} / {total} \u9875",
  "writerLayoutLimits": "\u90E8\u5206\u5B57\u4F53\u6216\u6392\u7248\u6548\u679C\u4ECD\u4E3A\u8FD1\u4F3C\u5904\u7406\u3002",
  "writerPreviewUnavailable": "\u5F53\u524D\u5185\u5BB9\u6216\u5E03\u5C40\u8D85\u51FA\u9884\u89C8\u652F\u6301\u8303\u56F4\uFF0C\u539F\u59CB\u5185\u5BB9\u4FDD\u6301\u4E0D\u53D8\u3002",
  "writerBold": "\u7C97\u4F53",
  "writerItalic": "\u659C\u4F53",
  "writerUnderline": "\u4E0B\u5212\u7EBF",
  "writerAlignLeft": "\u5DE6\u5BF9\u9F50",
  "writerAlignCenter": "\u5C45\u4E2D",
  "writerAlignRight": "\u53F3\u5BF9\u9F50",
  "writerSplit": "\u62C6\u5206\u6BB5\u843D",
  "writerPageBreak": "\u6BB5\u540E\u5206\u9875\u7B26",
  "writerUnsupportedBlock": "\u6B64\u5185\u5BB9\u5757\u6682\u4E0D\u53EF\u7F16\u8F91\u3002",
  "docxNew": "\u65B0\u5EFA DOCX \u6587\u6863",
  "docxDocument": "DOCX \u6587\u6863",
  "docxNote": "\u5F53\u524D DOCX \u652F\u6301\u6587\u672C\u3001\u76F4\u63A5\u683C\u5F0F\u3001\u90E8\u5206\u547D\u540D\u6837\u5F0F\u3001\u56FA\u5B9A\u77E9\u5F62\u8868\u683C\u3001\u5185\u5D4C\u884C\u5185 PNG/JPEG \u56FE\u7247\u53CA\u57FA\u7840\u6392\u7248\uFF0C\u590D\u6742\u6587\u6863\u4ECD\u53EA\u8BFB\u3002",
  "writerFontFamily": "\u5B57\u4F53",
  "writerFontSize": "\u5B57\u53F7\uFF08\u78C5\uFF09",
  "writerTextColor": "\u6587\u5B57\u989C\u8272",
  "writerParagraphStyle": "\u6BB5\u843D\u6837\u5F0F",
  "writerCharacterStyle": "\u5B57\u7B26\u6837\u5F0F",
  "writerChooseStyle": "\u9009\u62E9\u6837\u5F0F",
  "writerTable": "\u8868\u683C",
  "writerTableRows": "\u884C\u6570",
  "writerTableColumns": "\u5217\u6570",
  "writerInsertTable": "\u63D2\u5165\u8868\u683C",
  "writerAddRow": "\u4E0B\u65B9\u63D2\u5165\u884C",
  "writerDeleteRow": "\u5220\u9664\u884C",
  "writerAddColumn": "\u53F3\u4FA7\u63D2\u5165\u5217",
  "writerDeleteColumn": "\u5220\u9664\u5217",
  "writerColumnWidth": "\u5217\u5BBD\uFF08\u78C5\uFF09",
  "writerTableBorder": "\u8868\u683C\u8FB9\u6846",
  "writerDeleteTable": "\u5220\u9664\u8868\u683C",
  "writerCell": "\u5355\u5143\u683C {row}, {column}",
  "writerInsertImage": "\u63D2\u5165\u56FE\u7247",
  "writerImage": "\u56FE\u7247",
  "writerImageWidth": "\u56FE\u7247\u5BBD\u5EA6\uFF08\u78C5\uFF09",
  "writerRemoveImage": "\u5220\u9664\u56FE\u7247",
  "writerPaper": "\u7EB8\u578B",
  "writerCustomPaper": "\u81EA\u5B9A\u4E49",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "\u9875\u9762\u65B9\u5411",
  "writerPortrait": "\u7EB5\u5411",
  "writerLandscape": "\u6A2A\u5411",
  "writerPageWidth": "\u7EB8\u5F20\u5BBD\u5EA6\uFF08\u78C5\uFF09",
  "writerPageHeight": "\u7EB8\u5F20\u9AD8\u5EA6\uFF08\u78C5\uFF09",
  "writerMarginTop": "\u4E0A\u8FB9\u8DDD\uFF08\u78C5\uFF09",
  "writerMarginRight": "\u53F3\u8FB9\u8DDD\uFF08\u78C5\uFF09",
  "writerMarginBottom": "\u4E0B\u8FB9\u8DDD\uFF08\u78C5\uFF09",
  "writerMarginLeft": "\u5DE6\u8FB9\u8DDD\uFF08\u78C5\uFF09",
  "writerApplyPage": "\u5E94\u7528\u9875\u9762\u8BBE\u7F6E",
  "writerIndent": "\u7F29\u8FDB\uFF08\u78C5\uFF09",
  "writerSpaceBefore": "\u6BB5\u524D\uFF08\u78C5\uFF09",
  "writerSpaceAfter": "\u6BB5\u540E\uFF08\u78C5\uFF09",
  "writerLineHeight": "\u884C\u8DDD\uFF08\u78C5\uFF1B0 \u4E3A\u81EA\u52A8\uFF09",
  "writerInsertInlineImage": "\u5149\u6807\u5904\u63D2\u5165\u56FE\u7247",
  "writerInlineImageNote": "\u5BF9\u8C61\u6807\u8BB0\u4EE3\u8868\u884C\u5185\u56FE\u7247\u3002\u8BF7\u901A\u8FC7\u56FE\u7247\u63A7\u4EF6\u7F29\u653E\u6216\u5220\u9664\u3002",
  "writerContinuous": "\u8FDE\u7EED\u6587\u5B57\u7F16\u8F91",
  "writerExitContinuous": "\u8FD4\u56DE\u6BB5\u843D\u7F16\u8F91",
  "writerContinuousNote": "\u53EF\u8DE8\u76F8\u90BB\u6587\u5B57\u6BB5\u843D\u9009\u53D6\u3001\u590D\u5236\u3001\u526A\u5207\u3001\u7C98\u8D34\u548C\u8BBE\u7F6E\u683C\u5F0F\u3002\u8868\u683C\u3001\u5206\u9875\u7B26\u3001\u5206\u8282\u53CA\u56FE\u7247\u6BB5\u843D\u662F\u9009\u533A\u8FB9\u754C\u3002\u65B0\u7C98\u8D34\u7684\u6362\u884C\u6210\u4E3A\u65B0\u6BB5\u843D\u3002",
  "writerSection": "\u5206\u8282",
  "writerSectionNumber": "\u7B2C {number} \u8282",
  "writerSectionBreak": "\u4E0B\u4E00\u9875\u5206\u8282\u7B26",
  "writerTextLanguage": "\u6587\u5B57\u8BED\u8A00\uFF08BCP 47\uFF09",
  "writerParagraphDirection": "\u6BB5\u843D\u65B9\u5411",
  "writerLtr": "\u4ECE\u5DE6\u5230\u53F3",
  "writerRtl": "\u4ECE\u53F3\u5230\u5DE6",
  "docNew": "\u65B0\u5EFA DOC",
  "docDocument": "Word 97\u20132003 \u6587\u6863",
  "docNote": "DOC \u9650\u5B9A\u7F16\u8F91\uFF1AUnicode \u6587\u5B57\u3001\u57FA\u672C\u683C\u5F0F\u548C\u5355\u8282\u9875\u9762\u3002\u4E0D\u652F\u6301\u7684 DOC \u6587\u4EF6\u4FDD\u6301\u53EA\u8BFB\uFF1B\u6B64\u8303\u56F4\u4E0D\u80FD\u4FDD\u5B58\u8868\u683C\u548C\u56FE\u7247\u3002",
  "docTextPreview": "\u53EA\u8BFB\u6B63\u6587\u6587\u5B57\u9884\u89C8\uFF0C\u5E76\u975E\u5B8C\u6574\u6587\u6863\u6392\u7248\u3002\u4FDD\u5B58\u526F\u672C\u4FDD\u7559\u539F\u59CB\u5B57\u8282\u3002",
  "convertDoc": "\u8F6C\u6362\u4E3A DOC",
  "convertDocx": "\u8F6C\u6362\u4E3A DOCX",
  "conversionBoundary": "\u8F6C\u6362\u8981\u6C42\u6587\u6863\u4EC5\u5305\u542B\u5DF2\u652F\u6301\u7684\u7ED3\u6784\uFF1B\u4E0D\u900F\u660E\u90E8\u4EF6\u4FDD\u7559\u5728\u6E90\u6587\u4EF6\u4E2D\uFF0C\u4E0D\u4F1A\u88AB\u4E22\u5F03\u3002",
  "writerPageEdit": "\u9875\u9762\u7F16\u8F91",
  "writerExitPageEdit": "\u8FD4\u56DE\u7F16\u8F91\u5DE5\u5177",
  "writerNativePageNote": "\u4F7F\u7528\u539F\u751F\u6587\u5B57\u5851\u5F62\u76F4\u63A5\u5728\u9875\u9762\u4E0A\u7F16\u8F91\uFF0C\u62D6\u52A8\u53EF\u9009\u53D6\u6587\u5B57\uFF1B\u5185\u90E8\u590D\u5236\u7C98\u8D34\u4FDD\u7559\u652F\u6301\u7684\u683C\u5F0F\u548C\u56FE\u7247\u3002\u5C1A\u672A\u4E0E Word \u9A8C\u8BC1\u6392\u7248\u7CBE\u5EA6\u3002"
};
var traditional = {
  "open": "\u958B\u555F\u6A94\u6848",
  "newDraft": "\u65B0\u589E\u8349\u7A3F",
  "recent": "\u6700\u8FD1\u958B\u555F",
  "local": "\u672C\u6A5F\u5DE5\u4F5C \xB7 \u96E2\u7DDA\u512A\u5148",
  "settings": "\u8A2D\u5B9A",
  "workspace": "\u5DE5\u4F5C\u53F0",
  "undo": "\u5FA9\u539F",
  "redo": "\u91CD\u505A",
  "saveAs": "\u53E6\u5B58\u65B0\u6A94",
  "save": "\u5132\u5B58",
  "ready": "\u5C31\u7DD2",
  "theme": "\u5916\u89C0",
  "system": "\u8DDF\u96A8\u7CFB\u7D71",
  "light": "\u6DFA\u8272",
  "dark": "\u6DF1\u8272",
  "language": "\u8A9E\u8A00",
  "clearRecent": "\u6E05\u9664\u6700\u8FD1\u6A94\u6848\u8A18\u9304",
  "settingsNote": "\u8A2D\u5B9A\u8207\u5FA9\u539F\u5FEB\u7167\u50C5\u5132\u5B58\u5728\u672C\u6A5F\u3002",
  "welcome": "\u4F60\u7684\u6587\u4EF6\uFF0C\u5F9E\u9019\u88E1\u958B\u59CB\u3002",
  "welcomeSub": "\u81EA\u4E3B\u958B\u767C\u7684\u684C\u9762\u8FA6\u516C\u5957\u4EF6\u3002M3 \u9810\u89BD\u7248\u63D0\u4F9B\u5DF2\u652F\u63F4\u683C\u5F0F\u7BC4\u570D\u5167\u7684\u6587\u4EF6\u53CA\u8A66\u7B97\u8868\u7DE8\u8F2F\u3002",
  "newHeading": "\u5EFA\u7ACB\u672C\u6A5F\u8349\u7A3F",
  "draftHint": "\u5167\u90E8\u8349\u7A3F\u683C\u5F0F \xB7 .oex",
  "writer": "\u6587\u5B57\u6587\u4EF6",
  "sheets": "\u8A66\u7B97\u8868",
  "slides": "\u7C21\u5831",
  "writerSub": "\u64B0\u5BEB\u6587\u4EF6\u53CA\u8A2D\u5B9A\u683C\u5F0F",
  "sheetsSub": "\u5132\u5B58\u683C\u3001\u516C\u5F0F\u53CA\u683C\u5F0F",
  "slidesSub": "\u7C21\u5831\u5834\u666F\u9810\u89BD",
  "dropTitle": "\u958B\u555F\u6216\u62D6\u653E\u6A94\u6848",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX \u8349\u7A3F",
  "choose": "\u9078\u64C7\u6A94\u6848",
  "boundary": "\u5DF2\u652F\u63F4\u7684 DOC/DOCX \u6587\u4EF6\u53CA XLS/XLSX \u6D3B\u9801\u7C3F\u53EF\u7DE8\u8F2F\u4E26\u5132\u5B58\u3002\u5176\u4ED6\u6A94\u6848\u4EE5\u552F\u8B80\u65B9\u5F0F\u958B\u555F\uFF0C\u53EF\u5132\u5B58\u5B8C\u5168\u76F8\u540C\u7684\u8907\u672C\u3002\u5B8C\u6574\u76F8\u5BB9\u6027\u4ECD\u5728\u958B\u767C\u4E2D\u3002",
  "formats": "\u683C\u5F0F\u57FA\u790E\u8A2D\u65BD",
  "containerReady": "\u5BB9\u5668\u5DF2\u63A5\u5165",
  "modern": "\u73FE\u4EE3\u683C\u5F0F",
  "legacy": "\u820A\u7248\u683C\u5F0F",
  "draft": "\u672C\u6A5F\u8349\u7A3F",
  "noRecent": "\u66AB\u7121\u6700\u8FD1\u6A94\u6848",
  "untitled": "\u672A\u547D\u540D",
  "draftLabel": "Office EX \u8349\u7A3F",
  "readOnly": "\u552F\u8B80 \xB7 \u7D50\u69CB\u6AA2\u67E5",
  "unsaved": "\u672A\u5132\u5B58",
  "saved": "\u5DF2\u5132\u5B58",
  "reading": "\u6B63\u5728\u6AA2\u67E5\u6A94\u6848\u7D50\u69CB\u2026",
  "cancel": "\u53D6\u6D88",
  "close": "\u95DC\u9589",
  "cancelled": "\u64CD\u4F5C\u5DF2\u53D6\u6D88",
  "snapshot": "\u5FEB\u7167",
  "revision": "\u7248\u672C",
  "savedNote": "\u5132\u5B58\u5B8C\u6210",
  "draftNote": "OEX \u8349\u7A3F\u4F7F\u7528\u5167\u90E8\u683C\u5F0F\u3002\u9700\u8981 Office \u6A94\u6848\u6642\uFF0C\u8ACB\u65B0\u589E\u5305\u542B\u5DF2\u652F\u63F4\u529F\u80FD\u7684 DOC/DOCX \u6587\u4EF6\u6216 XLS/XLSX \u6D3B\u9801\u7C3F\u3002",
  "textLabel": "\u8349\u7A3F\u6587\u5B57",
  "cellsLabel": "\u8A66\u7B97\u8868\u5132\u5B58\u683C",
  "cellsNote": "\u7DE8\u8F2F\u5132\u5B58\u683C\u3001\u516C\u5F0F\u53CA\u683C\u5F0F\uFF1B\u4EE5\u5DF2\u652F\u63F4\u683C\u5F0F\u5132\u5B58\u6642\uFF0C\u4FDD\u7559\u6578\u503C\u985E\u578B\u53CA\u6D3B\u9801\u7C3F\u65E5\u671F\u7CFB\u7D71\u3002",
  "slideLabel": "\u5834\u666F\u8207\u547D\u4E2D\u6E2C\u8A66\u9810\u89BD",
  "addShape": "\u65B0\u589E\u77E9\u5F62",
  "shapeNote": "\u9EDE\u9078\u5716\u5F62\u53EF\u9A57\u8B49\u5EA7\u6A19\u547D\u4E2D\uFF1B\u5B8C\u6574\u7DE8\u8F2F\u5668\u5C07\u65BC M4 \u5BE6\u4F5C\u3002",
  "parts": "\u5957\u4EF6\u90E8\u4EF6 / \u4E32\u6D41",
  "part": "\u90E8\u4EF6",
  "size": "\u5927\u5C0F",
  "digest": "SHA-256",
  "version": "\u683C\u5F0F\u7248\u672C",
  "format": "\u8FA8\u8B58\u683C\u5F0F",
  "copy": "\u539F\u6A23\u53E6\u5B58",
  "pending": "\u8A9E\u610F\u4ECB\u9762\u5C1A\u672A\u5BE6\u4F5C",
  "recoveries": "\u53EF\u5FA9\u539F\u7684\u8349\u7A3F",
  "restore": "\u5FA9\u539F\u526F\u672C",
  "discard": "\u6368\u68C4",
  "recoveryNote": "\u5FA9\u539F\u70BA\u672A\u5132\u5B58\u7684\u65B0\u526F\u672C\uFF1B\u539F\u59CB\u6A94\u6848\u4FDD\u6301\u4E0D\u8B8A\u3002",
  "recoveryCorrupt": "\u640D\u58DE\u7684\u5FA9\u539F\u5FEB\u7167\u5DF2\u9694\u96E2\uFF0C\u672A\u8F09\u5165\u3002",
  "recovered": "\u5DF2\u5FA9\u539F\u70BA\u65B0\u8349\u7A3F",
  "working": "\u8655\u7406\u4E2D",
  "diagnostics": "\u76F8\u5BB9\u6027\u5831\u544A",
  "noEntries": "\u6C92\u6709\u53EF\u986F\u793A\u7684\u5BB9\u5668\u90E8\u4EF6\u3002",
  "emptySlide": "\u7A7A\u767D\u6295\u5F71\u7247",
  "clearDone": "\u5DF2\u6E05\u9664\u6700\u8FD1\u6A94\u6848\u8A18\u9304",
  "draftTitle": "\u6587\u4EF6\u6A19\u984C",
  "limitTabs": "\u6700\u591A\u540C\u6642\u958B\u555F 32 \u500B\u5206\u9801",
  "stage": "\u81EA\u4E3B\u958B\u767C \xB7 Writer \u8207 Sheets",
  "partialDirectorySync": "\u6A94\u6848\u5DF2\u5132\u5B58\uFF1B\u76EE\u524D\u6A94\u6848\u7CFB\u7D71\u672A\u63D0\u4F9B\u76EE\u9304\u540C\u6B65\u4FDD\u8B49\u3002",
  "savedMaintenanceWarning": "\u6A94\u6848\u5DF2\u5132\u5B58\uFF0C\u4F46\u5FA9\u539F\u8A18\u9304\u6216\u6700\u8FD1\u6A94\u6848\u8A18\u9304\u6E05\u7406\u5931\u6557\u3002",
  "homeLabel": "Office EX \u9996\u9801",
  "mainNav": "\u4E3B\u5C0E\u89BD",
  "documents": "\u6587\u4EF6",
  "documentActions": "\u6587\u4EF6\u64CD\u4F5C",
  "previewTag": "M3 \xB7 \u958B\u767C\u9810\u89BD\u7248",
  "eyebrow": "OFFICE EX / \u672C\u6A5F\u5DE5\u4F5C\u7A7A\u9593",
  "region": "\u5730\u5340\u683C\u5F0F",
  "documentLanguage": "\u65B0\u589E\u6587\u4EF6\u8A9E\u8A00\uFF08\u504F\u597D\uFF09",
  "documentLanguageNote": "\u65B0\u589E Writer \u6587\u4EF6\u4F7F\u7528\u6B64\u6587\u5B57\u8A9E\u8A00\u3002\u73FE\u6709\u6A94\u6848\u4FDD\u6301\u4E0D\u8B8A\uFF1B\u5176\u4ED6\u7DE8\u8F2F\u5668\u5C07\u65BC\u5F8C\u7E8C\u968E\u6BB5\u63A5\u5165\u3002",
  "regionSample": "\u5730\u5340\u683C\u5F0F\u9810\u89BD",
  "history": "\u6B77\u7A0B\u8A18\u9304",
  "canvas": "\u756B\u5E03",
  "entriesLimited": "\u5171 {count} \u9805\uFF0C\u50C5\u986F\u793A\u524D 500 \u9805\u3002",
  "menuFile": "\u6A94\u6848",
  "menuEdit": "\u7DE8\u8F2F",
  "menuView": "\u6AA2\u8996",
  "menuNewWriter": "\u65B0\u589E\u6587\u5B57\u8349\u7A3F",
  "menuNewSheets": "\u65B0\u589E\u8A66\u7B97\u8868\u8349\u7A3F",
  "menuNewSlides": "\u65B0\u589E\u7C21\u5831\u8349\u7A3F",
  "menuOpen": "\u958B\u555F\u2026",
  "menuSaveAs": "\u53E6\u5B58\u65B0\u6A94\u2026",
  "menuCloseTab": "\u95DC\u9589\u5206\u9801",
  "menuCut": "\u526A\u4E0B",
  "menuCopy": "\u8907\u88FD",
  "menuPaste": "\u8CBC\u4E0A",
  "menuSelectAll": "\u5168\u9078",
  "menuFullscreen": "\u5207\u63DB\u5168\u87A2\u5E55",
  "menuResetZoom": "\u91CD\u8A2D\u7E2E\u653E",
  "menuZoomIn": "\u653E\u5927",
  "menuZoomOut": "\u7E2E\u5C0F",
  "officeFiles": "Office \u6587\u4EF6 / Office EX \u8349\u7A3F",
  "allFiles": "\u6240\u6709\u6A94\u6848",
  "originalFormat": "\u539F\u59CB\u6A94\u6848\u683C\u5F0F",
  "replaceTarget": "\u53D6\u4EE3\u73FE\u6709\u76EE\u6A19\u6A94\u6848\uFF1F",
  "replace": "\u53D6\u4EE3",
  "saveBeforeClose": "\u95DC\u9589\u524D\u5132\u5B58\u8B8A\u66F4\uFF1F",
  "discardChanges": "\u6368\u68C4\u8B8A\u66F4",
  "openFailed": "\u7121\u6CD5\u958B\u555F\u6A94\u6848",
  "windowFailed": "\u7121\u6CD5\u958B\u555F\u8996\u7A97",
  "finishComposition": "\u8ACB\u5148\u5B8C\u6210\u76EE\u524D\u7684\u8F38\u5165\uFF0C\u518D\u5207\u63DB\u8A9E\u8A00\u3002",
  "oneDroppedFile": "\u4E00\u6B21\u53EA\u80FD\u62D6\u5165\u4E00\u500B\u6A94\u6848\u3002",
  "errorInvalid": "\u6A94\u6848\u6216\u8ACB\u6C42\u7121\u6548\u3002",
  "errorUnsupported": "\u5C1A\u672A\u652F\u63F4\u6B64\u529F\u80FD\u6216\u683C\u5F0F\u3002",
  "errorUnsafe": "\u70BA\u4FDD\u8B77\u8CC7\u6599\uFF0C\u5DF2\u5C01\u9396\u6B64\u64CD\u4F5C\u3002",
  "errorLimit": "\u64CD\u4F5C\u8D85\u51FA\u8CC7\u6E90\u9650\u5236\u3002",
  "errorConflict": "\u6587\u4EF6\u6216\u76EE\u6A19\u5DF2\u767C\u751F\u8B8A\u66F4\u3002",
  "errorIo": "\u6A94\u6848\u64CD\u4F5C\u5931\u6557\u3002",
  "errorInternal": "\u767C\u751F\u5167\u90E8\u932F\u8AA4\u3002",
  "diagUnknown": "\u5075\u6E2C\u5230\u7121\u6CD5\u8FA8\u8B58\u7684\u76F8\u5BB9\u6027\u8A3A\u65B7\u3002",
  "diagSemanticPending": "\u76EE\u524D\u50C5\u6AA2\u67E5\u5BB9\u5668\u7D50\u69CB\uFF1B\u5C1A\u672A\u532F\u5165\u53EF\u7DE8\u8F2F\u7684\u6587\u4EF6\u5167\u5BB9\u3002",
  "diagMacrosDisabled": "\u5075\u6E2C\u5230\u5DE8\u96C6\u5167\u5BB9\uFF1B\u4E0D\u57F7\u884C\u5DE8\u96C6\uFF0C\u50C5\u5728\u539F\u6A23\u526F\u672C\u4FDD\u7559\u539F\u59CB\u5167\u5BB9\u3002",
  "diagSignedReadOnly": "\u7C3D\u7AE0\u6A94\u6848\u50C5\u4F9B\u7D50\u69CB\u6AA2\u67E5\uFF1B\u4E0D\u4FEE\u6539\u7C3D\u7AE0\u6216\u8072\u7A31\u7C3D\u7AE0\u6709\u6548\u3002",
  "diagExternalDisabled": "\u5916\u90E8\u95DC\u806F\u5DF2\u8A18\u9304\uFF1B\u4E0D\u6703\u9023\u7DDA\u6216\u8F09\u5165\u5916\u90E8\u5167\u5BB9\u3002",
  "diagStrictReadOnly": "\u5DF2\u8FA8\u8B58 Strict OOXML\uFF1B\u5167\u5BB9\u8B80\u5BEB\u5C1A\u672A\u9A57\u8B49\u3002",
  "diagEncryptedUnsupported": "\u5DF2\u8FA8\u8B58\u52A0\u5BC6\u5BB9\u5668\uFF1B\u6B64\u968E\u6BB5\u4E0D\u89E3\u5BC6\u3001\u4E0D\u7DE8\u8F2F\u3002",
  "diagExtensionMismatch": "\u526F\u6A94\u540D\u8207\u5075\u6E2C\u5230\u7684\u5167\u5BB9\u4E0D\u4E00\u81F4\u3002",
  "writerFormatting": "\u6587\u5B57\u683C\u5F0F",
  "writerEditNote": "\u5728\u7DE8\u8F2F\u5340\u4FEE\u6539\u6BB5\u843D\uFF0C\u9078\u53D6\u6587\u5B57\u5F8C\u8A2D\u5B9A\u683C\u5F0F\u3002Enter \u5206\u6BB5\uFF0CShift+Enter \u63DB\u884C\u3002",
  "writerPagePreview": "\u5206\u9801\u9810\u89BD",
  "writerEstimated": "\u76EE\u524D\u70BA\u4F30\u7B97\u5206\u9801\u9810\u89BD\uFF0C\u9EDE\u9078\u9801\u9762\u53EF\u5B9A\u4F4D\u6587\u5B57\uFF0C\u5C1A\u672A\u9A57\u8B49\u5217\u5370\u7CBE\u5EA6\u3002",
  "writerPreviousPage": "\u4E0A\u4E00\u9801",
  "writerNextPage": "\u4E0B\u4E00\u9801",
  "writerPageNumber": "\u7B2C {current} / {total} \u9801",
  "writerLayoutLimits": "\u90E8\u5206\u5B57\u578B\u6216\u6392\u7248\u6548\u679C\u4ECD\u70BA\u8FD1\u4F3C\u8655\u7406\u3002",
  "writerPreviewUnavailable": "\u76EE\u524D\u5167\u5BB9\u6216\u7248\u9762\u8D85\u51FA\u9810\u89BD\u652F\u63F4\u7BC4\u570D\uFF0C\u539F\u59CB\u5167\u5BB9\u4FDD\u6301\u4E0D\u8B8A\u3002",
  "writerBold": "\u7C97\u9AD4",
  "writerItalic": "\u659C\u9AD4",
  "writerUnderline": "\u5E95\u7DDA",
  "writerAlignLeft": "\u9760\u5DE6\u5C0D\u9F4A",
  "writerAlignCenter": "\u7F6E\u4E2D",
  "writerAlignRight": "\u9760\u53F3\u5C0D\u9F4A",
  "writerSplit": "\u5206\u5272\u6BB5\u843D",
  "writerPageBreak": "\u6BB5\u5F8C\u5206\u9801\u7B26",
  "writerUnsupportedBlock": "\u6B64\u5167\u5BB9\u5340\u584A\u66AB\u4E0D\u53EF\u7DE8\u8F2F\u3002",
  "docxNew": "\u65B0\u589E DOCX \u6587\u4EF6",
  "docxDocument": "DOCX \u6587\u4EF6",
  "docxNote": "\u76EE\u524D DOCX \u652F\u63F4\u6587\u5B57\u3001\u76F4\u63A5\u683C\u5F0F\u3001\u90E8\u5206\u547D\u540D\u6A23\u5F0F\u3001\u56FA\u5B9A\u77E9\u5F62\u8868\u683C\u3001\u5167\u5D4C\u884C\u5167 PNG/JPEG \u5716\u7247\u8207\u57FA\u672C\u6392\u7248\uFF0C\u8907\u96DC\u6587\u4EF6\u4ECD\u552F\u8B80\u3002",
  "writerFontFamily": "\u5B57\u578B",
  "writerFontSize": "\u5B57\u7D1A\uFF08\u9EDE\uFF09",
  "writerTextColor": "\u6587\u5B57\u984F\u8272",
  "writerParagraphStyle": "\u6BB5\u843D\u6A23\u5F0F",
  "writerCharacterStyle": "\u5B57\u5143\u6A23\u5F0F",
  "writerChooseStyle": "\u9078\u64C7\u6A23\u5F0F",
  "writerTable": "\u8868\u683C",
  "writerTableRows": "\u5217\u6578",
  "writerTableColumns": "\u6B04\u6578",
  "writerInsertTable": "\u63D2\u5165\u8868\u683C",
  "writerAddRow": "\u4E0B\u65B9\u63D2\u5165\u5217",
  "writerDeleteRow": "\u522A\u9664\u5217",
  "writerAddColumn": "\u53F3\u5074\u63D2\u5165\u6B04",
  "writerDeleteColumn": "\u522A\u9664\u6B04",
  "writerColumnWidth": "\u6B04\u5BEC\uFF08\u9EDE\uFF09",
  "writerTableBorder": "\u8868\u683C\u6846\u7DDA",
  "writerDeleteTable": "\u522A\u9664\u8868\u683C",
  "writerCell": "\u5132\u5B58\u683C {row}, {column}",
  "writerInsertImage": "\u63D2\u5165\u5716\u7247",
  "writerImage": "\u5716\u7247",
  "writerImageWidth": "\u5716\u7247\u5BEC\u5EA6\uFF08\u9EDE\uFF09",
  "writerRemoveImage": "\u522A\u9664\u5716\u7247",
  "writerPaper": "\u7D19\u578B",
  "writerCustomPaper": "\u81EA\u8A02",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "\u9801\u9762\u65B9\u5411",
  "writerPortrait": "\u76F4\u5411",
  "writerLandscape": "\u6A6B\u5411",
  "writerPageWidth": "\u7D19\u5F35\u5BEC\u5EA6\uFF08\u9EDE\uFF09",
  "writerPageHeight": "\u7D19\u5F35\u9AD8\u5EA6\uFF08\u9EDE\uFF09",
  "writerMarginTop": "\u4E0A\u908A\u754C\uFF08\u9EDE\uFF09",
  "writerMarginRight": "\u53F3\u908A\u754C\uFF08\u9EDE\uFF09",
  "writerMarginBottom": "\u4E0B\u908A\u754C\uFF08\u9EDE\uFF09",
  "writerMarginLeft": "\u5DE6\u908A\u754C\uFF08\u9EDE\uFF09",
  "writerApplyPage": "\u5957\u7528\u9801\u9762\u8A2D\u5B9A",
  "writerIndent": "\u7E2E\u6392\uFF08\u9EDE\uFF09",
  "writerSpaceBefore": "\u6BB5\u524D\uFF08\u9EDE\uFF09",
  "writerSpaceAfter": "\u6BB5\u5F8C\uFF08\u9EDE\uFF09",
  "writerLineHeight": "\u884C\u8DDD\uFF08\u9EDE\uFF1B0 \u70BA\u81EA\u52D5\uFF09",
  "writerInsertInlineImage": "\u5728\u6E38\u6A19\u8655\u63D2\u5165\u5716\u7247",
  "writerInlineImageNote": "\u7269\u4EF6\u6A19\u8A18\u4EE3\u8868\u884C\u5167\u5716\u7247\u3002\u8ACB\u900F\u904E\u5716\u7247\u63A7\u5236\u9805\u7E2E\u653E\u6216\u522A\u9664\u3002",
  "writerContinuous": "\u9023\u7E8C\u6587\u5B57\u7DE8\u8F2F",
  "writerExitContinuous": "\u8FD4\u56DE\u6BB5\u843D\u7DE8\u8F2F",
  "writerContinuousNote": "\u53EF\u8DE8\u76F8\u9130\u6587\u5B57\u6BB5\u843D\u9078\u53D6\u3001\u8907\u88FD\u3001\u526A\u4E0B\u3001\u8CBC\u4E0A\u548C\u8A2D\u5B9A\u683C\u5F0F\u3002\u8868\u683C\u3001\u5206\u9801\u7B26\u3001\u5206\u7BC0\u8207\u5716\u7247\u6BB5\u843D\u662F\u9078\u53D6\u908A\u754C\u3002\u65B0\u8CBC\u4E0A\u7684\u63DB\u884C\u6210\u70BA\u65B0\u6BB5\u843D\u3002",
  "writerSection": "\u5206\u7BC0",
  "writerSectionNumber": "\u7B2C {number} \u7BC0",
  "writerSectionBreak": "\u4E0B\u4E00\u9801\u5206\u7BC0\u7B26",
  "writerTextLanguage": "\u6587\u5B57\u8A9E\u8A00\uFF08BCP 47\uFF09",
  "writerParagraphDirection": "\u6BB5\u843D\u65B9\u5411",
  "writerLtr": "\u5F9E\u5DE6\u5230\u53F3",
  "writerRtl": "\u5F9E\u53F3\u5230\u5DE6",
  "docNew": "\u65B0\u589E DOC",
  "docDocument": "Word 97\u20132003 \u6587\u4EF6",
  "docNote": "DOC \u9650\u5B9A\u7DE8\u8F2F\uFF1AUnicode \u6587\u5B57\u3001\u57FA\u672C\u683C\u5F0F\u8207\u55AE\u7BC0\u9801\u9762\u3002\u4E0D\u652F\u63F4\u7684 DOC \u6A94\u6848\u7DAD\u6301\u552F\u8B80\uFF1B\u6B64\u7BC4\u570D\u7121\u6CD5\u5132\u5B58\u8868\u683C\u53CA\u5716\u7247\u3002",
  "docTextPreview": "\u552F\u8B80\u6B63\u6587\u6587\u5B57\u9810\u89BD\uFF0C\u4E26\u975E\u5B8C\u6574\u6587\u4EF6\u6392\u7248\u3002\u5132\u5B58\u526F\u672C\u4FDD\u7559\u539F\u59CB\u4F4D\u5143\u7D44\u3002",
  "convertDoc": "\u8F49\u63DB\u70BA DOC",
  "convertDocx": "\u8F49\u63DB\u70BA DOCX",
  "conversionBoundary": "\u8F49\u63DB\u8981\u6C42\u6587\u4EF6\u50C5\u542B\u5DF2\u652F\u63F4\u7684\u7D50\u69CB\uFF1B\u4E0D\u900F\u660E\u90E8\u4EF6\u4FDD\u7559\u65BC\u4F86\u6E90\u6A94\u6848\uFF0C\u4E0D\u6703\u906D\u4E1F\u68C4\u3002",
  "writerPageEdit": "\u9801\u9762\u7DE8\u8F2F",
  "writerExitPageEdit": "\u8FD4\u56DE\u7DE8\u8F2F\u5DE5\u5177",
  "writerNativePageNote": "\u4F7F\u7528\u539F\u751F\u6587\u5B57\u5851\u5F62\u76F4\u63A5\u5728\u9801\u9762\u4E0A\u7DE8\u8F2F\uFF0C\u62D6\u66F3\u53EF\u9078\u53D6\u6587\u5B57\uFF1B\u5167\u90E8\u8907\u88FD\u8CBC\u4E0A\u4FDD\u7559\u652F\u63F4\u7684\u683C\u5F0F\u8207\u5716\u7247\u3002\u5C1A\u672A\u8207 Word \u9A57\u8B49\u6392\u7248\u7CBE\u5EA6\u3002"
};
var japanese = {
  "open": "\u30D5\u30A1\u30A4\u30EB\u3092\u958B\u304F",
  "newDraft": "\u65B0\u898F\u4E0B\u66F8\u304D",
  "recent": "\u6700\u8FD1\u4F7F\u3063\u305F\u30D5\u30A1\u30A4\u30EB",
  "local": "\u30ED\u30FC\u30AB\u30EB\u4F5C\u696D \xB7 \u30AA\u30D5\u30E9\u30A4\u30F3\u512A\u5148",
  "settings": "\u8A2D\u5B9A",
  "workspace": "\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9",
  "undo": "\u5143\u306B\u623B\u3059",
  "redo": "\u3084\u308A\u76F4\u3059",
  "saveAs": "\u540D\u524D\u3092\u4ED8\u3051\u3066\u4FDD\u5B58",
  "save": "\u4FDD\u5B58",
  "ready": "\u6E96\u5099\u5B8C\u4E86",
  "theme": "\u5916\u89B3",
  "system": "\u30B7\u30B9\u30C6\u30E0\u306B\u5F93\u3046",
  "light": "\u30E9\u30A4\u30C8",
  "dark": "\u30C0\u30FC\u30AF",
  "language": "\u8A00\u8A9E",
  "clearRecent": "\u6700\u8FD1\u4F7F\u3063\u305F\u30D5\u30A1\u30A4\u30EB\u3092\u6D88\u53BB",
  "settingsNote": "\u8A2D\u5B9A\u3068\u5FA9\u5143\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u306F\u3053\u306E\u7AEF\u672B\u306B\u4FDD\u5B58\u3055\u308C\u307E\u3059\u3002",
  "welcome": "\u30C9\u30AD\u30E5\u30E1\u30F3\u30C8\u306F\u3053\u3053\u304B\u3089\u3002",
  "welcomeSub": "\u72EC\u81EA\u958B\u767A\u306E\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7\u30AA\u30D5\u30A3\u30B9\u30B9\u30A4\u30FC\u30C8\u3067\u3059\u3002M3 \u30D7\u30EC\u30D3\u30E5\u30FC\u3067\u306F\u3001\u5BFE\u5FDC\u5F62\u5F0F\u306E\u7BC4\u56F2\u5185\u3067\u6587\u66F8\u3068\u8868\u8A08\u7B97\u3092\u7DE8\u96C6\u3067\u304D\u307E\u3059\u3002",
  "newHeading": "\u30ED\u30FC\u30AB\u30EB\u306E\u4E0B\u66F8\u304D\u3092\u4F5C\u6210",
  "draftHint": "\u5185\u90E8\u4E0B\u66F8\u304D\u5F62\u5F0F \xB7 .oex",
  "writer": "\u6587\u66F8",
  "sheets": "\u30B9\u30D7\u30EC\u30C3\u30C9\u30B7\u30FC\u30C8",
  "slides": "\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3",
  "writerSub": "\u6587\u66F8\u306E\u4F5C\u6210\u3068\u66F8\u5F0F\u8A2D\u5B9A",
  "sheetsSub": "\u30BB\u30EB\u3001\u6570\u5F0F\u3001\u66F8\u5F0F",
  "slidesSub": "\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u306E\u30B7\u30FC\u30F3\u30D7\u30EC\u30D3\u30E5\u30FC",
  "dropTitle": "\u30D5\u30A1\u30A4\u30EB\u3092\u958B\u304F\u304B\u30C9\u30ED\u30C3\u30D7",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX \u4E0B\u66F8\u304D",
  "choose": "\u30D5\u30A1\u30A4\u30EB\u3092\u9078\u629E",
  "boundary": "\u5BFE\u5FDC\u3059\u308B DOC/DOCX \u6587\u66F8\u3068 XLS/XLSX \u30D6\u30C3\u30AF\u3092\u7DE8\u96C6\u30FB\u4FDD\u5B58\u3067\u304D\u307E\u3059\u3002\u305D\u306E\u4ED6\u306E\u30D5\u30A1\u30A4\u30EB\u306F\u8AAD\u307F\u53D6\u308A\u5C02\u7528\u3067\u958B\u304D\u3001\u5B8C\u5168\u306A\u30B3\u30D4\u30FC\u3092\u4FDD\u5B58\u3067\u304D\u307E\u3059\u3002\u5B8C\u5168\u306A\u4E92\u63DB\u6027\u306F\u958B\u767A\u4E2D\u3067\u3059\u3002",
  "formats": "\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u306E\u57FA\u76E4",
  "containerReady": "\u30B3\u30F3\u30C6\u30CA\u5BFE\u5FDC\u6E08\u307F",
  "modern": "\u65B0\u3057\u3044\u5F62\u5F0F",
  "legacy": "\u65E7\u5F62\u5F0F",
  "draft": "\u30ED\u30FC\u30AB\u30EB\u306E\u4E0B\u66F8\u304D",
  "noRecent": "\u6700\u8FD1\u4F7F\u3063\u305F\u30D5\u30A1\u30A4\u30EB\u306F\u3042\u308A\u307E\u305B\u3093",
  "untitled": "\u7121\u984C",
  "draftLabel": "Office EX \u4E0B\u66F8\u304D",
  "readOnly": "\u8AAD\u307F\u53D6\u308A\u5C02\u7528 \xB7 \u69CB\u9020\u691C\u67FB",
  "unsaved": "\u672A\u4FDD\u5B58",
  "saved": "\u4FDD\u5B58\u6E08\u307F",
  "reading": "\u30D5\u30A1\u30A4\u30EB\u69CB\u9020\u3092\u691C\u67FB\u4E2D\u2026",
  "cancel": "\u30AD\u30E3\u30F3\u30BB\u30EB",
  "close": "\u9589\u3058\u308B",
  "cancelled": "\u64CD\u4F5C\u3092\u30AD\u30E3\u30F3\u30BB\u30EB\u3057\u307E\u3057\u305F",
  "snapshot": "\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8",
  "revision": "\u30EA\u30D3\u30B8\u30E7\u30F3",
  "savedNote": "\u4FDD\u5B58\u3057\u307E\u3057\u305F",
  "draftNote": "OEX \u306E\u4E0B\u66F8\u304D\u306F\u5185\u90E8\u5F62\u5F0F\u3067\u3059\u3002Office \u30D5\u30A1\u30A4\u30EB\u304C\u5FC5\u8981\u306A\u5834\u5408\u306F\u3001\u5BFE\u5FDC\u3059\u308B\u6A5F\u80FD\u3067 DOC/DOCX \u6587\u66F8\u307E\u305F\u306F XLS/XLSX \u30D6\u30C3\u30AF\u3092\u4F5C\u6210\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
  "textLabel": "\u4E0B\u66F8\u304D\u30C6\u30AD\u30B9\u30C8",
  "cellsLabel": "\u8868\u8A08\u7B97\u306E\u30BB\u30EB",
  "cellsNote": "\u30BB\u30EB\u3001\u6570\u5F0F\u3001\u66F8\u5F0F\u3092\u7DE8\u96C6\u3067\u304D\u307E\u3059\u3002\u5BFE\u5FDC\u5F62\u5F0F\u3067\u4FDD\u5B58\u3059\u308B\u3068\u3001\u5024\u306E\u578B\u3068\u30D6\u30C3\u30AF\u306E\u65E5\u4ED8\u30B7\u30B9\u30C6\u30E0\u304C\u4FDD\u6301\u3055\u308C\u307E\u3059\u3002",
  "slideLabel": "\u30B7\u30FC\u30F3\u3068\u30D2\u30C3\u30C8\u30C6\u30B9\u30C8\u306E\u30D7\u30EC\u30D3\u30E5\u30FC",
  "addShape": "\u56DB\u89D2\u5F62\u3092\u8FFD\u52A0",
  "shapeNote": "\u56F3\u5F62\u3092\u30AF\u30EA\u30C3\u30AF\u3057\u3066\u5EA7\u6A19\u5224\u5B9A\u3092\u78BA\u8A8D\u3067\u304D\u307E\u3059\u3002\u5B8C\u5168\u306A\u30A8\u30C7\u30A3\u30BF\u30FC\u306F M4 \u3067\u5BFE\u5FDC\u3057\u307E\u3059\u3002",
  "parts": "\u30D1\u30C3\u30B1\u30FC\u30B8\u306E\u30D1\u30FC\u30C4 / \u30B9\u30C8\u30EA\u30FC\u30E0",
  "part": "\u30D1\u30FC\u30C4",
  "size": "\u30B5\u30A4\u30BA",
  "digest": "SHA-256",
  "version": "\u5F62\u5F0F\u30D0\u30FC\u30B8\u30E7\u30F3",
  "format": "\u691C\u51FA\u3055\u308C\u305F\u5F62\u5F0F",
  "copy": "\u5B8C\u5168\u30B3\u30D4\u30FC\u3092\u4FDD\u5B58",
  "pending": "\u5185\u5BB9\u306E\u8AAD\u307F\u66F8\u304D\u306F\u672A\u5BFE\u5FDC",
  "recoveries": "\u5FA9\u5143\u53EF\u80FD\u306A\u4E0B\u66F8\u304D",
  "restore": "\u30B3\u30D4\u30FC\u3092\u5FA9\u5143",
  "discard": "\u7834\u68C4",
  "recoveryNote": "\u672A\u4FDD\u5B58\u306E\u65B0\u3057\u3044\u30B3\u30D4\u30FC\u3068\u3057\u3066\u5FA9\u5143\u3057\u3001\u5143\u306E\u30D5\u30A1\u30A4\u30EB\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002",
  "recoveryCorrupt": "\u7834\u640D\u3057\u305F\u5FA9\u5143\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u306F\u9694\u96E2\u3055\u308C\u3001\u8AAD\u307F\u8FBC\u307E\u308C\u3066\u3044\u307E\u305B\u3093\u3002",
  "recovered": "\u65B0\u3057\u3044\u4E0B\u66F8\u304D\u3068\u3057\u3066\u5FA9\u5143\u3057\u307E\u3057\u305F",
  "working": "\u51E6\u7406\u4E2D",
  "diagnostics": "\u4E92\u63DB\u6027\u30EC\u30DD\u30FC\u30C8",
  "noEntries": "\u8868\u793A\u3067\u304D\u308B\u30D1\u30FC\u30C4\u304C\u3042\u308A\u307E\u305B\u3093\u3002",
  "emptySlide": "\u7A7A\u767D\u30B9\u30E9\u30A4\u30C9",
  "clearDone": "\u6700\u8FD1\u4F7F\u3063\u305F\u30D5\u30A1\u30A4\u30EB\u306E\u5C65\u6B74\u3092\u6D88\u53BB\u3057\u307E\u3057\u305F",
  "draftTitle": "\u6587\u66F8\u30BF\u30A4\u30C8\u30EB",
  "limitTabs": "\u540C\u6642\u306B\u958B\u3051\u308B\u30BF\u30D6\u306F\u6700\u5927 32 \u500B\u3067\u3059",
  "stage": "\u72EC\u81EA\u958B\u767A \xB7 Writer \u3068 Sheets",
  "partialDirectorySync": "\u30D5\u30A1\u30A4\u30EB\u306F\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F\u304C\u3001\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA\u306E\u540C\u671F\u306F\u4FDD\u8A3C\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002",
  "savedMaintenanceWarning": "\u30D5\u30A1\u30A4\u30EB\u306F\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F\u304C\u3001\u5FA9\u5143\u60C5\u5831\u307E\u305F\u306F\u6700\u8FD1\u306E\u30D5\u30A1\u30A4\u30EB\u5C65\u6B74\u3092\u66F4\u65B0\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
  "homeLabel": "Office EX \u30DB\u30FC\u30E0",
  "mainNav": "\u30E1\u30A4\u30F3\u30CA\u30D3\u30B2\u30FC\u30B7\u30E7\u30F3",
  "documents": "\u30C9\u30AD\u30E5\u30E1\u30F3\u30C8",
  "documentActions": "\u30C9\u30AD\u30E5\u30E1\u30F3\u30C8\u64CD\u4F5C",
  "previewTag": "M3 \xB7 \u958B\u767A\u30D7\u30EC\u30D3\u30E5\u30FC",
  "eyebrow": "OFFICE EX / \u30ED\u30FC\u30AB\u30EB\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9",
  "region": "\u5730\u57DF\u5F62\u5F0F",
  "documentLanguage": "\u65B0\u898F\u6587\u66F8\u306E\u8A00\u8A9E\uFF08\u8A2D\u5B9A\uFF09",
  "documentLanguageNote": "\u65B0\u898F Writer \u6587\u66F8\u306B\u3053\u306E\u8A00\u8A9E\u304C\u9069\u7528\u3055\u308C\u307E\u3059\u3002\u65E2\u5B58\u306E\u30D5\u30A1\u30A4\u30EB\u306F\u5909\u66F4\u3055\u308C\u305A\u3001\u4ED6\u306E\u30A8\u30C7\u30A3\u30BF\u30FC\u306F\u5F8C\u3067\u5BFE\u5FDC\u3057\u307E\u3059\u3002",
  "regionSample": "\u5730\u57DF\u5F62\u5F0F\u306E\u30D7\u30EC\u30D3\u30E5\u30FC",
  "history": "\u5C65\u6B74",
  "canvas": "\u30AD\u30E3\u30F3\u30D0\u30B9",
  "entriesLimited": "\u5168 {count} \u4EF6\u306E\u3046\u3061\u6700\u521D\u306E 500 \u4EF6\u3092\u8868\u793A\u3057\u3066\u3044\u307E\u3059\u3002",
  "menuFile": "\u30D5\u30A1\u30A4\u30EB",
  "menuEdit": "\u7DE8\u96C6",
  "menuView": "\u8868\u793A",
  "menuNewWriter": "\u65B0\u898F\u6587\u66F8\u306E\u4E0B\u66F8\u304D",
  "menuNewSheets": "\u65B0\u898F\u30B9\u30D7\u30EC\u30C3\u30C9\u30B7\u30FC\u30C8\u306E\u4E0B\u66F8\u304D",
  "menuNewSlides": "\u65B0\u898F\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u306E\u4E0B\u66F8\u304D",
  "menuOpen": "\u958B\u304F\u2026",
  "menuSaveAs": "\u540D\u524D\u3092\u4ED8\u3051\u3066\u4FDD\u5B58\u2026",
  "menuCloseTab": "\u30BF\u30D6\u3092\u9589\u3058\u308B",
  "menuCut": "\u5207\u308A\u53D6\u308A",
  "menuCopy": "\u30B3\u30D4\u30FC",
  "menuPaste": "\u8CBC\u308A\u4ED8\u3051",
  "menuSelectAll": "\u3059\u3079\u3066\u9078\u629E",
  "menuFullscreen": "\u30D5\u30EB\u30B9\u30AF\u30EA\u30FC\u30F3\u3092\u5207\u308A\u66FF\u3048",
  "menuResetZoom": "\u30BA\u30FC\u30E0\u3092\u30EA\u30BB\u30C3\u30C8",
  "menuZoomIn": "\u62E1\u5927",
  "menuZoomOut": "\u7E2E\u5C0F",
  "officeFiles": "Office \u6587\u66F8 / Office EX \u4E0B\u66F8\u304D",
  "allFiles": "\u3059\u3079\u3066\u306E\u30D5\u30A1\u30A4\u30EB",
  "originalFormat": "\u5143\u306E\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F",
  "replaceTarget": "\u65E2\u5B58\u306E\u30D5\u30A1\u30A4\u30EB\u3092\u7F6E\u304D\u63DB\u3048\u307E\u3059\u304B\uFF1F",
  "replace": "\u7F6E\u304D\u63DB\u3048\u308B",
  "saveBeforeClose": "\u9589\u3058\u308B\u524D\u306B\u5909\u66F4\u3092\u4FDD\u5B58\u3057\u307E\u3059\u304B\uFF1F",
  "discardChanges": "\u5909\u66F4\u3092\u7834\u68C4",
  "openFailed": "\u30D5\u30A1\u30A4\u30EB\u3092\u958B\u3051\u307E\u305B\u3093",
  "windowFailed": "\u30A6\u30A3\u30F3\u30C9\u30A6\u3092\u958B\u3051\u307E\u305B\u3093",
  "finishComposition": "\u8A00\u8A9E\u3092\u5909\u66F4\u3059\u308B\u524D\u306B\u5165\u529B\u3092\u78BA\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
  "oneDroppedFile": "\u4E00\u5EA6\u306B\u30C9\u30ED\u30C3\u30D7\u3067\u304D\u308B\u30D5\u30A1\u30A4\u30EB\u306F 1 \u3064\u3067\u3059\u3002",
  "errorInvalid": "\u30D5\u30A1\u30A4\u30EB\u307E\u305F\u306F\u8981\u6C42\u304C\u7121\u52B9\u3067\u3059\u3002",
  "errorUnsupported": "\u3053\u306E\u6A5F\u80FD\u307E\u305F\u306F\u5F62\u5F0F\u306F\u307E\u3060\u30B5\u30DD\u30FC\u30C8\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002",
  "errorUnsafe": "\u5B89\u5168\u306E\u305F\u3081\u64CD\u4F5C\u3092\u30D6\u30ED\u30C3\u30AF\u3057\u307E\u3057\u305F\u3002",
  "errorLimit": "\u64CD\u4F5C\u304C\u30EA\u30BD\u30FC\u30B9\u5236\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002",
  "errorConflict": "\u6587\u66F8\u307E\u305F\u306F\u5BFE\u8C61\u304C\u5909\u66F4\u3055\u308C\u3066\u3044\u307E\u3059\u3002",
  "errorIo": "\u30D5\u30A1\u30A4\u30EB\u64CD\u4F5C\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002",
  "errorInternal": "\u5185\u90E8\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F\u3002",
  "diagUnknown": "\u4E0D\u660E\u306A\u4E92\u63DB\u6027\u8A3A\u65AD\u304C\u5831\u544A\u3055\u308C\u307E\u3057\u305F\u3002",
  "diagSemanticPending": "\u30B3\u30F3\u30C6\u30CA\u69CB\u9020\u306E\u307F\u691C\u67FB\u3057\u3066\u3044\u307E\u3059\u3002\u7DE8\u96C6\u53EF\u80FD\u306A\u6587\u66F8\u5185\u5BB9\u306F\u307E\u3060\u8AAD\u307F\u8FBC\u307E\u308C\u3066\u3044\u307E\u305B\u3093\u3002",
  "diagMacrosDisabled": "\u30DE\u30AF\u30ED\u95A2\u9023\u306E\u5185\u5BB9\u3092\u691C\u51FA\u3057\u307E\u3057\u305F\u3002\u5B9F\u884C\u305B\u305A\u3001\u5B8C\u5168\u30B3\u30D4\u30FC\u306B\u306E\u307F\u5143\u306E\u30C7\u30FC\u30BF\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002",
  "diagSignedReadOnly": "\u7F72\u540D\u6E08\u307F\u30D5\u30A1\u30A4\u30EB\u306F\u691C\u67FB\u306E\u307F\u3067\u3059\u3002\u7F72\u540D\u306E\u6709\u52B9\u6027\u306F\u4FDD\u8A3C\u3057\u307E\u305B\u3093\u3002",
  "diagExternalDisabled": "\u5916\u90E8\u53C2\u7167\u3092\u8A18\u9332\u3057\u307E\u3057\u305F\u3002\u5916\u90E8\u30B3\u30F3\u30C6\u30F3\u30C4\u306F\u8AAD\u307F\u8FBC\u307F\u307E\u305B\u3093\u3002",
  "diagStrictReadOnly": "Strict OOXML \u3092\u691C\u51FA\u3057\u307E\u3057\u305F\u3002\u5185\u5BB9\u306E\u8AAD\u307F\u66F8\u304D\u306F\u672A\u691C\u8A3C\u3067\u3059\u3002",
  "diagEncryptedUnsupported": "\u6697\u53F7\u5316\u3055\u308C\u305F\u30B3\u30F3\u30C6\u30CA\u3067\u3059\u3002\u5FA9\u53F7\u3068\u7DE8\u96C6\u306F\u3067\u304D\u307E\u305B\u3093\u3002",
  "diagExtensionMismatch": "\u62E1\u5F35\u5B50\u304C\u691C\u51FA\u3055\u308C\u305F\u5185\u5BB9\u3068\u4E00\u81F4\u3057\u307E\u305B\u3093\u3002",
  "writerFormatting": "\u6587\u5B57\u66F8\u5F0F",
  "writerEditNote": "\u6BB5\u843D\u3092\u7DE8\u96C6\u3057\u3001\u9078\u629E\u3057\u305F\u6587\u5B57\u306B\u66F8\u5F0F\u3092\u9069\u7528\u3057\u307E\u3059\u3002Enter \u3067\u6BB5\u843D\u5206\u5272\u3001Shift+Enter \u3067\u6539\u884C\u3057\u307E\u3059\u3002",
  "writerPagePreview": "\u30DA\u30FC\u30B8\u30D7\u30EC\u30D3\u30E5\u30FC",
  "writerEstimated": "\u6982\u7B97\u306E\u30DA\u30FC\u30B8\u30EC\u30A4\u30A2\u30A6\u30C8\u3067\u3059\u3002\u30AF\u30EA\u30C3\u30AF\u3057\u3066\u6587\u5B57\u4F4D\u7F6E\u3092\u6307\u5B9A\u3067\u304D\u307E\u3059\u3002\u5370\u5237\u7CBE\u5EA6\u306F\u672A\u691C\u8A3C\u3067\u3059\u3002",
  "writerPreviousPage": "\u524D\u306E\u30DA\u30FC\u30B8",
  "writerNextPage": "\u6B21\u306E\u30DA\u30FC\u30B8",
  "writerPageNumber": "{current} / {total} \u30DA\u30FC\u30B8",
  "writerLayoutLimits": "\u4E00\u90E8\u306E\u6587\u5B57\u7D44\u7248\u3084\u30EC\u30A4\u30A2\u30A6\u30C8\u306F\u8FD1\u4F3C\u8868\u793A\u3067\u3059\u3002",
  "writerPreviewUnavailable": "\u3053\u306E\u5185\u5BB9\u307E\u305F\u306F\u30EC\u30A4\u30A2\u30A6\u30C8\u5236\u9650\u3067\u306F\u30D7\u30EC\u30D3\u30E5\u30FC\u3067\u304D\u307E\u305B\u3093\u3002\u5143\u306E\u5185\u5BB9\u306F\u5909\u66F4\u3055\u308C\u307E\u305B\u3093\u3002",
  "writerBold": "\u592A\u5B57",
  "writerItalic": "\u659C\u4F53",
  "writerUnderline": "\u4E0B\u7DDA",
  "writerAlignLeft": "\u5DE6\u63C3\u3048",
  "writerAlignCenter": "\u4E2D\u592E\u63C3\u3048",
  "writerAlignRight": "\u53F3\u63C3\u3048",
  "writerSplit": "\u6BB5\u843D\u3092\u5206\u5272",
  "writerPageBreak": "\u6BB5\u843D\u306E\u5F8C\u306B\u6539\u30DA\u30FC\u30B8",
  "writerUnsupportedBlock": "\u3053\u306E\u30D6\u30ED\u30C3\u30AF\u306F\u73FE\u5728\u306E\u30D7\u30EC\u30D3\u30E5\u30FC\u3067\u306F\u7DE8\u96C6\u3067\u304D\u307E\u305B\u3093\u3002",
  "docxNew": "DOCX \u6587\u66F8\u3092\u65B0\u898F\u4F5C\u6210",
  "docxDocument": "DOCX \u6587\u66F8",
  "docxNote": "\u9650\u5B9A DOCX \u5BFE\u5FDC\uFF1A\u6587\u5B57\u3001\u76F4\u63A5\u66F8\u5F0F\u3001\u5BFE\u5FDC\u30B9\u30BF\u30A4\u30EB\u3001\u56FA\u5B9A\u5E45\u306E\u8868\u3001\u884C\u5185 PNG/JPEG \u753B\u50CF\u3001\u57FA\u672C\u30EC\u30A4\u30A2\u30A6\u30C8\u3002\u8907\u96D1\u306A\u6587\u66F8\u306F\u8AAD\u307F\u53D6\u308A\u5C02\u7528\u3067\u3059\u3002",
  "writerFontFamily": "\u30D5\u30A9\u30F3\u30C8",
  "writerFontSize": "\u30B5\u30A4\u30BA\uFF08pt\uFF09",
  "writerTextColor": "\u6587\u5B57\u8272",
  "writerParagraphStyle": "\u6BB5\u843D\u30B9\u30BF\u30A4\u30EB",
  "writerCharacterStyle": "\u6587\u5B57\u30B9\u30BF\u30A4\u30EB",
  "writerChooseStyle": "\u30B9\u30BF\u30A4\u30EB\u3092\u9078\u629E",
  "writerTable": "\u8868",
  "writerTableRows": "\u884C\u6570",
  "writerTableColumns": "\u5217\u6570",
  "writerInsertTable": "\u8868\u3092\u633F\u5165",
  "writerAddRow": "\u4E0B\u306B\u884C\u3092\u8FFD\u52A0",
  "writerDeleteRow": "\u884C\u3092\u524A\u9664",
  "writerAddColumn": "\u53F3\u306B\u5217\u3092\u8FFD\u52A0",
  "writerDeleteColumn": "\u5217\u3092\u524A\u9664",
  "writerColumnWidth": "\u5217\u5E45 (pt)",
  "writerTableBorder": "\u8868\u306E\u7F6B\u7DDA",
  "writerDeleteTable": "\u8868\u3092\u524A\u9664",
  "writerCell": "\u30BB\u30EB {row}, {column}",
  "writerInsertImage": "\u753B\u50CF\u3092\u633F\u5165",
  "writerImage": "\u753B\u50CF",
  "writerImageWidth": "\u753B\u50CF\u5E45 (pt)",
  "writerRemoveImage": "\u753B\u50CF\u3092\u524A\u9664",
  "writerPaper": "\u7528\u7D19\u30B5\u30A4\u30BA",
  "writerCustomPaper": "\u30AB\u30B9\u30BF\u30E0",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "\u30DA\u30FC\u30B8\u306E\u5411\u304D",
  "writerPortrait": "\u7E26",
  "writerLandscape": "\u6A2A",
  "writerPageWidth": "\u7528\u7D19\u5E45 (pt)",
  "writerPageHeight": "\u7528\u7D19\u9AD8\u3055 (pt)",
  "writerMarginTop": "\u4E0A\u4F59\u767D (pt)",
  "writerMarginRight": "\u53F3\u4F59\u767D (pt)",
  "writerMarginBottom": "\u4E0B\u4F59\u767D (pt)",
  "writerMarginLeft": "\u5DE6\u4F59\u767D (pt)",
  "writerApplyPage": "\u30DA\u30FC\u30B8\u8A2D\u5B9A\u3092\u9069\u7528",
  "writerIndent": "\u30A4\u30F3\u30C7\u30F3\u30C8 (pt)",
  "writerSpaceBefore": "\u6BB5\u843D\u524D (pt)",
  "writerSpaceAfter": "\u6BB5\u843D\u5F8C (pt)",
  "writerLineHeight": "\u884C\u9593 (pt\u30010 \u306F\u81EA\u52D5)",
  "writerInsertInlineImage": "\u30AB\u30FC\u30BD\u30EB\u4F4D\u7F6E\u306B\u753B\u50CF\u3092\u633F\u5165",
  "writerInlineImageNote": "\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u8A18\u53F7\u306F\u884C\u5185\u753B\u50CF\u3092\u8868\u3057\u307E\u3059\u3002\u753B\u50CF\u306E\u64CD\u4F5C\u6B04\u3067\u30B5\u30A4\u30BA\u5909\u66F4\u3084\u524A\u9664\u3092\u884C\u3044\u307E\u3059\u3002",
  "writerContinuous": "\u9023\u7D9A\u30C6\u30AD\u30B9\u30C8\u7DE8\u96C6",
  "writerExitContinuous": "\u6BB5\u843D\u7DE8\u96C6\u306B\u623B\u308B",
  "writerContinuousNote": "\u96A3\u63A5\u3059\u308B\u6BB5\u843D\u3092\u307E\u305F\u3044\u3067\u9078\u629E\u3001\u30B3\u30D4\u30FC\u3001\u5207\u308A\u53D6\u308A\u3001\u8CBC\u308A\u4ED8\u3051\u3001\u66F8\u5F0F\u8A2D\u5B9A\u304C\u3067\u304D\u307E\u3059\u3002\u8868\u3001\u6539\u30DA\u30FC\u30B8\u3001\u30BB\u30AF\u30B7\u30E7\u30F3\u3001\u753B\u50CF\u6BB5\u843D\u306F\u9078\u629E\u7BC4\u56F2\u306E\u5883\u754C\u3067\u3059\u3002\u8CBC\u308A\u4ED8\u3051\u305F\u6539\u884C\u306F\u65B0\u3057\u3044\u6BB5\u843D\u306B\u306A\u308A\u307E\u3059\u3002",
  "writerSection": "\u30BB\u30AF\u30B7\u30E7\u30F3",
  "writerSectionNumber": "\u30BB\u30AF\u30B7\u30E7\u30F3 {number}",
  "writerSectionBreak": "\u6B21\u306E\u30DA\u30FC\u30B8\u304B\u3089\u30BB\u30AF\u30B7\u30E7\u30F3\u3092\u958B\u59CB",
  "writerTextLanguage": "\u30C6\u30AD\u30B9\u30C8\u306E\u8A00\u8A9E (BCP 47)",
  "writerParagraphDirection": "\u6BB5\u843D\u306E\u65B9\u5411",
  "writerLtr": "\u5DE6\u304B\u3089\u53F3",
  "writerRtl": "\u53F3\u304B\u3089\u5DE6",
  "docNew": "DOC \u3092\u65B0\u898F\u4F5C\u6210",
  "docDocument": "Word 97\u20132003 \u6587\u66F8",
  "docNote": "DOC \u306E\u9650\u5B9A\u7DE8\u96C6\uFF1AUnicode \u30C6\u30AD\u30B9\u30C8\u3001\u57FA\u672C\u66F8\u5F0F\u30011 \u30BB\u30AF\u30B7\u30E7\u30F3\u3002\u672A\u5BFE\u5FDC\u306E DOC \u306F\u8AAD\u307F\u53D6\u308A\u5C02\u7528\u3067\u3059\u3002\u8868\u3084\u753B\u50CF\u306F\u4FDD\u5B58\u3067\u304D\u307E\u305B\u3093\u3002",
  "docTextPreview": "\u672C\u6587\u306E\u8AAD\u307F\u53D6\u308A\u5C02\u7528\u30C6\u30AD\u30B9\u30C8\u30D7\u30EC\u30D3\u30E5\u30FC\u3067\u3059\u3002\u5B8C\u5168\u306A\u30EC\u30A4\u30A2\u30A6\u30C8\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u30B3\u30D4\u30FC\u306F\u5143\u306E\u30D0\u30A4\u30C8\u5217\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002",
  "convertDoc": "DOC \u306B\u5909\u63DB",
  "convertDocx": "DOCX \u306B\u5909\u63DB",
  "conversionBoundary": "\u5BFE\u5FDC\u6E08\u307F\u306E\u69CB\u9020\u306E\u307F\u5909\u63DB\u3067\u304D\u307E\u3059\u3002\u672A\u89E3\u91C8\u306E\u90E8\u54C1\u306F\u5143\u306E\u30D5\u30A1\u30A4\u30EB\u306B\u4FDD\u6301\u3055\u308C\u307E\u3059\u3002",
  "writerPageEdit": "\u30DA\u30FC\u30B8\u4E0A\u3067\u7DE8\u96C6",
  "writerExitPageEdit": "\u7DE8\u96C6\u30C4\u30FC\u30EB\u306B\u623B\u308B",
  "writerNativePageNote": "\u30D6\u30E9\u30A6\u30B6\u30FC\u306E\u6587\u5B57\u7D44\u7248\u3092\u4F7F\u3044\u3001\u30DA\u30FC\u30B8\u4E0A\u3067\u7DE8\u96C6\u3057\u307E\u3059\u3002\u30C9\u30E9\u30C3\u30B0\u3067\u9078\u629E\u3067\u304D\u3001\u5185\u90E8\u306E\u30B3\u30D4\u30FC\u3068\u8CBC\u308A\u4ED8\u3051\u306F\u5BFE\u5FDC\u66F8\u5F0F\u3068\u753B\u50CF\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002Word \u3068\u306E\u7248\u9762\u7CBE\u5EA6\u306F\u672A\u691C\u8A3C\u3067\u3059\u3002"
};

// packages/i18n/src/catalogs-a1.ts
var korean = {
  "open": "\uD30C\uC77C \uC5F4\uAE30",
  "newDraft": "\uC0C8 \uCD08\uC548",
  "recent": "\uCD5C\uADFC \uD30C\uC77C",
  "local": "\uB85C\uCEEC \uC791\uC5C5 \uACF5\uAC04 \xB7 \uC624\uD504\uB77C\uC778 \uC6B0\uC120",
  "settings": "\uC124\uC815",
  "workspace": "\uC791\uC5C5 \uACF5\uAC04",
  "undo": "\uC2E4\uD589 \uCDE8\uC18C",
  "redo": "\uB2E4\uC2DC \uC2E4\uD589",
  "saveAs": "\uB2E4\uB978 \uC774\uB984\uC73C\uB85C \uC800\uC7A5",
  "save": "\uC800\uC7A5",
  "ready": "\uC900\uBE44 \uC644\uB8CC",
  "theme": "\uBAA8\uC591",
  "system": "\uC2DC\uC2A4\uD15C \uC124\uC815",
  "light": "\uBC1D\uAC8C",
  "dark": "\uC5B4\uB461\uAC8C",
  "language": "\uC5B8\uC5B4",
  "clearRecent": "\uCD5C\uADFC \uD30C\uC77C \uBAA9\uB85D \uC9C0\uC6B0\uAE30",
  "settingsNote": "\uC124\uC815\uACFC \uBCF5\uAD6C \uC2A4\uB0C5\uC0F7\uC740 \uC774 \uCEF4\uD4E8\uD130\uC5D0\uB9CC \uC800\uC7A5\uB429\uB2C8\uB2E4.",
  "welcome": "\uBB38\uC11C\uB97C \uC5EC\uAE30\uC5D0\uC11C \uC2DC\uC791\uD558\uC138\uC694.",
  "welcomeSub": "\uB3C5\uB9BD \uAC1C\uBC1C \uB370\uC2A4\uD06C\uD1B1 \uC624\uD53C\uC2A4 \uC81C\uD488\uAD70\uC785\uB2C8\uB2E4. M3 \uBBF8\uB9AC \uBCF4\uAE30\uC5D0\uC11C\uB294 \uC9C0\uC6D0\uB418\uB294 \uD615\uC2DD \uBC94\uC704 \uB0B4\uC5D0\uC11C \uBB38\uC11C\uC640 \uC2A4\uD504\uB808\uB4DC\uC2DC\uD2B8\uB97C \uD3B8\uC9D1\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
  "newHeading": "\uB85C\uCEEC \uCD08\uC548 \uB9CC\uB4E4\uAE30",
  "draftHint": "\uB0B4\uBD80 \uCD08\uC548 \uD615\uC2DD \xB7 .oex",
  "writer": "\uBB38\uC11C",
  "sheets": "\uC2A4\uD504\uB808\uB4DC\uC2DC\uD2B8",
  "slides": "\uD504\uB808\uC820\uD14C\uC774\uC158",
  "writerSub": "\uBB38\uC11C \uC791\uC131 \uBC0F \uC11C\uC2DD \uC9C0\uC815",
  "sheetsSub": "\uC140, \uC218\uC2DD \uBC0F \uC11C\uC2DD",
  "slidesSub": "\uD504\uB808\uC820\uD14C\uC774\uC158 \uC7A5\uBA74 \uBBF8\uB9AC \uBCF4\uAE30",
  "dropTitle": "\uD30C\uC77C\uC744 \uC5F4\uAC70\uB098 \uC5EC\uAE30\uC5D0 \uB193\uC73C\uC138\uC694",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX \uCD08\uC548",
  "choose": "\uD30C\uC77C \uC120\uD0DD",
  "boundary": "\uC9C0\uC6D0\uB418\uB294 DOC/DOCX \uBB38\uC11C\uC640 XLS/XLSX \uD1B5\uD569 \uBB38\uC11C\uB97C \uD3B8\uC9D1\uD558\uACE0 \uC800\uC7A5\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uB2E4\uB978 \uD30C\uC77C\uC740 \uC77D\uAE30 \uC804\uC6A9\uC73C\uB85C \uC5F4\uB9AC\uACE0 \uB3D9\uC77C\uD55C \uBCF5\uC0AC\uBCF8\uC744 \uC800\uC7A5\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uC644\uC804\uD55C \uD638\uD658\uC131\uC740 \uAC1C\uBC1C \uC911\uC785\uB2C8\uB2E4.",
  "formats": "\uD30C\uC77C \uD615\uC2DD \uAE30\uBC18",
  "containerReady": "\uCEE8\uD14C\uC774\uB108 \uC5F0\uACB0\uB428",
  "modern": "\uCD5C\uC2E0 \uD615\uC2DD",
  "legacy": "\uC774\uC804 \uD615\uC2DD",
  "draft": "\uB85C\uCEEC \uCD08\uC548",
  "noRecent": "\uCD5C\uADFC \uD30C\uC77C \uC5C6\uC74C",
  "untitled": "\uC81C\uBAA9 \uC5C6\uC74C",
  "draftLabel": "Office EX \uCD08\uC548",
  "readOnly": "\uC77D\uAE30 \uC804\uC6A9 \xB7 \uAD6C\uC870 \uAC80\uC0AC",
  "unsaved": "\uC800\uC7A5\uB418\uC9C0 \uC54A\uC74C",
  "saved": "\uC800\uC7A5\uB428",
  "reading": "\uD30C\uC77C \uAD6C\uC870 \uAC80\uC0AC \uC911\u2026",
  "cancel": "\uCDE8\uC18C",
  "close": "\uB2EB\uAE30",
  "cancelled": "\uC791\uC5C5\uC774 \uCDE8\uC18C\uB418\uC5C8\uC2B5\uB2C8\uB2E4",
  "snapshot": "\uC2A4\uB0C5\uC0F7",
  "revision": "\uB9AC\uBE44\uC804",
  "savedNote": "\uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
  "draftNote": "OEX \uCD08\uC548\uC740 \uB0B4\uBD80 \uD615\uC2DD\uC785\uB2C8\uB2E4. Office \uD30C\uC77C\uC774 \uD544\uC694\uD558\uBA74 \uC9C0\uC6D0\uB418\uB294 \uAE30\uB2A5\uC73C\uB85C DOC/DOCX \uBB38\uC11C \uB610\uB294 XLS/XLSX \uD1B5\uD569 \uBB38\uC11C\uB97C \uB9CC\uB4DC\uC138\uC694.",
  "textLabel": "\uCD08\uC548 \uD14D\uC2A4\uD2B8",
  "cellsLabel": "\uC2A4\uD504\uB808\uB4DC\uC2DC\uD2B8 \uC140",
  "cellsNote": "\uC140, \uC218\uC2DD \uBC0F \uC11C\uC2DD\uC744 \uD3B8\uC9D1\uD569\uB2C8\uB2E4. \uC9C0\uC6D0\uB418\uB294 \uD615\uC2DD\uC73C\uB85C \uC800\uC7A5\uD558\uBA74 \uAC12 \uC720\uD615\uACFC \uD1B5\uD569 \uBB38\uC11C \uB0A0\uC9DC \uCCB4\uACC4\uAC00 \uC720\uC9C0\uB429\uB2C8\uB2E4.",
  "slideLabel": "\uC7A5\uBA74 \uBC0F \uC801\uC911 \uAC80\uC0AC \uBBF8\uB9AC\uBCF4\uAE30",
  "addShape": "\uC0AC\uAC01\uD615 \uCD94\uAC00",
  "shapeNote": "\uB3C4\uD615\uC744 \uD074\uB9AD\uD574 \uC88C\uD45C\uB97C \uD655\uC778\uD558\uC138\uC694. \uC804\uCCB4 \uD3B8\uC9D1\uAE30\uB294 M4\uC5D0\uC11C \uAD6C\uD604\uB429\uB2C8\uB2E4.",
  "parts": "\uD328\uD0A4\uC9C0 \uD30C\uD2B8 / \uC2A4\uD2B8\uB9BC",
  "part": "\uD30C\uD2B8",
  "size": "\uD06C\uAE30",
  "digest": "SHA-256",
  "version": "\uD615\uC2DD \uBC84\uC804",
  "format": "\uAC10\uC9C0\uB41C \uD615\uC2DD",
  "copy": "\uB3D9\uC77C\uD55C \uBCF5\uC0AC\uBCF8 \uC800\uC7A5",
  "pending": "\uBB38\uC11C \uB0B4\uC6A9 \uC5B4\uB311\uD130 \uBBF8\uAD6C\uD604",
  "recoveries": "\uBCF5\uAD6C \uAC00\uB2A5\uD55C \uCD08\uC548",
  "restore": "\uBCF5\uC0AC\uBCF8 \uBCF5\uAD6C",
  "discard": "\uBC84\uB9AC\uAE30",
  "recoveryNote": "\uBCF5\uAD6C \uC2DC \uC800\uC7A5\uB418\uC9C0 \uC54A\uC740 \uC0C8 \uBCF5\uC0AC\uBCF8\uC744 \uB9CC\uB4E4\uACE0 \uC6D0\uBCF8 \uD30C\uC77C\uC740 \uADF8\uB300\uB85C \uC720\uC9C0\uD569\uB2C8\uB2E4.",
  "recoveryCorrupt": "\uC190\uC0C1\uB41C \uBCF5\uAD6C \uC2A4\uB0C5\uC0F7\uC740 \uACA9\uB9AC\uB418\uC5B4 \uB85C\uB4DC\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
  "recovered": "\uC0C8 \uCD08\uC548\uC73C\uB85C \uBCF5\uAD6C\uD588\uC2B5\uB2C8\uB2E4",
  "working": "\uCC98\uB9AC \uC911",
  "diagnostics": "\uD638\uD658\uC131 \uBCF4\uACE0\uC11C",
  "noEntries": "\uD45C\uC2DC\uD560 \uCEE8\uD14C\uC774\uB108 \uD30C\uD2B8\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4.",
  "emptySlide": "\uBE48 \uC2AC\uB77C\uC774\uB4DC",
  "clearDone": "\uCD5C\uADFC \uD30C\uC77C \uBAA9\uB85D\uC744 \uC9C0\uC6E0\uC2B5\uB2C8\uB2E4",
  "draftTitle": "\uBB38\uC11C \uC81C\uBAA9",
  "limitTabs": "\uD0ED\uC740 \uCD5C\uB300 32\uAC1C\uAE4C\uC9C0 \uC5F4 \uC218 \uC788\uC2B5\uB2C8\uB2E4",
  "stage": "\uB3C5\uB9BD \uAC1C\uBC1C \xB7 Writer \uBC0F Sheets",
  "partialDirectorySync": "\uD30C\uC77C\uC744 \uC800\uC7A5\uD588\uC9C0\uB9CC \uC774 \uD30C\uC77C \uC2DC\uC2A4\uD15C\uC758 \uB514\uB809\uD130\uB9AC \uB3D9\uAE30\uD654\uB294 \uBCF4\uC7A5\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  "savedMaintenanceWarning": "\uD30C\uC77C\uC744 \uC800\uC7A5\uD588\uC9C0\uB9CC \uBCF5\uAD6C \uC815\uBCF4 \uB610\uB294 \uCD5C\uADFC \uD30C\uC77C \uAE30\uB85D\uC744 \uAC31\uC2E0\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
  "homeLabel": "Office EX \uD648",
  "mainNav": "\uAE30\uBCF8 \uD0D0\uC0C9",
  "documents": "\uBB38\uC11C",
  "documentActions": "\uBB38\uC11C \uC791\uC5C5",
  "previewTag": "M3 \xB7 \uAC1C\uBC1C \uBBF8\uB9AC \uBCF4\uAE30",
  "eyebrow": "OFFICE EX / \uB85C\uCEEC \uC791\uC5C5 \uACF5\uAC04",
  "region": "\uC9C0\uC5ED \uD615\uC2DD",
  "documentLanguage": "\uC0C8 \uBB38\uC11C \uC5B8\uC5B4 (\uAE30\uBCF8 \uC124\uC815)",
  "documentLanguageNote": "\uC0C8 Writer \uBB38\uC11C\uC5D0 \uC774 \uD14D\uC2A4\uD2B8 \uC5B8\uC5B4\uAC00 \uC801\uC6A9\uB429\uB2C8\uB2E4. \uAE30\uC874 \uD30C\uC77C\uC740 \uBCC0\uACBD\uB418\uC9C0 \uC54A\uC73C\uBA70 \uB2E4\uB978 \uD3B8\uC9D1\uAE30\uB294 \uB098\uC911\uC5D0 \uC9C0\uC6D0\uD569\uB2C8\uB2E4.",
  "regionSample": "\uC9C0\uC5ED \uD615\uC2DD \uBBF8\uB9AC\uBCF4\uAE30",
  "history": "\uAE30\uB85D",
  "canvas": "\uCE94\uBC84\uC2A4",
  "entriesLimited": "\uC804\uCCB4 {count}\uAC1C \uC911 \uCC98\uC74C 500\uAC1C\uB97C \uD45C\uC2DC\uD569\uB2C8\uB2E4.",
  "menuFile": "\uD30C\uC77C",
  "menuEdit": "\uD3B8\uC9D1",
  "menuView": "\uBCF4\uAE30",
  "menuNewWriter": "\uC0C8 \uBB38\uC11C \uCD08\uC548",
  "menuNewSheets": "\uC0C8 \uC2A4\uD504\uB808\uB4DC\uC2DC\uD2B8 \uCD08\uC548",
  "menuNewSlides": "\uC0C8 \uD504\uB808\uC820\uD14C\uC774\uC158 \uCD08\uC548",
  "menuOpen": "\uC5F4\uAE30\u2026",
  "menuSaveAs": "\uB2E4\uB978 \uC774\uB984\uC73C\uB85C \uC800\uC7A5\u2026",
  "menuCloseTab": "\uD0ED \uB2EB\uAE30",
  "menuCut": "\uC798\uB77C\uB0B4\uAE30",
  "menuCopy": "\uBCF5\uC0AC",
  "menuPaste": "\uBD99\uC5EC\uB123\uAE30",
  "menuSelectAll": "\uBAA8\uB450 \uC120\uD0DD",
  "menuFullscreen": "\uC804\uCCB4 \uD654\uBA74 \uC804\uD658",
  "menuResetZoom": "\uD655\uB300/\uCD95\uC18C \uCD08\uAE30\uD654",
  "menuZoomIn": "\uD655\uB300",
  "menuZoomOut": "\uCD95\uC18C",
  "officeFiles": "Office \uBB38\uC11C / Office EX \uCD08\uC548",
  "allFiles": "\uBAA8\uB4E0 \uD30C\uC77C",
  "originalFormat": "\uC6D0\uBCF8 \uD30C\uC77C \uD615\uC2DD",
  "replaceTarget": "\uAE30\uC874 \uB300\uC0C1 \uD30C\uC77C\uC744 \uBC14\uAFB8\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?",
  "replace": "\uBC14\uAFB8\uAE30",
  "saveBeforeClose": "\uB2EB\uAE30 \uC804\uC5D0 \uBCC0\uACBD \uB0B4\uC6A9\uC744 \uC800\uC7A5\uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?",
  "discardChanges": "\uBCC0\uACBD \uB0B4\uC6A9 \uBC84\uB9AC\uAE30",
  "openFailed": "\uD30C\uC77C\uC744 \uC5F4 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4",
  "windowFailed": "\uCC3D\uC744 \uC5F4 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4",
  "finishComposition": "\uC5B8\uC5B4\uB97C \uBCC0\uACBD\uD558\uAE30 \uC804\uC5D0 \uD604\uC7AC \uC785\uB825\uC744 \uC644\uB8CC\uD558\uC138\uC694.",
  "oneDroppedFile": "\uD55C \uBC88\uC5D0 \uD30C\uC77C \uD558\uB098\uB9CC \uB193\uC744 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
  "errorInvalid": "\uC798\uBABB\uB41C \uD30C\uC77C \uB610\uB294 \uC694\uCCAD\uC785\uB2C8\uB2E4.",
  "errorUnsupported": "\uC544\uC9C1 \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uAE30\uB2A5 \uB610\uB294 \uD615\uC2DD\uC785\uB2C8\uB2E4.",
  "errorUnsafe": "\uC548\uC804\uC744 \uC704\uD574 \uC791\uC5C5\uC744 \uCC28\uB2E8\uD588\uC2B5\uB2C8\uB2E4.",
  "errorLimit": "\uC791\uC5C5\uC774 \uB9AC\uC18C\uC2A4 \uD55C\uB3C4\uB97C \uCD08\uACFC\uD588\uC2B5\uB2C8\uB2E4.",
  "errorConflict": "\uBB38\uC11C \uB610\uB294 \uB300\uC0C1\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
  "errorIo": "\uD30C\uC77C \uC791\uC5C5\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.",
  "errorInternal": "\uB0B4\uBD80 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4.",
  "diagUnknown": "\uC54C \uC218 \uC5C6\uB294 \uD638\uD658\uC131 \uC9C4\uB2E8\uC774 \uBCF4\uACE0\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
  "diagSemanticPending": "\uCEE8\uD14C\uC774\uB108 \uAD6C\uC870\uB9CC \uAC80\uC0AC\uD569\uB2C8\uB2E4. \uD3B8\uC9D1 \uAC00\uB2A5\uD55C \uBB38\uC11C \uB0B4\uC6A9\uC740 \uC544\uC9C1 \uAC00\uC838\uC624\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
  "diagMacrosDisabled": "\uB9E4\uD06C\uB85C \uAD00\uB828 \uB0B4\uC6A9\uC744 \uAC10\uC9C0\uD588\uC2B5\uB2C8\uB2E4. \uB9E4\uD06C\uB85C\uB294 \uC2E4\uD589\uD558\uC9C0 \uC54A\uC73C\uBA70 \uB3D9\uC77C\uD55C \uBCF5\uC0AC\uBCF8\uC5D0\uB9CC \uC6D0\uBCF8 \uBC14\uC774\uD2B8\uB97C \uC720\uC9C0\uD569\uB2C8\uB2E4.",
  "diagSignedReadOnly": "\uC11C\uBA85\uB41C \uD30C\uC77C\uC740 \uAC80\uC0AC\uB9CC \uAC00\uB2A5\uD569\uB2C8\uB2E4. \uC11C\uBA85\uC758 \uC720\uD6A8\uC131\uC740 \uBCF4\uC7A5\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  "diagExternalDisabled": "\uC678\uBD80 \uAD00\uACC4\uB97C \uAE30\uB85D\uD588\uC2B5\uB2C8\uB2E4. \uC678\uBD80 \uCF58\uD150\uCE20\uB294 \uBD88\uB7EC\uC624\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  "diagStrictReadOnly": "Strict OOXML\uC744 \uAC10\uC9C0\uD588\uC2B5\uB2C8\uB2E4. \uBB38\uC11C \uB0B4\uC6A9 \uC77D\uAE30\uC640 \uC4F0\uAE30\uB294 \uC544\uC9C1 \uAC80\uC99D\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
  "diagEncryptedUnsupported": "\uC554\uD638\uD654\uB41C \uCEE8\uD14C\uC774\uB108\uB97C \uAC10\uC9C0\uD588\uC2B5\uB2C8\uB2E4. \uBCF5\uD638\uD654 \uBC0F \uD3B8\uC9D1\uC740 \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  "diagExtensionMismatch": "\uD30C\uC77C \uD655\uC7A5\uBA85\uC774 \uAC10\uC9C0\uB41C \uB0B4\uC6A9\uACFC \uB2E4\uB985\uB2C8\uB2E4.",
  "writerFormatting": "\uD14D\uC2A4\uD2B8 \uC11C\uC2DD",
  "writerEditNote": "\uBB38\uB2E8\uC744 \uC218\uC815\uD558\uACE0 \uC120\uD0DD\uD55C \uD14D\uC2A4\uD2B8\uC5D0 \uC11C\uC2DD\uC744 \uC801\uC6A9\uD558\uC138\uC694. Enter\uB294 \uBB38\uB2E8 \uBD84\uB9AC, Shift+Enter\uB294 \uC904\uBC14\uAFC8\uC785\uB2C8\uB2E4.",
  "writerPagePreview": "\uD398\uC774\uC9C0 \uBBF8\uB9AC\uBCF4\uAE30",
  "writerEstimated": "\uC608\uC0C1 \uD398\uC774\uC9C0 \uBC30\uCE58\uC785\uB2C8\uB2E4. \uD398\uC774\uC9C0\uB97C \uD074\uB9AD\uD574 \uD14D\uC2A4\uD2B8 \uC704\uCE58\uB97C \uCC3E\uC744 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uC778\uC1C4 \uC815\uD655\uB3C4\uB294 \uC544\uC9C1 \uAC80\uC99D\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
  "writerPreviousPage": "\uC774\uC804 \uD398\uC774\uC9C0",
  "writerNextPage": "\uB2E4\uC74C \uD398\uC774\uC9C0",
  "writerPageNumber": "{current} / {total} \uD398\uC774\uC9C0",
  "writerLayoutLimits": "\uC77C\uBD80 \uAE00\uAF34 \uB610\uB294 \uBC30\uCE58 \uAE30\uB2A5\uC740 \uADFC\uC0AC \uD45C\uC2DC\uB429\uB2C8\uB2E4.",
  "writerPreviewUnavailable": "\uC774 \uCF58\uD150\uCE20 \uB610\uB294 \uBC30\uCE58 \uC81C\uD55C\uC5D0\uC11C\uB294 \uBBF8\uB9AC\uBCF4\uAE30\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uC6D0\uBCF8 \uB0B4\uC6A9\uC740 \uBCC0\uACBD\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  "writerBold": "\uAD75\uAC8C",
  "writerItalic": "\uAE30\uC6B8\uC784\uAF34",
  "writerUnderline": "\uBC11\uC904",
  "writerAlignLeft": "\uC67C\uCABD \uC815\uB82C",
  "writerAlignCenter": "\uAC00\uC6B4\uB370 \uC815\uB82C",
  "writerAlignRight": "\uC624\uB978\uCABD \uC815\uB82C",
  "writerSplit": "\uBB38\uB2E8 \uBD84\uB9AC",
  "writerPageBreak": "\uBB38\uB2E8 \uB4A4 \uD398\uC774\uC9C0 \uB098\uB204\uAE30",
  "writerUnsupportedBlock": "\uC774 \uBE14\uB85D\uC740 \uD604\uC7AC \uBBF8\uB9AC\uBCF4\uAE30\uC5D0\uC11C \uD3B8\uC9D1\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.",
  "docxNew": "\uC0C8 DOCX \uBB38\uC11C",
  "docxDocument": "DOCX \uBB38\uC11C",
  "docxNote": "\uC81C\uD55C\uB41C DOCX \uC9C0\uC6D0: \uD14D\uC2A4\uD2B8, \uC9C1\uC811 \uC11C\uC2DD, \uC77C\uBD80 \uC2A4\uD0C0\uC77C, \uACE0\uC815 \uB108\uBE44 \uD45C, \uC778\uB77C\uC778 PNG/JPEG \uC774\uBBF8\uC9C0 \uBC0F \uAE30\uBCF8 \uBC30\uCE58. \uBCF5\uC7A1\uD55C \uBB38\uC11C\uB294 \uC77D\uAE30 \uC804\uC6A9\uC785\uB2C8\uB2E4.",
  "writerFontFamily": "\uAE00\uAF34",
  "writerFontSize": "\uD06C\uAE30 (pt)",
  "writerTextColor": "\uAE00\uC790 \uC0C9",
  "writerParagraphStyle": "\uBB38\uB2E8 \uC2A4\uD0C0\uC77C",
  "writerCharacterStyle": "\uBB38\uC790 \uC2A4\uD0C0\uC77C",
  "writerChooseStyle": "\uC2A4\uD0C0\uC77C \uC120\uD0DD",
  "writerTable": "\uD45C",
  "writerTableRows": "\uD589 \uC218",
  "writerTableColumns": "\uC5F4 \uC218",
  "writerInsertTable": "\uD45C \uC0BD\uC785",
  "writerAddRow": "\uC544\uB798\uC5D0 \uD589 \uCD94\uAC00",
  "writerDeleteRow": "\uD589 \uC0AD\uC81C",
  "writerAddColumn": "\uC624\uB978\uCABD\uC5D0 \uC5F4 \uCD94\uAC00",
  "writerDeleteColumn": "\uC5F4 \uC0AD\uC81C",
  "writerColumnWidth": "\uC5F4 \uB108\uBE44 (pt)",
  "writerTableBorder": "\uD45C \uD14C\uB450\uB9AC",
  "writerDeleteTable": "\uD45C \uC0AD\uC81C",
  "writerCell": "\uC140 {row}, {column}",
  "writerInsertImage": "\uC774\uBBF8\uC9C0 \uC0BD\uC785",
  "writerImage": "\uC774\uBBF8\uC9C0",
  "writerImageWidth": "\uC774\uBBF8\uC9C0 \uB108\uBE44 (pt)",
  "writerRemoveImage": "\uC774\uBBF8\uC9C0 \uC0AD\uC81C",
  "writerPaper": "\uC6A9\uC9C0 \uD06C\uAE30",
  "writerCustomPaper": "\uC0AC\uC6A9\uC790 \uC9C0\uC815",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "\uD398\uC774\uC9C0 \uBC29\uD5A5",
  "writerPortrait": "\uC138\uB85C",
  "writerLandscape": "\uAC00\uB85C",
  "writerPageWidth": "\uC6A9\uC9C0 \uB108\uBE44 (pt)",
  "writerPageHeight": "\uC6A9\uC9C0 \uB192\uC774 (pt)",
  "writerMarginTop": "\uC704\uCABD \uC5EC\uBC31 (pt)",
  "writerMarginRight": "\uC624\uB978\uCABD \uC5EC\uBC31 (pt)",
  "writerMarginBottom": "\uC544\uB798\uCABD \uC5EC\uBC31 (pt)",
  "writerMarginLeft": "\uC67C\uCABD \uC5EC\uBC31 (pt)",
  "writerApplyPage": "\uD398\uC774\uC9C0 \uC124\uC815 \uC801\uC6A9",
  "writerIndent": "\uB4E4\uC5EC\uC4F0\uAE30 (pt)",
  "writerSpaceBefore": "\uBB38\uB2E8 \uC55E (pt)",
  "writerSpaceAfter": "\uBB38\uB2E8 \uB4A4 (pt)",
  "writerLineHeight": "\uC904 \uB192\uC774 (pt, 0\uC740 \uC790\uB3D9)",
  "writerInsertInlineImage": "\uCEE4\uC11C \uC704\uCE58\uC5D0 \uC774\uBBF8\uC9C0 \uC0BD\uC785",
  "writerInlineImageNote": "\uAC1C\uCCB4 \uD45C\uC2DC\uB294 \uC778\uB77C\uC778 \uC774\uBBF8\uC9C0\uC785\uB2C8\uB2E4. \uC774\uBBF8\uC9C0 \uCEE8\uD2B8\uB864\uC5D0\uC11C \uD06C\uAE30\uB97C \uC870\uC815\uD558\uAC70\uB098 \uC0AD\uC81C\uD558\uC138\uC694.",
  "writerContinuous": "\uC5F0\uC18D \uD14D\uC2A4\uD2B8 \uD3B8\uC9D1",
  "writerExitContinuous": "\uBB38\uB2E8 \uD3B8\uC9D1\uC73C\uB85C \uB3CC\uC544\uAC00\uAE30",
  "writerContinuousNote": "\uC778\uC811 \uD14D\uC2A4\uD2B8 \uBB38\uB2E8\uC744 \uC120\uD0DD, \uBCF5\uC0AC, \uC798\uB77C\uB0B4\uAE30, \uBD99\uC5EC\uB123\uAE30 \uBC0F \uC11C\uC2DD \uC9C0\uC815\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uD45C, \uD398\uC774\uC9C0 \uB098\uB204\uAE30, \uAD6C\uC5ED \uBC0F \uC774\uBBF8\uC9C0 \uBB38\uB2E8\uC740 \uC120\uD0DD \uACBD\uACC4\uC785\uB2C8\uB2E4. \uBD99\uC5EC\uB123\uC740 \uC904\uBC14\uAFC8\uC740 \uC0C8 \uBB38\uB2E8\uC774 \uB429\uB2C8\uB2E4.",
  "writerSection": "\uAD6C\uC5ED",
  "writerSectionNumber": "\uAD6C\uC5ED {number}",
  "writerSectionBreak": "\uB2E4\uC74C \uD398\uC774\uC9C0 \uAD6C\uC5ED \uB098\uB204\uAE30",
  "writerTextLanguage": "\uD14D\uC2A4\uD2B8 \uC5B8\uC5B4 (BCP 47)",
  "writerParagraphDirection": "\uBB38\uB2E8 \uBC29\uD5A5",
  "writerLtr": "\uC67C\uCABD\uC5D0\uC11C \uC624\uB978\uCABD\uC73C\uB85C",
  "writerRtl": "\uC624\uB978\uCABD\uC5D0\uC11C \uC67C\uCABD\uC73C\uB85C",
  "docNew": "\uC0C8 DOC",
  "docDocument": "Word 97\u20132003 \uBB38\uC11C",
  "docNote": "\uC81C\uD55C\uB41C DOC \uD3B8\uC9D1: Unicode \uD14D\uC2A4\uD2B8, \uAE30\uBCF8 \uC11C\uC2DD, \uB2E8\uC77C \uAD6C\uC5ED. \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 DOC\uB294 \uC77D\uAE30 \uC804\uC6A9\uC774\uBA70 \uD45C\uC640 \uADF8\uB9BC\uC740 \uC800\uC7A5\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.",
  "docTextPreview": "\uC77D\uAE30 \uC804\uC6A9 \uBCF8\uBB38 \uD14D\uC2A4\uD2B8 \uBBF8\uB9AC\uBCF4\uAE30\uC785\uB2C8\uB2E4. \uC804\uCCB4 \uB808\uC774\uC544\uC6C3\uC740 \uC544\uB2C8\uBA70 \uBCF5\uC0AC\uBCF8\uC740 \uC6D0\uBCF8 \uBC14\uC774\uD2B8\uB97C \uC720\uC9C0\uD569\uB2C8\uB2E4.",
  "convertDoc": "DOC\uB85C \uBCC0\uD658",
  "convertDocx": "DOCX\uB85C \uBCC0\uD658",
  "conversionBoundary": "\uC9C0\uC6D0\uB418\uB294 \uAD6C\uC870\uB9CC \uBCC0\uD658\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uD574\uC11D\uB418\uC9C0 \uC54A\uC740 \uBD80\uBD84\uC740 \uC6D0\uBCF8\uC5D0 \uBCF4\uC874\uB429\uB2C8\uB2E4.",
  "writerPageEdit": "\uD398\uC774\uC9C0\uC5D0\uC11C \uD3B8\uC9D1",
  "writerExitPageEdit": "\uD3B8\uC9D1 \uB3C4\uAD6C\uB85C \uB3CC\uC544\uAC00\uAE30",
  "writerNativePageNote": "\uBE0C\uB77C\uC6B0\uC800\uC758 \uAE30\uBCF8 \uD14D\uC2A4\uD2B8 \uC170\uC774\uD551\uC73C\uB85C \uD398\uC774\uC9C0\uC5D0\uC11C \uD3B8\uC9D1\uD569\uB2C8\uB2E4. \uB4DC\uB798\uADF8\uB85C \uC120\uD0DD\uD558\uACE0 \uB0B4\uBD80 \uBCF5\uC0AC \uBC0F \uBD99\uC5EC\uB123\uAE30\uB294 \uC9C0\uC6D0 \uC11C\uC2DD\uACFC \uC774\uBBF8\uC9C0\uB97C \uBCF4\uC874\uD569\uB2C8\uB2E4. Word\uC640\uC758 \uBC30\uCE58 \uC815\uD655\uB3C4\uB294 \uAC80\uC99D\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4."
};
var french = {
  "open": "Ouvrir un fichier",
  "newDraft": "Nouveau brouillon",
  "recent": "Fichiers r\xE9cents",
  "local": "Espace local \xB7 Hors ligne avant tout",
  "settings": "Param\xE8tres",
  "workspace": "Espace de travail",
  "undo": "Annuler",
  "redo": "R\xE9tablir",
  "saveAs": "Enregistrer sous",
  "save": "Enregistrer",
  "ready": "Pr\xEAt",
  "theme": "Apparence",
  "system": "Syst\xE8me",
  "light": "Clair",
  "dark": "Sombre",
  "language": "Langue",
  "clearRecent": "Effacer les fichiers r\xE9cents",
  "settingsNote": "Les param\xE8tres et les instantan\xE9s de r\xE9cup\xE9ration restent sur cet ordinateur.",
  "welcome": "Un espace pour vos documents.",
  "welcomeSub": "Suite bureautique d\xE9velopp\xE9e ind\xE9pendamment. Cet aper\xE7u M3 permet de modifier des documents et des tableurs dans les formats pris en charge.",
  "newHeading": "Cr\xE9er un brouillon local",
  "draftHint": "Format interne de brouillon \xB7 .oex",
  "writer": "Document",
  "sheets": "Feuille de calcul",
  "slides": "Pr\xE9sentation",
  "writerSub": "R\xE9daction et mise en forme",
  "sheetsSub": "Cellules, formules et mise en forme",
  "slidesSub": "Aper\xE7u des sc\xE8nes de pr\xE9sentation",
  "dropTitle": "Ouvrez un fichier ou d\xE9posez-le ici",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Brouillons Office EX",
  "choose": "Choisir un fichier",
  "boundary": "Les documents DOC/DOCX et classeurs XLS/XLSX pris en charge peuvent \xEAtre modifi\xE9s et enregistr\xE9s. Les autres fichiers restent en lecture seule et peuvent \xEAtre copi\xE9s \xE0 l\u2019identique. La compatibilit\xE9 compl\xE8te est en d\xE9veloppement.",
  "formats": "Infrastructure des formats",
  "containerReady": "Conteneur int\xE9gr\xE9",
  "modern": "Formats modernes",
  "legacy": "Anciens formats",
  "draft": "Brouillons locaux",
  "noRecent": "Aucun fichier r\xE9cent",
  "untitled": "Sans titre",
  "draftLabel": "Brouillon Office EX",
  "readOnly": "Lecture seule \xB7 Inspection de la structure",
  "unsaved": "Non enregistr\xE9",
  "saved": "Enregistr\xE9",
  "reading": "Inspection de la structure du fichier\u2026",
  "cancel": "Annuler",
  "close": "Fermer",
  "cancelled": "Op\xE9ration annul\xE9e",
  "snapshot": "Instantan\xE9",
  "revision": "R\xE9vision",
  "savedNote": "Enregistrement r\xE9ussi",
  "draftNote": "Les brouillons OEX utilisent un format interne. Pour un fichier Office, cr\xE9ez un document DOC/DOCX ou un classeur XLS/XLSX avec les fonctions prises en charge.",
  "textLabel": "Texte du brouillon",
  "cellsLabel": "Cellules du tableur",
  "cellsNote": "Modifiez les cellules, les formules et la mise en forme. Les types de valeurs et le syst\xE8me de dates sont conserv\xE9s lors de l\u2019enregistrement dans les formats pris en charge.",
  "slideLabel": "Aper\xE7u de la sc\xE8ne et de la d\xE9tection de clics",
  "addShape": "Ajouter un rectangle",
  "shapeNote": "Cliquez sur une forme pour v\xE9rifier les coordonn\xE9es. L'\xE9diteur complet arrivera en M4.",
  "parts": "Parties du paquet / flux",
  "part": "Partie",
  "size": "Taille",
  "digest": "SHA-256",
  "version": "Version du format",
  "format": "Format d\xE9tect\xE9",
  "copy": "Enregistrer une copie identique",
  "pending": "Adaptateur de contenu en attente",
  "recoveries": "Brouillons r\xE9cup\xE9rables",
  "restore": "R\xE9cup\xE9rer une copie",
  "discard": "Abandonner",
  "recoveryNote": "La r\xE9cup\xE9ration cr\xE9e une nouvelle copie non enregistr\xE9e et pr\xE9serve le fichier source.",
  "recoveryCorrupt": "Les instantan\xE9s de r\xE9cup\xE9ration corrompus ont \xE9t\xE9 isol\xE9s et n'ont pas \xE9t\xE9 charg\xE9s.",
  "recovered": "R\xE9cup\xE9r\xE9 en tant que nouveau brouillon",
  "working": "Traitement en cours",
  "diagnostics": "Rapport de compatibilit\xE9",
  "noEntries": "Aucune partie du conteneur \xE0 afficher.",
  "emptySlide": "Diapositive vide",
  "clearDone": "Historique des fichiers r\xE9cents effac\xE9",
  "draftTitle": "Titre du document",
  "limitTabs": "32 onglets ouverts au maximum",
  "stage": "D\xE9veloppement ind\xE9pendant \xB7 Writer et Sheets",
  "partialDirectorySync": "Fichier enregistr\xE9 ; ce syst\xE8me de fichiers ne garantit pas la synchronisation du r\xE9pertoire.",
  "savedMaintenanceWarning": "Fichier enregistr\xE9, mais les donn\xE9es de r\xE9cup\xE9ration ou l'historique r\xE9cent n'ont pas pu \xEAtre actualis\xE9s.",
  "homeLabel": "Accueil Office EX",
  "mainNav": "Navigation principale",
  "documents": "Documents",
  "documentActions": "Actions sur le document",
  "previewTag": "M3 \xB7 APER\xC7U DE D\xC9VELOPPEMENT",
  "eyebrow": "OFFICE EX / ESPACE LOCAL",
  "region": "Formats r\xE9gionaux",
  "documentLanguage": "Langue des nouveaux documents (pr\xE9f\xE9rence)",
  "documentLanguageNote": "Les nouveaux documents Writer utilisent cette langue. Les fichiers existants restent inchang\xE9s ; les autres \xE9diteurs suivront.",
  "regionSample": "Aper\xE7u du format r\xE9gional",
  "history": "Historique",
  "canvas": "Canevas",
  "entriesLimited": "{count} entr\xE9es ; les 500 premi\xE8res sont affich\xE9es.",
  "menuFile": "Fichier",
  "menuEdit": "\xC9dition",
  "menuView": "Affichage",
  "menuNewWriter": "Nouveau brouillon de document",
  "menuNewSheets": "Nouveau brouillon de feuille de calcul",
  "menuNewSlides": "Nouveau brouillon de pr\xE9sentation",
  "menuOpen": "Ouvrir\u2026",
  "menuSaveAs": "Enregistrer sous\u2026",
  "menuCloseTab": "Fermer l'onglet",
  "menuCut": "Couper",
  "menuCopy": "Copier",
  "menuPaste": "Coller",
  "menuSelectAll": "Tout s\xE9lectionner",
  "menuFullscreen": "Basculer en plein \xE9cran",
  "menuResetZoom": "R\xE9initialiser le zoom",
  "menuZoomIn": "Zoom avant",
  "menuZoomOut": "Zoom arri\xE8re",
  "officeFiles": "Documents Office / Brouillons Office EX",
  "allFiles": "Tous les fichiers",
  "originalFormat": "Format de fichier d'origine",
  "replaceTarget": "Remplacer le fichier de destination existant ?",
  "replace": "Remplacer",
  "saveBeforeClose": "Enregistrer les modifications avant de fermer ?",
  "discardChanges": "Abandonner les modifications",
  "openFailed": "Impossible d'ouvrir le fichier",
  "windowFailed": "Impossible d'ouvrir la fen\xEAtre",
  "finishComposition": "Terminez la saisie en cours avant de changer de langue.",
  "oneDroppedFile": "D\xE9posez un seul fichier \xE0 la fois.",
  "errorInvalid": "Fichier ou requ\xEAte non valide.",
  "errorUnsupported": "Cette fonctionnalit\xE9 ou ce format n'est pas encore pris en charge.",
  "errorUnsafe": "L'op\xE9ration a \xE9t\xE9 bloqu\xE9e pour des raisons de s\xE9curit\xE9.",
  "errorLimit": "L'op\xE9ration d\xE9passe une limite de ressources.",
  "errorConflict": "Le document ou la destination a chang\xE9.",
  "errorIo": "L'op\xE9ration sur le fichier a \xE9chou\xE9.",
  "errorInternal": "Une erreur interne est survenue.",
  "diagUnknown": "Un diagnostic de compatibilit\xE9 inconnu a \xE9t\xE9 signal\xE9.",
  "diagSemanticPending": "Inspection du conteneur uniquement. Le contenu modifiable du document n'a pas \xE9t\xE9 import\xE9.",
  "diagMacrosDisabled": "Contenu li\xE9 aux macros d\xE9tect\xE9. Les macros ne sont pas ex\xE9cut\xE9es ; les octets d'origine ne sont conserv\xE9s que dans les copies identiques.",
  "diagSignedReadOnly": "Fichier sign\xE9 : inspection uniquement. La validit\xE9 de la signature n'est pas garantie.",
  "diagExternalDisabled": "Les relations externes sont r\xE9pertori\xE9es ; aucun contenu externe n'est charg\xE9.",
  "diagStrictReadOnly": "Strict OOXML identifi\xE9 ; la lecture et l'\xE9criture du contenu restent non v\xE9rifi\xE9es.",
  "diagEncryptedUnsupported": "Conteneur chiffr\xE9 d\xE9tect\xE9. Le d\xE9chiffrement et la modification ne sont pas disponibles.",
  "diagExtensionMismatch": "L'extension diff\xE8re du contenu d\xE9tect\xE9.",
  "writerFormatting": "Mise en forme du texte",
  "writerEditNote": "Modifiez les paragraphes et s\xE9lectionnez le texte \xE0 mettre en forme. Entr\xE9e scinde le paragraphe ; Maj+Entr\xE9e ins\xE8re un saut de ligne.",
  "writerPagePreview": "Aper\xE7u des pages",
  "writerEstimated": "Mise en page estim\xE9e. Cliquez sur la page pour placer le curseur. La fid\xE9lit\xE9 d'impression reste \xE0 v\xE9rifier.",
  "writerPreviousPage": "Page pr\xE9c\xE9dente",
  "writerNextPage": "Page suivante",
  "writerPageNumber": "Page {current} / {total}",
  "writerLayoutLimits": "Certaines fonctions typographiques sont approximatives.",
  "writerPreviewUnavailable": "Aper\xE7u indisponible pour ce contenu ou cette limite de mise en page. Le contenu source reste intact.",
  "writerBold": "Gras",
  "writerItalic": "Italique",
  "writerUnderline": "Soulign\xE9",
  "writerAlignLeft": "Aligner \xE0 gauche",
  "writerAlignCenter": "Centrer",
  "writerAlignRight": "Aligner \xE0 droite",
  "writerSplit": "Scinder le paragraphe",
  "writerPageBreak": "Saut de page apr\xE8s le paragraphe",
  "writerUnsupportedBlock": "Ce bloc ne peut pas \xEAtre modifi\xE9 dans cet aper\xE7u.",
  "docxNew": "Nouveau document DOCX",
  "docxDocument": "Document DOCX",
  "docxNote": "Profil DOCX limit\xE9 : texte, formatage direct, styles pris en charge, tableaux fixes, images PNG/JPEG int\xE9gr\xE9es et mise en page de base. Documents complexes en lecture seule.",
  "writerFontFamily": "Police",
  "writerFontSize": "Taille (pt)",
  "writerTextColor": "Couleur du texte",
  "writerParagraphStyle": "Style de paragraphe",
  "writerCharacterStyle": "Style de caract\xE8re",
  "writerChooseStyle": "Choisir un style",
  "writerTable": "Tableau",
  "writerTableRows": "Lignes",
  "writerTableColumns": "Colonnes",
  "writerInsertTable": "Ins\xE9rer un tableau",
  "writerAddRow": "Ajouter une ligne en dessous",
  "writerDeleteRow": "Supprimer la ligne",
  "writerAddColumn": "Ajouter une colonne \xE0 droite",
  "writerDeleteColumn": "Supprimer la colonne",
  "writerColumnWidth": "Largeur de colonne (pt)",
  "writerTableBorder": "Bordures du tableau",
  "writerDeleteTable": "Supprimer le tableau",
  "writerCell": "Cellule {row}, {column}",
  "writerInsertImage": "Ins\xE9rer une image",
  "writerImage": "Image",
  "writerImageWidth": "Largeur de l\u2019image (pt)",
  "writerRemoveImage": "Supprimer l\u2019image",
  "writerPaper": "Format papier",
  "writerCustomPaper": "Personnalis\xE9",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "Orientation",
  "writerPortrait": "Portrait",
  "writerLandscape": "Paysage",
  "writerPageWidth": "Largeur de page (pt)",
  "writerPageHeight": "Hauteur de page (pt)",
  "writerMarginTop": "Marge haute (pt)",
  "writerMarginRight": "Marge droite (pt)",
  "writerMarginBottom": "Marge basse (pt)",
  "writerMarginLeft": "Marge gauche (pt)",
  "writerApplyPage": "Appliquer la mise en page",
  "writerIndent": "Retrait (pt)",
  "writerSpaceBefore": "Avant (pt)",
  "writerSpaceAfter": "Apr\xE8s (pt)",
  "writerLineHeight": "Hauteur de ligne (pt ; 0 = auto)",
  "writerInsertInlineImage": "Ins\xE9rer une image au curseur",
  "writerInlineImageNote": "Le rep\xE8re d'objet repr\xE9sente une image int\xE9gr\xE9e. Utilisez ses commandes pour la redimensionner ou la supprimer.",
  "writerContinuous": "\xC9diter le texte continu",
  "writerExitContinuous": "Revenir \xE0 l'\xE9diteur de paragraphes",
  "writerContinuousNote": "S\xE9lectionnez, copiez, coupez, collez ou mettez en forme plusieurs paragraphes de texte adjacents. Les tableaux, sauts de page, sections et paragraphes avec images d\xE9limitent la s\xE9lection. Les nouvelles lignes coll\xE9es deviennent des paragraphes.",
  "writerSection": "Section",
  "writerSectionNumber": "Section {number}",
  "writerSectionBreak": "Saut de section sur la page suivante",
  "writerTextLanguage": "Langue du texte (BCP 47)",
  "writerParagraphDirection": "Direction du paragraphe",
  "writerLtr": "De gauche \xE0 droite",
  "writerRtl": "De droite \xE0 gauche",
  "docNew": "Nouveau DOC",
  "docDocument": "Document Word 97\u20132003",
  "docNote": "\xC9dition DOC limit\xE9e : texte Unicode, mise en forme simple et une section. Les autres DOC restent en lecture seule ; tableaux et images ne sont pas enregistrables.",
  "docTextPreview": "Aper\xE7u du texte principal en lecture seule, sans mise en page compl\xE8te. La copie conserve les octets d'origine.",
  "convertDoc": "Convertir en DOC",
  "convertDocx": "Convertir en DOCX",
  "conversionBoundary": "Seules les structures prises en charge peuvent \xEAtre converties ; les parties non interpr\xE9t\xE9es restent dans le fichier source.",
  "writerPageEdit": "Modifier sur la page",
  "writerExitPageEdit": "Retour aux outils",
  "writerNativePageNote": "Modifiez sur la page avec la mise en forme native du texte. Faites glisser pour s\xE9lectionner ; le presse-papiers interne conserve les styles et images pris en charge. La fid\xE9lit\xE9 \xE0 Word reste \xE0 v\xE9rifier."
};
var german = {
  "open": "Datei \xF6ffnen",
  "newDraft": "Neuer Entwurf",
  "recent": "Zuletzt ge\xF6ffnet",
  "local": "Lokaler Arbeitsbereich \xB7 Offline zuerst",
  "settings": "Einstellungen",
  "workspace": "Arbeitsbereich",
  "undo": "R\xFCckg\xE4ngig",
  "redo": "Wiederholen",
  "saveAs": "Speichern unter",
  "save": "Speichern",
  "ready": "Bereit",
  "theme": "Darstellung",
  "system": "System",
  "light": "Hell",
  "dark": "Dunkel",
  "language": "Sprache",
  "clearRecent": "Liste zuletzt ge\xF6ffneter Dateien leeren",
  "settingsNote": "Einstellungen und Wiederherstellungskopien bleiben auf diesem Computer.",
  "welcome": "Ein Platz f\xFCr Ihre Dokumente.",
  "welcomeSub": "Unabh\xE4ngig entwickelte Office-Suite. Diese M3-Vorschau erm\xF6glicht die Bearbeitung von Dokumenten und Tabellen im Umfang der unterst\xFCtzten Formate.",
  "newHeading": "Lokalen Entwurf erstellen",
  "draftHint": "Internes Entwurfsformat \xB7 .oex",
  "writer": "Dokument",
  "sheets": "Tabellenkalkulation",
  "slides": "Pr\xE4sentation",
  "writerSub": "Dokumente schreiben und formatieren",
  "sheetsSub": "Zellen, Formeln und Formatierung",
  "slidesSub": "Vorschau der Pr\xE4sentationsszene",
  "dropTitle": "Datei \xF6ffnen oder hier ablegen",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX-Entw\xFCrfe",
  "choose": "Datei ausw\xE4hlen",
  "boundary": "Unterst\xFCtzte DOC/DOCX-Dokumente und XLS/XLSX-Arbeitsmappen k\xF6nnen bearbeitet und gespeichert werden. Andere Dateien bleiben schreibgesch\xFCtzt und k\xF6nnen exakt kopiert werden. Vollst\xE4ndige Kompatibilit\xE4t ist noch in Entwicklung.",
  "formats": "Formatinfrastruktur",
  "containerReady": "Container eingebunden",
  "modern": "Moderne Formate",
  "legacy": "\xC4ltere Formate",
  "draft": "Lokale Entw\xFCrfe",
  "noRecent": "Keine zuletzt ge\xF6ffneten Dateien",
  "untitled": "Unbenannt",
  "draftLabel": "Office EX-Entwurf",
  "readOnly": "Schreibgesch\xFCtzt \xB7 Strukturpr\xFCfung",
  "unsaved": "Nicht gespeichert",
  "saved": "Gespeichert",
  "reading": "Dateistruktur wird gepr\xFCft\u2026",
  "cancel": "Abbrechen",
  "close": "Schlie\xDFen",
  "cancelled": "Vorgang abgebrochen",
  "snapshot": "Momentaufnahme",
  "revision": "Revision",
  "savedNote": "Erfolgreich gespeichert",
  "draftNote": "OEX-Entw\xFCrfe verwenden ein internes Format. F\xFCr Office-Dateien erstellen Sie ein DOC/DOCX-Dokument oder eine XLS/XLSX-Arbeitsmappe mit den unterst\xFCtzten Funktionen.",
  "textLabel": "Entwurfstext",
  "cellsLabel": "Tabellenzellen",
  "cellsNote": "Bearbeiten Sie Zellen, Formeln und Formate. Werttypen und das Datumssystem bleiben beim Speichern unterst\xFCtzter Formate erhalten.",
  "slideLabel": "Vorschau von Szene und Treffertest",
  "addShape": "Rechteck hinzuf\xFCgen",
  "shapeNote": "Klicken Sie auf eine Form, um die Koordinaten zu pr\xFCfen. Der vollst\xE4ndige Editor folgt in M4.",
  "parts": "Paketteile / Datenstr\xF6me",
  "part": "Teil",
  "size": "Gr\xF6\xDFe",
  "digest": "SHA-256",
  "version": "Formatversion",
  "format": "Erkanntes Format",
  "copy": "Identische Kopie speichern",
  "pending": "Inhaltsadapter ausstehend",
  "recoveries": "Wiederherstellbare Entw\xFCrfe",
  "restore": "Kopie wiederherstellen",
  "discard": "Verwerfen",
  "recoveryNote": "Die Wiederherstellung erstellt eine neue ungespeicherte Kopie und erh\xE4lt die Quelldatei.",
  "recoveryCorrupt": "Besch\xE4digte Wiederherstellungskopien wurden isoliert und nicht geladen.",
  "recovered": "Als neuer Entwurf wiederhergestellt",
  "working": "In Bearbeitung",
  "diagnostics": "Kompatibilit\xE4tsbericht",
  "noEntries": "Keine anzeigbaren Containerteile.",
  "emptySlide": "Leere Folie",
  "clearDone": "Liste zuletzt ge\xF6ffneter Dateien geleert",
  "draftTitle": "Dokumenttitel",
  "limitTabs": "Maximal 32 ge\xF6ffnete Registerkarten",
  "stage": "Unabh\xE4ngige Entwicklung \xB7 Writer und Sheets",
  "partialDirectorySync": "Datei gespeichert; dieses Dateisystem garantiert keine Verzeichnissynchronisierung.",
  "savedMaintenanceWarning": "Datei gespeichert, aber Wiederherstellungsdaten oder Dateiverlauf konnten nicht aktualisiert werden.",
  "homeLabel": "Office EX-Startseite",
  "mainNav": "Hauptnavigation",
  "documents": "Dokumente",
  "documentActions": "Dokumentaktionen",
  "previewTag": "M3 \xB7 ENTWICKLUNGSVORSCHAU",
  "eyebrow": "OFFICE EX / LOKALER ARBEITSBEREICH",
  "region": "Regionale Formate",
  "documentLanguage": "Sprache neuer Dokumente (Voreinstellung)",
  "documentLanguageNote": "Neue Writer-Dokumente verwenden diese Textsprache. Vorhandene Dateien bleiben unver\xE4ndert; andere Editoren folgen sp\xE4ter.",
  "regionSample": "Vorschau regionaler Formate",
  "history": "Verlauf",
  "canvas": "Zeichenfl\xE4che",
  "entriesLimited": "{count} Eintr\xE4ge; die ersten 500 werden angezeigt.",
  "menuFile": "Datei",
  "menuEdit": "Bearbeiten",
  "menuView": "Ansicht",
  "menuNewWriter": "Neuer Dokumententwurf",
  "menuNewSheets": "Neuer Tabellenentwurf",
  "menuNewSlides": "Neuer Pr\xE4sentationsentwurf",
  "menuOpen": "\xD6ffnen\u2026",
  "menuSaveAs": "Speichern unter\u2026",
  "menuCloseTab": "Registerkarte schlie\xDFen",
  "menuCut": "Ausschneiden",
  "menuCopy": "Kopieren",
  "menuPaste": "Einf\xFCgen",
  "menuSelectAll": "Alles ausw\xE4hlen",
  "menuFullscreen": "Vollbild umschalten",
  "menuResetZoom": "Zoom zur\xFCcksetzen",
  "menuZoomIn": "Vergr\xF6\xDFern",
  "menuZoomOut": "Verkleinern",
  "officeFiles": "Office-Dokumente / Office EX-Entw\xFCrfe",
  "allFiles": "Alle Dateien",
  "originalFormat": "Urspr\xFCngliches Dateiformat",
  "replaceTarget": "Vorhandene Zieldatei ersetzen?",
  "replace": "Ersetzen",
  "saveBeforeClose": "\xC4nderungen vor dem Schlie\xDFen speichern?",
  "discardChanges": "\xC4nderungen verwerfen",
  "openFailed": "Datei konnte nicht ge\xF6ffnet werden",
  "windowFailed": "Fenster konnte nicht ge\xF6ffnet werden",
  "finishComposition": "Beenden Sie die laufende Eingabe vor dem Sprachwechsel.",
  "oneDroppedFile": "Legen Sie jeweils nur eine Datei ab.",
  "errorInvalid": "Ung\xFCltige Datei oder Anfrage.",
  "errorUnsupported": "Diese Funktion oder dieses Format wird noch nicht unterst\xFCtzt.",
  "errorUnsafe": "Der Vorgang wurde aus Sicherheitsgr\xFCnden blockiert.",
  "errorLimit": "Der Vorgang \xFCberschreitet ein Ressourcenlimit.",
  "errorConflict": "Das Dokument oder Ziel wurde ge\xE4ndert.",
  "errorIo": "Der Dateivorgang ist fehlgeschlagen.",
  "errorInternal": "Ein interner Fehler ist aufgetreten.",
  "diagUnknown": "Eine unbekannte Kompatibilit\xE4tsdiagnose wurde gemeldet.",
  "diagSemanticPending": "Nur Containerpr\xFCfung. Bearbeitbare Dokumentinhalte wurden noch nicht importiert.",
  "diagMacrosDisabled": "Makrobezogene Inhalte erkannt. Makros werden nicht ausgef\xFChrt; Originalbytes bleiben nur in identischen Kopien erhalten.",
  "diagSignedReadOnly": "Signierte Datei: nur Pr\xFCfung. Die G\xFCltigkeit der Signatur wird nicht best\xE4tigt.",
  "diagExternalDisabled": "Externe Beziehungen wurden erfasst; externe Inhalte werden nicht geladen.",
  "diagStrictReadOnly": "Strict OOXML erkannt; Lesen und Schreiben von Inhalten sind noch nicht verifiziert.",
  "diagEncryptedUnsupported": "Verschl\xFCsselter Container erkannt. Entschl\xFCsselung und Bearbeitung sind nicht verf\xFCgbar.",
  "diagExtensionMismatch": "Die Dateiendung stimmt nicht mit dem erkannten Inhalt \xFCberein.",
  "writerFormatting": "Textformatierung",
  "writerEditNote": "Bearbeiten Sie Abs\xE4tze und markieren Sie Text. Eingabe teilt den Absatz; Umschalt+Eingabe f\xFCgt einen Zeilenumbruch ein.",
  "writerPagePreview": "Seitenvorschau",
  "writerEstimated": "Gesch\xE4tztes Seitenlayout. Klicken Sie auf die Seite, um Text zu finden. Die Drucktreue ist noch nicht gepr\xFCft.",
  "writerPreviousPage": "Vorherige Seite",
  "writerNextPage": "N\xE4chste Seite",
  "writerPageNumber": "Seite {current} / {total}",
  "writerLayoutLimits": "Einige Typografie- oder Layoutfunktionen werden angen\xE4hert.",
  "writerPreviewUnavailable": "Vorschau f\xFCr diesen Inhalt oder diese Layoutgrenze nicht verf\xFCgbar. Der Quellinhalt bleibt unver\xE4ndert.",
  "writerBold": "Fett",
  "writerItalic": "Kursiv",
  "writerUnderline": "Unterstrichen",
  "writerAlignLeft": "Linksb\xFCndig",
  "writerAlignCenter": "Zentriert",
  "writerAlignRight": "Rechtsb\xFCndig",
  "writerSplit": "Absatz teilen",
  "writerPageBreak": "Seitenumbruch nach Absatz",
  "writerUnsupportedBlock": "Dieser Block ist in dieser Vorschau nicht bearbeitbar.",
  "docxNew": "Neues DOCX-Dokument",
  "docxDocument": "DOCX-Dokument",
  "docxNote": "Begrenztes DOCX-Profil: Text, direkte Formatierung, unterst\xFCtzte Stile, feste Tabellen, Inline-Bilder (PNG/JPEG) und einfaches Layout. Komplexe Dokumente bleiben schreibgesch\xFCtzt.",
  "writerFontFamily": "Schriftart",
  "writerFontSize": "Gr\xF6\xDFe (pt)",
  "writerTextColor": "Textfarbe",
  "writerParagraphStyle": "Absatzstil",
  "writerCharacterStyle": "Zeichenstil",
  "writerChooseStyle": "Stil ausw\xE4hlen",
  "writerTable": "Tabelle",
  "writerTableRows": "Zeilen",
  "writerTableColumns": "Spalten",
  "writerInsertTable": "Tabelle einf\xFCgen",
  "writerAddRow": "Zeile darunter einf\xFCgen",
  "writerDeleteRow": "Zeile l\xF6schen",
  "writerAddColumn": "Spalte rechts einf\xFCgen",
  "writerDeleteColumn": "Spalte l\xF6schen",
  "writerColumnWidth": "Spaltenbreite (pt)",
  "writerTableBorder": "Tabellenrahmen",
  "writerDeleteTable": "Tabelle l\xF6schen",
  "writerCell": "Zelle {row}, {column}",
  "writerInsertImage": "Bild einf\xFCgen",
  "writerImage": "Bild",
  "writerImageWidth": "Bildbreite (pt)",
  "writerRemoveImage": "Bild l\xF6schen",
  "writerPaper": "Papierformat",
  "writerCustomPaper": "Benutzerdefiniert",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "Seitenausrichtung",
  "writerPortrait": "Hochformat",
  "writerLandscape": "Querformat",
  "writerPageWidth": "Seitenbreite (pt)",
  "writerPageHeight": "Seitenh\xF6he (pt)",
  "writerMarginTop": "Oberer Rand (pt)",
  "writerMarginRight": "Rechter Rand (pt)",
  "writerMarginBottom": "Unterer Rand (pt)",
  "writerMarginLeft": "Linker Rand (pt)",
  "writerApplyPage": "Seiteneinstellungen anwenden",
  "writerIndent": "Einzug (pt)",
  "writerSpaceBefore": "Abstand davor (pt)",
  "writerSpaceAfter": "Abstand danach (pt)",
  "writerLineHeight": "Zeilenh\xF6he (pt; 0 = automatisch)",
  "writerInsertInlineImage": "Bild am Cursor einf\xFCgen",
  "writerInlineImageNote": "Die Objektmarke steht f\xFCr ein Inline-Bild. Verwenden Sie die Bildsteuerung zum Verkleinern, Vergr\xF6\xDFern oder Entfernen.",
  "writerContinuous": "Zusammenh\xE4ngenden Text bearbeiten",
  "writerExitContinuous": "Zur\xFCck zum Absatzeditor",
  "writerContinuousNote": "Markieren, kopieren, schneiden, f\xFCgen oder formatieren Sie benachbarte Textabs\xE4tze. Tabellen, Seitenumbr\xFCche, Abschnitte und Bildabs\xE4tze begrenzen die Auswahl. Eingef\xFCgte neue Zeilen werden Abs\xE4tze.",
  "writerSection": "Abschnitt",
  "writerSectionNumber": "Abschnitt {number}",
  "writerSectionBreak": "Abschnittsumbruch (n\xE4chste Seite)",
  "writerTextLanguage": "Textsprache (BCP 47)",
  "writerParagraphDirection": "Absatzrichtung",
  "writerLtr": "Links nach rechts",
  "writerRtl": "Rechts nach links",
  "docNew": "Neues DOC",
  "docDocument": "Word-97\u20132003-Dokument",
  "docNote": "Begrenzte DOC-Bearbeitung: Unicode-Text, einfache Formatierung und ein Abschnitt. Andere DOC-Dateien bleiben schreibgesch\xFCtzt; Tabellen und Bilder k\xF6nnen nicht gespeichert werden.",
  "docTextPreview": "Schreibgesch\xFCtzte Vorschau des Haupttexts, kein vollst\xE4ndiges Layout. Eine Kopie bewahrt die urspr\xFCnglichen Bytes.",
  "convertDoc": "In DOC umwandeln",
  "convertDocx": "In DOCX umwandeln",
  "conversionBoundary": "Nur unterst\xFCtzte Strukturen k\xF6nnen konvertiert werden. Nicht interpretierte Teile bleiben in der Quelldatei.",
  "writerPageEdit": "Auf der Seite bearbeiten",
  "writerExitPageEdit": "Zur\xFCck zu den Werkzeugen",
  "writerNativePageNote": "Bearbeiten Sie direkt auf der Seite mit nativer Textformung. Ziehen Sie zum Ausw\xE4hlen; die interne Zwischenablage erh\xE4lt unterst\xFCtzte Formate und Bilder. Die Layouttreue zu Word ist noch nicht gepr\xFCft."
};

// packages/i18n/src/catalogs-a2.ts
var spanish = {
  "open": "Abrir archivo",
  "newDraft": "Nuevo borrador",
  "recent": "Archivos recientes",
  "local": "Espacio local \xB7 Sin conexi\xF3n por defecto",
  "settings": "Configuraci\xF3n",
  "workspace": "Espacio de trabajo",
  "undo": "Deshacer",
  "redo": "Rehacer",
  "saveAs": "Guardar como",
  "save": "Guardar",
  "ready": "Listo",
  "theme": "Apariencia",
  "system": "Sistema",
  "light": "Claro",
  "dark": "Oscuro",
  "language": "Idioma",
  "clearRecent": "Borrar archivos recientes",
  "settingsNote": "La configuraci\xF3n y las instant\xE1neas de recuperaci\xF3n permanecen en este equipo.",
  "welcome": "Un lugar para tus documentos.",
  "welcomeSub": "Suite ofim\xE1tica de desarrollo independiente. Esta vista previa M3 permite editar documentos y hojas de c\xE1lculo dentro de los formatos compatibles.",
  "newHeading": "Crear un borrador local",
  "draftHint": "Formato interno de borrador \xB7 .oex",
  "writer": "Documento",
  "sheets": "Hoja de c\xE1lculo",
  "slides": "Presentaci\xF3n",
  "writerSub": "Redacci\xF3n y formato de documentos",
  "sheetsSub": "Celdas, f\xF3rmulas y formatos",
  "slidesSub": "Vista previa de escenas de presentaci\xF3n",
  "dropTitle": "Abre un archivo o su\xE9ltalo aqu\xED",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Borradores Office EX",
  "choose": "Elegir archivo",
  "boundary": "Los documentos DOC/DOCX y libros XLS/XLSX compatibles se pueden editar y guardar. Los dem\xE1s archivos son de solo lectura y se pueden copiar de forma exacta. La compatibilidad completa est\xE1 en desarrollo.",
  "formats": "Infraestructura de formatos",
  "containerReady": "Contenedor integrado",
  "modern": "Formatos modernos",
  "legacy": "Formatos antiguos",
  "draft": "Borradores locales",
  "noRecent": "No hay archivos recientes",
  "untitled": "Sin t\xEDtulo",
  "draftLabel": "Borrador de Office EX",
  "readOnly": "Solo lectura \xB7 Inspecci\xF3n de estructura",
  "unsaved": "Sin guardar",
  "saved": "Guardado",
  "reading": "Inspeccionando la estructura del archivo\u2026",
  "cancel": "Cancelar",
  "close": "Cerrar",
  "cancelled": "Operaci\xF3n cancelada",
  "snapshot": "Instant\xE1nea",
  "revision": "Revisi\xF3n",
  "savedNote": "Guardado correctamente",
  "draftNote": "Los borradores OEX usan un formato interno. Para archivos de Office, cree un documento DOC/DOCX o un libro XLS/XLSX con las funciones compatibles.",
  "textLabel": "Texto del borrador",
  "cellsLabel": "Celdas de la hoja de c\xE1lculo",
  "cellsNote": "Edite celdas, f\xF3rmulas y formatos. Los tipos de valores y el sistema de fechas se conservan al guardar en formatos compatibles.",
  "slideLabel": "Vista previa de escena y detecci\xF3n de clics",
  "addShape": "A\xF1adir rect\xE1ngulo",
  "shapeNote": "Haz clic en una forma para comprobar las coordenadas. El editor completo llegar\xE1 en M4.",
  "parts": "Partes del paquete / flujos",
  "part": "Parte",
  "size": "Tama\xF1o",
  "digest": "SHA-256",
  "version": "Versi\xF3n del formato",
  "format": "Formato detectado",
  "copy": "Guardar copia exacta",
  "pending": "Adaptador de contenido pendiente",
  "recoveries": "Borradores recuperables",
  "restore": "Recuperar una copia",
  "discard": "Descartar",
  "recoveryNote": "La recuperaci\xF3n crea una copia nueva sin guardar y conserva el archivo original.",
  "recoveryCorrupt": "Las instant\xE1neas de recuperaci\xF3n da\xF1adas se aislaron y no se cargaron.",
  "recovered": "Recuperado como nuevo borrador",
  "working": "Procesando",
  "diagnostics": "Informe de compatibilidad",
  "noEntries": "No hay partes del contenedor que mostrar.",
  "emptySlide": "Diapositiva en blanco",
  "clearDone": "Historial de archivos recientes borrado",
  "draftTitle": "T\xEDtulo del documento",
  "limitTabs": "Se pueden abrir hasta 32 pesta\xF1as",
  "stage": "Desarrollo independiente \xB7 Writer y Sheets",
  "partialDirectorySync": "Archivo guardado; este sistema de archivos no garantiza la sincronizaci\xF3n del directorio.",
  "savedMaintenanceWarning": "Archivo guardado, pero no se pudieron actualizar los datos de recuperaci\xF3n o el historial reciente.",
  "homeLabel": "Inicio de Office EX",
  "mainNav": "Navegaci\xF3n principal",
  "documents": "Documentos",
  "documentActions": "Acciones del documento",
  "previewTag": "M3 \xB7 VISTA PREVIA DE DESARROLLO",
  "eyebrow": "OFFICE EX / ESPACIO LOCAL",
  "region": "Formatos regionales",
  "documentLanguage": "Idioma de documentos nuevos (preferencia)",
  "documentLanguageNote": "Los documentos nuevos de Writer usan este idioma. Los archivos existentes no cambian; los otros editores lo incorporar\xE1n m\xE1s adelante.",
  "regionSample": "Vista previa del formato regional",
  "history": "Historial",
  "canvas": "Lienzo",
  "entriesLimited": "{count} entradas; se muestran las primeras 500.",
  "menuFile": "Archivo",
  "menuEdit": "Editar",
  "menuView": "Ver",
  "menuNewWriter": "Nuevo borrador de documento",
  "menuNewSheets": "Nuevo borrador de hoja de c\xE1lculo",
  "menuNewSlides": "Nuevo borrador de presentaci\xF3n",
  "menuOpen": "Abrir\u2026",
  "menuSaveAs": "Guardar como\u2026",
  "menuCloseTab": "Cerrar pesta\xF1a",
  "menuCut": "Cortar",
  "menuCopy": "Copiar",
  "menuPaste": "Pegar",
  "menuSelectAll": "Seleccionar todo",
  "menuFullscreen": "Alternar pantalla completa",
  "menuResetZoom": "Restablecer zoom",
  "menuZoomIn": "Acercar",
  "menuZoomOut": "Alejar",
  "officeFiles": "Documentos de Office / Borradores de Office EX",
  "allFiles": "Todos los archivos",
  "originalFormat": "Formato de archivo original",
  "replaceTarget": "\xBFReemplazar el archivo de destino existente?",
  "replace": "Reemplazar",
  "saveBeforeClose": "\xBFGuardar los cambios antes de cerrar?",
  "discardChanges": "Descartar cambios",
  "openFailed": "No se pudo abrir el archivo",
  "windowFailed": "No se pudo abrir la ventana",
  "finishComposition": "Termina la entrada actual antes de cambiar el idioma.",
  "oneDroppedFile": "Suelta un solo archivo cada vez.",
  "errorInvalid": "Archivo o solicitud no v\xE1lidos.",
  "errorUnsupported": "Esta funci\xF3n o formato a\xFAn no es compatible.",
  "errorUnsafe": "La operaci\xF3n se bloque\xF3 por seguridad.",
  "errorLimit": "La operaci\xF3n supera un l\xEDmite de recursos.",
  "errorConflict": "El documento o el destino ha cambiado.",
  "errorIo": "La operaci\xF3n de archivo ha fallado.",
  "errorInternal": "Se produjo un error interno.",
  "diagUnknown": "Se notific\xF3 un diagn\xF3stico de compatibilidad desconocido.",
  "diagSemanticPending": "Solo se inspecciona el contenedor. El contenido editable del documento no se ha importado.",
  "diagMacrosDisabled": "Se detect\xF3 contenido relacionado con macros. Las macros no se ejecutan; los bytes originales solo se conservan en copias exactas.",
  "diagSignedReadOnly": "Archivo firmado: solo inspecci\xF3n. No se garantiza la validez de la firma.",
  "diagExternalDisabled": "Se registraron las relaciones externas; no se carga contenido externo.",
  "diagStrictReadOnly": "Se identific\xF3 Strict OOXML; la lectura y escritura del contenido a\xFAn no se han verificado.",
  "diagEncryptedUnsupported": "Se identific\xF3 un contenedor cifrado. El descifrado y la edici\xF3n no est\xE1n disponibles.",
  "diagExtensionMismatch": "La extensi\xF3n no coincide con el contenido detectado.",
  "writerFormatting": "Formato de texto",
  "writerEditNote": "Edita los p\xE1rrafos y selecciona texto para darle formato. Intro divide el p\xE1rrafo; May\xFAs+Intro inserta un salto de l\xEDnea.",
  "writerPagePreview": "Vista previa de p\xE1gina",
  "writerEstimated": "Dise\xF1o estimado. Haz clic en la p\xE1gina para localizar el texto. La fidelidad de impresi\xF3n a\xFAn no se ha verificado.",
  "writerPreviousPage": "P\xE1gina anterior",
  "writerNextPage": "P\xE1gina siguiente",
  "writerPageNumber": "P\xE1gina {current} / {total}",
  "writerLayoutLimits": "Algunas funciones tipogr\xE1ficas son aproximadas.",
  "writerPreviewUnavailable": "Vista previa no disponible para este contenido o l\xEDmite de dise\xF1o. El contenido original no cambia.",
  "writerBold": "Negrita",
  "writerItalic": "Cursiva",
  "writerUnderline": "Subrayado",
  "writerAlignLeft": "Alinear a la izquierda",
  "writerAlignCenter": "Centrar",
  "writerAlignRight": "Alinear a la derecha",
  "writerSplit": "Dividir p\xE1rrafo",
  "writerPageBreak": "Salto de p\xE1gina despu\xE9s del p\xE1rrafo",
  "writerUnsupportedBlock": "Este bloque no se puede editar en esta vista previa.",
  "docxNew": "Nuevo documento DOCX",
  "docxDocument": "Documento DOCX",
  "docxNote": "Perfil DOCX limitado: texto, formato directo, estilos compatibles, tablas fijas, im\xE1genes PNG/JPEG en l\xEDnea y dise\xF1o b\xE1sico. Documentos complejos de solo lectura.",
  "writerFontFamily": "Fuente",
  "writerFontSize": "Tama\xF1o (pt)",
  "writerTextColor": "Color del texto",
  "writerParagraphStyle": "Estilo de p\xE1rrafo",
  "writerCharacterStyle": "Estilo de car\xE1cter",
  "writerChooseStyle": "Elegir estilo",
  "writerTable": "Tabla",
  "writerTableRows": "Filas",
  "writerTableColumns": "Columnas",
  "writerInsertTable": "Insertar tabla",
  "writerAddRow": "A\xF1adir fila debajo",
  "writerDeleteRow": "Eliminar fila",
  "writerAddColumn": "A\xF1adir columna a la derecha",
  "writerDeleteColumn": "Eliminar columna",
  "writerColumnWidth": "Ancho de columna (pt)",
  "writerTableBorder": "Bordes de tabla",
  "writerDeleteTable": "Eliminar tabla",
  "writerCell": "Celda {row}, {column}",
  "writerInsertImage": "Insertar imagen",
  "writerImage": "Imagen",
  "writerImageWidth": "Ancho de imagen (pt)",
  "writerRemoveImage": "Eliminar imagen",
  "writerPaper": "Tama\xF1o de papel",
  "writerCustomPaper": "Personalizado",
  "writerA4": "A4",
  "writerLetter": "Carta",
  "writerA3": "A3",
  "writerOrientation": "Orientaci\xF3n",
  "writerPortrait": "Vertical",
  "writerLandscape": "Horizontal",
  "writerPageWidth": "Ancho de p\xE1gina (pt)",
  "writerPageHeight": "Alto de p\xE1gina (pt)",
  "writerMarginTop": "Margen superior (pt)",
  "writerMarginRight": "Margen derecho (pt)",
  "writerMarginBottom": "Margen inferior (pt)",
  "writerMarginLeft": "Margen izquierdo (pt)",
  "writerApplyPage": "Aplicar configuraci\xF3n de p\xE1gina",
  "writerIndent": "Sangr\xEDa (pt)",
  "writerSpaceBefore": "Anterior (pt)",
  "writerSpaceAfter": "Posterior (pt)",
  "writerLineHeight": "Altura de l\xEDnea (pt; 0 = auto)",
  "writerInsertInlineImage": "Insertar imagen en el cursor",
  "writerInlineImageNote": "La marca de objeto representa una imagen en l\xEDnea. Usa sus controles para cambiar el tama\xF1o o eliminarla.",
  "writerContinuous": "Editar texto continuo",
  "writerExitContinuous": "Volver al editor de p\xE1rrafos",
  "writerContinuousNote": "Selecciona, copia, corta, pega o da formato a p\xE1rrafos de texto contiguos. Las tablas, saltos de p\xE1gina, secciones y p\xE1rrafos con im\xE1genes delimitan la selecci\xF3n. Las nuevas l\xEDneas pegadas se convierten en p\xE1rrafos.",
  "writerSection": "Secci\xF3n",
  "writerSectionNumber": "Secci\xF3n {number}",
  "writerSectionBreak": "Salto de secci\xF3n en la p\xE1gina siguiente",
  "writerTextLanguage": "Idioma del texto (BCP 47)",
  "writerParagraphDirection": "Direcci\xF3n del p\xE1rrafo",
  "writerLtr": "De izquierda a derecha",
  "writerRtl": "De derecha a izquierda",
  "docNew": "Nuevo DOC",
  "docDocument": "Documento Word 97\u20132003",
  "docNote": "Edici\xF3n DOC limitada: texto Unicode, formato b\xE1sico y una secci\xF3n. Los DOC no compatibles son de solo lectura; no se pueden guardar tablas ni im\xE1genes.",
  "docTextPreview": "Vista previa de solo lectura del texto principal, no del dise\xF1o completo. La copia conserva los bytes originales.",
  "convertDoc": "Convertir a DOC",
  "convertDocx": "Convertir a DOCX",
  "conversionBoundary": "Solo pueden convertirse estructuras compatibles. Las partes no interpretadas se conservan en el archivo original.",
  "writerPageEdit": "Editar en la p\xE1gina",
  "writerExitPageEdit": "Volver a las herramientas",
  "writerNativePageNote": "Edita en la p\xE1gina con la composici\xF3n nativa de texto. Arrastra para seleccionar; el portapapeles interno conserva formatos e im\xE1genes compatibles. A\xFAn no se ha verificado la fidelidad a Word."
};
var portuguese = {
  "open": "Abrir arquivo",
  "newDraft": "Novo rascunho",
  "recent": "Arquivos recentes",
  "local": "Espa\xE7o local \xB7 Offline por padr\xE3o",
  "settings": "Configura\xE7\xF5es",
  "workspace": "\xC1rea de trabalho",
  "undo": "Desfazer",
  "redo": "Refazer",
  "saveAs": "Salvar como",
  "save": "Salvar",
  "ready": "Pronto",
  "theme": "Apar\xEAncia",
  "system": "Sistema",
  "light": "Claro",
  "dark": "Escuro",
  "language": "Idioma",
  "clearRecent": "Limpar arquivos recentes",
  "settingsNote": "As configura\xE7\xF5es e os instant\xE2neos de recupera\xE7\xE3o ficam neste computador.",
  "welcome": "Um lugar para seus documentos.",
  "welcomeSub": "Su\xEDte de escrit\xF3rio desenvolvida de forma independente. Esta pr\xE9via M3 permite editar documentos e planilhas dentro dos formatos compat\xEDveis.",
  "newHeading": "Criar um rascunho local",
  "draftHint": "Formato interno de rascunho \xB7 .oex",
  "writer": "Documento",
  "sheets": "Planilha",
  "slides": "Apresenta\xE7\xE3o",
  "writerSub": "Escrita e formata\xE7\xE3o de documentos",
  "sheetsSub": "C\xE9lulas, f\xF3rmulas e formata\xE7\xE3o",
  "slidesSub": "Pr\xE9via das cenas da apresenta\xE7\xE3o",
  "dropTitle": "Abra um arquivo ou solte-o aqui",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Rascunhos do Office EX",
  "choose": "Escolher arquivo",
  "boundary": "Documentos DOC/DOCX e pastas XLS/XLSX compat\xEDveis podem ser editados e salvos. Os demais arquivos permanecem somente leitura e podem ser copiados integralmente. A compatibilidade completa est\xE1 em desenvolvimento.",
  "formats": "Infraestrutura de formatos",
  "containerReady": "Cont\xEAiner integrado",
  "modern": "Formatos modernos",
  "legacy": "Formatos antigos",
  "draft": "Rascunhos locais",
  "noRecent": "Nenhum arquivo recente",
  "untitled": "Sem t\xEDtulo",
  "draftLabel": "Rascunho do Office EX",
  "readOnly": "Somente leitura \xB7 Inspe\xE7\xE3o da estrutura",
  "unsaved": "N\xE3o salvo",
  "saved": "Salvo",
  "reading": "Inspecionando a estrutura do arquivo\u2026",
  "cancel": "Cancelar",
  "close": "Fechar",
  "cancelled": "Opera\xE7\xE3o cancelada",
  "snapshot": "Instant\xE2neo",
  "revision": "Revis\xE3o",
  "savedNote": "Salvo com sucesso",
  "draftNote": "Rascunhos OEX usam um formato interno. Para arquivos do Office, crie um documento DOC/DOCX ou uma pasta XLS/XLSX com os recursos compat\xEDveis.",
  "textLabel": "Texto do rascunho",
  "cellsLabel": "C\xE9lulas da planilha",
  "cellsNote": "Edite c\xE9lulas, f\xF3rmulas e formata\xE7\xE3o. Os tipos de valores e o sistema de datas s\xE3o preservados ao salvar nos formatos compat\xEDveis.",
  "slideLabel": "Pr\xE9via da cena e da detec\xE7\xE3o de cliques",
  "addShape": "Adicionar ret\xE2ngulo",
  "shapeNote": "Clique em uma forma para verificar as coordenadas. O editor completo chegar\xE1 no M4.",
  "parts": "Partes do pacote / fluxos",
  "part": "Parte",
  "size": "Tamanho",
  "digest": "SHA-256",
  "version": "Vers\xE3o do formato",
  "format": "Formato detectado",
  "copy": "Salvar c\xF3pia exata",
  "pending": "Adaptador de conte\xFAdo pendente",
  "recoveries": "Rascunhos recuper\xE1veis",
  "restore": "Recuperar uma c\xF3pia",
  "discard": "Descartar",
  "recoveryNote": "A recupera\xE7\xE3o cria uma nova c\xF3pia n\xE3o salva e preserva o arquivo original.",
  "recoveryCorrupt": "Os instant\xE2neos de recupera\xE7\xE3o corrompidos foram isolados e n\xE3o foram carregados.",
  "recovered": "Recuperado como novo rascunho",
  "working": "Processando",
  "diagnostics": "Relat\xF3rio de compatibilidade",
  "noEntries": "N\xE3o h\xE1 partes do cont\xEAiner para exibir.",
  "emptySlide": "Slide em branco",
  "clearDone": "Hist\xF3rico de arquivos recentes limpo",
  "draftTitle": "T\xEDtulo do documento",
  "limitTabs": "\xC9 poss\xEDvel abrir at\xE9 32 abas",
  "stage": "Desenvolvimento independente \xB7 Writer e Sheets",
  "partialDirectorySync": "Arquivo salvo; este sistema de arquivos n\xE3o garante a sincroniza\xE7\xE3o do diret\xF3rio.",
  "savedMaintenanceWarning": "Arquivo salvo, mas n\xE3o foi poss\xEDvel atualizar os dados de recupera\xE7\xE3o ou o hist\xF3rico recente.",
  "homeLabel": "In\xEDcio do Office EX",
  "mainNav": "Navega\xE7\xE3o principal",
  "documents": "Documentos",
  "documentActions": "A\xE7\xF5es do documento",
  "previewTag": "M3 \xB7 PR\xC9VIA DE DESENVOLVIMENTO",
  "eyebrow": "OFFICE EX / ESPA\xC7O LOCAL",
  "region": "Formatos regionais",
  "documentLanguage": "Idioma de novos documentos (prefer\xEAncia)",
  "documentLanguageNote": "Novos documentos Writer usam este idioma. Arquivos existentes n\xE3o mudam; os outros editores ter\xE3o suporte posteriormente.",
  "regionSample": "Pr\xE9via do formato regional",
  "history": "Hist\xF3rico",
  "canvas": "\xC1rea de desenho",
  "entriesLimited": "{count} entradas; exibindo as primeiras 500.",
  "menuFile": "Arquivo",
  "menuEdit": "Editar",
  "menuView": "Exibir",
  "menuNewWriter": "Novo rascunho de documento",
  "menuNewSheets": "Novo rascunho de planilha",
  "menuNewSlides": "Novo rascunho de apresenta\xE7\xE3o",
  "menuOpen": "Abrir\u2026",
  "menuSaveAs": "Salvar como\u2026",
  "menuCloseTab": "Fechar aba",
  "menuCut": "Recortar",
  "menuCopy": "Copiar",
  "menuPaste": "Colar",
  "menuSelectAll": "Selecionar tudo",
  "menuFullscreen": "Alternar tela cheia",
  "menuResetZoom": "Redefinir zoom",
  "menuZoomIn": "Ampliar",
  "menuZoomOut": "Reduzir",
  "officeFiles": "Documentos do Office / Rascunhos do Office EX",
  "allFiles": "Todos os arquivos",
  "originalFormat": "Formato original do arquivo",
  "replaceTarget": "Substituir o arquivo de destino existente?",
  "replace": "Substituir",
  "saveBeforeClose": "Salvar as altera\xE7\xF5es antes de fechar?",
  "discardChanges": "Descartar altera\xE7\xF5es",
  "openFailed": "N\xE3o foi poss\xEDvel abrir o arquivo",
  "windowFailed": "N\xE3o foi poss\xEDvel abrir a janela",
  "finishComposition": "Conclua a entrada atual antes de alterar o idioma.",
  "oneDroppedFile": "Solte apenas um arquivo por vez.",
  "errorInvalid": "Arquivo ou solicita\xE7\xE3o inv\xE1lida.",
  "errorUnsupported": "Este recurso ou formato ainda n\xE3o \xE9 compat\xEDvel.",
  "errorUnsafe": "A opera\xE7\xE3o foi bloqueada por seguran\xE7a.",
  "errorLimit": "A opera\xE7\xE3o excede um limite de recursos.",
  "errorConflict": "O documento ou o destino foi alterado.",
  "errorIo": "A opera\xE7\xE3o de arquivo falhou.",
  "errorInternal": "Ocorreu um erro interno.",
  "diagUnknown": "Foi relatado um diagn\xF3stico de compatibilidade desconhecido.",
  "diagSemanticPending": "Somente inspe\xE7\xE3o do cont\xEAiner. O conte\xFAdo edit\xE1vel do documento n\xE3o foi importado.",
  "diagMacrosDisabled": "Foi detectado conte\xFAdo relacionado a macros. As macros n\xE3o s\xE3o executadas; os bytes originais s\xE3o mantidos apenas em c\xF3pias exatas.",
  "diagSignedReadOnly": "Arquivo assinado: somente inspe\xE7\xE3o. A validade da assinatura n\xE3o \xE9 garantida.",
  "diagExternalDisabled": "As rela\xE7\xF5es externas foram registradas; nenhum conte\xFAdo externo \xE9 carregado.",
  "diagStrictReadOnly": "Strict OOXML identificado; a leitura e a grava\xE7\xE3o do conte\xFAdo ainda n\xE3o foram verificadas.",
  "diagEncryptedUnsupported": "Cont\xEAiner criptografado identificado. A descriptografia e a edi\xE7\xE3o n\xE3o est\xE3o dispon\xEDveis.",
  "diagExtensionMismatch": "A extens\xE3o n\xE3o corresponde ao conte\xFAdo detectado.",
  "writerFormatting": "Formata\xE7\xE3o de texto",
  "writerEditNote": "Edite os par\xE1grafos e selecione o texto para format\xE1-lo. Enter divide o par\xE1grafo; Shift+Enter insere uma quebra de linha.",
  "writerPagePreview": "Pr\xE9via de p\xE1gina",
  "writerEstimated": "Layout estimado. Clique na p\xE1gina para localizar o texto. A fidelidade de impress\xE3o ainda n\xE3o foi verificada.",
  "writerPreviousPage": "P\xE1gina anterior",
  "writerNextPage": "Pr\xF3xima p\xE1gina",
  "writerPageNumber": "P\xE1gina {current} / {total}",
  "writerLayoutLimits": "Alguns recursos tipogr\xE1ficos s\xE3o aproximados.",
  "writerPreviewUnavailable": "Pr\xE9via indispon\xEDvel para este conte\xFAdo ou limite de layout. O conte\xFAdo original permanece intacto.",
  "writerBold": "Negrito",
  "writerItalic": "It\xE1lico",
  "writerUnderline": "Sublinhado",
  "writerAlignLeft": "Alinhar \xE0 esquerda",
  "writerAlignCenter": "Centralizar",
  "writerAlignRight": "Alinhar \xE0 direita",
  "writerSplit": "Dividir par\xE1grafo",
  "writerPageBreak": "Quebra de p\xE1gina ap\xF3s o par\xE1grafo",
  "writerUnsupportedBlock": "Este bloco n\xE3o pode ser editado nesta pr\xE9via.",
  "docxNew": "Novo documento DOCX",
  "docxDocument": "Documento DOCX",
  "docxNote": "Perfil DOCX limitado: texto, formata\xE7\xE3o direta, estilos compat\xEDveis, tabelas fixas, imagens PNG/JPEG em linha e layout b\xE1sico. Documentos complexos s\xE3o somente leitura.",
  "writerFontFamily": "Fonte",
  "writerFontSize": "Tamanho (pt)",
  "writerTextColor": "Cor do texto",
  "writerParagraphStyle": "Estilo de par\xE1grafo",
  "writerCharacterStyle": "Estilo de caractere",
  "writerChooseStyle": "Escolher estilo",
  "writerTable": "Tabela",
  "writerTableRows": "Linhas",
  "writerTableColumns": "Colunas",
  "writerInsertTable": "Inserir tabela",
  "writerAddRow": "Adicionar linha abaixo",
  "writerDeleteRow": "Excluir linha",
  "writerAddColumn": "Adicionar coluna \xE0 direita",
  "writerDeleteColumn": "Excluir coluna",
  "writerColumnWidth": "Largura da coluna (pt)",
  "writerTableBorder": "Bordas da tabela",
  "writerDeleteTable": "Excluir tabela",
  "writerCell": "C\xE9lula {row}, {column}",
  "writerInsertImage": "Inserir imagem",
  "writerImage": "Imagem",
  "writerImageWidth": "Largura da imagem (pt)",
  "writerRemoveImage": "Excluir imagem",
  "writerPaper": "Tamanho do papel",
  "writerCustomPaper": "Personalizado",
  "writerA4": "A4",
  "writerLetter": "Carta",
  "writerA3": "A3",
  "writerOrientation": "Orienta\xE7\xE3o",
  "writerPortrait": "Retrato",
  "writerLandscape": "Paisagem",
  "writerPageWidth": "Largura da p\xE1gina (pt)",
  "writerPageHeight": "Altura da p\xE1gina (pt)",
  "writerMarginTop": "Margem superior (pt)",
  "writerMarginRight": "Margem direita (pt)",
  "writerMarginBottom": "Margem inferior (pt)",
  "writerMarginLeft": "Margem esquerda (pt)",
  "writerApplyPage": "Aplicar configura\xE7\xE3o de p\xE1gina",
  "writerIndent": "Recuo (pt)",
  "writerSpaceBefore": "Antes (pt)",
  "writerSpaceAfter": "Depois (pt)",
  "writerLineHeight": "Altura da linha (pt; 0 = auto)",
  "writerInsertInlineImage": "Inserir imagem no cursor",
  "writerInlineImageNote": "O marcador de objeto representa uma imagem em linha. Use os controles da imagem para redimension\xE1-la ou remov\xEA-la.",
  "writerContinuous": "Editar texto cont\xEDnuo",
  "writerExitContinuous": "Voltar ao editor de par\xE1grafos",
  "writerContinuousNote": "Selecione, copie, recorte, cole ou formate par\xE1grafos de texto adjacentes. Tabelas, quebras de p\xE1gina, se\xE7\xF5es e par\xE1grafos com imagens delimitam a sele\xE7\xE3o. Novas linhas coladas se tornam par\xE1grafos.",
  "writerSection": "Se\xE7\xE3o",
  "writerSectionNumber": "Se\xE7\xE3o {number}",
  "writerSectionBreak": "Quebra de se\xE7\xE3o na pr\xF3xima p\xE1gina",
  "writerTextLanguage": "Idioma do texto (BCP 47)",
  "writerParagraphDirection": "Dire\xE7\xE3o do par\xE1grafo",
  "writerLtr": "Da esquerda para a direita",
  "writerRtl": "Da direita para a esquerda",
  "docNew": "Novo DOC",
  "docDocument": "Documento Word 97\u20132003",
  "docNote": "Edi\xE7\xE3o DOC limitada: texto Unicode, formata\xE7\xE3o b\xE1sica e uma se\xE7\xE3o. DOC n\xE3o compat\xEDvel fica somente leitura; tabelas e imagens n\xE3o podem ser salvas.",
  "docTextPreview": "Pr\xE9via somente leitura do texto principal, n\xE3o do layout completo. A c\xF3pia preserva os bytes originais.",
  "convertDoc": "Converter para DOC",
  "convertDocx": "Converter para DOCX",
  "conversionBoundary": "Apenas estruturas compat\xEDveis podem ser convertidas. Partes n\xE3o interpretadas permanecem no arquivo de origem.",
  "writerPageEdit": "Editar na p\xE1gina",
  "writerExitPageEdit": "Voltar \xE0s ferramentas",
  "writerNativePageNote": "Edite na p\xE1gina usando a composi\xE7\xE3o nativa de texto. Arraste para selecionar; a \xE1rea de transfer\xEAncia interna preserva formata\xE7\xE3o e imagens compat\xEDveis. A fidelidade ao Word ainda n\xE3o foi verificada."
};

// packages/i18n/src/catalogs-a3.ts
var russian = {
  "open": "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0444\u0430\u0439\u043B",
  "newDraft": "\u041D\u043E\u0432\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A",
  "recent": "\u041D\u0435\u0434\u0430\u0432\u043D\u0438\u0435 \u0444\u0430\u0439\u043B\u044B",
  "local": "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E \xB7 \u0411\u0435\u0437 \u0441\u0435\u0442\u0438 \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E",
  "settings": "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438",
  "workspace": "\u0420\u0430\u0431\u043E\u0447\u0435\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E",
  "undo": "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C",
  "redo": "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C",
  "saveAs": "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u0430\u043A",
  "save": "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",
  "ready": "\u0413\u043E\u0442\u043E\u0432\u043E",
  "theme": "\u041E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435",
  "system": "\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438",
  "light": "\u0421\u0432\u0435\u0442\u043B\u0430\u044F",
  "dark": "\u0422\u0451\u043C\u043D\u0430\u044F",
  "language": "\u042F\u0437\u044B\u043A",
  "clearRecent": "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u0445 \u0444\u0430\u0439\u043B\u043E\u0432",
  "settingsNote": "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0438 \u0441\u043D\u0438\u043C\u043A\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u0445\u0440\u0430\u043D\u044F\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 \u044D\u0442\u043E\u043C \u043A\u043E\u043C\u043F\u044C\u044E\u0442\u0435\u0440\u0435.",
  "welcome": "\u041C\u0435\u0441\u0442\u043E \u0434\u043B\u044F \u0432\u0430\u0448\u0438\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432.",
  "welcomeSub": "\u041D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043D\u044B\u0439 \u043E\u0444\u0438\u0441\u043D\u044B\u0439 \u043F\u0430\u043A\u0435\u0442. \u041F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F M3 \u043F\u043E\u0437\u0432\u043E\u043B\u044F\u0435\u0442 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u0432 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u0445 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0445 \u0444\u043E\u0440\u043C\u0430\u0442\u043E\u0432.",
  "newHeading": "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A",
  "draftHint": "\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430 \xB7 .oex",
  "writer": "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442",
  "sheets": "\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430",
  "slides": "\u041F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0438\u044F",
  "writerSub": "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0438 \u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432",
  "sheetsSub": "\u042F\u0447\u0435\u0439\u043A\u0438, \u0444\u043E\u0440\u043C\u0443\u043B\u044B \u0438 \u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435",
  "slidesSub": "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0441\u0446\u0435\u043D\u044B \u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0438\u0438",
  "dropTitle": "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0444\u0430\u0439\u043B \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u0442\u0430\u0449\u0438\u0442\u0435 \u0435\u0433\u043E \u0441\u044E\u0434\u0430",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 \u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 Office EX",
  "choose": "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0444\u0430\u0439\u043B",
  "boundary": "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B DOC/DOCX \u0438 \u043A\u043D\u0438\u0433\u0438 XLS/XLSX \u043C\u043E\u0436\u043D\u043E \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0442\u044C. \u041E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u0444\u0430\u0439\u043B\u044B \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F \u0447\u0442\u0435\u043D\u0438\u044F \u0438 \u0442\u043E\u0447\u043D\u043E\u0433\u043E \u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F. \u041F\u043E\u043B\u043D\u0430\u044F \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C \u0435\u0449\u0451 \u0440\u0430\u0437\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u0435\u0442\u0441\u044F.",
  "formats": "\u0418\u043D\u0444\u0440\u0430\u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0444\u043E\u0440\u043C\u0430\u0442\u043E\u0432",
  "containerReady": "\u041A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D",
  "modern": "\u0421\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u044B",
  "legacy": "\u0421\u0442\u0430\u0440\u044B\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u044B",
  "draft": "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438",
  "noRecent": "\u041D\u0435\u0442 \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u0445 \u0444\u0430\u0439\u043B\u043E\u0432",
  "untitled": "\u0411\u0435\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F",
  "draftLabel": "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A Office EX",
  "readOnly": "\u0422\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u0435\u043D\u0438\u0435 \xB7 \u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u044B",
  "unsaved": "\u041D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E",
  "saved": "\u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E",
  "reading": "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u044B \u0444\u0430\u0439\u043B\u0430\u2026",
  "cancel": "\u041E\u0442\u043C\u0435\u043D\u0430",
  "close": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C",
  "cancelled": "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u043E\u0442\u043C\u0435\u043D\u0435\u043D\u0430",
  "snapshot": "\u0421\u043D\u0438\u043C\u043E\u043A",
  "revision": "\u0412\u0435\u0440\u0441\u0438\u044F",
  "savedNote": "\u0423\u0441\u043F\u0435\u0448\u043D\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E",
  "draftNote": "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 OEX \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u044E\u0442 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0444\u043E\u0440\u043C\u0430\u0442. \u0414\u043B\u044F \u0444\u0430\u0439\u043B\u043E\u0432 Office \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 DOC/DOCX \u0438\u043B\u0438 \u043A\u043D\u0438\u0433\u0443 XLS/XLSX \u0441 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u043C\u0438 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u044F\u043C\u0438.",
  "textLabel": "\u0422\u0435\u043A\u0441\u0442 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430",
  "cellsLabel": "\u042F\u0447\u0435\u0439\u043A\u0438 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B",
  "cellsNote": "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u044F\u0447\u0435\u0439\u043A\u0438, \u0444\u043E\u0440\u043C\u0443\u043B\u044B \u0438 \u0444\u043E\u0440\u043C\u0430\u0442\u044B. \u0422\u0438\u043F\u044B \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0438 \u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u0434\u0430\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u043F\u0440\u0438 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0445 \u0444\u043E\u0440\u043C\u0430\u0442\u0430\u0445.",
  "slideLabel": "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0441\u0446\u0435\u043D\u044B \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u043E\u043F\u0430\u0434\u0430\u043D\u0438\u044F",
  "addShape": "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u0440\u044F\u043C\u043E\u0443\u0433\u043E\u043B\u044C\u043D\u0438\u043A",
  "shapeNote": "\u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u043D\u0430 \u0444\u0438\u0433\u0443\u0440\u0443 \u0434\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043A\u043E\u043E\u0440\u0434\u0438\u043D\u0430\u0442. \u041F\u043E\u043B\u043D\u044B\u0439 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u0432 M4.",
  "parts": "\u0427\u0430\u0441\u0442\u0438 \u043F\u0430\u043A\u0435\u0442\u0430 / \u043F\u043E\u0442\u043E\u043A\u0438",
  "part": "\u0427\u0430\u0441\u0442\u044C",
  "size": "\u0420\u0430\u0437\u043C\u0435\u0440",
  "digest": "SHA-256",
  "version": "\u0412\u0435\u0440\u0441\u0438\u044F \u0444\u043E\u0440\u043C\u0430\u0442\u0430",
  "format": "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442",
  "copy": "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0442\u043E\u0447\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E",
  "pending": "\u0410\u0434\u0430\u043F\u0442\u0435\u0440 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E \u0435\u0449\u0451 \u043D\u0435 \u0433\u043E\u0442\u043E\u0432",
  "recoveries": "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 \u0434\u043B\u044F \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F",
  "restore": "\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u043A\u043E\u043F\u0438\u044E",
  "discard": "\u041E\u0442\u043A\u0430\u0437\u0430\u0442\u044C\u0441\u044F",
  "recoveryNote": "\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0441\u043E\u0437\u0434\u0430\u0451\u0442 \u043D\u043E\u0432\u0443\u044E \u043D\u0435\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u0430\u0439\u043B.",
  "recoveryCorrupt": "\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D\u043D\u044B\u0435 \u0441\u043D\u0438\u043C\u043A\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u0438\u0437\u043E\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u044B \u0438 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u044B.",
  "recovered": "\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E \u043A\u0430\u043A \u043D\u043E\u0432\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A",
  "working": "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F",
  "diagnostics": "\u041E\u0442\u0447\u0451\u0442 \u043E \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u0438",
  "noEntries": "\u041D\u0435\u0442 \u0447\u0430\u0441\u0442\u0435\u0439 \u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440\u0430 \u0434\u043B\u044F \u043E\u0442\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F.",
  "emptySlide": "\u041F\u0443\u0441\u0442\u043E\u0439 \u0441\u043B\u0430\u0439\u0434",
  "clearDone": "\u0421\u043F\u0438\u0441\u043E\u043A \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 \u043E\u0447\u0438\u0449\u0435\u043D",
  "draftTitle": "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430",
  "limitTabs": "\u041C\u043E\u0436\u043D\u043E \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0435 \u0431\u043E\u043B\u0435\u0435 32 \u0432\u043A\u043B\u0430\u0434\u043E\u043A",
  "stage": "\u041D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u0430\u044F \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \xB7 Writer \u0438 Sheets",
  "partialDirectorySync": "\u0424\u0430\u0439\u043B \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D; \u044D\u0442\u0430 \u0444\u0430\u0439\u043B\u043E\u0432\u0430\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u043D\u0435 \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0440\u0443\u0435\u0442 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044E \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430.",
  "savedMaintenanceWarning": "\u0424\u0430\u0439\u043B \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D, \u043D\u043E \u043D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0434\u0430\u043D\u043D\u044B\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u0441\u043F\u0438\u0441\u043E\u043A \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u0445 \u0444\u0430\u0439\u043B\u043E\u0432.",
  "homeLabel": "\u0413\u043B\u0430\u0432\u043D\u0430\u044F Office EX",
  "mainNav": "\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u043D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F",
  "documents": "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B",
  "documentActions": "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u043C",
  "previewTag": "M3 \xB7 \u041F\u0420\u0415\u0414\u0412\u0410\u0420\u0418\u0422\u0415\u041B\u042C\u041D\u0410\u042F \u0412\u0415\u0420\u0421\u0418\u042F",
  "eyebrow": "OFFICE EX / \u041B\u041E\u041A\u0410\u041B\u042C\u041D\u041E\u0415 \u0420\u0410\u0411\u041E\u0427\u0415\u0415 \u041F\u0420\u041E\u0421\u0422\u0420\u0410\u041D\u0421\u0422\u0412\u041E",
  "region": "\u0420\u0435\u0433\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u044B",
  "documentLanguage": "\u042F\u0437\u044B\u043A \u043D\u043E\u0432\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 (\u043F\u0440\u0435\u0434\u043F\u043E\u0447\u0442\u0435\u043D\u0438\u0435)",
  "documentLanguageNote": "\u041D\u043E\u0432\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B Writer \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u044E\u0442 \u044D\u0442\u043E\u0442 \u044F\u0437\u044B\u043A. \u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0444\u0430\u0439\u043B\u044B \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u044E\u0442\u0441\u044F; \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \u0432 \u0434\u0440\u0443\u0433\u0438\u0445 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430\u0445 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u043F\u043E\u0437\u0436\u0435.",
  "regionSample": "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0440\u0435\u0433\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0444\u043E\u0440\u043C\u0430\u0442\u043E\u0432",
  "history": "\u0418\u0441\u0442\u043E\u0440\u0438\u044F",
  "canvas": "\u0425\u043E\u043B\u0441\u0442",
  "entriesLimited": "\u0412\u0441\u0435\u0433\u043E \u0437\u0430\u043F\u0438\u0441\u0435\u0439: {count}; \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u044B \u043F\u0435\u0440\u0432\u044B\u0435 500.",
  "menuFile": "\u0424\u0430\u0439\u043B",
  "menuEdit": "\u041F\u0440\u0430\u0432\u043A\u0430",
  "menuView": "\u0412\u0438\u0434",
  "menuNewWriter": "\u041D\u043E\u0432\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430",
  "menuNewSheets": "\u041D\u043E\u0432\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0442\u0430\u0431\u043B\u0438\u0446\u044B",
  "menuNewSlides": "\u041D\u043E\u0432\u044B\u0439 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0438\u0438",
  "menuOpen": "\u041E\u0442\u043A\u0440\u044B\u0442\u044C\u2026",
  "menuSaveAs": "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u0430\u043A\u2026",
  "menuCloseTab": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0432\u043A\u043B\u0430\u0434\u043A\u0443",
  "menuCut": "\u0412\u044B\u0440\u0435\u0437\u0430\u0442\u044C",
  "menuCopy": "\u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C",
  "menuPaste": "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C",
  "menuSelectAll": "\u0412\u044B\u0434\u0435\u043B\u0438\u0442\u044C \u0432\u0441\u0451",
  "menuFullscreen": "\u041F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043F\u043E\u043B\u043D\u043E\u044D\u043A\u0440\u0430\u043D\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C",
  "menuResetZoom": "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u043C\u0430\u0441\u0448\u0442\u0430\u0431",
  "menuZoomIn": "\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C",
  "menuZoomOut": "\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C",
  "officeFiles": "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B Office / \u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 Office EX",
  "allFiles": "\u0412\u0441\u0435 \u0444\u0430\u0439\u043B\u044B",
  "originalFormat": "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u0444\u0430\u0439\u043B\u0430",
  "replaceTarget": "\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0439 \u0446\u0435\u043B\u0435\u0432\u043E\u0439 \u0444\u0430\u0439\u043B?",
  "replace": "\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C",
  "saveBeforeClose": "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043F\u0435\u0440\u0435\u0434 \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u0435\u043C?",
  "discardChanges": "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F",
  "openFailed": "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0444\u0430\u0439\u043B",
  "windowFailed": "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u043A\u043D\u043E",
  "finishComposition": "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u0432\u0432\u043E\u0434 \u043F\u0435\u0440\u0435\u0434 \u0441\u043C\u0435\u043D\u043E\u0439 \u044F\u0437\u044B\u043A\u0430.",
  "oneDroppedFile": "\u041F\u0435\u0440\u0435\u0442\u0430\u0441\u043A\u0438\u0432\u0430\u0439\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0434\u0438\u043D \u0444\u0430\u0439\u043B \u0437\u0430 \u0440\u0430\u0437.",
  "errorInvalid": "\u041D\u0435\u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0444\u0430\u0439\u043B \u0438\u043B\u0438 \u0437\u0430\u043F\u0440\u043E\u0441.",
  "errorUnsupported": "\u042D\u0442\u0430 \u0444\u0443\u043D\u043A\u0446\u0438\u044F \u0438\u043B\u0438 \u0444\u043E\u0440\u043C\u0430\u0442 \u043F\u043E\u043A\u0430 \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044E\u0442\u0441\u044F.",
  "errorUnsafe": "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0438\u0437 \u0441\u043E\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0441\u0442\u0438.",
  "errorLimit": "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u0440\u0435\u0441\u0443\u0440\u0441\u043E\u0432.",
  "errorConflict": "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0438\u043B\u0438 \u0446\u0435\u043B\u0435\u0432\u043E\u0439 \u0444\u0430\u0439\u043B \u0438\u0437\u043C\u0435\u043D\u0451\u043D.",
  "errorIo": "\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u044F \u0441 \u0444\u0430\u0439\u043B\u043E\u043C \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0430\u0441\u044C \u043E\u0448\u0438\u0431\u043A\u043E\u0439.",
  "errorInternal": "\u041F\u0440\u043E\u0438\u0437\u043E\u0448\u043B\u0430 \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u044F\u044F \u043E\u0448\u0438\u0431\u043A\u0430.",
  "diagUnknown": "\u041F\u043E\u043B\u0443\u0447\u0435\u043D\u043E \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u043E \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u0438.",
  "diagSemanticPending": "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440\u0430. \u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u043C\u043E\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0435\u0449\u0451 \u043D\u0435 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043E.",
  "diagMacrosDisabled": "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u043E \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u043E\u0435 \u0441 \u043C\u0430\u043A\u0440\u043E\u0441\u0430\u043C\u0438. \u041C\u0430\u043A\u0440\u043E\u0441\u044B \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u044E\u0442\u0441\u044F; \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0431\u0430\u0439\u0442\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u0442\u043E\u0447\u043D\u044B\u0445 \u043A\u043E\u043F\u0438\u044F\u0445.",
  "diagSignedReadOnly": "\u041F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043D\u044B\u0439 \u0444\u0430\u0439\u043B: \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430. \u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u0438 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442\u0441\u044F.",
  "diagExternalDisabled": "\u0412\u043D\u0435\u0448\u043D\u0438\u0435 \u0441\u0432\u044F\u0437\u0438 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u044B; \u0432\u043D\u0435\u0448\u043D\u0435\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u0442\u0441\u044F.",
  "diagStrictReadOnly": "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D Strict OOXML; \u0447\u0442\u0435\u043D\u0438\u0435 \u0438 \u0437\u0430\u043F\u0438\u0441\u044C \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E \u043F\u043E\u043A\u0430 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u044B.",
  "diagEncryptedUnsupported": "\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D \u0437\u0430\u0448\u0438\u0444\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440. \u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430 \u0438 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B.",
  "diagExtensionMismatch": "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0444\u0430\u0439\u043B\u0430 \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D\u043D\u043E\u043C\u0443 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u043C\u0443.",
  "writerFormatting": "\u0424\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0442\u0435\u043A\u0441\u0442\u0430",
  "writerEditNote": "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u0430\u0431\u0437\u0430\u0446\u044B \u0438 \u0432\u044B\u0434\u0435\u043B\u044F\u0439\u0442\u0435 \u0442\u0435\u043A\u0441\u0442. Enter \u0440\u0430\u0437\u0434\u0435\u043B\u044F\u0435\u0442 \u0430\u0431\u0437\u0430\u0446; Shift+Enter \u0432\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0440\u0430\u0437\u0440\u044B\u0432 \u0441\u0442\u0440\u043E\u043A\u0438.",
  "writerPagePreview": "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0441\u0442\u0440\u0430\u043D\u0438\u0446",
  "writerEstimated": "\u041F\u0440\u0438\u0431\u043B\u0438\u0437\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043C\u0430\u043A\u0435\u0442 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443, \u0447\u0442\u043E\u0431\u044B \u043D\u0430\u0439\u0442\u0438 \u0442\u0435\u043A\u0441\u0442. \u0422\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u043F\u0435\u0447\u0430\u0442\u0438 \u0435\u0449\u0451 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430.",
  "writerPreviousPage": "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430",
  "writerNextPage": "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430",
  "writerPageNumber": "\u0421\u0442\u0440\u0430\u043D\u0438\u0446\u0430 {current} / {total}",
  "writerLayoutLimits": "\u041D\u0435\u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u0438 \u0442\u0438\u043F\u043E\u0433\u0440\u0430\u0444\u0438\u043A\u0438 \u0438 \u043C\u0430\u043A\u0435\u0442\u0430 \u043F\u0440\u0438\u0431\u043B\u0438\u0437\u0438\u0442\u0435\u043B\u044C\u043D\u044B.",
  "writerPreviewUnavailable": "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0433\u043E \u0438\u043B\u0438 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u043C\u0430\u043A\u0435\u0442\u0430. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0451\u043D.",
  "writerBold": "\u041F\u043E\u043B\u0443\u0436\u0438\u0440\u043D\u044B\u0439",
  "writerItalic": "\u041A\u0443\u0440\u0441\u0438\u0432",
  "writerUnderline": "\u041F\u043E\u0434\u0447\u0451\u0440\u043A\u043D\u0443\u0442\u044B\u0439",
  "writerAlignLeft": "\u041F\u043E \u043B\u0435\u0432\u043E\u043C\u0443 \u043A\u0440\u0430\u044E",
  "writerAlignCenter": "\u041F\u043E \u0446\u0435\u043D\u0442\u0440\u0443",
  "writerAlignRight": "\u041F\u043E \u043F\u0440\u0430\u0432\u043E\u043C\u0443 \u043A\u0440\u0430\u044E",
  "writerSplit": "\u0420\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u044C \u0430\u0431\u0437\u0430\u0446",
  "writerPageBreak": "\u0420\u0430\u0437\u0440\u044B\u0432 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u043F\u043E\u0441\u043B\u0435 \u0430\u0431\u0437\u0430\u0446\u0430",
  "writerUnsupportedBlock": "\u042D\u0442\u043E\u0442 \u0431\u043B\u043E\u043A \u043F\u043E\u043A\u0430 \u043D\u0435\u043B\u044C\u0437\u044F \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C.",
  "docxNew": "\u041D\u043E\u0432\u044B\u0439 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 DOCX",
  "docxDocument": "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 DOCX",
  "docxNote": "\u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u043D\u044B\u0439 DOCX: \u0442\u0435\u043A\u0441\u0442, \u043F\u0440\u044F\u043C\u043E\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435, \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0441\u0442\u0438\u043B\u0438, \u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u044B, \u0432\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u044B\u0435 PNG/JPEG \u0438 \u0431\u0430\u0437\u043E\u0432\u0430\u044F \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0430. \u0421\u043B\u043E\u0436\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F \u0447\u0442\u0435\u043D\u0438\u044F.",
  "writerFontFamily": "\u0428\u0440\u0438\u0444\u0442",
  "writerFontSize": "\u0420\u0430\u0437\u043C\u0435\u0440 (\u043F\u0442)",
  "writerTextColor": "\u0426\u0432\u0435\u0442 \u0442\u0435\u043A\u0441\u0442\u0430",
  "writerParagraphStyle": "\u0421\u0442\u0438\u043B\u044C \u0430\u0431\u0437\u0430\u0446\u0430",
  "writerCharacterStyle": "\u0421\u0442\u0438\u043B\u044C \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432",
  "writerChooseStyle": "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0441\u0442\u0438\u043B\u044C",
  "writerTable": "\u0422\u0430\u0431\u043B\u0438\u0446\u0430",
  "writerTableRows": "\u0421\u0442\u0440\u043E\u043A\u0438",
  "writerTableColumns": "\u0421\u0442\u043E\u043B\u0431\u0446\u044B",
  "writerInsertTable": "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0442\u0430\u0431\u043B\u0438\u0446\u0443",
  "writerAddRow": "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443 \u043D\u0438\u0436\u0435",
  "writerDeleteRow": "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443",
  "writerAddColumn": "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0441\u0442\u043E\u043B\u0431\u0435\u0446 \u0441\u043F\u0440\u0430\u0432\u0430",
  "writerDeleteColumn": "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u0442\u043E\u043B\u0431\u0435\u0446",
  "writerColumnWidth": "\u0428\u0438\u0440\u0438\u043D\u0430 \u0441\u0442\u043E\u043B\u0431\u0446\u0430 (\u043F\u0442)",
  "writerTableBorder": "\u0413\u0440\u0430\u043D\u0438\u0446\u044B \u0442\u0430\u0431\u043B\u0438\u0446\u044B",
  "writerDeleteTable": "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0442\u0430\u0431\u043B\u0438\u0446\u0443",
  "writerCell": "\u042F\u0447\u0435\u0439\u043A\u0430 {row}, {column}",
  "writerInsertImage": "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435",
  "writerImage": "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435",
  "writerImageWidth": "\u0428\u0438\u0440\u0438\u043D\u0430 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F (\u043F\u0442)",
  "writerRemoveImage": "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435",
  "writerPaper": "\u0424\u043E\u0440\u043C\u0430\u0442 \u0431\u0443\u043C\u0430\u0433\u0438",
  "writerCustomPaper": "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0439",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "\u041E\u0440\u0438\u0435\u043D\u0442\u0430\u0446\u0438\u044F",
  "writerPortrait": "\u041A\u043D\u0438\u0436\u043D\u0430\u044F",
  "writerLandscape": "\u0410\u043B\u044C\u0431\u043E\u043C\u043D\u0430\u044F",
  "writerPageWidth": "\u0428\u0438\u0440\u0438\u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B (\u043F\u0442)",
  "writerPageHeight": "\u0412\u044B\u0441\u043E\u0442\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B (\u043F\u0442)",
  "writerMarginTop": "\u0412\u0435\u0440\u0445\u043D\u0435\u0435 \u043F\u043E\u043B\u0435 (\u043F\u0442)",
  "writerMarginRight": "\u041F\u0440\u0430\u0432\u043E\u0435 \u043F\u043E\u043B\u0435 (\u043F\u0442)",
  "writerMarginBottom": "\u041D\u0438\u0436\u043D\u0435\u0435 \u043F\u043E\u043B\u0435 (\u043F\u0442)",
  "writerMarginLeft": "\u041B\u0435\u0432\u043E\u0435 \u043F\u043E\u043B\u0435 (\u043F\u0442)",
  "writerApplyPage": "\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B",
  "writerIndent": "\u041E\u0442\u0441\u0442\u0443\u043F (\u043F\u0442)",
  "writerSpaceBefore": "\u041F\u0435\u0440\u0435\u0434 \u0430\u0431\u0437\u0430\u0446\u0435\u043C (\u043F\u0442)",
  "writerSpaceAfter": "\u041F\u043E\u0441\u043B\u0435 \u0430\u0431\u0437\u0430\u0446\u0430 (\u043F\u0442)",
  "writerLineHeight": "\u0412\u044B\u0441\u043E\u0442\u0430 \u0441\u0442\u0440\u043E\u043A\u0438 (\u043F\u0442; 0 = \u0430\u0432\u0442\u043E)",
  "writerInsertInlineImage": "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0432 \u043F\u043E\u0437\u0438\u0446\u0438\u0438 \u043A\u0443\u0440\u0441\u043E\u0440\u0430",
  "writerInlineImageNote": "\u041C\u0430\u0440\u043A\u0435\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u043E\u0431\u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442 \u0432\u0441\u0442\u0440\u043E\u0435\u043D\u043D\u043E\u0435 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435. \u0418\u0437\u043C\u0435\u043D\u044F\u0439\u0442\u0435 \u0440\u0430\u0437\u043C\u0435\u0440 \u0438 \u0443\u0434\u0430\u043B\u044F\u0439\u0442\u0435 \u0435\u0433\u043E \u0441 \u043F\u043E\u043C\u043E\u0449\u044C\u044E \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432 \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435\u043C.",
  "writerContinuous": "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043D\u0435\u043F\u0440\u0435\u0440\u044B\u0432\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442",
  "writerExitContinuous": "\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u043A \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0443 \u0430\u0431\u0437\u0430\u0446\u0435\u0432",
  "writerContinuousNote": "\u0412\u044B\u0434\u0435\u043B\u044F\u0439\u0442\u0435, \u043A\u043E\u043F\u0438\u0440\u0443\u0439\u0442\u0435, \u0432\u044B\u0440\u0435\u0437\u0430\u0439\u0442\u0435, \u0432\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0438 \u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u0441\u043E\u0441\u0435\u0434\u043D\u0438\u0435 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0435 \u0430\u0431\u0437\u0430\u0446\u044B. \u0422\u0430\u0431\u043B\u0438\u0446\u044B, \u0440\u0430\u0437\u0440\u044B\u0432\u044B \u0441\u0442\u0440\u0430\u043D\u0438\u0446, \u0440\u0430\u0437\u0434\u0435\u043B\u044B \u0438 \u0430\u0431\u0437\u0430\u0446\u044B \u0441 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F\u043C\u0438 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0438\u0432\u0430\u044E\u0442 \u0432\u044B\u0434\u0435\u043B\u0435\u043D\u0438\u0435. \u0412\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0435 \u043D\u043E\u0432\u044B\u0435 \u0441\u0442\u0440\u043E\u043A\u0438 \u0441\u0442\u0430\u043D\u043E\u0432\u044F\u0442\u0441\u044F \u0430\u0431\u0437\u0430\u0446\u0430\u043C\u0438.",
  "writerSection": "\u0420\u0430\u0437\u0434\u0435\u043B",
  "writerSectionNumber": "\u0420\u0430\u0437\u0434\u0435\u043B {number}",
  "writerSectionBreak": "\u0420\u0430\u0437\u0440\u044B\u0432 \u0440\u0430\u0437\u0434\u0435\u043B\u0430 \u0441\u043E \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B",
  "writerTextLanguage": "\u042F\u0437\u044B\u043A \u0442\u0435\u043A\u0441\u0442\u0430 (BCP 47)",
  "writerParagraphDirection": "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0430\u0431\u0437\u0430\u0446\u0430",
  "writerLtr": "\u0421\u043B\u0435\u0432\u0430 \u043D\u0430\u043F\u0440\u0430\u0432\u043E",
  "writerRtl": "\u0421\u043F\u0440\u0430\u0432\u0430 \u043D\u0430\u043B\u0435\u0432\u043E",
  "docNew": "\u041D\u043E\u0432\u044B\u0439 DOC",
  "docDocument": "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 Word 97\u20132003",
  "docNote": "\u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u043D\u043E\u0435 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 DOC: \u0442\u0435\u043A\u0441\u0442 Unicode, \u0431\u0430\u0437\u043E\u0432\u043E\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0438 \u043E\u0434\u0438\u043D \u0440\u0430\u0437\u0434\u0435\u043B. \u041D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 DOC \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F \u0447\u0442\u0435\u043D\u0438\u044F; \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u0438 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F.",
  "docTextPreview": "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u043E\u0441\u043D\u043E\u0432\u043D\u043E\u0433\u043E \u0442\u0435\u043A\u0441\u0442\u0430 \u0431\u0435\u0437 \u043F\u043E\u043B\u043D\u043E\u0433\u043E \u043C\u0430\u043A\u0435\u0442\u0430, \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u0435\u043D\u0438\u0435. \u041A\u043E\u043F\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0431\u0430\u0439\u0442\u044B.",
  "convertDoc": "\u041F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u044C \u0432 DOC",
  "convertDocx": "\u041F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u044C \u0432 DOCX",
  "conversionBoundary": "\u041F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u0443\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u044B. \u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D\u044B\u0435 \u0447\u0430\u0441\u0442\u0438 \u043E\u0441\u0442\u0430\u044E\u0442\u0441\u044F \u0432 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C \u0444\u0430\u0439\u043B\u0435.",
  "writerPageEdit": "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435",
  "writerExitPageEdit": "\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u043A \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u0430\u043C",
  "writerNativePageNote": "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u0440\u044F\u043C\u043E \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u0441 \u043D\u0430\u0442\u0438\u0432\u043D\u043E\u0439 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u043E\u0439 \u0442\u0435\u043A\u0441\u0442\u0430. \u0412\u044B\u0434\u0435\u043B\u044F\u0439\u0442\u0435 \u043F\u0435\u0440\u0435\u0442\u0430\u0441\u043A\u0438\u0432\u0430\u043D\u0438\u0435\u043C; \u0432\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u0438\u0439 \u0431\u0443\u0444\u0435\u0440 \u043E\u0431\u043C\u0435\u043D\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0441\u0442\u0438\u043B\u0438 \u0438 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F. \u0422\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0435\u043B\u044C\u043D\u043E Word \u0435\u0449\u0451 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430."
};
var italian = {
  "open": "Apri file",
  "newDraft": "Nuova bozza",
  "recent": "File recenti",
  "local": "Area locale \xB7 Offline per impostazione predefinita",
  "settings": "Impostazioni",
  "workspace": "Area di lavoro",
  "undo": "Annulla",
  "redo": "Ripeti",
  "saveAs": "Salva con nome",
  "save": "Salva",
  "ready": "Pronto",
  "theme": "Aspetto",
  "system": "Sistema",
  "light": "Chiaro",
  "dark": "Scuro",
  "language": "Lingua",
  "clearRecent": "Cancella file recenti",
  "settingsNote": "Le impostazioni e le istantanee di ripristino rimangono su questo computer.",
  "welcome": "Uno spazio per i tuoi documenti.",
  "welcomeSub": "Suite per ufficio sviluppata in modo indipendente. Questa anteprima M3 consente di modificare documenti e fogli di calcolo nei formati supportati.",
  "newHeading": "Crea una bozza locale",
  "draftHint": "Formato interno delle bozze \xB7 .oex",
  "writer": "Documento",
  "sheets": "Foglio di calcolo",
  "slides": "Presentazione",
  "writerSub": "Scrittura e formattazione dei documenti",
  "sheetsSub": "Celle, formule e formattazione",
  "slidesSub": "Anteprima delle scene di presentazione",
  "dropTitle": "Apri un file o trascinalo qui",
  "dropHint": "DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Bozze Office EX",
  "choose": "Scegli file",
  "boundary": "I documenti DOC/DOCX e le cartelle XLS/XLSX supportati possono essere modificati e salvati. Gli altri file restano in sola lettura e possono essere copiati integralmente. La compatibilit\xE0 completa \xE8 in sviluppo.",
  "formats": "Infrastruttura dei formati",
  "containerReady": "Contenitore integrato",
  "modern": "Formati moderni",
  "legacy": "Formati precedenti",
  "draft": "Bozze locali",
  "noRecent": "Nessun file recente",
  "untitled": "Senza titolo",
  "draftLabel": "Bozza Office EX",
  "readOnly": "Sola lettura \xB7 Ispezione della struttura",
  "unsaved": "Non salvato",
  "saved": "Salvato",
  "reading": "Ispezione della struttura del file\u2026",
  "cancel": "Annulla",
  "close": "Chiudi",
  "cancelled": "Operazione annullata",
  "snapshot": "Istantanea",
  "revision": "Revisione",
  "savedNote": "Salvataggio riuscito",
  "draftNote": "Le bozze OEX usano un formato interno. Per i file Office, crea un documento DOC/DOCX o una cartella XLS/XLSX con le funzioni supportate.",
  "textLabel": "Testo della bozza",
  "cellsLabel": "Celle del foglio di calcolo",
  "cellsNote": "Modifica celle, formule e formattazione. I tipi di valori e il sistema di date vengono conservati quando salvi nei formati supportati.",
  "slideLabel": "Anteprima della scena e del rilevamento dei clic",
  "addShape": "Aggiungi rettangolo",
  "shapeNote": "Fai clic su una forma per verificare le coordinate. L'editor completo arriver\xE0 in M4.",
  "parts": "Parti del pacchetto / flussi",
  "part": "Parte",
  "size": "Dimensione",
  "digest": "SHA-256",
  "version": "Versione del formato",
  "format": "Formato rilevato",
  "copy": "Salva copia identica",
  "pending": "Adattatore dei contenuti in attesa",
  "recoveries": "Bozze recuperabili",
  "restore": "Ripristina una copia",
  "discard": "Scarta",
  "recoveryNote": "Il ripristino crea una nuova copia non salvata e conserva il file originale.",
  "recoveryCorrupt": "Le istantanee di ripristino danneggiate sono state isolate e non caricate.",
  "recovered": "Ripristinato come nuova bozza",
  "working": "Elaborazione",
  "diagnostics": "Rapporto di compatibilit\xE0",
  "noEntries": "Nessuna parte del contenitore da mostrare.",
  "emptySlide": "Diapositiva vuota",
  "clearDone": "Cronologia dei file recenti cancellata",
  "draftTitle": "Titolo del documento",
  "limitTabs": "\xC8 possibile aprire al massimo 32 schede",
  "stage": "Sviluppo indipendente \xB7 Writer e Sheets",
  "partialDirectorySync": "File salvato; questo file system non garantisce la sincronizzazione della directory.",
  "savedMaintenanceWarning": "File salvato, ma non \xE8 stato possibile aggiornare i dati di ripristino o la cronologia dei file recenti.",
  "homeLabel": "Home di Office EX",
  "mainNav": "Navigazione principale",
  "documents": "Documenti",
  "documentActions": "Azioni sul documento",
  "previewTag": "M3 \xB7 ANTEPRIMA DI SVILUPPO",
  "eyebrow": "OFFICE EX / AREA DI LAVORO LOCALE",
  "region": "Formati regionali",
  "documentLanguage": "Lingua dei nuovi documenti (preferenza)",
  "documentLanguageNote": "I nuovi documenti Writer utilizzano questa lingua. I file esistenti non cambiano; gli altri editor la adotteranno in seguito.",
  "regionSample": "Anteprima del formato regionale",
  "history": "Cronologia",
  "canvas": "Area di disegno",
  "entriesLimited": "Voci totali: {count}; sono mostrate le prime 500.",
  "menuFile": "File",
  "menuEdit": "Modifica",
  "menuView": "Visualizza",
  "menuNewWriter": "Nuova bozza di documento",
  "menuNewSheets": "Nuova bozza di foglio di calcolo",
  "menuNewSlides": "Nuova bozza di presentazione",
  "menuOpen": "Apri\u2026",
  "menuSaveAs": "Salva con nome\u2026",
  "menuCloseTab": "Chiudi scheda",
  "menuCut": "Taglia",
  "menuCopy": "Copia",
  "menuPaste": "Incolla",
  "menuSelectAll": "Seleziona tutto",
  "menuFullscreen": "Attiva o disattiva schermo intero",
  "menuResetZoom": "Ripristina zoom",
  "menuZoomIn": "Ingrandisci",
  "menuZoomOut": "Riduci",
  "officeFiles": "Documenti Office / Bozze Office EX",
  "allFiles": "Tutti i file",
  "originalFormat": "Formato originale del file",
  "replaceTarget": "Sostituire il file di destinazione esistente?",
  "replace": "Sostituisci",
  "saveBeforeClose": "Salvare le modifiche prima di chiudere?",
  "discardChanges": "Scarta modifiche",
  "openFailed": "Impossibile aprire il file",
  "windowFailed": "Impossibile aprire la finestra",
  "finishComposition": "Completa l'immissione corrente prima di cambiare lingua.",
  "oneDroppedFile": "Trascina un solo file alla volta.",
  "errorInvalid": "File o richiesta non validi.",
  "errorUnsupported": "Questa funzione o questo formato non sono ancora supportati.",
  "errorUnsafe": "L'operazione \xE8 stata bloccata per motivi di sicurezza.",
  "errorLimit": "L'operazione supera un limite di risorse.",
  "errorConflict": "Il documento o la destinazione sono cambiati.",
  "errorIo": "L'operazione sul file non \xE8 riuscita.",
  "errorInternal": "Si \xE8 verificato un errore interno.",
  "diagUnknown": "\xC8 stato segnalato un avviso di compatibilit\xE0 sconosciuto.",
  "diagSemanticPending": "Solo ispezione del contenitore. Il contenuto modificabile del documento non \xE8 stato importato.",
  "diagMacrosDisabled": "Rilevato contenuto relativo alle macro. Le macro non vengono eseguite; i byte originali sono conservati solo nelle copie identiche.",
  "diagSignedReadOnly": "File firmato: sola ispezione. La validit\xE0 della firma non \xE8 garantita.",
  "diagExternalDisabled": "Le relazioni esterne sono registrate; nessun contenuto esterno viene caricato.",
  "diagStrictReadOnly": "Rilevato Strict OOXML; lettura e scrittura del contenuto non ancora verificate.",
  "diagEncryptedUnsupported": "Rilevato un contenitore cifrato. Decifratura e modifica non disponibili.",
  "diagExtensionMismatch": "L'estensione del file non corrisponde al contenuto rilevato.",
  "writerFormatting": "Formattazione del testo",
  "writerEditNote": "Modifica i paragrafi e seleziona il testo. Invio divide il paragrafo; Maiusc+Invio inserisce un'interruzione di riga.",
  "writerPagePreview": "Anteprima pagina",
  "writerEstimated": "Layout stimato. Fai clic sulla pagina per individuare il testo. La fedelt\xE0 di stampa non \xE8 ancora verificata.",
  "writerPreviousPage": "Pagina precedente",
  "writerNextPage": "Pagina successiva",
  "writerPageNumber": "Pagina {current} / {total}",
  "writerLayoutLimits": "Alcune funzioni tipografiche sono approssimate.",
  "writerPreviewUnavailable": "Anteprima non disponibile per questo contenuto o limite di layout. Il contenuto originale rimane invariato.",
  "writerBold": "Grassetto",
  "writerItalic": "Corsivo",
  "writerUnderline": "Sottolineato",
  "writerAlignLeft": "Allinea a sinistra",
  "writerAlignCenter": "Centra",
  "writerAlignRight": "Allinea a destra",
  "writerSplit": "Dividi paragrafo",
  "writerPageBreak": "Interruzione di pagina dopo il paragrafo",
  "writerUnsupportedBlock": "Questo blocco non \xE8 modificabile in questa anteprima.",
  "docxNew": "Nuovo documento DOCX",
  "docxDocument": "Documento DOCX",
  "docxNote": "Profilo DOCX limitato: testo, formattazione diretta, stili supportati, tabelle fisse, immagini PNG/JPEG in linea e layout di base. I documenti complessi restano in sola lettura.",
  "writerFontFamily": "Carattere",
  "writerFontSize": "Dimensione (pt)",
  "writerTextColor": "Colore del testo",
  "writerParagraphStyle": "Stile di paragrafo",
  "writerCharacterStyle": "Stile di carattere",
  "writerChooseStyle": "Scegli stile",
  "writerTable": "Tabella",
  "writerTableRows": "Righe",
  "writerTableColumns": "Colonne",
  "writerInsertTable": "Inserisci tabella",
  "writerAddRow": "Aggiungi riga sotto",
  "writerDeleteRow": "Elimina riga",
  "writerAddColumn": "Aggiungi colonna a destra",
  "writerDeleteColumn": "Elimina colonna",
  "writerColumnWidth": "Larghezza colonna (pt)",
  "writerTableBorder": "Bordi tabella",
  "writerDeleteTable": "Elimina tabella",
  "writerCell": "Cella {row}, {column}",
  "writerInsertImage": "Inserisci immagine",
  "writerImage": "Immagine",
  "writerImageWidth": "Larghezza immagine (pt)",
  "writerRemoveImage": "Elimina immagine",
  "writerPaper": "Formato carta",
  "writerCustomPaper": "Personalizzato",
  "writerA4": "A4",
  "writerLetter": "Letter",
  "writerA3": "A3",
  "writerOrientation": "Orientamento",
  "writerPortrait": "Verticale",
  "writerLandscape": "Orizzontale",
  "writerPageWidth": "Larghezza pagina (pt)",
  "writerPageHeight": "Altezza pagina (pt)",
  "writerMarginTop": "Margine superiore (pt)",
  "writerMarginRight": "Margine destro (pt)",
  "writerMarginBottom": "Margine inferiore (pt)",
  "writerMarginLeft": "Margine sinistro (pt)",
  "writerApplyPage": "Applica impostazioni pagina",
  "writerIndent": "Rientro (pt)",
  "writerSpaceBefore": "Prima (pt)",
  "writerSpaceAfter": "Dopo (pt)",
  "writerLineHeight": "Altezza riga (pt; 0 = auto)",
  "writerInsertInlineImage": "Inserisci immagine al cursore",
  "writerInlineImageNote": "Il simbolo rappresenta un'immagine in linea. Usa i controlli dell'immagine per ridimensionarla o rimuoverla.",
  "writerContinuous": "Modifica testo continuo",
  "writerExitContinuous": "Torna all'editor dei paragrafi",
  "writerContinuousNote": "Seleziona, copia, taglia, incolla o formatta paragrafi di testo adiacenti. Tabelle, interruzioni di pagina, sezioni e paragrafi con immagini delimitano la selezione. Le nuove righe incollate diventano paragrafi.",
  "writerSection": "Sezione",
  "writerSectionNumber": "Sezione {number}",
  "writerSectionBreak": "Interruzione di sezione alla pagina successiva",
  "writerTextLanguage": "Lingua del testo (BCP 47)",
  "writerParagraphDirection": "Direzione del paragrafo",
  "writerLtr": "Da sinistra a destra",
  "writerRtl": "Da destra a sinistra",
  "docNew": "Nuovo DOC",
  "docDocument": "Documento Word 97\u20132003",
  "docNote": "Modifica DOC limitata: testo Unicode, formattazione di base e una sezione. I DOC non supportati restano in sola lettura; tabelle e immagini non sono salvabili.",
  "docTextPreview": "Anteprima del testo principale in sola lettura, non del layout completo. La copia conserva i byte originali.",
  "convertDoc": "Converti in DOC",
  "convertDocx": "Converti in DOCX",
  "conversionBoundary": "Si convertono solo le strutture supportate. Le parti non interpretate restano nel file sorgente.",
  "writerPageEdit": "Modifica sulla pagina",
  "writerExitPageEdit": "Torna agli strumenti",
  "writerNativePageNote": "Modifica sulla pagina con la composizione nativa del testo. Trascina per selezionare; gli appunti interni conservano formati e immagini supportati. La fedelt\xE0 a Word non \xE8 ancora verificata."
};

// packages/i18n/src/messages.ts
var PARAM = /\{([A-Za-z][A-Za-z0-9_]*)\}/g;
function formatTemplate(template, args = {}) {
  if (template.length > 16384) throw new Error("Message template too large");
  const output = template.replace(PARAM, (_match, name) => {
    const descriptor = Object.getOwnPropertyDescriptor(args, name);
    if (!descriptor || !Object.hasOwn(descriptor, "value")) throw new Error("Missing or unsafe message parameter: " + name);
    const value = descriptor.value;
    if (typeof value !== "string" && (typeof value !== "number" || !Number.isFinite(value))) throw new Error("Invalid message parameter: " + name);
    if (typeof value === "string" && value.length > 8192) throw new Error("Message parameter too large");
    return String(value);
  });
  if (output.length > 65536) throw new Error("Formatted message too large");
  return output;
}

// packages/i18n/src/sheets-catalogs.ts
var sheetsEnglish = {
  xlsxNew: "New XLSX workbook",
  xlsxDocument: "Excel workbook (.xlsx)",
  xlsxNote: "Edit supported workbook cells, formulas and styles. Files with protected or unsupported dependencies open as preserved read-only previews.",
  xlsNew: "New Excel 97\u20132003 workbook",
  xlsDocument: "Excel 97\u20132003 workbook (.xls)",
  xlsNote: "BIFF8 workbook: up to 65,536 rows and 256 columns. Saving and conversion check formulas, styles and source dependencies before writing.",
  convertXlsx: "Convert to XLSX copy",
  convertXls: "Convert to XLS copy",
  sheetGrid: "Spreadsheet grid",
  sheetFormula: "Cell value or formula",
  sheetAddress: "Cell or range address",
  sheetAdd: "Add sheet",
  sheetRename: "Rename sheet",
  sheetDelete: "Delete sheet",
  sheetMoveLeft: "Move sheet earlier",
  sheetMoveRight: "Move sheet later",
  sheetName: "Sheet name",
  sheetManage: "Sheets, rows and columns",
  sheetMerge: "Merge cells",
  sheetUnmerge: "Unmerge cells",
  sheetClear: "Clear values",
  sheetInsertRows: "Insert rows",
  sheetDeleteRows: "Delete rows",
  sheetInsertColumns: "Insert columns",
  sheetDeleteColumns: "Delete columns",
  sheetRowHeight: "Row height (px)",
  sheetColumnWidth: "Column width (px)",
  sheetNumberFormat: "Number format",
  sheetGeneral: "General",
  sheetNumber: "Number",
  sheetPercent: "Percentage",
  sheetCurrency: "Currency",
  sheetDate: "Date",
  sheetTime: "Time",
  sheetScientific: "Scientific",
  sheetCustomFormat: "Custom format code",
  sheetFillColor: "Cell fill",
  sheetWrap: "Wrap text",
  sheetBorder: "Cell borders",
  sheetFormulaMode: "Formula input",
  sheetCanonical: "English names \xB7 decimal point",
  sheetRegional: "Regional names and separators",
  sheetRecalculate: "Recalculate",
  sheetCalculating: "Calculating\u2026",
  sheetCalculated: "Calculated",
  sheetUnsupported: "Not calculated: unsupported formula",
  sheetStale: "Previous result: recalculation needed",
  sheetCalcError: "Formula error",
  sheetCancelCalculation: "Cancel calculation",
  sheetSelectionSummary: "{count} numeric cells \xB7 Sum {sum}",
  sheetPosition: "Selection {address}",
  sheetHelp: "Click or drag to select. Type or press F2 to edit; Enter confirms, Esc cancels. Shift extends selection. Copy and paste ranges as TSV. Formulas start with =.",
  sheetFreeze: "Freeze at selection",
  sheetUnfreeze: "Unfreeze panes",
  sheetRtl: "Right-to-left sheet",
  sheetShowGrid: "Show grid lines",
  sheetDateSystem: "Workbook date system",
  sheetPreview: "Preserved workbook preview",
  sheetSourceProtected: "This workbook contains dependencies outside the editable profile. You can inspect cells and save an exact original copy.",
  sheetConvertBoundary: "Conversion is blocked because source dependencies cannot be represented safely in the target format.",
  sheetFormulaPending: "Waiting for calculation",
  sheetInputInvalid: "The value or formula cannot be entered in the selected input mode.",
  sheetView: "View",
  sheetApply: "Apply",
  sheetFormatting: "Cell formatting",
  sheetFillDown: "Fill down",
  sheetFillRight: "Fill right"
};
var sheetsSimplified = {
  xlsxNew: "\u65B0\u5EFA XLSX \u5DE5\u4F5C\u7C3F",
  xlsxDocument: "Excel \u5DE5\u4F5C\u7C3F\uFF08.xlsx\uFF09",
  xlsxNote: "\u7F16\u8F91\u5DF2\u652F\u6301\u7684\u5355\u5143\u683C\u3001\u516C\u5F0F\u548C\u6837\u5F0F\u3002\u5305\u542B\u4FDD\u62A4\u6216\u672A\u77E5\u4F9D\u8D56\u7684\u6587\u4EF6\u4EE5\u4FDD\u7559\u539F\u4EF6\u7684\u53EA\u8BFB\u9884\u89C8\u6253\u5F00\u3002",
  xlsNew: "\u65B0\u5EFA Excel 97\u20132003 \u5DE5\u4F5C\u7C3F",
  xlsDocument: "Excel 97\u20132003 \u5DE5\u4F5C\u7C3F\uFF08.xls\uFF09",
  xlsNote: "BIFF8 \u5DE5\u4F5C\u7C3F\uFF1A\u6700\u591A 65,536 \u884C\u3001256 \u5217\u3002\u4FDD\u5B58\u548C\u8F6C\u6362\u524D\u68C0\u67E5\u516C\u5F0F\u3001\u6837\u5F0F\u53CA\u539F\u6587\u4EF6\u4F9D\u8D56\u3002",
  convertXlsx: "\u8F6C\u6362\u4E3A XLSX \u526F\u672C",
  convertXls: "\u8F6C\u6362\u4E3A XLS \u526F\u672C",
  sheetGrid: "\u7535\u5B50\u8868\u683C\u7F51\u683C",
  sheetFormula: "\u5355\u5143\u683C\u503C\u6216\u516C\u5F0F",
  sheetAddress: "\u5355\u5143\u683C\u6216\u9009\u533A\u5730\u5740",
  sheetAdd: "\u6DFB\u52A0\u5DE5\u4F5C\u8868",
  sheetRename: "\u91CD\u547D\u540D\u5DE5\u4F5C\u8868",
  sheetDelete: "\u5220\u9664\u5DE5\u4F5C\u8868",
  sheetMoveLeft: "\u5DE5\u4F5C\u8868\u524D\u79FB",
  sheetMoveRight: "\u5DE5\u4F5C\u8868\u540E\u79FB",
  sheetName: "\u5DE5\u4F5C\u8868\u540D\u79F0",
  sheetManage: "\u5DE5\u4F5C\u8868\u3001\u884C\u548C\u5217",
  sheetMerge: "\u5408\u5E76\u5355\u5143\u683C",
  sheetUnmerge: "\u62C6\u5206\u5355\u5143\u683C",
  sheetClear: "\u6E05\u9664\u6570\u503C",
  sheetInsertRows: "\u63D2\u5165\u884C",
  sheetDeleteRows: "\u5220\u9664\u884C",
  sheetInsertColumns: "\u63D2\u5165\u5217",
  sheetDeleteColumns: "\u5220\u9664\u5217",
  sheetRowHeight: "\u884C\u9AD8\uFF08px\uFF09",
  sheetColumnWidth: "\u5217\u5BBD\uFF08px\uFF09",
  sheetNumberFormat: "\u6570\u5B57\u683C\u5F0F",
  sheetGeneral: "\u5E38\u89C4",
  sheetNumber: "\u6570\u5B57",
  sheetPercent: "\u767E\u5206\u6BD4",
  sheetCurrency: "\u8D27\u5E01",
  sheetDate: "\u65E5\u671F",
  sheetTime: "\u65F6\u95F4",
  sheetScientific: "\u79D1\u5B66\u8BB0\u6570",
  sheetCustomFormat: "\u81EA\u5B9A\u4E49\u683C\u5F0F\u4EE3\u7801",
  sheetFillColor: "\u586B\u5145\u989C\u8272",
  sheetWrap: "\u81EA\u52A8\u6362\u884C",
  sheetBorder: "\u5355\u5143\u683C\u8FB9\u6846",
  sheetFormulaMode: "\u516C\u5F0F\u8F93\u5165",
  sheetCanonical: "\u82F1\u6587\u540D\u79F0 \xB7 \u5C0F\u6570\u70B9",
  sheetRegional: "\u5730\u533A\u540D\u79F0\u548C\u5206\u9694\u7B26",
  sheetRecalculate: "\u91CD\u65B0\u8BA1\u7B97",
  sheetCalculating: "\u6B63\u5728\u8BA1\u7B97\u2026",
  sheetCalculated: "\u5DF2\u8BA1\u7B97",
  sheetUnsupported: "\u672A\u8BA1\u7B97\uFF1A\u516C\u5F0F\u5C1A\u672A\u652F\u6301",
  sheetStale: "\u4E0A\u6B21\u7ED3\u679C\uFF1A\u9700\u8981\u91CD\u65B0\u8BA1\u7B97",
  sheetCalcError: "\u516C\u5F0F\u9519\u8BEF",
  sheetCancelCalculation: "\u53D6\u6D88\u8BA1\u7B97",
  sheetSelectionSummary: "{count} \u4E2A\u6570\u5B57\u5355\u5143\u683C \xB7 \u5408\u8BA1 {sum}",
  sheetPosition: "\u9009\u533A {address}",
  sheetHelp: "\u5355\u51FB\u6216\u62D6\u52A8\u9009\u62E9\uFF1B\u76F4\u63A5\u952E\u5165\u6216\u6309 F2 \u7F16\u8F91\uFF0CEnter \u786E\u8BA4\uFF0CEsc \u53D6\u6D88\u3002Shift \u6269\u5C55\u9009\u533A\uFF1B\u6309 TSV \u590D\u5236\u7C98\u8D34\u8303\u56F4\uFF0C\u516C\u5F0F\u4EE5 = \u5F00\u5934\u3002",
  sheetFreeze: "\u5728\u9009\u533A\u5904\u51BB\u7ED3",
  sheetUnfreeze: "\u53D6\u6D88\u51BB\u7ED3",
  sheetRtl: "\u5DE5\u4F5C\u8868\u4ECE\u53F3\u5230\u5DE6",
  sheetShowGrid: "\u663E\u793A\u7F51\u683C\u7EBF",
  sheetDateSystem: "\u5DE5\u4F5C\u7C3F\u65E5\u671F\u7CFB\u7EDF",
  sheetPreview: "\u4FDD\u7559\u539F\u4EF6\u7684\u5DE5\u4F5C\u7C3F\u9884\u89C8",
  sheetSourceProtected: "\u5DE5\u4F5C\u7C3F\u5305\u542B\u5F53\u524D\u7F16\u8F91\u8303\u56F4\u4EE5\u5916\u7684\u4F9D\u8D56\u3002\u53EF\u4EE5\u67E5\u770B\u5355\u5143\u683C\uFF0C\u5E76\u4FDD\u5B58\u4E0E\u539F\u4EF6\u5B8C\u5168\u4E00\u81F4\u7684\u526F\u672C\u3002",
  sheetConvertBoundary: "\u539F\u6587\u4EF6\u4F9D\u8D56\u65E0\u6CD5\u5728\u76EE\u6807\u683C\u5F0F\u4E2D\u5B89\u5168\u8868\u8FBE\uFF0C\u5DF2\u963B\u6B62\u8F6C\u6362\u3002",
  sheetFormulaPending: "\u7B49\u5F85\u8BA1\u7B97",
  sheetInputInvalid: "\u65E0\u6CD5\u5728\u6240\u9009\u8F93\u5165\u6A21\u5F0F\u4E0B\u8F93\u5165\u6B64\u6570\u503C\u6216\u516C\u5F0F\u3002",
  sheetView: "\u89C6\u56FE",
  sheetApply: "\u5E94\u7528",
  sheetFormatting: "\u5355\u5143\u683C\u683C\u5F0F",
  sheetFillDown: "\u5411\u4E0B\u586B\u5145",
  sheetFillRight: "\u5411\u53F3\u586B\u5145"
};

// packages/i18n/src/sheets-locales.ts
function sheetsCatalog(values) {
  const keys = Object.keys(sheetsEnglish), lines = values.trim().split("\n");
  if (lines.length !== keys.length) throw Error("Sheets translation key count mismatch: " + lines.length);
  return Object.fromEntries(keys.map((key, index) => [key, lines[index]]));
}
var sheetsTraditional = sheetsCatalog(`
\u65B0\u589E XLSX \u6D3B\u9801\u7C3F
Excel \u6D3B\u9801\u7C3F\uFF08.xlsx\uFF09
\u7DE8\u8F2F\u5DF2\u652F\u63F4\u7684\u5132\u5B58\u683C\u3001\u516C\u5F0F\u53CA\u6A23\u5F0F\u3002\u5305\u542B\u4FDD\u8B77\u6216\u4E0D\u652F\u63F4\u76F8\u4F9D\u9805\u76EE\u7684\u6A94\u6848\u6703\u4EE5\u4FDD\u7559\u539F\u4EF6\u7684\u552F\u8B80\u9810\u89BD\u958B\u555F\u3002
\u65B0\u589E Excel 97\u20132003 \u6D3B\u9801\u7C3F
Excel 97\u20132003 \u6D3B\u9801\u7C3F\uFF08.xls\uFF09
BIFF8 \u6D3B\u9801\u7C3F\uFF1A\u6700\u591A 65,536 \u5217\u3001256 \u6B04\u3002\u5132\u5B58\u53CA\u8F49\u63DB\u524D\u6703\u6AA2\u67E5\u516C\u5F0F\u3001\u6A23\u5F0F\u8207\u4F86\u6E90\u76F8\u4F9D\u9805\u76EE\u3002
\u8F49\u63DB\u70BA XLSX \u8907\u672C
\u8F49\u63DB\u70BA XLS \u8907\u672C
\u8A66\u7B97\u8868\u683C\u7DDA
\u5132\u5B58\u683C\u503C\u6216\u516C\u5F0F
\u5132\u5B58\u683C\u6216\u7BC4\u570D\u4F4D\u5740
\u65B0\u589E\u5DE5\u4F5C\u8868
\u91CD\u65B0\u547D\u540D\u5DE5\u4F5C\u8868
\u522A\u9664\u5DE5\u4F5C\u8868
\u5DE5\u4F5C\u8868\u5F80\u524D\u79FB
\u5DE5\u4F5C\u8868\u5F80\u5F8C\u79FB
\u5DE5\u4F5C\u8868\u540D\u7A31
\u5DE5\u4F5C\u8868\u3001\u5217\u8207\u6B04
\u5408\u4F75\u5132\u5B58\u683C
\u53D6\u6D88\u5408\u4F75\u5132\u5B58\u683C
\u6E05\u9664\u503C
\u63D2\u5165\u5217
\u522A\u9664\u5217
\u63D2\u5165\u6B04
\u522A\u9664\u6B04
\u5217\u9AD8\uFF08px\uFF09
\u6B04\u5BEC\uFF08px\uFF09
\u6578\u503C\u683C\u5F0F
\u4E00\u822C
\u6578\u503C
\u767E\u5206\u6BD4
\u8CA8\u5E63
\u65E5\u671F
\u6642\u9593
\u79D1\u5B78\u8A18\u865F
\u81EA\u8A02\u683C\u5F0F\u4EE3\u78BC
\u5132\u5B58\u683C\u586B\u6EFF\u8272\u5F69
\u81EA\u52D5\u63DB\u884C
\u5132\u5B58\u683C\u6846\u7DDA
\u516C\u5F0F\u8F38\u5165
\u82F1\u6587\u540D\u7A31 \xB7 \u5C0F\u6578\u9EDE
\u5730\u5340\u540D\u7A31\u53CA\u5206\u9694\u7B26\u865F
\u91CD\u65B0\u8A08\u7B97
\u6B63\u5728\u8A08\u7B97\u2026
\u5DF2\u8A08\u7B97
\u672A\u8A08\u7B97\uFF1A\u4E0D\u652F\u63F4\u7684\u516C\u5F0F
\u4E0A\u6B21\u7D50\u679C\uFF1A\u9700\u8981\u91CD\u65B0\u8A08\u7B97
\u516C\u5F0F\u932F\u8AA4
\u53D6\u6D88\u8A08\u7B97
{count} \u500B\u6578\u503C\u5132\u5B58\u683C \xB7 \u7E3D\u548C {sum}
\u9078\u53D6\u7BC4\u570D {address}
\u6309\u4E00\u4E0B\u6216\u62D6\u66F3\u4EE5\u9078\u53D6\u3002\u76F4\u63A5\u8F38\u5165\u6216\u6309 F2 \u7DE8\u8F2F\uFF0CEnter \u78BA\u8A8D\uFF0CEsc \u53D6\u6D88\u3002Shift \u53EF\u64F4\u5927\u9078\u53D6\u7BC4\u570D\uFF1B\u4EE5 TSV \u8907\u88FD\u8CBC\u4E0A\u7BC4\u570D\u3002\u516C\u5F0F\u4EE5 = \u958B\u982D\u3002
\u5728\u9078\u53D6\u7BC4\u570D\u8655\u51CD\u7D50
\u53D6\u6D88\u51CD\u7D50\u7A97\u683C
\u5DE5\u4F5C\u8868\u7531\u53F3\u81F3\u5DE6
\u986F\u793A\u683C\u7DDA
\u6D3B\u9801\u7C3F\u65E5\u671F\u7CFB\u7D71
\u4FDD\u7559\u539F\u4EF6\u7684\u6D3B\u9801\u7C3F\u9810\u89BD
\u6B64\u6D3B\u9801\u7C3F\u5305\u542B\u76EE\u524D\u7DE8\u8F2F\u7BC4\u570D\u4EE5\u5916\u7684\u76F8\u4F9D\u9805\u76EE\u3002\u60A8\u53EF\u4EE5\u6AA2\u8996\u5132\u5B58\u683C\uFF0C\u4E26\u5132\u5B58\u8207\u539F\u4EF6\u5B8C\u5168\u76F8\u540C\u7684\u8907\u672C\u3002
\u4F86\u6E90\u76F8\u4F9D\u9805\u76EE\u7121\u6CD5\u5728\u76EE\u6A19\u683C\u5F0F\u4E2D\u5B89\u5168\u8868\u9054\uFF0C\u56E0\u6B64\u5DF2\u963B\u6B62\u8F49\u63DB\u3002
\u7B49\u5F85\u8A08\u7B97
\u7121\u6CD5\u5728\u6240\u9078\u8F38\u5165\u6A21\u5F0F\u4E0B\u8F38\u5165\u6B64\u503C\u6216\u516C\u5F0F\u3002
\u6AA2\u8996
\u5957\u7528
\u5132\u5B58\u683C\u683C\u5F0F
\u5411\u4E0B\u586B\u6EFF
\u5411\u53F3\u586B\u6EFF
`);
var sheetsJapanese = sheetsCatalog(`
\u65B0\u3057\u3044 XLSX \u30D6\u30C3\u30AF
Excel \u30D6\u30C3\u30AF\uFF08.xlsx\uFF09
\u5BFE\u5FDC\u3059\u308B\u30BB\u30EB\u3001\u6570\u5F0F\u3001\u66F8\u5F0F\u3092\u7DE8\u96C6\u3067\u304D\u307E\u3059\u3002\u4FDD\u8B77\u3084\u672A\u5BFE\u5FDC\u306E\u4F9D\u5B58\u95A2\u4FC2\u3092\u542B\u3080\u30D5\u30A1\u30A4\u30EB\u306F\u3001\u539F\u672C\u3092\u4FDD\u6301\u3057\u305F\u8AAD\u307F\u53D6\u308A\u5C02\u7528\u30D7\u30EC\u30D3\u30E5\u30FC\u3067\u958B\u304D\u307E\u3059\u3002
\u65B0\u3057\u3044 Excel 97\u20132003 \u30D6\u30C3\u30AF
Excel 97\u20132003 \u30D6\u30C3\u30AF\uFF08.xls\uFF09
BIFF8 \u30D6\u30C3\u30AF\uFF1A\u6700\u5927 65,536 \u884C\u3001256 \u5217\u3002\u4FDD\u5B58\u3068\u5909\u63DB\u306E\u524D\u306B\u6570\u5F0F\u3001\u66F8\u5F0F\u3001\u5143\u30D5\u30A1\u30A4\u30EB\u306E\u4F9D\u5B58\u95A2\u4FC2\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002
XLSX \u306E\u30B3\u30D4\u30FC\u306B\u5909\u63DB
XLS \u306E\u30B3\u30D4\u30FC\u306B\u5909\u63DB
\u30B9\u30D7\u30EC\u30C3\u30C9\u30B7\u30FC\u30C8\u306E\u30B0\u30EA\u30C3\u30C9
\u30BB\u30EB\u306E\u5024\u307E\u305F\u306F\u6570\u5F0F
\u30BB\u30EB\u307E\u305F\u306F\u7BC4\u56F2\u306E\u30A2\u30C9\u30EC\u30B9
\u30B7\u30FC\u30C8\u3092\u8FFD\u52A0
\u30B7\u30FC\u30C8\u540D\u3092\u5909\u66F4
\u30B7\u30FC\u30C8\u3092\u524A\u9664
\u30B7\u30FC\u30C8\u3092\u524D\u3078\u79FB\u52D5
\u30B7\u30FC\u30C8\u3092\u5F8C\u308D\u3078\u79FB\u52D5
\u30B7\u30FC\u30C8\u540D
\u30B7\u30FC\u30C8\u3001\u884C\u3001\u5217
\u30BB\u30EB\u3092\u7D50\u5408
\u30BB\u30EB\u7D50\u5408\u3092\u89E3\u9664
\u5024\u3092\u30AF\u30EA\u30A2
\u884C\u3092\u633F\u5165
\u884C\u3092\u524A\u9664
\u5217\u3092\u633F\u5165
\u5217\u3092\u524A\u9664
\u884C\u306E\u9AD8\u3055\uFF08px\uFF09
\u5217\u306E\u5E45\uFF08px\uFF09
\u8868\u793A\u5F62\u5F0F
\u6A19\u6E96
\u6570\u5024
\u30D1\u30FC\u30BB\u30F3\u30C8
\u901A\u8CA8
\u65E5\u4ED8
\u6642\u523B
\u6307\u6570
\u30E6\u30FC\u30B6\u30FC\u5B9A\u7FA9\u306E\u8868\u793A\u5F62\u5F0F
\u30BB\u30EB\u306E\u5857\u308A\u3064\u3076\u3057
\u6298\u308A\u8FD4\u3057\u3066\u8868\u793A
\u30BB\u30EB\u306E\u7F6B\u7DDA
\u6570\u5F0F\u306E\u5165\u529B
\u82F1\u8A9E\u306E\u95A2\u6570\u540D \xB7 \u5C0F\u6570\u70B9
\u5730\u57DF\u306E\u95A2\u6570\u540D\u3068\u533A\u5207\u308A\u8A18\u53F7
\u518D\u8A08\u7B97
\u8A08\u7B97\u4E2D\u2026
\u8A08\u7B97\u6E08\u307F
\u672A\u8A08\u7B97\uFF1A\u672A\u5BFE\u5FDC\u306E\u6570\u5F0F
\u524D\u56DE\u306E\u7D50\u679C\uFF1A\u518D\u8A08\u7B97\u304C\u5FC5\u8981
\u6570\u5F0F\u30A8\u30E9\u30FC
\u8A08\u7B97\u3092\u30AD\u30E3\u30F3\u30BB\u30EB
\u6570\u5024\u30BB\u30EB {count} \u500B \xB7 \u5408\u8A08 {sum}
\u9078\u629E\u7BC4\u56F2 {address}
\u30AF\u30EA\u30C3\u30AF\u307E\u305F\u306F\u30C9\u30E9\u30C3\u30B0\u3067\u9078\u629E\u3057\u307E\u3059\u3002\u5165\u529B\u307E\u305F\u306F F2 \u3067\u7DE8\u96C6\u3057\u3001Enter \u3067\u78BA\u5B9A\u3001Esc \u3067\u53D6\u308A\u6D88\u3057\u307E\u3059\u3002Shift \u3067\u9078\u629E\u3092\u62E1\u5F35\u3067\u304D\u307E\u3059\u3002\u7BC4\u56F2\u306F TSV \u3068\u3057\u3066\u30B3\u30D4\u30FC\u30FB\u8CBC\u308A\u4ED8\u3051\u3057\u307E\u3059\u3002\u6570\u5F0F\u306F = \u3067\u59CB\u3081\u307E\u3059\u3002
\u9078\u629E\u4F4D\u7F6E\u3067\u56FA\u5B9A
\u30A6\u30A3\u30F3\u30C9\u30A6\u67A0\u306E\u56FA\u5B9A\u3092\u89E3\u9664
\u53F3\u304B\u3089\u5DE6\u306E\u30B7\u30FC\u30C8
\u76EE\u76DB\u7DDA\u3092\u8868\u793A
\u30D6\u30C3\u30AF\u306E\u65E5\u4ED8\u30B7\u30B9\u30C6\u30E0
\u539F\u672C\u3092\u4FDD\u6301\u3057\u305F\u30D6\u30C3\u30AF\u306E\u30D7\u30EC\u30D3\u30E5\u30FC
\u3053\u306E\u30D6\u30C3\u30AF\u306B\u306F\u7DE8\u96C6\u5BFE\u8C61\u5916\u306E\u4F9D\u5B58\u95A2\u4FC2\u304C\u542B\u307E\u308C\u3066\u3044\u307E\u3059\u3002\u30BB\u30EB\u3092\u78BA\u8A8D\u3057\u3001\u539F\u672C\u3068\u5B8C\u5168\u306B\u540C\u3058\u30B3\u30D4\u30FC\u3092\u4FDD\u5B58\u3067\u304D\u307E\u3059\u3002
\u5143\u30D5\u30A1\u30A4\u30EB\u306E\u4F9D\u5B58\u95A2\u4FC2\u3092\u5909\u63DB\u5148\u306E\u5F62\u5F0F\u3067\u5B89\u5168\u306B\u8868\u73FE\u3067\u304D\u306A\u3044\u305F\u3081\u3001\u5909\u63DB\u3067\u304D\u307E\u305B\u3093\u3002
\u8A08\u7B97\u5F85\u3061
\u9078\u629E\u3057\u305F\u5165\u529B\u30E2\u30FC\u30C9\u3067\u306F\u3001\u3053\u306E\u5024\u307E\u305F\u306F\u6570\u5F0F\u3092\u5165\u529B\u3067\u304D\u307E\u305B\u3093\u3002
\u8868\u793A
\u9069\u7528
\u30BB\u30EB\u306E\u66F8\u5F0F
\u4E0B\u65B9\u5411\u3078\u30B3\u30D4\u30FC
\u53F3\u65B9\u5411\u3078\u30B3\u30D4\u30FC
`);
var sheetsKorean = sheetsCatalog(`
\uC0C8 XLSX \uD1B5\uD569 \uBB38\uC11C
Excel \uD1B5\uD569 \uBB38\uC11C (.xlsx)
\uC9C0\uC6D0\uB418\uB294 \uC140, \uC218\uC2DD \uBC0F \uC11C\uC2DD\uC744 \uD3B8\uC9D1\uD569\uB2C8\uB2E4. \uBCF4\uD638\uB418\uAC70\uB098 \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC885\uC18D \uD56D\uBAA9\uC774 \uC788\uB294 \uD30C\uC77C\uC740 \uC6D0\uBCF8\uC744 \uBCF4\uC874\uD55C \uC77D\uAE30 \uC804\uC6A9 \uBBF8\uB9AC \uBCF4\uAE30\uB85C \uC5F4\uB9BD\uB2C8\uB2E4.
\uC0C8 Excel 97\u20132003 \uD1B5\uD569 \uBB38\uC11C
Excel 97\u20132003 \uD1B5\uD569 \uBB38\uC11C (.xls)
BIFF8 \uD1B5\uD569 \uBB38\uC11C: \uCD5C\uB300 65,536\uD589, 256\uC5F4\uC785\uB2C8\uB2E4. \uC800\uC7A5 \uBC0F \uBCC0\uD658 \uC804\uC5D0 \uC218\uC2DD, \uC11C\uC2DD, \uC6D0\uBCF8 \uC885\uC18D \uD56D\uBAA9\uC744 \uD655\uC778\uD569\uB2C8\uB2E4.
XLSX \uBCF5\uC0AC\uBCF8\uC73C\uB85C \uBCC0\uD658
XLS \uBCF5\uC0AC\uBCF8\uC73C\uB85C \uBCC0\uD658
\uC2A4\uD504\uB808\uB4DC\uC2DC\uD2B8 \uACA9\uC790
\uC140 \uAC12 \uB610\uB294 \uC218\uC2DD
\uC140 \uB610\uB294 \uBC94\uC704 \uC8FC\uC18C
\uC2DC\uD2B8 \uCD94\uAC00
\uC2DC\uD2B8 \uC774\uB984 \uBC14\uAFB8\uAE30
\uC2DC\uD2B8 \uC0AD\uC81C
\uC2DC\uD2B8\uB97C \uC55E\uC73C\uB85C \uC774\uB3D9
\uC2DC\uD2B8\uB97C \uB4A4\uB85C \uC774\uB3D9
\uC2DC\uD2B8 \uC774\uB984
\uC2DC\uD2B8, \uD589 \uBC0F \uC5F4
\uC140 \uBCD1\uD569
\uC140 \uBCD1\uD569 \uD574\uC81C
\uAC12 \uC9C0\uC6B0\uAE30
\uD589 \uC0BD\uC785
\uD589 \uC0AD\uC81C
\uC5F4 \uC0BD\uC785
\uC5F4 \uC0AD\uC81C
\uD589 \uB192\uC774 (px)
\uC5F4 \uB108\uBE44 (px)
\uD45C\uC2DC \uD615\uC2DD
\uC77C\uBC18
\uC22B\uC790
\uBC31\uBD84\uC728
\uD1B5\uD654
\uB0A0\uC9DC
\uC2DC\uAC04
\uC9C0\uC218
\uC0AC\uC6A9\uC790 \uC9C0\uC815 \uD615\uC2DD \uCF54\uB4DC
\uC140 \uCC44\uC6B0\uAE30
\uD14D\uC2A4\uD2B8 \uC904 \uBC14\uAFC8
\uC140 \uD14C\uB450\uB9AC
\uC218\uC2DD \uC785\uB825
\uC601\uC5B4 \uD568\uC218 \uC774\uB984 \xB7 \uC18C\uC218\uC810
\uC9C0\uC5ED\uBCC4 \uC774\uB984 \uBC0F \uAD6C\uBD84 \uAE30\uD638
\uB2E4\uC2DC \uACC4\uC0B0
\uACC4\uC0B0 \uC911\u2026
\uACC4\uC0B0\uB428
\uACC4\uC0B0\uB418\uC9C0 \uC54A\uC74C: \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC218\uC2DD
\uC774\uC804 \uACB0\uACFC: \uB2E4\uC2DC \uACC4\uC0B0 \uD544\uC694
\uC218\uC2DD \uC624\uB958
\uACC4\uC0B0 \uCDE8\uC18C
\uC22B\uC790 \uC140 {count}\uAC1C \xB7 \uD569\uACC4 {sum}
\uC120\uD0DD \uBC94\uC704 {address}
\uD074\uB9AD\uD558\uAC70\uB098 \uB4DC\uB798\uADF8\uD558\uC5EC \uC120\uD0DD\uD569\uB2C8\uB2E4. \uC785\uB825\uD558\uAC70\uB098 F2\uB97C \uB20C\uB7EC \uD3B8\uC9D1\uD558\uACE0 Enter\uB85C \uD655\uC778, Esc\uB85C \uCDE8\uC18C\uD569\uB2C8\uB2E4. Shift\uB85C \uC120\uD0DD \uBC94\uC704\uB97C \uB298\uB9BD\uB2C8\uB2E4. \uBC94\uC704\uB97C TSV\uB85C \uBCF5\uC0AC\uD558\uC5EC \uBD99\uC5EC \uB123\uC2B5\uB2C8\uB2E4. \uC218\uC2DD\uC740 =\uB85C \uC2DC\uC791\uD569\uB2C8\uB2E4.
\uC120\uD0DD \uC704\uCE58\uC5D0\uC11C \uD2C0 \uACE0\uC815
\uD2C0 \uACE0\uC815 \uCDE8\uC18C
\uC624\uB978\uCABD\uC5D0\uC11C \uC67C\uCABD\uC73C\uB85C \uC2DC\uD2B8 \uD45C\uC2DC
\uB208\uAE08\uC120 \uD45C\uC2DC
\uD1B5\uD569 \uBB38\uC11C \uB0A0\uC9DC \uCCB4\uACC4
\uC6D0\uBCF8\uC744 \uBCF4\uC874\uD55C \uD1B5\uD569 \uBB38\uC11C \uBBF8\uB9AC \uBCF4\uAE30
\uC774 \uD1B5\uD569 \uBB38\uC11C\uC5D0\uB294 \uD3B8\uC9D1 \uBC94\uC704 \uBC16\uC758 \uC885\uC18D \uD56D\uBAA9\uC774 \uC788\uC2B5\uB2C8\uB2E4. \uC140\uC744 \uD655\uC778\uD558\uACE0 \uC6D0\uBCF8\uACFC \uC644\uC804\uD788 \uB3D9\uC77C\uD55C \uBCF5\uC0AC\uBCF8\uC744 \uC800\uC7A5\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.
\uC6D0\uBCF8 \uC885\uC18D \uD56D\uBAA9\uC744 \uB300\uC0C1 \uD615\uC2DD\uC73C\uB85C \uC548\uC804\uD558\uAC8C \uD45C\uD604\uD560 \uC218 \uC5C6\uC5B4 \uBCC0\uD658\uC774 \uCC28\uB2E8\uB418\uC5C8\uC2B5\uB2C8\uB2E4.
\uACC4\uC0B0 \uB300\uAE30 \uC911
\uC120\uD0DD\uD55C \uC785\uB825 \uBAA8\uB4DC\uC5D0\uC11C \uC774 \uAC12 \uB610\uB294 \uC218\uC2DD\uC744 \uC785\uB825\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.
\uBCF4\uAE30
\uC801\uC6A9
\uC140 \uC11C\uC2DD
\uC544\uB798\uB85C \uCC44\uC6B0\uAE30
\uC624\uB978\uCABD\uC73C\uB85C \uCC44\uC6B0\uAE30
`);
var sheetsFrench = sheetsCatalog(`
Nouveau classeur XLSX
Classeur Excel (.xlsx)
Modifiez les cellules, formules et styles pris en charge. Les fichiers prot\xE9g\xE9s ou comportant des d\xE9pendances non prises en charge s\u2019ouvrent en lecture seule, en pr\xE9servant l\u2019original.
Nouveau classeur Excel 97\u20132003
Classeur Excel 97\u20132003 (.xls)
Classeur BIFF8 : 65 536 lignes et 256 colonnes au maximum. Les formules, les styles et les d\xE9pendances sont v\xE9rifi\xE9s avant l\u2019enregistrement ou la conversion.
Convertir en copie XLSX
Convertir en copie XLS
Grille du tableur
Valeur ou formule de cellule
Adresse de cellule ou de plage
Ajouter une feuille
Renommer la feuille
Supprimer la feuille
D\xE9placer la feuille avant
D\xE9placer la feuille apr\xE8s
Nom de la feuille
Feuilles, lignes et colonnes
Fusionner les cellules
Annuler la fusion
Effacer les valeurs
Ins\xE9rer des lignes
Supprimer des lignes
Ins\xE9rer des colonnes
Supprimer des colonnes
Hauteur des lignes (px)
Largeur des colonnes (px)
Format de nombre
Standard
Nombre
Pourcentage
Mon\xE9taire
Date
Heure
Scientifique
Code de format personnalis\xE9
Remplissage des cellules
Renvoyer \xE0 la ligne
Bordures des cellules
Saisie des formules
Noms anglais \xB7 point d\xE9cimal
Noms et s\xE9parateurs r\xE9gionaux
Recalculer
Calcul en cours\u2026
Calcul\xE9
Non calcul\xE9 : formule non prise en charge
R\xE9sultat pr\xE9c\xE9dent : recalcul n\xE9cessaire
Erreur de formule
Annuler le calcul
{count} cellules num\xE9riques \xB7 Somme {sum}
S\xE9lection {address}
Cliquez ou faites glisser pour s\xE9lectionner. Saisissez du texte ou appuyez sur F2 pour modifier ; Entr\xE9e valide, \xC9chap annule. Maj \xE9tend la s\xE9lection. Copiez et collez les plages au format TSV. Les formules commencent par =.
Figer \xE0 la s\xE9lection
Lib\xE9rer les volets
Feuille de droite \xE0 gauche
Afficher le quadrillage
Syst\xE8me de dates du classeur
Aper\xE7u du classeur original pr\xE9serv\xE9
Ce classeur contient des d\xE9pendances hors du p\xE9rim\xE8tre \xE9ditable. Vous pouvez consulter les cellules et enregistrer une copie exacte de l\u2019original.
La conversion est bloqu\xE9e : les d\xE9pendances du fichier source ne peuvent pas \xEAtre repr\xE9sent\xE9es sans risque dans le format cible.
En attente du calcul
Cette valeur ou formule ne peut pas \xEAtre saisie dans le mode s\xE9lectionn\xE9.
Affichage
Appliquer
Format des cellules
Recopier vers le bas
Recopier vers la droite
`);
var sheetsGerman = sheetsCatalog(`
Neue XLSX-Arbeitsmappe
Excel-Arbeitsmappe (.xlsx)
Bearbeiten Sie unterst\xFCtzte Zellen, Formeln und Formate. Gesch\xFCtzte Dateien oder Dateien mit nicht unterst\xFCtzten Abh\xE4ngigkeiten werden als schreibgesch\xFCtzte Vorschau ge\xF6ffnet; das Original bleibt erhalten.
Neue Excel 97\u20132003-Arbeitsmappe
Excel 97\u20132003-Arbeitsmappe (.xls)
BIFF8-Arbeitsmappe: maximal 65.536 Zeilen und 256 Spalten. Vor dem Speichern und Konvertieren werden Formeln, Formate und Quellabh\xE4ngigkeiten gepr\xFCft.
In XLSX-Kopie konvertieren
In XLS-Kopie konvertieren
Tabellenraster
Zellwert oder Formel
Zell- oder Bereichsadresse
Blatt hinzuf\xFCgen
Blatt umbenennen
Blatt l\xF6schen
Blatt nach vorne verschieben
Blatt nach hinten verschieben
Blattname
Bl\xE4tter, Zeilen und Spalten
Zellen verbinden
Zellverbund aufheben
Werte l\xF6schen
Zeilen einf\xFCgen
Zeilen l\xF6schen
Spalten einf\xFCgen
Spalten l\xF6schen
Zeilenh\xF6he (px)
Spaltenbreite (px)
Zahlenformat
Standard
Zahl
Prozent
W\xE4hrung
Datum
Uhrzeit
Wissenschaftlich
Benutzerdefinierter Formatcode
Zellf\xFCllung
Zeilenumbruch
Zellrahmen
Formeleingabe
Englische Namen \xB7 Dezimalpunkt
Regionale Namen und Trennzeichen
Neu berechnen
Berechnung l\xE4uft\u2026
Berechnet
Nicht berechnet: nicht unterst\xFCtzte Formel
Vorheriges Ergebnis: Neuberechnung erforderlich
Formelfehler
Berechnung abbrechen
{count} numerische Zellen \xB7 Summe {sum}
Auswahl {address}
Zum Ausw\xE4hlen klicken oder ziehen. Zum Bearbeiten tippen oder F2 dr\xFCcken; Eingabe best\xE4tigt, Esc verwirft. Umschalt erweitert die Auswahl. Bereiche als TSV kopieren und einf\xFCgen. Formeln beginnen mit =.
An Auswahl fixieren
Fixierung aufheben
Blatt von rechts nach links
Gitternetzlinien anzeigen
Datumssystem der Arbeitsmappe
Vorschau der erhaltenen Arbeitsmappe
Diese Arbeitsmappe enth\xE4lt Abh\xE4ngigkeiten au\xDFerhalb des bearbeitbaren Umfangs. Sie k\xF6nnen die Zellen pr\xFCfen und eine exakte Kopie des Originals speichern.
Die Konvertierung wurde blockiert, da Quellabh\xE4ngigkeiten im Zielformat nicht sicher dargestellt werden k\xF6nnen.
Warten auf Berechnung
Dieser Wert oder diese Formel kann im gew\xE4hlten Eingabemodus nicht eingegeben werden.
Ansicht
\xDCbernehmen
Zellformatierung
Nach unten ausf\xFCllen
Nach rechts ausf\xFCllen
`);
var sheetsSpanish = sheetsCatalog(`
Nuevo libro XLSX
Libro de Excel (.xlsx)
Edite las celdas, f\xF3rmulas y estilos compatibles. Los archivos protegidos o con dependencias no compatibles se abren como vistas de solo lectura que conservan el original.
Nuevo libro de Excel 97\u20132003
Libro de Excel 97\u20132003 (.xls)
Libro BIFF8: hasta 65.536 filas y 256 columnas. Antes de guardar o convertir se comprueban las f\xF3rmulas, los estilos y las dependencias del origen.
Convertir en copia XLSX
Convertir en copia XLS
Cuadr\xEDcula de la hoja de c\xE1lculo
Valor o f\xF3rmula de la celda
Direcci\xF3n de celda o rango
Agregar hoja
Cambiar nombre de la hoja
Eliminar hoja
Mover hoja hacia delante
Mover hoja hacia atr\xE1s
Nombre de la hoja
Hojas, filas y columnas
Combinar celdas
Separar celdas
Borrar valores
Insertar filas
Eliminar filas
Insertar columnas
Eliminar columnas
Alto de fila (px)
Ancho de columna (px)
Formato de n\xFAmero
General
N\xFAmero
Porcentaje
Moneda
Fecha
Hora
Cient\xEDfico
C\xF3digo de formato personalizado
Relleno de celda
Ajustar texto
Bordes de celda
Entrada de f\xF3rmulas
Nombres en ingl\xE9s \xB7 punto decimal
Nombres y separadores regionales
Recalcular
Calculando\u2026
Calculado
Sin calcular: f\xF3rmula no compatible
Resultado anterior: es necesario recalcular
Error de f\xF3rmula
Cancelar c\xE1lculo
{count} celdas num\xE9ricas \xB7 Suma {sum}
Selecci\xF3n {address}
Haga clic o arrastre para seleccionar. Escriba o pulse F2 para editar; Intro confirma y Esc cancela. May\xFAs ampl\xEDa la selecci\xF3n. Copie y pegue rangos como TSV. Las f\xF3rmulas empiezan por =.
Inmovilizar en la selecci\xF3n
Movilizar paneles
Hoja de derecha a izquierda
Mostrar l\xEDneas de cuadr\xEDcula
Sistema de fechas del libro
Vista del libro con el original conservado
Este libro contiene dependencias fuera del \xE1mbito editable. Puede consultar las celdas y guardar una copia exacta del original.
Se ha bloqueado la conversi\xF3n porque las dependencias del origen no se pueden representar de forma segura en el formato de destino.
Esperando el c\xE1lculo
No se puede introducir este valor o f\xF3rmula en el modo de entrada seleccionado.
Vista
Aplicar
Formato de celdas
Rellenar hacia abajo
Rellenar hacia la derecha
`);
var sheetsPortuguese = sheetsCatalog(`
Nova pasta de trabalho XLSX
Pasta de trabalho do Excel (.xlsx)
Edite c\xE9lulas, f\xF3rmulas e estilos compat\xEDveis. Arquivos protegidos ou com depend\xEAncias n\xE3o compat\xEDveis s\xE3o abertos como visualiza\xE7\xF5es somente leitura, preservando o original.
Nova pasta de trabalho do Excel 97\u20132003
Pasta de trabalho do Excel 97\u20132003 (.xls)
Pasta de trabalho BIFF8: at\xE9 65.536 linhas e 256 colunas. As f\xF3rmulas, os estilos e as depend\xEAncias s\xE3o verificados antes de salvar ou converter.
Converter em c\xF3pia XLSX
Converter em c\xF3pia XLS
Grade da planilha
Valor ou f\xF3rmula da c\xE9lula
Endere\xE7o da c\xE9lula ou do intervalo
Adicionar planilha
Renomear planilha
Excluir planilha
Mover planilha para antes
Mover planilha para depois
Nome da planilha
Planilhas, linhas e colunas
Mesclar c\xE9lulas
Desfazer mesclagem
Limpar valores
Inserir linhas
Excluir linhas
Inserir colunas
Excluir colunas
Altura da linha (px)
Largura da coluna (px)
Formato de n\xFAmero
Geral
N\xFAmero
Porcentagem
Moeda
Data
Hora
Cient\xEDfico
C\xF3digo de formato personalizado
Preenchimento da c\xE9lula
Quebrar texto automaticamente
Bordas da c\xE9lula
Entrada de f\xF3rmulas
Nomes em ingl\xEAs \xB7 ponto decimal
Nomes e separadores regionais
Recalcular
Calculando\u2026
Calculado
N\xE3o calculado: f\xF3rmula n\xE3o compat\xEDvel
Resultado anterior: \xE9 necess\xE1rio recalcular
Erro de f\xF3rmula
Cancelar c\xE1lculo
{count} c\xE9lulas num\xE9ricas \xB7 Soma {sum}
Sele\xE7\xE3o {address}
Clique ou arraste para selecionar. Digite ou pressione F2 para editar; Enter confirma e Esc cancela. Shift amplia a sele\xE7\xE3o. Copie e cole intervalos como TSV. As f\xF3rmulas come\xE7am com =.
Congelar na sele\xE7\xE3o
Descongelar pain\xE9is
Planilha da direita para a esquerda
Mostrar linhas de grade
Sistema de datas da pasta de trabalho
Visualiza\xE7\xE3o da pasta de trabalho preservada
Esta pasta de trabalho cont\xE9m depend\xEAncias fora do escopo edit\xE1vel. Voc\xEA pode inspecionar as c\xE9lulas e salvar uma c\xF3pia exata do original.
A convers\xE3o foi bloqueada porque as depend\xEAncias do arquivo de origem n\xE3o podem ser representadas com seguran\xE7a no formato de destino.
Aguardando c\xE1lculo
Este valor ou f\xF3rmula n\xE3o pode ser inserido no modo de entrada selecionado.
Exibir
Aplicar
Formata\xE7\xE3o de c\xE9lulas
Preencher para baixo
Preencher para a direita
`);
var sheetsRussian = sheetsCatalog(`
\u041D\u043E\u0432\u0430\u044F \u043A\u043D\u0438\u0433\u0430 XLSX
\u041A\u043D\u0438\u0433\u0430 Excel (.xlsx)
\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u044F\u0447\u0435\u0439\u043A\u0438, \u0444\u043E\u0440\u043C\u0443\u043B\u044B \u0438 \u0441\u0442\u0438\u043B\u0438. \u0417\u0430\u0449\u0438\u0449\u0451\u043D\u043D\u044B\u0435 \u0444\u0430\u0439\u043B\u044B \u0438 \u0444\u0430\u0439\u043B\u044B \u0441 \u043D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u043C\u0438 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u044F\u043C\u0438 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F \u0447\u0442\u0435\u043D\u0438\u044F \u0441 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435\u043C \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0430.
\u041D\u043E\u0432\u0430\u044F \u043A\u043D\u0438\u0433\u0430 Excel 97\u20132003
\u041A\u043D\u0438\u0433\u0430 Excel 97\u20132003 (.xls)
\u041A\u043D\u0438\u0433\u0430 BIFF8: \u0434\u043E 65 536 \u0441\u0442\u0440\u043E\u043A \u0438 256 \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432. \u041F\u0435\u0440\u0435\u0434 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435\u043C \u0438 \u043F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435\u043C \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0442\u0441\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u044B, \u0441\u0442\u0438\u043B\u0438 \u0438 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430.
\u041F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u044C \u0432 \u043A\u043E\u043F\u0438\u044E XLSX
\u041F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u044C \u0432 \u043A\u043E\u043F\u0438\u044E XLS
\u0421\u0435\u0442\u043A\u0430 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B
\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u0444\u043E\u0440\u043C\u0443\u043B\u0430 \u044F\u0447\u0435\u0439\u043A\u0438
\u0410\u0434\u0440\u0435\u0441 \u044F\u0447\u0435\u0439\u043A\u0438 \u0438\u043B\u0438 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0430
\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043B\u0438\u0441\u0442
\u041F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u0442\u044C \u043B\u0438\u0441\u0442
\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u043B\u0438\u0441\u0442
\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u043B\u0438\u0441\u0442 \u0440\u0430\u043D\u044C\u0448\u0435
\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u043B\u0438\u0441\u0442 \u043F\u043E\u0437\u0436\u0435
\u0418\u043C\u044F \u043B\u0438\u0441\u0442\u0430
\u041B\u0438\u0441\u0442\u044B, \u0441\u0442\u0440\u043E\u043A\u0438 \u0438 \u0441\u0442\u043E\u043B\u0431\u0446\u044B
\u041E\u0431\u044A\u0435\u0434\u0438\u043D\u0438\u0442\u044C \u044F\u0447\u0435\u0439\u043A\u0438
\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u0431\u044A\u0435\u0434\u0438\u043D\u0435\u043D\u0438\u0435
\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F
\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0438
\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0438
\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0441\u0442\u043E\u043B\u0431\u0446\u044B
\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u0442\u043E\u043B\u0431\u0446\u044B
\u0412\u044B\u0441\u043E\u0442\u0430 \u0441\u0442\u0440\u043E\u043A\u0438 (\u043F\u043A\u0441)
\u0428\u0438\u0440\u0438\u043D\u0430 \u0441\u0442\u043E\u043B\u0431\u0446\u0430 (\u043F\u043A\u0441)
\u0427\u0438\u0441\u043B\u043E\u0432\u043E\u0439 \u0444\u043E\u0440\u043C\u0430\u0442
\u041E\u0431\u0449\u0438\u0439
\u0427\u0438\u0441\u043B\u043E\u0432\u043E\u0439
\u041F\u0440\u043E\u0446\u0435\u043D\u0442\u043D\u044B\u0439
\u0414\u0435\u043D\u0435\u0436\u043D\u044B\u0439
\u0414\u0430\u0442\u0430
\u0412\u0440\u0435\u043C\u044F
\u042D\u043A\u0441\u043F\u043E\u043D\u0435\u043D\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0439
\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0439 \u043A\u043E\u0434 \u0444\u043E\u0440\u043C\u0430\u0442\u0430
\u0417\u0430\u043B\u0438\u0432\u043A\u0430 \u044F\u0447\u0435\u0439\u043A\u0438
\u041F\u0435\u0440\u0435\u043D\u043E\u0441 \u0442\u0435\u043A\u0441\u0442\u0430
\u0413\u0440\u0430\u043D\u0438\u0446\u044B \u044F\u0447\u0435\u0439\u043A\u0438
\u0412\u0432\u043E\u0434 \u0444\u043E\u0440\u043C\u0443\u043B
\u0410\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438\u0435 \u0438\u043C\u0435\u043D\u0430 \xB7 \u0434\u0435\u0441\u044F\u0442\u0438\u0447\u043D\u0430\u044F \u0442\u043E\u0447\u043A\u0430
\u0420\u0435\u0433\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u043C\u0435\u043D\u0430 \u0438 \u0440\u0430\u0437\u0434\u0435\u043B\u0438\u0442\u0435\u043B\u0438
\u041F\u0435\u0440\u0435\u0441\u0447\u0438\u0442\u0430\u0442\u044C
\u0412\u044B\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0435\u2026
\u0412\u044B\u0447\u0438\u0441\u043B\u0435\u043D\u043E
\u041D\u0435 \u0432\u044B\u0447\u0438\u0441\u043B\u0435\u043D\u043E: \u043D\u0435\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u0430\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0430
\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u0439 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043F\u0435\u0440\u0435\u0441\u0447\u0451\u0442
\u041E\u0448\u0438\u0431\u043A\u0430 \u0444\u043E\u0440\u043C\u0443\u043B\u044B
\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u0432\u044B\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0435
\u0427\u0438\u0441\u043B\u043E\u0432\u044B\u0445 \u044F\u0447\u0435\u0435\u043A: {count} \xB7 \u0421\u0443\u043C\u043C\u0430: {sum}
\u0412\u044B\u0434\u0435\u043B\u0435\u043D\u0438\u0435 {address}
\u0429\u0451\u043B\u043A\u043D\u0438\u0442\u0435 \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u0442\u0430\u0449\u0438\u0442\u0435 \u0434\u043B\u044F \u0432\u044B\u0434\u0435\u043B\u0435\u043D\u0438\u044F. \u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0442\u0435\u043A\u0441\u0442 \u0438\u043B\u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 F2 \u0434\u043B\u044F \u043F\u0440\u0430\u0432\u043A\u0438; Enter \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442, Esc \u043E\u0442\u043C\u0435\u043D\u044F\u0435\u0442. Shift \u0440\u0430\u0441\u0448\u0438\u0440\u044F\u0435\u0442 \u0432\u044B\u0434\u0435\u043B\u0435\u043D\u0438\u0435. \u041A\u043E\u043F\u0438\u0440\u0443\u0439\u0442\u0435 \u0438 \u0432\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u044B \u043A\u0430\u043A TSV. \u0424\u043E\u0440\u043C\u0443\u043B\u044B \u043D\u0430\u0447\u0438\u043D\u0430\u044E\u0442\u0441\u044F \u0441 =.
\u0417\u0430\u043A\u0440\u0435\u043F\u0438\u0442\u044C \u043F\u043E \u0432\u044B\u0434\u0435\u043B\u0435\u043D\u0438\u044E
\u0421\u043D\u044F\u0442\u044C \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u0435\u043D\u0438\u0435 \u043E\u0431\u043B\u0430\u0441\u0442\u0435\u0439
\u041B\u0438\u0441\u0442 \u0441\u043F\u0440\u0430\u0432\u0430 \u043D\u0430\u043B\u0435\u0432\u043E
\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0441\u0435\u0442\u043A\u0443
\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0434\u0430\u0442 \u043A\u043D\u0438\u0433\u0438
\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u043A\u043D\u0438\u0433\u0438 \u0441 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435\u043C \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0430
\u042D\u0442\u0430 \u043A\u043D\u0438\u0433\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0438 \u0437\u0430 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u043C\u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u043E\u0433\u043E \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F. \u041C\u043E\u0436\u043D\u043E \u043F\u0440\u043E\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u0442\u044C \u044F\u0447\u0435\u0439\u043A\u0438 \u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0442\u043E\u0447\u043D\u0443\u044E \u043A\u043E\u043F\u0438\u044E \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0430.
\u041F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u043E: \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0438 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u043D\u0435\u043B\u044C\u0437\u044F \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0432 \u0446\u0435\u043B\u0435\u0432\u043E\u043C \u0444\u043E\u0440\u043C\u0430\u0442\u0435.
\u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 \u0432\u044B\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F
\u042D\u0442\u043E \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u0444\u043E\u0440\u043C\u0443\u043B\u0443 \u043D\u0435\u043B\u044C\u0437\u044F \u0432\u0432\u0435\u0441\u0442\u0438 \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C \u0440\u0435\u0436\u0438\u043C\u0435 \u0432\u0432\u043E\u0434\u0430.
\u0412\u0438\u0434
\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C
\u0424\u043E\u0440\u043C\u0430\u0442 \u044F\u0447\u0435\u0435\u043A
\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0432\u043D\u0438\u0437
\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0432\u043F\u0440\u0430\u0432\u043E
`);
var sheetsItalian = sheetsCatalog(`
Nuova cartella di lavoro XLSX
Cartella di lavoro Excel (.xlsx)
Modifica le celle, le formule e gli stili supportati. I file protetti o con dipendenze non supportate si aprono in sola lettura, conservando l\u2019originale.
Nuova cartella di lavoro Excel 97\u20132003
Cartella di lavoro Excel 97\u20132003 (.xls)
Cartella BIFF8: fino a 65.536 righe e 256 colonne. Formule, stili e dipendenze dell\u2019origine vengono verificati prima del salvataggio e della conversione.
Converti in copia XLSX
Converti in copia XLS
Griglia del foglio di calcolo
Valore o formula della cella
Indirizzo della cella o dell\u2019intervallo
Aggiungi foglio
Rinomina foglio
Elimina foglio
Sposta il foglio prima
Sposta il foglio dopo
Nome del foglio
Fogli, righe e colonne
Unisci celle
Separa celle
Cancella valori
Inserisci righe
Elimina righe
Inserisci colonne
Elimina colonne
Altezza riga (px)
Larghezza colonna (px)
Formato numero
Generale
Numero
Percentuale
Valuta
Data
Ora
Scientifico
Codice di formato personalizzato
Riempimento cella
Testo a capo
Bordi cella
Inserimento formule
Nomi inglesi \xB7 punto decimale
Nomi e separatori regionali
Ricalcola
Calcolo in corso\u2026
Calcolato
Non calcolato: formula non supportata
Risultato precedente: ricalcolo necessario
Errore di formula
Annulla calcolo
{count} celle numeriche \xB7 Somma {sum}
Selezione {address}
Fai clic o trascina per selezionare. Digita o premi F2 per modificare; Invio conferma, Esc annulla. Maiusc estende la selezione. Copia e incolla gli intervalli come TSV. Le formule iniziano con =.
Blocca alla selezione
Sblocca riquadri
Foglio da destra a sinistra
Mostra griglia
Sistema di date della cartella
Anteprima della cartella originale conservata
Questa cartella contiene dipendenze fuori dall\u2019ambito modificabile. Puoi esaminare le celle e salvare una copia esatta dell\u2019originale.
La conversione \xE8 bloccata perch\xE9 le dipendenze dell\u2019origine non possono essere rappresentate in modo sicuro nel formato di destinazione.
In attesa del calcolo
Questo valore o formula non pu\xF2 essere inserito nella modalit\xE0 selezionata.
Visualizza
Applica
Formato celle
Ricopia in basso
Ricopia a destra
`);

// packages/i18n/src/catalogs-b-common.ts
function baseCatalog(values) {
  const keys = Object.keys(english), lines = values.trim().split("\n");
  if (lines.length !== keys.length) throw Error("Base translation key count mismatch: " + lines.length + " / " + keys.length);
  return Object.fromEntries(keys.map((key, index) => [key, lines[index]]));
}

// packages/i18n/src/catalogs-b1-indic.ts
var pairs = `
\u092B\u093C\u093E\u0907\u0932 \u0916\u094B\u0932\u0947\u0902\xA6\u0E40\u0E1B\u0E34\u0E14\u0E44\u0E1F\u0E25\u0E4C
\u0928\u092F\u093E \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48
\u0939\u093E\u0932 \u0915\u0940 \u092B\u093C\u093E\u0907\u0932\u0947\u0902\xA6\u0E44\u0E1F\u0E25\u0E4C\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14
\u0938\u094D\u0925\u093E\u0928\u0940\u092F \u0915\u093E\u0930\u094D\u092F\u0938\u094D\u0925\u093E\u0928 \xB7 \u092A\u0939\u0932\u0947 \u0911\u092B\u093C\u0932\u093E\u0907\u0928\xA6\u0E1E\u0E37\u0E49\u0E19\u0E17\u0E35\u0E48\u0E17\u0E33\u0E07\u0E32\u0E19\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \xB7 \u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E2D\u0E2D\u0E1F\u0E44\u0E25\u0E19\u0E4C\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E25\u0E31\u0E01
\u0938\u0947\u091F\u093F\u0902\u0917\xA6\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32
\u0915\u093E\u0930\u094D\u092F\u0938\u094D\u0925\u093E\u0928\xA6\u0E1E\u0E37\u0E49\u0E19\u0E17\u0E35\u0E48\u0E17\u0E33\u0E07\u0E32\u0E19
\u092A\u0942\u0930\u094D\u0935\u0935\u0924 \u0915\u0930\u0947\u0902\xA6\u0E40\u0E25\u0E34\u0E01\u0E17\u0E33
\u092B\u093F\u0930 \u0938\u0947 \u0915\u0930\u0947\u0902\xA6\u0E17\u0E33\u0E0B\u0E49\u0E33
\u0907\u0938 \u0930\u0942\u092A \u092E\u0947\u0902 \u0938\u0939\u0947\u091C\u0947\u0902\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E40\u0E1B\u0E47\u0E19
\u0938\u0939\u0947\u091C\u0947\u0902\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01
\u0924\u0948\u092F\u093E\u0930\xA6\u0E1E\u0E23\u0E49\u0E2D\u0E21
\u0926\u093F\u0916\u093E\u0935\u091F\xA6\u0E25\u0E31\u0E01\u0E29\u0E13\u0E30\u0E17\u0E35\u0E48\u0E1B\u0E23\u0E32\u0E01\u0E0F
\u0938\u093F\u0938\u094D\u091F\u092E\xA6\u0E23\u0E30\u0E1A\u0E1A
\u0939\u0932\u094D\u0915\u093E\xA6\u0E2A\u0E27\u0E48\u0E32\u0E07
\u0917\u0939\u0930\u093E\xA6\u0E21\u0E37\u0E14
\u092D\u093E\u0937\u093E\xA6\u0E20\u0E32\u0E29\u0E32
\u0939\u093E\u0932 \u0915\u0940 \u092B\u093C\u093E\u0907\u0932\u094B\u0902 \u0915\u093E \u0907\u0924\u093F\u0939\u093E\u0938 \u092E\u093F\u091F\u093E\u090F\u0901\xA6\u0E25\u0E49\u0E32\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14
\u0938\u0947\u091F\u093F\u0902\u0917 \u0914\u0930 \u092A\u0941\u0928\u0930\u094D\u092A\u094D\u0930\u093E\u092A\u094D\u0924\u093F \u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F \u0907\u0938\u0940 \u0915\u0902\u092A\u094D\u092F\u0942\u091F\u0930 \u092A\u0930 \u0930\u0939\u0924\u0947 \u0939\u0948\u0902\u0964\xA6\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E30\u0E20\u0E32\u0E1E\u0E23\u0E27\u0E21\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E08\u0E30\u0E40\u0E01\u0E47\u0E1A\u0E44\u0E27\u0E49\u0E43\u0E19\u0E04\u0E2D\u0E21\u0E1E\u0E34\u0E27\u0E40\u0E15\u0E2D\u0E23\u0E4C\u0E19\u0E35\u0E49
\u0906\u092A\u0915\u0947 \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C\u094B\u0902 \u0915\u0947 \u0932\u093F\u090F \u090F\u0915 \u0938\u094D\u0925\u093E\u0928\u0964\xA6\u0E1E\u0E37\u0E49\u0E19\u0E17\u0E35\u0E48\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13
\u0938\u094D\u0935\u0924\u0902\u0924\u094D\u0930 \u0921\u0947\u0938\u094D\u0915\u091F\u0949\u092A \u0911\u092B\u093C\u093F\u0938 \u0938\u0941\u0907\u091F\u0964 M3 \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928 \u092E\u0947\u0902 \u0938\u0940\u092E\u093F\u0924 Writer \u0938\u0902\u092A\u093E\u0926\u0928, \u0938\u094D\u092A\u094D\u0930\u0947\u0921\u0936\u0940\u091F \u0914\u0930 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 Office \u092B\u093C\u093E\u0907\u0932 \u0938\u0939\u0947\u091C\u0928\u093E \u0909\u092A\u0932\u092C\u094D\u0927 \u0939\u0948\u0964\xA6\u0E0A\u0E38\u0E14\u0E2A\u0E33\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E40\u0E14\u0E2A\u0E01\u0E4C\u0E17\u0E47\u0E2D\u0E1B\u0E17\u0E35\u0E48\u0E1E\u0E31\u0E12\u0E19\u0E32\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E2D\u0E34\u0E2A\u0E23\u0E30 \u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07 M3 \u0E21\u0E35\u0E01\u0E32\u0E23\u0E41\u0E01\u0E49\u0E44\u0E02 Writer \u0E41\u0E1A\u0E1A\u0E08\u0E33\u0E01\u0E31\u0E14 \u0E2A\u0E40\u0E1B\u0E23\u0E14\u0E0A\u0E35\u0E15 \u0E41\u0E25\u0E30\u0E01\u0E32\u0E23\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E1F\u0E25\u0E4C Office \u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E01\u0E32\u0E23\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A
\u0938\u094D\u0925\u093E\u0928\u0940\u092F \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u092C\u0928\u093E\u090F\u0901\xA6\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07
\u0906\u0902\u0924\u0930\u093F\u0915 \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u092B\u093C\u093E\u0907\u0932 \xB7 .oex\xA6\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E20\u0E32\u0E22\u0E43\u0E19 \xB7 .oex
\u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C\xA6\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23
\u0938\u094D\u092A\u094D\u0930\u0947\u0921\u0936\u0940\u091F\xA6\u0E2A\u0E40\u0E1B\u0E23\u0E14\u0E0A\u0E35\u0E15
\u092A\u094D\u0930\u0938\u094D\u0924\u0941\u0924\u093F\xA6\u0E07\u0E32\u0E19\u0E19\u0E33\u0E40\u0E2A\u0E19\u0E2D
\u092A\u093E\u0920 \u092E\u0949\u0921\u0932 \u0914\u0930 \u092A\u0942\u0930\u094D\u0935\u0935\u0924 \u0932\u0947\u0928\u0926\u0947\u0928\xA6\u0E42\u0E21\u0E40\u0E14\u0E25\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E25\u0E30\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E41\u0E01\u0E49\u0E44\u0E02\u0E17\u0E35\u0E48\u0E40\u0E25\u0E34\u0E01\u0E17\u0E33\u0E44\u0E14\u0E49
\u0935\u093F\u0930\u0932 \u0938\u0947\u0932 \u0914\u0930 \u0938\u093E\u092E\u0942\u0939\u093F\u0915 \u0906\u0926\u0947\u0936\xA6\u0E40\u0E0B\u0E25\u0E25\u0E4C\u0E41\u0E1A\u0E1A\u0E40\u0E1A\u0E32\u0E1A\u0E32\u0E07\u0E41\u0E25\u0E30\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E0A\u0E38\u0E14
\u0926\u0943\u0936\u094D\u092F \u092E\u0949\u0921\u0932 \u0914\u0930 \u0928\u093F\u0930\u094D\u0926\u0947\u0936\u093E\u0902\u0915\xA6\u0E42\u0E21\u0E40\u0E14\u0E25\u0E09\u0E32\u0E01\u0E41\u0E25\u0E30\u0E1E\u0E34\u0E01\u0E31\u0E14
\u092B\u093C\u093E\u0907\u0932 \u0916\u094B\u0932\u0947\u0902 \u092F\u093E \u092F\u0939\u093E\u0901 \u091B\u094B\u0921\u093C\u0947\u0902\xA6\u0E40\u0E1B\u0E34\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E2B\u0E23\u0E37\u0E2D\u0E25\u0E32\u0E01\u0E21\u0E32\u0E27\u0E32\u0E07\u0E17\u0E35\u0E48\u0E19\u0E35\u0E48
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 \u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07 Office EX
\u092B\u093C\u093E\u0907\u0932 \u091A\u0941\u0928\u0947\u0902\xA6\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C
\u0938\u092E\u0930\u094D\u0925\u093F\u0924 DOC, DOCX, XLS \u0914\u0930 XLSX \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u0938\u0902\u092A\u093E\u0926\u093F\u0924 \u0914\u0930 \u0938\u0939\u0947\u091C\u0940 \u091C\u093E \u0938\u0915\u0924\u0940 \u0939\u0948\u0964 \u0905\u0928\u094D\u092F \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u0915\u0947\u0935\u0932 \u092A\u0922\u093C\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0916\u0941\u0932\u0924\u0940 \u0939\u0948 \u0914\u0930 \u0909\u0938\u0915\u0940 \u0939\u0942\u092C\u0939\u0942 \u092A\u094D\u0930\u0924\u093F \u0938\u0939\u0947\u091C\u0940 \u091C\u093E \u0938\u0915\u0924\u0940 \u0939\u0948\u0964 \u092A\u0942\u0930\u094D\u0923 \u0938\u0902\u0917\u0924\u0924\u093E \u092A\u0930 \u0915\u093E\u092E \u091C\u093E\u0930\u0940 \u0939\u0948\u0964\xA6\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32 DOC, DOCX, XLS \u0E41\u0E25\u0E30 XLSX \u0E17\u0E35\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E41\u0E01\u0E49\u0E44\u0E02\u0E41\u0E25\u0E30\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E14\u0E49 \u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32\u0E2D\u0E37\u0E48\u0E19\u0E40\u0E1B\u0E34\u0E14\u0E41\u0E1A\u0E1A\u0E2D\u0E48\u0E32\u0E19\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27\u0E41\u0E25\u0E30\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E40\u0E1B\u0E47\u0E19\u0E2A\u0E33\u0E40\u0E19\u0E32\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E21\u0E37\u0E2D\u0E19\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E17\u0E38\u0E01\u0E44\u0E1A\u0E15\u0E4C\u0E44\u0E14\u0E49 \u0E04\u0E27\u0E32\u0E21\u0E40\u0E02\u0E49\u0E32\u0E01\u0E31\u0E19\u0E44\u0E14\u0E49\u0E40\u0E15\u0E47\u0E21\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E31\u0E07\u0E2D\u0E22\u0E39\u0E48\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1E\u0E31\u0E12\u0E19\u0E32
\u092B\u093C\u093E\u0907\u0932 \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0915\u093E \u0906\u0927\u093E\u0930\xA6\u0E42\u0E04\u0E23\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E1F\u0E25\u0E4C
\u0915\u0902\u091F\u0947\u0928\u0930 \u091C\u0941\u0921\u093C\u093E \u0939\u0948\xA6\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E40\u0E19\u0E2D\u0E23\u0E4C\u0E41\u0E25\u0E49\u0E27
\u0906\u0927\u0941\u0928\u093F\u0915 \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E2A\u0E21\u0E31\u0E22\u0E43\u0E2B\u0E21\u0E48
\u092A\u0941\u0930\u093E\u0928\u0947 \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E40\u0E14\u0E34\u0E21
\u0938\u094D\u0925\u093E\u0928\u0940\u092F \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C\xA6\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07
\u0915\u094B\u0908 \u0939\u093E\u0932 \u0915\u0940 \u092B\u093C\u093E\u0907\u0932 \u0928\u0939\u0940\u0902\xA6\u0E44\u0E21\u0E48\u0E21\u0E35\u0E44\u0E1F\u0E25\u0E4C\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14
\u0936\u0940\u0930\u094D\u0937\u0915\u0939\u0940\u0928\xA6\u0E44\u0E21\u0E48\u0E21\u0E35\u0E0A\u0E37\u0E48\u0E2D
Office EX \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07 Office EX
\u0915\u0947\u0935\u0932 \u092A\u0922\u093C\u0947\u0902 \xB7 \u0938\u0902\u0930\u091A\u0928\u093E \u0915\u0940 \u091C\u093E\u0901\u091A\xA6\u0E2D\u0E48\u0E32\u0E19\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27 \xB7 \u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E42\u0E04\u0E23\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07
\u0905\u0938\u0939\u0947\u091C\u093E\xA6\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01
\u0938\u0939\u0947\u091C\u093E \u0917\u092F\u093E\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27
\u092B\u093C\u093E\u0907\u0932 \u0938\u0902\u0930\u091A\u0928\u093E \u091C\u093E\u0901\u091A\u0940 \u091C\u093E \u0930\u0939\u0940 \u0939\u0948\u2026\xA6\u0E01\u0E33\u0E25\u0E31\u0E07\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E42\u0E04\u0E23\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E44\u0E1F\u0E25\u0E4C\u2026
\u0930\u0926\u094D\u0926 \u0915\u0930\u0947\u0902\xA6\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01
\u092C\u0902\u0926 \u0915\u0930\u0947\u0902\xA6\u0E1B\u0E34\u0E14
\u0915\u093E\u0930\u094D\u092F \u0930\u0926\u094D\u0926 \u0915\u093F\u092F\u093E \u0917\u092F\u093E\xA6\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E01\u0E32\u0E23\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E41\u0E25\u0E49\u0E27
\u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F\xA6\u0E20\u0E32\u0E1E\u0E23\u0E27\u0E21
\u0938\u0902\u0936\u094B\u0927\u0928\xA6\u0E23\u0E38\u0E48\u0E19\u0E01\u0E32\u0E23\u0E41\u0E01\u0E49\u0E44\u0E02
\u0938\u092B\u0932\u0924\u093E\u092A\u0942\u0930\u094D\u0935\u0915 \u0938\u0939\u0947\u091C\u093E \u0917\u092F\u093E\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08
\u092F\u0939 \u0906\u0902\u0924\u0930\u093F\u0915 OEX \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0939\u0948, Microsoft Office \u092B\u093C\u093E\u0907\u0932 \u0928\u0939\u0940\u0902\u0964 Office \u092B\u093C\u093E\u0907\u0932 \u092C\u0928\u093E\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0938\u0902\u092C\u0902\u0927\u093F\u0924 \u0928\u090F \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u0915\u093E \u0935\u093F\u0915\u0932\u094D\u092A \u091A\u0941\u0928\u0947\u0902\u0964 \u092A\u0942\u0930\u094D\u0923 \u0938\u0902\u092A\u093E\u0926\u0928 \u0938\u0902\u0917\u0924\u0924\u093E \u092A\u0930 \u0915\u093E\u092E \u091C\u093E\u0930\u0940 \u0939\u0948\u0964\xA6\u0E19\u0E35\u0E48\u0E04\u0E37\u0E2D\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07 OEX \u0E20\u0E32\u0E22\u0E43\u0E19 \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E44\u0E1F\u0E25\u0E4C Microsoft Office \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E02\u0E2D\u0E07\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E44\u0E1F\u0E25\u0E4C Office \u0E04\u0E27\u0E32\u0E21\u0E40\u0E02\u0E49\u0E32\u0E01\u0E31\u0E19\u0E44\u0E14\u0E49\u0E14\u0E49\u0E32\u0E19\u0E01\u0E32\u0E23\u0E41\u0E01\u0E49\u0E44\u0E02\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1E\u0E31\u0E12\u0E19\u0E32
\u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0915\u093E \u092A\u093E\u0920\xA6\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07
\u0938\u0947\u0932 \u0932\u0947\u0928\u0926\u0947\u0928 \u0915\u093E \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928 (A1:C3)\xA6\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E41\u0E01\u0E49\u0E44\u0E02\u0E40\u0E0B\u0E25\u0E25\u0E4C (A1:C3)
\u092A\u094D\u0930\u0915\u093E\u0930\u092F\u0941\u0915\u094D\u0924 \u092E\u093E\u0928 \u0914\u0930 \u092E\u0942\u0932 \u0938\u0942\u0924\u094D\u0930 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0939\u0924\u0947 \u0939\u0948\u0902\u0964 \u0938\u092E\u0930\u094D\u0925\u093F\u0924 \u0938\u0942\u0924\u094D\u0930\u094B\u0902 \u0914\u0930 \u0917\u094D\u0930\u093F\u0921 \u0938\u0902\u092A\u093E\u0926\u0928 \u0915\u0947 \u0932\u093F\u090F \u0938\u094D\u092A\u094D\u0930\u0947\u0921\u0936\u0940\u091F \u0915\u093E\u0930\u094D\u092F\u0938\u094D\u0925\u093E\u0928 \u0916\u094B\u0932\u0947\u0902\u0964\xA6\u0E40\u0E01\u0E47\u0E1A\u0E0A\u0E19\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25 \u0E04\u0E48\u0E32 \u0E41\u0E25\u0E30\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E2A\u0E39\u0E15\u0E23\u0E44\u0E27\u0E49 \u0E40\u0E1B\u0E34\u0E14\u0E1E\u0E37\u0E49\u0E19\u0E17\u0E35\u0E48\u0E2A\u0E40\u0E1B\u0E23\u0E14\u0E0A\u0E35\u0E15\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E04\u0E33\u0E19\u0E27\u0E13\u0E2A\u0E39\u0E15\u0E23\u0E17\u0E35\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E41\u0E25\u0E30\u0E41\u0E01\u0E49\u0E44\u0E02\u0E15\u0E32\u0E23\u0E32\u0E07
\u0926\u0943\u0936\u094D\u092F \u0914\u0930 \u0938\u094D\u0925\u093F\u0924\u093F-\u091C\u093E\u0901\u091A \u0915\u093E \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928\xA6\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E09\u0E32\u0E01\u0E41\u0E25\u0E30\u0E01\u0E32\u0E23\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E15\u0E33\u0E41\u0E2B\u0E19\u0E48\u0E07\u0E04\u0E25\u0E34\u0E01
\u0906\u092F\u0924 \u091C\u094B\u0921\u093C\u0947\u0902\xA6\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E2A\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E35\u0E48\u0E22\u0E21\u0E1C\u0E37\u0E19\u0E1C\u0E49\u0E32
\u0928\u093F\u0930\u094D\u0926\u0947\u0936\u093E\u0902\u0915 \u091C\u093E\u0901\u091A\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0906\u0915\u0943\u0924\u093F \u092A\u0930 \u0915\u094D\u0932\u093F\u0915 \u0915\u0930\u0947\u0902\u0964 \u092A\u0942\u0930\u094D\u0923 \u0938\u0902\u092A\u093E\u0926\u0915 M4 \u092E\u0947\u0902 \u0906\u090F\u0917\u093E\u0964\xA6\u0E04\u0E25\u0E34\u0E01\u0E23\u0E39\u0E1B\u0E23\u0E48\u0E32\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E1E\u0E34\u0E01\u0E31\u0E14 \u0E15\u0E31\u0E27\u0E41\u0E01\u0E49\u0E44\u0E02\u0E40\u0E15\u0E47\u0E21\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E08\u0E30\u0E21\u0E32\u0E43\u0E19 M4
\u092A\u0948\u0915\u0947\u091C \u092D\u093E\u0917 / \u0938\u094D\u091F\u094D\u0930\u0940\u092E\xA6\u0E2A\u0E48\u0E27\u0E19\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E41\u0E1E\u0E47\u0E01\u0E40\u0E01\u0E08 / \u0E2A\u0E15\u0E23\u0E35\u0E21
\u092D\u093E\u0917\xA6\u0E2A\u0E48\u0E27\u0E19\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A
\u0906\u0915\u093E\u0930\xA6\u0E02\u0E19\u0E32\u0E14
SHA-256\xA6SHA-256
\u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0938\u0902\u0938\u094D\u0915\u0930\u0923\xA6\u0E23\u0E38\u0E48\u0E19\u0E02\u0E2D\u0E07\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E1F\u0E25\u0E4C
\u092A\u0939\u091A\u093E\u0928\u093E \u0917\u092F\u093E \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E1E\u0E1A
\u0939\u0942\u092C\u0939\u0942 \u092A\u094D\u0930\u0924\u093F \u0938\u0939\u0947\u091C\u0947\u0902\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E2A\u0E33\u0E40\u0E19\u0E32\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E21\u0E37\u0E2D\u0E19\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A
\u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u090F\u0921\u0947\u092A\u094D\u091F\u0930 \u0932\u0902\u092C\u093F\u0924 \u0939\u0948\xA6\u0E15\u0E31\u0E27\u0E41\u0E1B\u0E25\u0E07\u0E04\u0E27\u0E32\u0E21\u0E2B\u0E21\u0E32\u0E22\u0E02\u0E2D\u0E07\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21
\u092A\u0941\u0928\u0930\u094D\u092A\u094D\u0930\u093E\u092A\u094D\u0924 \u0915\u093F\u090F \u091C\u093E \u0938\u0915\u0928\u0947 \u0935\u093E\u0932\u0947 \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E17\u0E35\u0E48\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E44\u0E14\u0E49
\u092A\u094D\u0930\u0924\u093F \u092A\u0941\u0928\u0930\u094D\u092A\u094D\u0930\u093E\u092A\u094D\u0924 \u0915\u0930\u0947\u0902\xA6\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E40\u0E1B\u0E47\u0E19\u0E2A\u0E33\u0E40\u0E19\u0E32
\u091B\u094B\u0921\u093C \u0926\u0947\u0902\xA6\u0E25\u0E30\u0E17\u0E34\u0E49\u0E07
\u092A\u0941\u0928\u0930\u094D\u092A\u094D\u0930\u093E\u092A\u094D\u0924\u093F \u090F\u0915 \u0928\u0908 \u0905\u0938\u0939\u0947\u091C\u0940 \u092A\u094D\u0930\u0924\u093F \u092C\u0928\u093E\u0924\u0940 \u0939\u0948 \u0914\u0930 \u092E\u0942\u0932 \u092B\u093C\u093E\u0907\u0932 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0916\u0924\u0940 \u0939\u0948\u0964\xA6\u0E01\u0E32\u0E23\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E08\u0E30\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E33\u0E40\u0E19\u0E32\u0E43\u0E2B\u0E21\u0E48\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E30\u0E40\u0E01\u0E47\u0E1A\u0E44\u0E1F\u0E25\u0E4C\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E44\u0E27\u0E49
\u0915\u094D\u0937\u0924\u093F\u0917\u094D\u0930\u0938\u094D\u0924 \u092A\u0941\u0928\u0930\u094D\u092A\u094D\u0930\u093E\u092A\u094D\u0924\u093F \u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F \u0905\u0932\u0917 \u0915\u0930 \u0926\u093F\u090F \u0917\u090F; \u0909\u0928\u094D\u0939\u0947\u0902 \u0916\u094B\u0932\u093E \u0928\u0939\u0940\u0902 \u0917\u092F\u093E\u0964\xA6\u0E41\u0E22\u0E01\u0E20\u0E32\u0E1E\u0E23\u0E27\u0E21\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E17\u0E35\u0E48\u0E40\u0E2A\u0E35\u0E22\u0E2B\u0E32\u0E22\u0E44\u0E27\u0E49\u0E41\u0E25\u0E49\u0E27\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E42\u0E2B\u0E25\u0E14
\u0928\u090F \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0915\u0947 \u0930\u0942\u092A \u092E\u0947\u0902 \u092A\u0941\u0928\u0930\u094D\u092A\u094D\u0930\u093E\u092A\u094D\u0924\xA6\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E40\u0E1B\u0E47\u0E19\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E41\u0E25\u0E49\u0E27
\u0915\u093E\u0930\u094D\u092F \u091C\u093E\u0930\u0940 \u0939\u0948\xA6\u0E01\u0E33\u0E25\u0E31\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19
\u0938\u0902\u0917\u0924\u0924\u093E \u0930\u093F\u092A\u094B\u0930\u094D\u091F\xA6\u0E23\u0E32\u0E22\u0E07\u0E32\u0E19\u0E04\u0E27\u0E32\u0E21\u0E40\u0E02\u0E49\u0E32\u0E01\u0E31\u0E19\u0E44\u0E14\u0E49
\u0926\u093F\u0916\u093E\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0915\u094B\u0908 \u0915\u0902\u091F\u0947\u0928\u0930 \u092D\u093E\u0917 \u0928\u0939\u0940\u0902\u0964\xA6\u0E44\u0E21\u0E48\u0E21\u0E35\u0E2A\u0E48\u0E27\u0E19\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E40\u0E19\u0E2D\u0E23\u0E4C\u0E43\u0E2B\u0E49\u0E41\u0E2A\u0E14\u0E07
\u0916\u093E\u0932\u0940 \u0938\u094D\u0932\u093E\u0907\u0921\xA6\u0E2A\u0E44\u0E25\u0E14\u0E4C\u0E27\u0E48\u0E32\u0E07
\u0939\u093E\u0932 \u0915\u0940 \u092B\u093C\u093E\u0907\u0932\u094B\u0902 \u0915\u093E \u0907\u0924\u093F\u0939\u093E\u0938 \u092E\u093F\u091F\u093E\u092F\u093E \u0917\u092F\u093E\xA6\u0E25\u0E49\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E44\u0E1F\u0E25\u0E4C\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14\u0E41\u0E25\u0E49\u0E27
\u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u0915\u093E \u0936\u0940\u0930\u094D\u0937\u0915\xA6\u0E0A\u0E37\u0E48\u0E2D\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23
\u0905\u0927\u093F\u0915\u0924\u092E 32 \u091F\u0948\u092C \u0916\u094B\u0932\u0947 \u091C\u093E \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\xA6\u0E40\u0E1B\u0E34\u0E14\u0E44\u0E14\u0E49\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14 32 \u0E41\u0E17\u0E47\u0E1A
\u0938\u094D\u0935\u0924\u0902\u0924\u094D\u0930 \u0907\u0902\u091C\u0928 \xB7 \u0921\u0947\u0938\u094D\u0915\u091F\u0949\u092A \u0911\u092B\u093C\u093F\u0938\xA6\u0E40\u0E2D\u0E19\u0E08\u0E34\u0E19\u0E2D\u0E34\u0E2A\u0E23\u0E30 \xB7 \u0E0A\u0E38\u0E14\u0E2A\u0E33\u0E19\u0E31\u0E01\u0E07\u0E32\u0E19\u0E40\u0E14\u0E2A\u0E01\u0E4C\u0E17\u0E47\u0E2D\u0E1B
\u092B\u093C\u093E\u0907\u0932 \u0938\u0939\u0947\u091C\u0940 \u0917\u0908; \u092F\u0939 \u092B\u093C\u093E\u0907\u0932 \u0938\u093F\u0938\u094D\u091F\u092E \u0928\u093F\u0930\u094D\u0926\u0947\u0936\u093F\u0915\u093E \u0938\u093F\u0902\u0915 \u0915\u0940 \u0917\u093E\u0930\u0902\u091F\u0940 \u0928\u0939\u0940\u0902 \u0926\u0947\u0924\u093E\u0964\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E1F\u0E25\u0E4C\u0E41\u0E25\u0E49\u0E27 \u0E41\u0E15\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E44\u0E1F\u0E25\u0E4C\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E23\u0E31\u0E1A\u0E1B\u0E23\u0E30\u0E01\u0E31\u0E19\u0E01\u0E32\u0E23\u0E0B\u0E34\u0E07\u0E04\u0E4C\u0E44\u0E14\u0E40\u0E23\u0E01\u0E17\u0E2D\u0E23\u0E35
\u092B\u093C\u093E\u0907\u0932 \u0938\u0939\u0947\u091C\u0940 \u0917\u0908, \u0932\u0947\u0915\u093F\u0928 \u092A\u0941\u0928\u0930\u094D\u092A\u094D\u0930\u093E\u092A\u094D\u0924\u093F \u092F\u093E \u0939\u093E\u0932 \u0915\u0940 \u092B\u093C\u093E\u0907\u0932\u094B\u0902 \u0915\u093E \u0930\u093F\u0915\u0949\u0930\u094D\u0921 \u0905\u0926\u094D\u092F\u0924\u0928 \u0928\u0939\u0940\u0902 \u0939\u0941\u0906\u0964\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E1F\u0E25\u0E4C\u0E41\u0E25\u0E49\u0E27 \u0E41\u0E15\u0E48\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E1B\u0E23\u0E31\u0E1A\u0E1B\u0E23\u0E38\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14\u0E44\u0E14\u0E49
Office EX \u092E\u0941\u0916\u092A\u0943\u0937\u094D\u0920\xA6\u0E2B\u0E19\u0E49\u0E32\u0E41\u0E23\u0E01 Office EX
\u092E\u0941\u0916\u094D\u092F \u0928\u0947\u0935\u093F\u0917\u0947\u0936\u0928\xA6\u0E01\u0E32\u0E23\u0E19\u0E33\u0E17\u0E32\u0E07\u0E2B\u0E25\u0E31\u0E01
\u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C\xA6\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23
\u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u0915\u0947 \u0915\u093E\u0930\u094D\u092F\xA6\u0E01\u0E32\u0E23\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E01\u0E31\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23
M3 \xB7 \u0935\u093F\u0915\u093E\u0938 \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928\xA6M3 \xB7 \u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1E\u0E31\u0E12\u0E19\u0E32
OFFICE EX / \u0906\u092A\u0915\u093E \u0938\u094D\u0925\u093E\u0928\u0940\u092F \u0915\u093E\u0930\u094D\u092F\u0938\u094D\u0925\u093E\u0928\xA6OFFICE EX / \u0E1E\u0E37\u0E49\u0E19\u0E17\u0E35\u0E48\u0E17\u0E33\u0E07\u0E32\u0E19\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13
\u0915\u094D\u0937\u0947\u0924\u094D\u0930\u0940\u092F \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E15\u0E32\u0E21\u0E20\u0E39\u0E21\u0E34\u0E20\u0E32\u0E04
\u0928\u090F \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u0915\u0940 \u092D\u093E\u0937\u093E (\u0935\u0930\u0940\u092F\u0924\u093E)\xA6\u0E20\u0E32\u0E29\u0E32\u0E02\u0E2D\u0E07\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E43\u0E2B\u0E21\u0E48 (\u0E04\u0E48\u0E32\u0E17\u0E35\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23)
\u0928\u090F Writer \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u0907\u0938 \u092A\u093E\u0920 \u092D\u093E\u0937\u093E \u0915\u093E \u0909\u092A\u092F\u094B\u0917 \u0915\u0930\u0924\u0947 \u0939\u0948\u0902\u0964 \u092E\u094C\u091C\u0942\u0926\u093E \u092B\u093C\u093E\u0907\u0932\u0947\u0902 \u0928\u0939\u0940\u0902 \u092C\u0926\u0932\u0924\u0940\u0902; \u0905\u0928\u094D\u092F \u0938\u0902\u092A\u093E\u0926\u0915 \u0907\u0938\u0947 \u092C\u093E\u0926 \u092E\u0947\u0902 \u0905\u092A\u0928\u093E\u090F\u0901\u0917\u0947\u0964\xA6\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23 Writer \u0E43\u0E2B\u0E21\u0E48\u0E43\u0E0A\u0E49\u0E20\u0E32\u0E29\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E19\u0E35\u0E49 \u0E44\u0E1F\u0E25\u0E4C\u0E40\u0E14\u0E34\u0E21\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E1B\u0E25\u0E07 \u0E15\u0E31\u0E27\u0E41\u0E01\u0E49\u0E44\u0E02\u0E2D\u0E37\u0E48\u0E19\u0E08\u0E30\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E43\u0E19\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07
\u0915\u094D\u0937\u0947\u0924\u094D\u0930\u0940\u092F \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0915\u093E \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928\xA6\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E15\u0E32\u0E21\u0E20\u0E39\u0E21\u0E34\u0E20\u0E32\u0E04
\u0907\u0924\u093F\u0939\u093E\u0938\xA6\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34
\u0915\u0948\u0928\u0935\u0938\xA6\u0E1C\u0E37\u0E19\u0E07\u0E32\u0E19
{count} \u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F\u092F\u093E\u0901; \u092A\u0939\u0932\u0940 500 \u0926\u093F\u0916\u093E\u0908 \u0917\u0908 \u0939\u0948\u0902\u0964\xA6\u0E21\u0E35 {count} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23 \u0E41\u0E2A\u0E14\u0E07 500 \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E41\u0E23\u0E01
\u092B\u093C\u093E\u0907\u0932\xA6\u0E44\u0E1F\u0E25\u0E4C
\u0938\u0902\u092A\u093E\u0926\u0928\xA6\u0E41\u0E01\u0E49\u0E44\u0E02
\u0926\u0943\u0936\u094D\u092F\xA6\u0E21\u0E38\u0E21\u0E21\u0E2D\u0E07
\u0928\u092F\u093E \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E43\u0E2B\u0E21\u0E48
\u0928\u092F\u093E \u0938\u094D\u092A\u094D\u0930\u0947\u0921\u0936\u0940\u091F \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E2A\u0E40\u0E1B\u0E23\u0E14\u0E0A\u0E35\u0E15\u0E43\u0E2B\u0E21\u0E48
\u0928\u092F\u093E \u092A\u094D\u0930\u0938\u094D\u0924\u0941\u0924\u093F \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E07\u0E32\u0E19\u0E19\u0E33\u0E40\u0E2A\u0E19\u0E2D\u0E43\u0E2B\u0E21\u0E48
\u0916\u094B\u0932\u0947\u0902\u2026\xA6\u0E40\u0E1B\u0E34\u0E14\u2026
\u0907\u0938 \u0930\u0942\u092A \u092E\u0947\u0902 \u0938\u0939\u0947\u091C\u0947\u0902\u2026\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E40\u0E1B\u0E47\u0E19\u2026
\u091F\u0948\u092C \u092C\u0902\u0926 \u0915\u0930\u0947\u0902\xA6\u0E1B\u0E34\u0E14\u0E41\u0E17\u0E47\u0E1A
\u0915\u093E\u091F\u0947\u0902\xA6\u0E15\u0E31\u0E14
\u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902\xA6\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01
\u091A\u093F\u092A\u0915\u093E\u090F\u0901\xA6\u0E27\u0E32\u0E07
\u0938\u092D\u0940 \u091A\u0941\u0928\u0947\u0902\xA6\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14
\u092A\u0942\u0930\u094D\u0923 \u0938\u094D\u0915\u094D\u0930\u0940\u0928 \u091A\u093E\u0932\u0942/\u092C\u0902\u0926 \u0915\u0930\u0947\u0902\xA6\u0E2A\u0E25\u0E31\u0E1A\u0E40\u0E15\u0E47\u0E21\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E2D
\u091C\u093C\u0942\u092E \u0930\u0940\u0938\u0947\u091F \u0915\u0930\u0947\u0902\xA6\u0E23\u0E35\u0E40\u0E0B\u0E47\u0E15\u0E01\u0E32\u0E23\u0E22\u0E48\u0E2D\u0E02\u0E22\u0E32\u0E22
\u092C\u0921\u093C\u093E \u0915\u0930\u0947\u0902\xA6\u0E02\u0E22\u0E32\u0E22\u0E40\u0E02\u0E49\u0E32
\u091B\u094B\u091F\u093E \u0915\u0930\u0947\u0902\xA6\u0E22\u0E48\u0E2D\u0E2D\u0E2D\u0E01
Office \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C / Office EX \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23 Office / \u0E41\u0E1A\u0E1A\u0E23\u0E48\u0E32\u0E07 Office EX
\u0938\u092D\u0940 \u092B\u093C\u093E\u0907\u0932\u0947\u0902\xA6\u0E44\u0E1F\u0E25\u0E4C\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14
\u092E\u0942\u0932 \u092B\u093C\u093E\u0907\u0932 \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E1F\u0E25\u0E4C\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A
\u092E\u094C\u091C\u0942\u0926\u093E \u0932\u0915\u094D\u0937\u094D\u092F \u092B\u093C\u093E\u0907\u0932 \u092C\u0926\u0932\u0947\u0902?\xA6\u0E41\u0E17\u0E19\u0E17\u0E35\u0E48\u0E44\u0E1F\u0E25\u0E4C\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E21\u0E35\u0E2D\u0E22\u0E39\u0E48\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48
\u092C\u0926\u0932\u0947\u0902\xA6\u0E41\u0E17\u0E19\u0E17\u0E35\u0E48
\u092C\u0902\u0926 \u0915\u0930\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u092A\u0930\u093F\u0935\u0930\u094D\u0924\u0928 \u0938\u0939\u0947\u091C\u0947\u0902?\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E01\u0E32\u0E23\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E1B\u0E25\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E1B\u0E34\u0E14\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48
\u092A\u0930\u093F\u0935\u0930\u094D\u0924\u0928 \u091B\u094B\u0921\u093C \u0926\u0947\u0902\xA6\u0E25\u0E30\u0E17\u0E34\u0E49\u0E07\u0E01\u0E32\u0E23\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E1B\u0E25\u0E07
\u092B\u093C\u093E\u0907\u0932 \u0928\u0939\u0940\u0902 \u0916\u0941\u0932 \u0938\u0915\u0940\xA6\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E1B\u0E34\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E14\u0E49
\u0935\u093F\u0902\u0921\u094B \u0928\u0939\u0940\u0902 \u0916\u0941\u0932 \u0938\u0915\u0940\xA6\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07\u0E44\u0E14\u0E49
\u092D\u093E\u0937\u093E \u092C\u0926\u0932\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0935\u0930\u094D\u0924\u092E\u093E\u0928 \u0907\u0928\u092A\u0941\u091F \u092A\u0942\u0930\u093E \u0915\u0930\u0947\u0902\u0964\xA6\u0E1B\u0E49\u0E2D\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E43\u0E2B\u0E49\u0E40\u0E2A\u0E23\u0E47\u0E08\u0E01\u0E48\u0E2D\u0E19\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E20\u0E32\u0E29\u0E32
\u090F\u0915 \u092C\u093E\u0930 \u092E\u0947\u0902 \u090F\u0915 \u091B\u094B\u0921\u093C\u0940 \u0917\u0908 \u092B\u093C\u093E\u0907\u0932 \u0916\u094B\u0932\u0947\u0902\u0964\xA6\u0E40\u0E1B\u0E34\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E17\u0E35\u0E48\u0E25\u0E32\u0E01\u0E21\u0E32\u0E27\u0E32\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E25\u0E30\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E44\u0E1F\u0E25\u0E4C
\u0905\u092E\u093E\u0928\u094D\u092F \u092B\u093C\u093E\u0907\u0932 \u092F\u093E \u0905\u0928\u0941\u0930\u094B\u0927\u0964\xA6\u0E44\u0E1F\u0E25\u0E4C\u0E2B\u0E23\u0E37\u0E2D\u0E04\u0E33\u0E02\u0E2D\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07
\u092F\u0939 \u0938\u0941\u0935\u093F\u0927\u093E \u092F\u093E \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0905\u092D\u0940 \u0938\u092E\u0930\u094D\u0925\u093F\u0924 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964\xA6\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E04\u0E38\u0E13\u0E2A\u0E21\u0E1A\u0E31\u0E15\u0E34\u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E19\u0E35\u0E49
\u0938\u0941\u0930\u0915\u094D\u0937\u093E \u0915\u0947 \u0932\u093F\u090F \u092F\u0939 \u0915\u093E\u0930\u094D\u092F \u0930\u094B\u0915\u093E \u0917\u092F\u093E\u0964\xA6\u0E23\u0E30\u0E07\u0E31\u0E1A\u0E01\u0E32\u0E23\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E1B\u0E25\u0E2D\u0E14\u0E20\u0E31\u0E22
\u092F\u0939 \u0915\u093E\u0930\u094D\u092F \u0938\u0902\u0938\u093E\u0927\u0928 \u0938\u0940\u092E\u093E \u0938\u0947 \u092C\u093E\u0939\u0930 \u0939\u0948\u0964\xA6\u0E01\u0E32\u0E23\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E40\u0E01\u0E34\u0E19\u0E02\u0E35\u0E14\u0E08\u0E33\u0E01\u0E31\u0E14\u0E17\u0E23\u0E31\u0E1E\u0E22\u0E32\u0E01\u0E23
\u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u092F\u093E \u0932\u0915\u094D\u0937\u094D\u092F \u092C\u0926\u0932 \u0917\u092F\u093E \u0939\u0948\u0964\xA6\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E2B\u0E23\u0E37\u0E2D\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27
\u092B\u093C\u093E\u0907\u0932 \u0938\u0902\u092C\u0902\u0927\u0940 \u0915\u093E\u0930\u094D\u092F \u0935\u093F\u092B\u0932 \u0939\u0941\u0906\u0964\xA6\u0E01\u0E32\u0E23\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E01\u0E31\u0E1A\u0E44\u0E1F\u0E25\u0E4C\u0E25\u0E49\u0E21\u0E40\u0E2B\u0E25\u0E27
\u0906\u0902\u0924\u0930\u093F\u0915 \u0924\u094D\u0930\u0941\u091F\u093F \u0939\u0941\u0908\u0964\xA6\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E20\u0E32\u0E22\u0E43\u0E19
\u090F\u0915 \u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0938\u0902\u0917\u0924\u0924\u093E \u0928\u093F\u0926\u093E\u0928 \u092E\u093F\u0932\u093E\u0964\xA6\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E27\u0E34\u0E19\u0E34\u0E08\u0E09\u0E31\u0E22\u0E04\u0E27\u0E32\u0E21\u0E40\u0E02\u0E49\u0E32\u0E01\u0E31\u0E19\u0E44\u0E14\u0E49\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01
\u0915\u0947\u0935\u0932 \u0915\u0902\u091F\u0947\u0928\u0930 \u0915\u0940 \u091C\u093E\u0901\u091A \u0939\u0941\u0908 \u0939\u0948\u0964 \u0938\u0902\u092A\u093E\u0926\u0928 \u092F\u094B\u0917\u094D\u092F \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u0906\u092F\u093E\u0924 \u0928\u0939\u0940\u0902 \u0939\u0941\u0908 \u0939\u0948\u0964\xA6\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E40\u0E19\u0E2D\u0E23\u0E4C \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E04\u0E27\u0E32\u0E21\u0E2B\u0E21\u0E32\u0E22\u0E02\u0E2D\u0E07\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E41\u0E01\u0E49\u0E44\u0E02
\u092E\u0948\u0915\u094D\u0930\u094B \u0938\u0902\u092C\u0902\u0927\u0940 \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u092E\u093F\u0932\u0940\u0964 \u092E\u0948\u0915\u094D\u0930\u094B \u0928\u0939\u0940\u0902 \u091A\u0932\u0924\u0947; \u0909\u0928\u0915\u0947 \u092C\u093E\u0907\u091F \u0915\u0947\u0935\u0932 \u0939\u0942\u092C\u0939\u0942 \u092A\u094D\u0930\u0924\u093F\u092F\u094B\u0902 \u092E\u0947\u0902 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0939\u0924\u0947 \u0939\u0948\u0902\u0964\xA6\u0E15\u0E23\u0E27\u0E08\u0E1E\u0E1A\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32\u0E17\u0E35\u0E48\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E02\u0E49\u0E2D\u0E07\u0E01\u0E31\u0E1A\u0E41\u0E21\u0E42\u0E04\u0E23 \u0E44\u0E21\u0E48\u0E21\u0E35\u0E01\u0E32\u0E23\u0E40\u0E23\u0E35\u0E22\u0E01\u0E43\u0E0A\u0E49\u0E41\u0E21\u0E42\u0E04\u0E23 \u0E41\u0E25\u0E30\u0E40\u0E01\u0E47\u0E1A\u0E44\u0E1A\u0E15\u0E4C\u0E44\u0E27\u0E49\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E43\u0E19\u0E2A\u0E33\u0E40\u0E19\u0E32\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E21\u0E37\u0E2D\u0E19\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A
\u0939\u0938\u094D\u0924\u093E\u0915\u094D\u0937\u0930\u093F\u0924 \u092B\u093C\u093E\u0907\u0932: \u0915\u0947\u0935\u0932 \u091C\u093E\u0901\u091A\u0964 \u0939\u0938\u094D\u0924\u093E\u0915\u094D\u0937\u0930 \u0915\u0940 \u0935\u0948\u0927\u0924\u093E \u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964\xA6\u0E44\u0E1F\u0E25\u0E4C\u0E21\u0E35\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19: \u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E14\u0E49\u0E40\u0E17\u0E48\u0E32\u0E19\u0E31\u0E49\u0E19 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E04\u0E27\u0E32\u0E21\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E2D\u0E07\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19
\u092C\u093E\u0939\u0930\u0940 \u0938\u0902\u092C\u0902\u0927 \u0926\u0930\u094D\u091C \u0939\u0948\u0902; \u0915\u094B\u0908 \u092C\u093E\u0939\u0930\u0940 \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u0932\u094B\u0921 \u0928\u0939\u0940\u0902 \u0939\u094B\u0924\u0940\u0964\xA6\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E31\u0E21\u0E1E\u0E31\u0E19\u0E18\u0E4C\u0E20\u0E32\u0E22\u0E19\u0E2D\u0E01\u0E44\u0E27\u0E49\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E42\u0E2B\u0E25\u0E14\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32\u0E20\u0E32\u0E22\u0E19\u0E2D\u0E01
Strict OOXML \u092A\u0939\u091A\u093E\u0928\u093E \u0917\u092F\u093E; \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u092A\u0922\u093C\u0928\u093E \u0914\u0930 \u0932\u093F\u0916\u0928\u093E \u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964\xA6\u0E15\u0E23\u0E27\u0E08\u0E1E\u0E1A Strict OOXML \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E32\u0E23\u0E2D\u0E48\u0E32\u0E19\u0E41\u0E25\u0E30\u0E40\u0E02\u0E35\u0E22\u0E19\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32
\u090F\u0928\u094D\u0915\u094D\u0930\u093F\u092A\u094D\u091F\u0947\u0921 \u0915\u0902\u091F\u0947\u0928\u0930 \u092A\u0939\u091A\u093E\u0928\u093E \u0917\u092F\u093E\u0964 \u0921\u093F\u0915\u094D\u0930\u093F\u092A\u094D\u0936\u0928 \u0914\u0930 \u0938\u0902\u092A\u093E\u0926\u0928 \u0909\u092A\u0932\u092C\u094D\u0927 \u0928\u0939\u0940\u0902 \u0939\u0948\u0902\u0964\xA6\u0E15\u0E23\u0E27\u0E08\u0E1E\u0E1A\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E40\u0E19\u0E2D\u0E23\u0E4C\u0E17\u0E35\u0E48\u0E40\u0E02\u0E49\u0E32\u0E23\u0E2B\u0E31\u0E2A \u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E16\u0E2D\u0E14\u0E23\u0E2B\u0E31\u0E2A\u0E2B\u0E23\u0E37\u0E2D\u0E41\u0E01\u0E49\u0E44\u0E02\u0E44\u0E14\u0E49
\u090F\u0915\u094D\u0938\u091F\u0947\u0902\u0936\u0928 \u092A\u0939\u091A\u093E\u0928\u0940 \u0917\u0908 \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u0938\u0947 \u0905\u0932\u0917 \u0939\u0948\u0964\xA6\u0E19\u0E32\u0E21\u0E2A\u0E01\u0E38\u0E25\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E1E\u0E1A
\u092A\u093E\u0920 \u0938\u094D\u0935\u0930\u0942\u092A\u0923\xA6\u0E01\u0E32\u0E23\u0E08\u0E31\u0E14\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21
\u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u0938\u0902\u092A\u093E\u0926\u093F\u0924 \u0915\u0930\u0947\u0902 \u0914\u0930 \u0938\u094D\u0935\u0930\u0942\u092A\u0923 \u0915\u0947 \u0932\u093F\u090F \u092A\u093E\u0920 \u091A\u0941\u0928\u0947\u0902\u0964 Enter \u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u092C\u093E\u0901\u091F\u0924\u093E \u0939\u0948; Shift+Enter \u0928\u0908 \u092A\u0902\u0915\u094D\u0924\u093F \u091C\u094B\u0921\u093C\u0924\u093E \u0939\u0948\u0964\xA6\u0E41\u0E01\u0E49\u0E44\u0E02\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32\u0E41\u0E25\u0E30\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E08\u0E31\u0E14\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A Enter \u0E41\u0E22\u0E01\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32 \u0E2A\u0E48\u0E27\u0E19 Shift+Enter \u0E02\u0E36\u0E49\u0E19\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E43\u0E2B\u0E21\u0E48
\u092A\u0943\u0937\u094D\u0920 \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928\xA6\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E2B\u0E19\u0E49\u0E32
\u0905\u0928\u0941\u092E\u093E\u0928\u093F\u0924 \u092A\u0943\u0937\u094D\u0920 \u0935\u093F\u0928\u094D\u092F\u093E\u0938\u0964 \u092A\u093E\u0920 \u0916\u094B\u091C\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u092A\u0943\u0937\u094D\u0920 \u092A\u0930 \u0915\u094D\u0932\u093F\u0915 \u0915\u0930\u0947\u0902\u0964 \u092E\u0941\u0926\u094D\u0930\u0923 \u0915\u0940 \u0938\u092E\u093E\u0928\u0924\u093E \u0905\u092D\u0940 \u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964\xA6\u0E40\u0E04\u0E49\u0E32\u0E42\u0E04\u0E23\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E42\u0E14\u0E22\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13 \u0E04\u0E25\u0E34\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E23\u0E30\u0E1A\u0E38\u0E15\u0E33\u0E41\u0E2B\u0E19\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E04\u0E27\u0E32\u0E21\u0E40\u0E17\u0E35\u0E48\u0E22\u0E07\u0E15\u0E23\u0E07\u0E43\u0E19\u0E01\u0E32\u0E23\u0E1E\u0E34\u0E21\u0E1E\u0E4C
\u092A\u093F\u091B\u0932\u093E \u092A\u0943\u0937\u094D\u0920\xA6\u0E2B\u0E19\u0E49\u0E32\u0E01\u0E48\u0E2D\u0E19\u0E2B\u0E19\u0E49\u0E32
\u0905\u0917\u0932\u093E \u092A\u0943\u0937\u094D\u0920\xA6\u0E2B\u0E19\u0E49\u0E32\u0E16\u0E31\u0E14\u0E44\u0E1B
\u092A\u0943\u0937\u094D\u0920 {current} / {total}\xA6\u0E2B\u0E19\u0E49\u0E32 {current} / {total}
\u0915\u0941\u091B \u0905\u0915\u094D\u0937\u0930-\u0935\u093F\u0928\u094D\u092F\u093E\u0938 \u092F\u093E \u092A\u0943\u0937\u094D\u0920-\u0935\u093F\u0928\u094D\u092F\u093E\u0938 \u0938\u0941\u0935\u093F\u0927\u093E\u090F\u0901 \u0905\u0928\u0941\u092E\u093E\u0928\u093F\u0924 \u0939\u0948\u0902\u0964\xA6\u0E01\u0E32\u0E23\u0E08\u0E31\u0E14\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E04\u0E49\u0E32\u0E42\u0E04\u0E23\u0E07\u0E1A\u0E32\u0E07\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E04\u0E48\u0E32\u0E1B\u0E23\u0E30\u0E21\u0E32\u0E13
\u0907\u0938 \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u092F\u093E \u0935\u093F\u0928\u094D\u092F\u093E\u0938 \u0938\u0940\u092E\u093E \u0915\u093E \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928 \u0909\u092A\u0932\u092C\u094D\u0927 \u0928\u0939\u0940\u0902\u0964 \u092E\u0942\u0932 \u0938\u093E\u092E\u0917\u094D\u0930\u0940 \u0928\u0939\u0940\u0902 \u092C\u0926\u0932\u0940 \u0939\u0948\u0964\xA6\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E41\u0E2A\u0E14\u0E07\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E04\u0E49\u0E32\u0E42\u0E04\u0E23\u0E07\u0E19\u0E35\u0E49\u0E44\u0E14\u0E49 \u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E1B\u0E25\u0E07
\u092E\u094B\u091F\u093E\xA6\u0E15\u0E31\u0E27\u0E2B\u0E19\u0E32
\u0924\u093F\u0930\u091B\u093E\xA6\u0E15\u0E31\u0E27\u0E40\u0E2D\u0E35\u0E22\u0E07
\u0930\u0947\u0916\u093E\u0902\u0915\u093F\u0924\xA6\u0E02\u0E35\u0E14\u0E40\u0E2A\u0E49\u0E19\u0E43\u0E15\u0E49
\u092C\u093E\u090F\u0901 \u0938\u0902\u0930\u0947\u0916\u093F\u0924 \u0915\u0930\u0947\u0902\xA6\u0E08\u0E31\u0E14\u0E0A\u0E34\u0E14\u0E0B\u0E49\u0E32\u0E22
\u0915\u0947\u0902\u0926\u094D\u0930\xA6\u0E08\u0E31\u0E14\u0E01\u0E36\u0E48\u0E07\u0E01\u0E25\u0E32\u0E07
\u0926\u093E\u090F\u0901 \u0938\u0902\u0930\u0947\u0916\u093F\u0924 \u0915\u0930\u0947\u0902\xA6\u0E08\u0E31\u0E14\u0E0A\u0E34\u0E14\u0E02\u0E27\u0E32
\u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u092C\u093E\u0901\u091F\u0947\u0902\xA6\u0E41\u0E22\u0E01\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32
\u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u0915\u0947 \u092C\u093E\u0926 \u092A\u0943\u0937\u094D\u0920 \u0935\u093F\u0930\u093E\u092E\xA6\u0E15\u0E31\u0E27\u0E41\u0E1A\u0E48\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E2B\u0E25\u0E31\u0E07\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32
\u0907\u0938 \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928 \u092E\u0947\u0902 \u092F\u0939 \u0916\u0902\u0921 \u0938\u0902\u092A\u093E\u0926\u093F\u0924 \u0928\u0939\u0940\u0902 \u0915\u093F\u092F\u093E \u091C\u093E \u0938\u0915\u0924\u093E\u0964\xA6\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E41\u0E01\u0E49\u0E44\u0E02\u0E1A\u0E25\u0E47\u0E2D\u0E01\u0E19\u0E35\u0E49\u0E43\u0E19\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E44\u0E14\u0E49
\u0928\u092F\u093E DOCX \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C\xA6\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23 DOCX \u0E43\u0E2B\u0E21\u0E48
DOCX \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C\xA6\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23 DOCX
\u0938\u0940\u092E\u093F\u0924 DOCX \u0938\u092E\u0930\u094D\u0925\u0928: \u092A\u093E\u0920, \u092A\u094D\u0930\u0924\u094D\u092F\u0915\u094D\u0937 \u0938\u094D\u0935\u0930\u0942\u092A\u0923, \u0938\u092E\u0930\u094D\u0925\u093F\u0924 \u0928\u093E\u092E\u093F\u0924 \u0936\u0948\u0932\u093F\u092F\u093E\u0901, \u0938\u094D\u0925\u093F\u0930 \u0906\u092F\u0924\u093E\u0915\u093E\u0930 \u0924\u093E\u0932\u093F\u0915\u093E\u090F\u0901, \u092A\u0902\u0915\u094D\u0924\u093F \u092E\u0947\u0902 \u090F\u092E\u094D\u092C\u0947\u0921 \u0915\u093F\u090F \u0917\u090F PNG/JPEG \u091A\u093F\u0924\u094D\u0930 \u0914\u0930 \u092E\u0942\u0932 \u0935\u093F\u0928\u094D\u092F\u093E\u0938\u0964 \u091C\u091F\u093F\u0932 \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u0915\u0947\u0935\u0932 \u092A\u0922\u093C\u0947 \u091C\u093E \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\u0964\xA6\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A DOCX \u0E41\u0E1A\u0E1A\u0E08\u0E33\u0E01\u0E31\u0E14: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E42\u0E14\u0E22\u0E15\u0E23\u0E07 \u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E17\u0E35\u0E48\u0E15\u0E31\u0E49\u0E07\u0E0A\u0E37\u0E48\u0E2D\u0E17\u0E35\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A \u0E15\u0E32\u0E23\u0E32\u0E07\u0E2A\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E35\u0E48\u0E22\u0E21\u0E04\u0E07\u0E17\u0E35\u0E48 \u0E23\u0E39\u0E1B PNG/JPEG \u0E17\u0E35\u0E48\u0E1D\u0E31\u0E07\u0E43\u0E19\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14 \u0E41\u0E25\u0E30\u0E40\u0E04\u0E49\u0E32\u0E42\u0E04\u0E23\u0E07\u0E1E\u0E37\u0E49\u0E19\u0E10\u0E32\u0E19 \u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E0B\u0E31\u0E1A\u0E0B\u0E49\u0E2D\u0E19\u0E40\u0E1B\u0E34\u0E14\u0E41\u0E1A\u0E1A\u0E2D\u0E48\u0E32\u0E19\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27
\u092B\u093C\u0949\u0928\u094D\u091F\xA6\u0E41\u0E1A\u0E1A\u0E2D\u0E31\u0E01\u0E29\u0E23
\u0906\u0915\u093E\u0930 (pt)\xA6\u0E02\u0E19\u0E32\u0E14 (pt)
\u092A\u093E\u0920 \u0915\u093E \u0930\u0902\u0917\xA6\u0E2A\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21
\u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u0936\u0948\u0932\u0940\xA6\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32
\u0905\u0915\u094D\u0937\u0930 \u0936\u0948\u0932\u0940\xA6\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E2D\u0E31\u0E01\u0E02\u0E23\u0E30
\u0936\u0948\u0932\u0940 \u091A\u0941\u0928\u0947\u0902\xA6\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E2A\u0E44\u0E15\u0E25\u0E4C
\u0924\u093E\u0932\u093F\u0915\u093E\xA6\u0E15\u0E32\u0E23\u0E32\u0E07
\u092A\u0902\u0915\u094D\u0924\u093F\u092F\u093E\u0901\xA6\u0E41\u0E16\u0E27
\u0938\u094D\u0924\u0902\u092D\xA6\u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C
\u0924\u093E\u0932\u093F\u0915\u093E \u0921\u093E\u0932\u0947\u0902\xA6\u0E41\u0E17\u0E23\u0E01\u0E15\u0E32\u0E23\u0E32\u0E07
\u0928\u0940\u091A\u0947 \u092A\u0902\u0915\u094D\u0924\u093F \u091C\u094B\u0921\u093C\u0947\u0902\xA6\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E41\u0E16\u0E27\u0E14\u0E49\u0E32\u0E19\u0E25\u0E48\u0E32\u0E07
\u092A\u0902\u0915\u094D\u0924\u093F \u0939\u091F\u093E\u090F\u0901\xA6\u0E25\u0E1A\u0E41\u0E16\u0E27
\u0926\u093E\u0908\u0902 \u0913\u0930 \u0938\u094D\u0924\u0902\u092D \u091C\u094B\u0921\u093C\u0947\u0902\xA6\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C\u0E14\u0E49\u0E32\u0E19\u0E02\u0E27\u0E32
\u0938\u094D\u0924\u0902\u092D \u0939\u091F\u093E\u090F\u0901\xA6\u0E25\u0E1A\u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C
\u0938\u094D\u0924\u0902\u092D \u091A\u094C\u0921\u093C\u093E\u0908 (pt)\xA6\u0E04\u0E27\u0E32\u0E21\u0E01\u0E27\u0E49\u0E32\u0E07\u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C (pt)
\u0924\u093E\u0932\u093F\u0915\u093E \u0915\u0940 \u0938\u0940\u092E\u093E\u090F\u0901\xA6\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A\u0E15\u0E32\u0E23\u0E32\u0E07
\u0924\u093E\u0932\u093F\u0915\u093E \u0939\u091F\u093E\u090F\u0901\xA6\u0E25\u0E1A\u0E15\u0E32\u0E23\u0E32\u0E07
\u0938\u0947\u0932 {row}, {column}\xA6\u0E40\u0E0B\u0E25\u0E25\u0E4C {row}, {column}
\u091A\u093F\u0924\u094D\u0930 \u0921\u093E\u0932\u0947\u0902\xA6\u0E41\u0E17\u0E23\u0E01\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E
\u091A\u093F\u0924\u094D\u0930\xA6\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E
\u091A\u093F\u0924\u094D\u0930 \u091A\u094C\u0921\u093C\u093E\u0908 (pt)\xA6\u0E04\u0E27\u0E32\u0E21\u0E01\u0E27\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E (pt)
\u091A\u093F\u0924\u094D\u0930 \u0939\u091F\u093E\u090F\u0901\xA6\u0E25\u0E1A\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E
\u0915\u093E\u0917\u093C\u091C\u093C \u0915\u093E \u0906\u0915\u093E\u0930\xA6\u0E02\u0E19\u0E32\u0E14\u0E01\u0E23\u0E30\u0E14\u0E32\u0E29
\u0915\u0938\u094D\u091F\u092E\xA6\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E40\u0E2D\u0E07
A4\xA6A4
Letter\xA6Letter
A3\xA6A3
\u092A\u0943\u0937\u094D\u0920 \u0915\u0940 \u0926\u093F\u0936\u093E\xA6\u0E01\u0E32\u0E23\u0E27\u0E32\u0E07\u0E41\u0E19\u0E27\u0E2B\u0E19\u0E49\u0E32
\u0932\u0902\u092C\u0935\u0924\xA6\u0E41\u0E19\u0E27\u0E15\u0E31\u0E49\u0E07
\u0915\u094D\u0937\u0948\u0924\u093F\u091C\xA6\u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19
\u092A\u0943\u0937\u094D\u0920 \u091A\u094C\u0921\u093C\u093E\u0908 (pt)\xA6\u0E04\u0E27\u0E32\u0E21\u0E01\u0E27\u0E49\u0E32\u0E07\u0E2B\u0E19\u0E49\u0E32 (pt)
\u092A\u0943\u0937\u094D\u0920 \u090A\u0901\u091A\u093E\u0908 (pt)\xA6\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E39\u0E07\u0E2B\u0E19\u0E49\u0E32 (pt)
\u090A\u092A\u0930\u0940 \u0939\u093E\u0936\u093F\u092F\u093E (pt)\xA6\u0E23\u0E30\u0E22\u0E30\u0E02\u0E2D\u0E1A\u0E1A\u0E19 (pt)
\u0926\u093E\u092F\u093E\u0901 \u0939\u093E\u0936\u093F\u092F\u093E (pt)\xA6\u0E23\u0E30\u0E22\u0E30\u0E02\u0E2D\u0E1A\u0E02\u0E27\u0E32 (pt)
\u0928\u093F\u091A\u0932\u093E \u0939\u093E\u0936\u093F\u092F\u093E (pt)\xA6\u0E23\u0E30\u0E22\u0E30\u0E02\u0E2D\u0E1A\u0E25\u0E48\u0E32\u0E07 (pt)
\u092C\u093E\u092F\u093E\u0901 \u0939\u093E\u0936\u093F\u092F\u093E (pt)\xA6\u0E23\u0E30\u0E22\u0E30\u0E02\u0E2D\u0E1A\u0E0B\u0E49\u0E32\u0E22 (pt)
\u092A\u0943\u0937\u094D\u0920 \u0938\u0947\u091F\u093F\u0902\u0917 \u0932\u093E\u0917\u0942 \u0915\u0930\u0947\u0902\xA6\u0E43\u0E0A\u0E49\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E2B\u0E19\u0E49\u0E32
\u0907\u0902\u0921\u0947\u0902\u091F (pt)\xA6\u0E01\u0E32\u0E23\u0E40\u0E22\u0E37\u0E49\u0E2D\u0E07 (pt)
\u092A\u0939\u0932\u0947 (pt)\xA6\u0E01\u0E48\u0E2D\u0E19 (pt)
\u092C\u093E\u0926 \u092E\u0947\u0902 (pt)\xA6\u0E2B\u0E25\u0E31\u0E07 (pt)
\u092A\u0902\u0915\u094D\u0924\u093F \u090A\u0901\u091A\u093E\u0908 (pt; 0 = \u0938\u094D\u0935\u0924\u0903)\xA6\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E39\u0E07\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14 (pt; 0 = \u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34)
\u0915\u0930\u094D\u0938\u0930 \u092A\u0930 \u091A\u093F\u0924\u094D\u0930 \u0921\u093E\u0932\u0947\u0902\xA6\u0E41\u0E17\u0E23\u0E01\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E17\u0E35\u0E48\u0E40\u0E04\u0E2D\u0E23\u0E4C\u0E40\u0E0B\u0E2D\u0E23\u0E4C
\u0911\u092C\u094D\u091C\u0947\u0915\u094D\u091F \u091A\u093F\u0939\u094D\u0928 \u092A\u0902\u0915\u094D\u0924\u093F \u092E\u0947\u0902 \u091A\u093F\u0924\u094D\u0930 \u0926\u093F\u0916\u093E\u0924\u093E \u0939\u0948\u0964 \u091A\u093F\u0924\u094D\u0930 \u0915\u0947 \u0928\u093F\u092F\u0902\u0924\u094D\u0930\u0923\u094B\u0902 \u0938\u0947 \u0909\u0938\u0915\u093E \u0906\u0915\u093E\u0930 \u092C\u0926\u0932\u0947\u0902 \u092F\u093E \u0909\u0938\u0947 \u0939\u091F\u093E\u090F\u0901\u0964\xA6\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E27\u0E31\u0E15\u0E16\u0E38\u0E41\u0E17\u0E19\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E43\u0E19\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14 \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E04\u0E27\u0E1A\u0E04\u0E38\u0E21\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E1B\u0E23\u0E31\u0E1A\u0E02\u0E19\u0E32\u0E14\u0E2B\u0E23\u0E37\u0E2D\u0E25\u0E1A
\u0932\u0917\u093E\u0924\u093E\u0930 \u092A\u093E\u0920 \u0938\u0902\u092A\u093E\u0926\u093F\u0924 \u0915\u0930\u0947\u0902\xA6\u0E41\u0E01\u0E49\u0E44\u0E02\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E48\u0E2D\u0E40\u0E19\u0E37\u0E48\u0E2D\u0E07
\u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u0938\u0902\u092A\u093E\u0926\u0915 \u092A\u0930 \u0932\u094C\u091F\u0947\u0902\xA6\u0E01\u0E25\u0E31\u0E1A\u0E44\u0E1B\u0E22\u0E31\u0E07\u0E15\u0E31\u0E27\u0E41\u0E01\u0E49\u0E44\u0E02\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32
\u0906\u0938\u092A\u093E\u0938 \u0915\u0947 \u092A\u093E\u0920 \u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926\u094B\u0902 \u092E\u0947\u0902 \u091A\u092F\u0928, \u0915\u0949\u092A\u0940, \u0915\u091F, \u092A\u0947\u0938\u094D\u091F \u092F\u093E \u0938\u094D\u0935\u0930\u0942\u092A\u0923 \u0915\u0930\u0947\u0902\u0964 \u0924\u093E\u0932\u093F\u0915\u093E\u090F\u0901, \u092A\u0943\u0937\u094D\u0920 \u0935\u093F\u0930\u093E\u092E, \u0905\u0928\u0941\u092D\u093E\u0917 \u0914\u0930 \u091A\u093F\u0924\u094D\u0930 \u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u091A\u092F\u0928 \u0915\u0940 \u0938\u0940\u092E\u093E\u090F\u0901 \u0939\u0948\u0902\u0964 \u091A\u093F\u092A\u0915\u093E\u0908 \u0917\u0908 \u0928\u0908 \u092A\u0902\u0915\u094D\u0924\u093F\u092F\u093E\u0901 \u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u092C\u0928\u0924\u0940 \u0939\u0948\u0902\u0964\xA6\u0E40\u0E25\u0E37\u0E2D\u0E01 \u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01 \u0E15\u0E31\u0E14 \u0E27\u0E32\u0E07 \u0E2B\u0E23\u0E37\u0E2D\u0E08\u0E31\u0E14\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E02\u0E49\u0E32\u0E21\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E15\u0E34\u0E14\u0E01\u0E31\u0E19\u0E44\u0E14\u0E49 \u0E15\u0E32\u0E23\u0E32\u0E07 \u0E15\u0E31\u0E27\u0E41\u0E1A\u0E48\u0E07\u0E2B\u0E19\u0E49\u0E32 \u0E2A\u0E48\u0E27\u0E19 \u0E41\u0E25\u0E30\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E40\u0E1B\u0E47\u0E19\u0E02\u0E2D\u0E1A\u0E40\u0E02\u0E15\u0E01\u0E32\u0E23\u0E40\u0E25\u0E37\u0E2D\u0E01 \u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E43\u0E2B\u0E21\u0E48\u0E17\u0E35\u0E48\u0E27\u0E32\u0E07\u0E08\u0E30\u0E01\u0E25\u0E32\u0E22\u0E40\u0E1B\u0E47\u0E19\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32
\u0905\u0928\u0941\u092D\u093E\u0917\xA6\u0E2A\u0E48\u0E27\u0E19
\u0905\u0928\u0941\u092D\u093E\u0917 {number}\xA6\u0E2A\u0E48\u0E27\u0E19 {number}
\u0905\u0917\u0932\u0947 \u092A\u0943\u0937\u094D\u0920 \u0915\u093E \u0905\u0928\u0941\u092D\u093E\u0917 \u0935\u093F\u0930\u093E\u092E\xA6\u0E15\u0E31\u0E27\u0E41\u0E1A\u0E48\u0E07\u0E2A\u0E48\u0E27\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E16\u0E31\u0E14\u0E44\u0E1B
\u092A\u093E\u0920 \u092D\u093E\u0937\u093E (BCP 47)\xA6\u0E20\u0E32\u0E29\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 (BCP 47)
\u0905\u0928\u0941\u091A\u094D\u091B\u0947\u0926 \u0926\u093F\u0936\u093E\xA6\u0E17\u0E34\u0E28\u0E17\u0E32\u0E07\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32
\u092C\u093E\u090F\u0901 \u0938\u0947 \u0926\u093E\u090F\u0901\xA6\u0E0B\u0E49\u0E32\u0E22\u0E44\u0E1B\u0E02\u0E27\u0E32
\u0926\u093E\u090F\u0901 \u0938\u0947 \u092C\u093E\u090F\u0901\xA6\u0E02\u0E27\u0E32\u0E44\u0E1B\u0E0B\u0E49\u0E32\u0E22
\u0928\u092F\u093E DOC\xA6DOC \u0E43\u0E2B\u0E21\u0E48
Word 97\u20132003 \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C\xA6\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23 Word 97\u20132003
\u0938\u0940\u092E\u093F\u0924 DOC \u0938\u0902\u092A\u093E\u0926\u0928: Unicode \u092A\u093E\u0920, \u092E\u0942\u0932 \u0936\u0948\u0932\u093F\u092F\u093E\u0901 \u0914\u0930 \u090F\u0915 \u0905\u0928\u0941\u092D\u093E\u0917\u0964 \u0905\u0938\u092E\u0930\u094D\u0925\u093F\u0924 DOC \u092B\u093C\u093E\u0907\u0932\u0947\u0902 \u0915\u0947\u0935\u0932 \u092A\u0922\u093C\u0940 \u091C\u093E \u0938\u0915\u0924\u0940 \u0939\u0948\u0902; \u0907\u0938 \u0938\u092E\u0930\u094D\u0925\u0928 \u0938\u094D\u0924\u0930 \u092A\u0930 \u0924\u093E\u0932\u093F\u0915\u093E\u090F\u0901 \u0914\u0930 \u091A\u093F\u0924\u094D\u0930 \u0928\u0939\u0940\u0902 \u0938\u0939\u0947\u091C\u0947 \u091C\u093E \u0938\u0915\u0924\u0947\u0964\xA6\u0E41\u0E01\u0E49\u0E44\u0E02 DOC \u0E41\u0E1A\u0E1A\u0E08\u0E33\u0E01\u0E31\u0E14: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 Unicode \u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E1E\u0E37\u0E49\u0E19\u0E10\u0E32\u0E19 \u0E41\u0E25\u0E30\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E2A\u0E48\u0E27\u0E19 \u0E44\u0E1F\u0E25\u0E4C DOC \u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E40\u0E1B\u0E34\u0E14\u0E41\u0E1A\u0E1A\u0E2D\u0E48\u0E32\u0E19\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27 \u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E15\u0E32\u0E23\u0E32\u0E07\u0E41\u0E25\u0E30\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E43\u0E19\u0E02\u0E2D\u0E1A\u0E40\u0E02\u0E15\u0E19\u0E35\u0E49\u0E44\u0E14\u0E49
\u092E\u0941\u0916\u094D\u092F \u092A\u093E\u0920 \u0915\u093E \u0915\u0947\u0935\u0932-\u092A\u0920\u0928 \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928, \u092A\u0942\u0930\u0947 \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u0915\u093E \u0935\u093F\u0928\u094D\u092F\u093E\u0938 \u0928\u0939\u0940\u0902\u0964 \u092A\u094D\u0930\u0924\u093F \u0938\u0939\u0947\u091C\u0928\u0947 \u092A\u0930 \u092E\u0942\u0932 \u092C\u093E\u0907\u091F \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0939\u0924\u0947 \u0939\u0948\u0902\u0964\xA6\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2B\u0E25\u0E31\u0E01\u0E41\u0E1A\u0E1A\u0E2D\u0E48\u0E32\u0E19\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27 \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E40\u0E04\u0E49\u0E32\u0E42\u0E04\u0E23\u0E07\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 \u0E01\u0E32\u0E23\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E2A\u0E33\u0E40\u0E19\u0E32\u0E08\u0E30\u0E40\u0E01\u0E47\u0E1A\u0E44\u0E1A\u0E15\u0E4C\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E44\u0E27\u0E49
DOC \u092E\u0947\u0902 \u092C\u0926\u0932\u0947\u0902\xA6\u0E41\u0E1B\u0E25\u0E07\u0E40\u0E1B\u0E47\u0E19 DOC
DOCX \u092E\u0947\u0902 \u092C\u0926\u0932\u0947\u0902\xA6\u0E41\u0E1B\u0E25\u0E07\u0E40\u0E1B\u0E47\u0E19 DOCX
\u0930\u0942\u092A\u093E\u0902\u0924\u0930\u0923 \u0915\u0947 \u0932\u093F\u090F \u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C \u092E\u0947\u0902 \u0915\u0947\u0935\u0932 \u0938\u092E\u0930\u094D\u0925\u093F\u0924 \u0938\u0902\u0930\u091A\u0928\u093E\u090F\u0901 \u0939\u094B\u0928\u0940 \u091A\u093E\u0939\u093F\u090F\u0964 \u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u092D\u093E\u0917 \u092E\u0942\u0932 \u092B\u093C\u093E\u0907\u0932 \u092E\u0947\u0902 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0939\u0924\u0947 \u0939\u0948\u0902; \u0909\u0928\u094D\u0939\u0947\u0902 \u0939\u091F\u093E\u092F\u093E \u0928\u0939\u0940\u0902 \u091C\u093E\u0924\u093E\u0964\xA6\u0E01\u0E32\u0E23\u0E41\u0E1B\u0E25\u0E07\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E17\u0E35\u0E48\u0E21\u0E35\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E42\u0E04\u0E23\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E17\u0E35\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A \u0E2A\u0E48\u0E27\u0E19\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E02\u0E49\u0E32\u0E43\u0E08\u0E08\u0E30\u0E40\u0E01\u0E47\u0E1A\u0E44\u0E27\u0E49\u0E43\u0E19\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E17\u0E34\u0E49\u0E07
\u092A\u0943\u0937\u094D\u0920 \u092A\u0930 \u0938\u0902\u092A\u093E\u0926\u093F\u0924 \u0915\u0930\u0947\u0902\xA6\u0E41\u0E01\u0E49\u0E44\u0E02\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32
\u0909\u092A\u0915\u0930\u0923\u094B\u0902 \u092A\u0930 \u0932\u094C\u091F\u0947\u0902\xA6\u0E01\u0E25\u0E31\u0E1A\u0E44\u0E1B\u0E22\u0E31\u0E07\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D
\u092C\u094D\u0930\u093E\u0909\u091C\u093C\u0930 \u0915\u0940 \u092E\u0942\u0932 \u0905\u0915\u094D\u0937\u0930-\u0906\u0915\u0943\u0924\u093F \u0938\u0941\u0935\u093F\u0927\u093E \u0938\u0947 \u092A\u0943\u0937\u094D\u0920 \u092A\u0930 \u0938\u0902\u092A\u093E\u0926\u093F\u0924 \u0915\u0930\u0947\u0902\u0964 \u0916\u0940\u0902\u091A\u0915\u0930 \u091A\u0941\u0928\u0947\u0902; \u0915\u0949\u092A\u0940 \u0914\u0930 \u092A\u0947\u0938\u094D\u091F \u092E\u0947\u0902 \u0938\u092E\u0930\u094D\u0925\u093F\u0924 Office EX \u0938\u094D\u0935\u0930\u0942\u092A\u0923 \u0914\u0930 \u091A\u093F\u0924\u094D\u0930 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0939\u0924\u0947 \u0939\u0948\u0902\u0964 Word \u0938\u0947 \u092A\u0943\u0937\u094D\u0920 \u0938\u092E\u093E\u0928\u0924\u093E \u0905\u092D\u0940 \u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964\xA6\u0E41\u0E01\u0E49\u0E44\u0E02\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E42\u0E14\u0E22\u0E43\u0E0A\u0E49\u0E01\u0E32\u0E23\u0E08\u0E31\u0E14\u0E23\u0E39\u0E1B\u0E2D\u0E31\u0E01\u0E29\u0E23\u0E02\u0E2D\u0E07\u0E40\u0E1A\u0E23\u0E32\u0E27\u0E4C\u0E40\u0E0B\u0E2D\u0E23\u0E4C \u0E25\u0E32\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E25\u0E37\u0E2D\u0E01 \u0E01\u0E32\u0E23\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E41\u0E25\u0E30\u0E27\u0E32\u0E07\u0E08\u0E30\u0E40\u0E01\u0E47\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E41\u0E25\u0E30\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E02\u0E2D\u0E07 Office EX \u0E17\u0E35\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E44\u0E27\u0E49 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E04\u0E27\u0E32\u0E21\u0E40\u0E17\u0E35\u0E48\u0E22\u0E07\u0E15\u0E23\u0E07\u0E02\u0E2D\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E01\u0E31\u0E1A Word
`.trim().split("\n").map((line) => line.split("\xA6"));
if (pairs.some((p) => p.length !== 2)) throw Error("Invalid Hindi/Thai translation row");
var hindiBase = baseCatalog(pairs.map((p) => p[0]).join("\n"));
var thaiBase = baseCatalog(pairs.map((p) => p[1]).join("\n"));
var sheetPairs = `
\u0928\u0908 XLSX \u0915\u093E\u0930\u094D\u092F\u092A\u0941\u0938\u094D\u0924\u093F\u0915\u093E\xA6\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01\u0E1A\u0E38\u0E4A\u0E01 XLSX \u0E43\u0E2B\u0E21\u0E48
Excel \u0915\u093E\u0930\u094D\u092F\u092A\u0941\u0938\u094D\u0924\u093F\u0915\u093E (.xlsx)\xA6\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01\u0E1A\u0E38\u0E4A\u0E01 Excel (.xlsx)
\u0938\u092E\u0930\u094D\u0925\u093F\u0924 \u0938\u0947\u0932, \u0938\u0942\u0924\u094D\u0930 \u0914\u0930 \u0936\u0948\u0932\u093F\u092F\u093E\u0901 \u0938\u0902\u092A\u093E\u0926\u093F\u0924 \u0915\u0930\u0947\u0902\u0964 \u0938\u0941\u0930\u0915\u094D\u0937\u093E \u092F\u093E \u0905\u0938\u092E\u0930\u094D\u0925\u093F\u0924 \u0928\u093F\u0930\u094D\u092D\u0930\u0924\u093E \u0935\u093E\u0932\u0940 \u092B\u093C\u093E\u0907\u0932\u0947\u0902 \u092E\u0942\u0932 \u0915\u094B \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0916\u0928\u0947 \u0935\u093E\u0932\u0947 \u0915\u0947\u0935\u0932-\u092A\u0920\u0928 \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928 \u092E\u0947\u0902 \u0916\u0941\u0932\u0924\u0940 \u0939\u0948\u0902\u0964\xA6\u0E41\u0E01\u0E49\u0E44\u0E02\u0E40\u0E0B\u0E25\u0E25\u0E4C \u0E2A\u0E39\u0E15\u0E23 \u0E41\u0E25\u0E30\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E17\u0E35\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A \u0E44\u0E1F\u0E25\u0E4C\u0E17\u0E35\u0E48\u0E21\u0E35\u0E01\u0E32\u0E23\u0E1B\u0E49\u0E2D\u0E07\u0E01\u0E31\u0E19\u0E2B\u0E23\u0E37\u0E2D\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E08\u0E30\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E1B\u0E47\u0E19\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E2D\u0E48\u0E32\u0E19\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27\u0E41\u0E25\u0E30\u0E40\u0E01\u0E47\u0E1A\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E44\u0E27\u0E49
\u0928\u0908 Excel 97\u20132003 \u0915\u093E\u0930\u094D\u092F\u092A\u0941\u0938\u094D\u0924\u093F\u0915\u093E\xA6\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01\u0E1A\u0E38\u0E4A\u0E01 Excel 97\u20132003 \u0E43\u0E2B\u0E21\u0E48
Excel 97\u20132003 \u0915\u093E\u0930\u094D\u092F\u092A\u0941\u0938\u094D\u0924\u093F\u0915\u093E (.xls)\xA6\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01\u0E1A\u0E38\u0E4A\u0E01 Excel 97\u20132003 (.xls)
BIFF8 \u0915\u093E\u0930\u094D\u092F\u092A\u0941\u0938\u094D\u0924\u093F\u0915\u093E: \u0905\u0927\u093F\u0915\u0924\u092E 65,536 \u092A\u0902\u0915\u094D\u0924\u093F\u092F\u093E\u0901 \u0914\u0930 256 \u0938\u094D\u0924\u0902\u092D\u0964 \u0938\u0939\u0947\u091C\u0928\u0947 \u0914\u0930 \u0930\u0942\u092A\u093E\u0902\u0924\u0930\u0923 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0938\u0942\u0924\u094D\u0930, \u0936\u0948\u0932\u093F\u092F\u093E\u0901 \u0914\u0930 \u092E\u0942\u0932 \u092B\u093C\u093E\u0907\u0932 \u0915\u0940 \u0928\u093F\u0930\u094D\u092D\u0930\u0924\u093E\u090F\u0901 \u091C\u093E\u0901\u091A\u0940 \u091C\u093E\u0924\u0940 \u0939\u0948\u0902\u0964\xA6\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01\u0E1A\u0E38\u0E4A\u0E01 BIFF8: \u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14 65,536 \u0E41\u0E16\u0E27\u0E41\u0E25\u0E30 256 \u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C \u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E2A\u0E39\u0E15\u0E23 \u0E2A\u0E44\u0E15\u0E25\u0E4C \u0E41\u0E25\u0E30\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E02\u0E49\u0E2D\u0E07\u0E43\u0E19\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E01\u0E48\u0E2D\u0E19\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E30\u0E41\u0E1B\u0E25\u0E07
XLSX \u092A\u094D\u0930\u0924\u093F \u092E\u0947\u0902 \u092C\u0926\u0932\u0947\u0902\xA6\u0E41\u0E1B\u0E25\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E2A\u0E33\u0E40\u0E19\u0E32 XLSX
XLS \u092A\u094D\u0930\u0924\u093F \u092E\u0947\u0902 \u092C\u0926\u0932\u0947\u0902\xA6\u0E41\u0E1B\u0E25\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E2A\u0E33\u0E40\u0E19\u0E32 XLS
\u0938\u094D\u092A\u094D\u0930\u0947\u0921\u0936\u0940\u091F \u0917\u094D\u0930\u093F\u0921\xA6\u0E15\u0E32\u0E23\u0E32\u0E07\u0E2A\u0E40\u0E1B\u0E23\u0E14\u0E0A\u0E35\u0E15
\u0938\u0947\u0932 \u0915\u093E \u092E\u093E\u0928 \u092F\u093E \u0938\u0942\u0924\u094D\u0930\xA6\u0E04\u0E48\u0E32\u0E2B\u0E23\u0E37\u0E2D\u0E2A\u0E39\u0E15\u0E23\u0E02\u0E2D\u0E07\u0E40\u0E0B\u0E25\u0E25\u0E4C
\u0938\u0947\u0932 \u092F\u093E \u0915\u094D\u0937\u0947\u0924\u094D\u0930 \u0915\u093E \u092A\u0924\u093E\xA6\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E40\u0E0B\u0E25\u0E25\u0E4C\u0E2B\u0E23\u0E37\u0E2D\u0E0A\u0E48\u0E27\u0E07
\u0936\u0940\u091F \u091C\u094B\u0921\u093C\u0947\u0902\xA6\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E41\u0E1C\u0E48\u0E19\u0E07\u0E32\u0E19
\u0936\u0940\u091F \u0915\u093E \u0928\u093E\u092E \u092C\u0926\u0932\u0947\u0902\xA6\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E1C\u0E48\u0E19\u0E07\u0E32\u0E19
\u0936\u0940\u091F \u0939\u091F\u093E\u090F\u0901\xA6\u0E25\u0E1A\u0E41\u0E1C\u0E48\u0E19\u0E07\u0E32\u0E19
\u0936\u0940\u091F \u0915\u094B \u092A\u0939\u0932\u0947 \u0932\u0947 \u091C\u093E\u090F\u0901\xA6\u0E22\u0E49\u0E32\u0E22\u0E41\u0E1C\u0E48\u0E19\u0E07\u0E32\u0E19\u0E44\u0E1B\u0E01\u0E48\u0E2D\u0E19\u0E2B\u0E19\u0E49\u0E32
\u0936\u0940\u091F \u0915\u094B \u092C\u093E\u0926 \u092E\u0947\u0902 \u0932\u0947 \u091C\u093E\u090F\u0901\xA6\u0E22\u0E49\u0E32\u0E22\u0E41\u0E1C\u0E48\u0E19\u0E07\u0E32\u0E19\u0E44\u0E1B\u0E16\u0E31\u0E14\u0E44\u0E1B
\u0936\u0940\u091F \u0915\u093E \u0928\u093E\u092E\xA6\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E1C\u0E48\u0E19\u0E07\u0E32\u0E19
\u0936\u0940\u091F, \u092A\u0902\u0915\u094D\u0924\u093F\u092F\u093E\u0901 \u0914\u0930 \u0938\u094D\u0924\u0902\u092D\xA6\u0E41\u0E1C\u0E48\u0E19\u0E07\u0E32\u0E19 \u0E41\u0E16\u0E27 \u0E41\u0E25\u0E30\u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C
\u0938\u0947\u0932 \u092E\u0930\u094D\u091C \u0915\u0930\u0947\u0902\xA6\u0E1C\u0E2A\u0E32\u0E19\u0E40\u0E0B\u0E25\u0E25\u0E4C
\u0938\u0947\u0932 \u0915\u093E \u092E\u0930\u094D\u091C \u0939\u091F\u093E\u090F\u0901\xA6\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E01\u0E32\u0E23\u0E1C\u0E2A\u0E32\u0E19\u0E40\u0E0B\u0E25\u0E25\u0E4C
\u092E\u093E\u0928 \u092E\u093F\u091F\u093E\u090F\u0901\xA6\u0E25\u0E49\u0E32\u0E07\u0E04\u0E48\u0E32
\u092A\u0902\u0915\u094D\u0924\u093F\u092F\u093E\u0901 \u0921\u093E\u0932\u0947\u0902\xA6\u0E41\u0E17\u0E23\u0E01\u0E41\u0E16\u0E27
\u092A\u0902\u0915\u094D\u0924\u093F\u092F\u093E\u0901 \u0939\u091F\u093E\u090F\u0901\xA6\u0E25\u0E1A\u0E41\u0E16\u0E27
\u0938\u094D\u0924\u0902\u092D \u0921\u093E\u0932\u0947\u0902\xA6\u0E41\u0E17\u0E23\u0E01\u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C
\u0938\u094D\u0924\u0902\u092D \u0939\u091F\u093E\u090F\u0901\xA6\u0E25\u0E1A\u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C
\u092A\u0902\u0915\u094D\u0924\u093F \u090A\u0901\u091A\u093E\u0908 (px)\xA6\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E39\u0E07\u0E41\u0E16\u0E27 (px)
\u0938\u094D\u0924\u0902\u092D \u091A\u094C\u0921\u093C\u093E\u0908 (px)\xA6\u0E04\u0E27\u0E32\u0E21\u0E01\u0E27\u0E49\u0E32\u0E07\u0E04\u0E2D\u0E25\u0E31\u0E21\u0E19\u0E4C (px)
\u0938\u0902\u0916\u094D\u092F\u093E \u092A\u094D\u0930\u093E\u0930\u0942\u092A\xA6\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02
\u0938\u093E\u092E\u093E\u0928\u094D\u092F\xA6\u0E17\u0E31\u0E48\u0E27\u0E44\u0E1B
\u0938\u0902\u0916\u094D\u092F\u093E\xA6\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02
\u092A\u094D\u0930\u0924\u093F\u0936\u0924\xA6\u0E40\u0E1B\u0E2D\u0E23\u0E4C\u0E40\u0E0B\u0E47\u0E19\u0E15\u0E4C
\u092E\u0941\u0926\u094D\u0930\u093E\xA6\u0E2A\u0E01\u0E38\u0E25\u0E40\u0E07\u0E34\u0E19
\u0924\u093E\u0930\u0940\u0916\xA6\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48
\u0938\u092E\u092F\xA6\u0E40\u0E27\u0E25\u0E32
\u0935\u0948\u091C\u094D\u091E\u093E\u0928\u093F\u0915\xA6\u0E40\u0E0A\u0E34\u0E07\u0E27\u0E34\u0E17\u0E22\u0E32\u0E28\u0E32\u0E2A\u0E15\u0E23\u0E4C
\u0915\u0938\u094D\u091F\u092E \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u0915\u094B\u0921\xA6\u0E23\u0E2B\u0E31\u0E2A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E40\u0E2D\u0E07
\u0938\u0947\u0932 \u0915\u093E \u092D\u0930\u0923 \u0930\u0902\u0917\xA6\u0E2A\u0E35\u0E1E\u0E37\u0E49\u0E19\u0E40\u0E0B\u0E25\u0E25\u0E4C
\u092A\u093E\u0920 \u0932\u092A\u0947\u091F\u0947\u0902\xA6\u0E15\u0E31\u0E14\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E43\u0E2B\u0E21\u0E48
\u0938\u0947\u0932 \u0915\u0940 \u0938\u0940\u092E\u093E\u090F\u0901\xA6\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A\u0E40\u0E0B\u0E25\u0E25\u0E4C
\u0938\u0942\u0924\u094D\u0930 \u0907\u0928\u092A\u0941\u091F\xA6\u0E01\u0E32\u0E23\u0E1B\u0E49\u0E2D\u0E19\u0E2A\u0E39\u0E15\u0E23
\u0905\u0902\u0917\u094D\u0930\u0947\u091C\u093C\u0940 \u0928\u093E\u092E \xB7 \u0926\u0936\u092E\u0932\u0935 \u092C\u093F\u0902\u0926\u0941\xA6\u0E0A\u0E37\u0E48\u0E2D\u0E20\u0E32\u0E29\u0E32\u0E2D\u0E31\u0E07\u0E01\u0E24\u0E29 \xB7 \u0E08\u0E38\u0E14\u0E17\u0E28\u0E19\u0E34\u0E22\u0E21
\u0915\u094D\u0937\u0947\u0924\u094D\u0930\u0940\u092F \u0928\u093E\u092E \u0914\u0930 \u0935\u093F\u092D\u093E\u091C\u0915\xA6\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E25\u0E30\u0E15\u0E31\u0E27\u0E04\u0E31\u0E48\u0E19\u0E15\u0E32\u0E21\u0E20\u0E39\u0E21\u0E34\u0E20\u0E32\u0E04
\u092B\u093F\u0930 \u0938\u0947 \u0917\u0923\u0928\u093E \u0915\u0930\u0947\u0902\xA6\u0E04\u0E33\u0E19\u0E27\u0E13\u0E43\u0E2B\u0E21\u0E48
\u0917\u0923\u0928\u093E \u091C\u093E\u0930\u0940 \u0939\u0948\u2026\xA6\u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E13\u2026
\u0917\u0923\u0928\u093E \u0915\u0940 \u0917\u0908\xA6\u0E04\u0E33\u0E19\u0E27\u0E13\u0E41\u0E25\u0E49\u0E27
\u0917\u0923\u0928\u093E \u0928\u0939\u0940\u0902 \u0939\u0941\u0908: \u0905\u0938\u092E\u0930\u094D\u0925\u093F\u0924 \u0938\u0942\u0924\u094D\u0930\xA6\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E04\u0E33\u0E19\u0E27\u0E13: \u0E2A\u0E39\u0E15\u0E23\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A
\u092A\u093F\u091B\u0932\u093E \u092A\u0930\u093F\u0923\u093E\u092E: \u0926\u094B\u092C\u093E\u0930\u093E \u0917\u0923\u0928\u093E \u0906\u0935\u0936\u094D\u092F\u0915\xA6\u0E1C\u0E25\u0E01\u0E48\u0E2D\u0E19\u0E2B\u0E19\u0E49\u0E32: \u0E15\u0E49\u0E2D\u0E07\u0E04\u0E33\u0E19\u0E27\u0E13\u0E43\u0E2B\u0E21\u0E48
\u0938\u0942\u0924\u094D\u0930 \u0924\u094D\u0930\u0941\u091F\u093F\xA6\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E02\u0E2D\u0E07\u0E2A\u0E39\u0E15\u0E23
\u0917\u0923\u0928\u093E \u0930\u0926\u094D\u0926 \u0915\u0930\u0947\u0902\xA6\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E01\u0E32\u0E23\u0E04\u0E33\u0E19\u0E27\u0E13
{count} \u0938\u0902\u0916\u094D\u092F\u093E\u0924\u094D\u092E\u0915 \u0938\u0947\u0932 \xB7 \u092F\u094B\u0917 {sum}\xA6\u0E40\u0E0B\u0E25\u0E25\u0E4C\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02 {count} \u0E40\u0E0B\u0E25\u0E25\u0E4C \xB7 \u0E1C\u0E25\u0E23\u0E27\u0E21 {sum}
\u091A\u092F\u0928 {address}\xA6\u0E0A\u0E48\u0E27\u0E07\u0E17\u0E35\u0E48\u0E40\u0E25\u0E37\u0E2D\u0E01 {address}
\u091A\u0941\u0928\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0915\u094D\u0932\u093F\u0915 \u0915\u0930\u0947\u0902 \u092F\u093E \u0916\u0940\u0902\u091A\u0947\u0902\u0964 \u0932\u093F\u0916\u0915\u0930 \u092F\u093E F2 \u0938\u0947 \u0938\u0902\u092A\u093E\u0926\u093F\u0924 \u0915\u0930\u0947\u0902; Enter \u092A\u0941\u0937\u094D\u091F\u093F \u0915\u0930\u0924\u093E \u0939\u0948 \u0914\u0930 Esc \u0930\u0926\u094D\u0926 \u0915\u0930\u0924\u093E \u0939\u0948\u0964 Shift \u0938\u0947 \u091A\u092F\u0928 \u092C\u0922\u093C\u093E\u090F\u0901\u0964 \u0915\u094D\u0937\u0947\u0924\u094D\u0930\u094B\u0902 \u0915\u094B TSV \u0915\u0947 \u0930\u0942\u092A \u092E\u0947\u0902 \u0915\u0949\u092A\u0940 \u0914\u0930 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u0947\u0902\u0964 \u0938\u0942\u0924\u094D\u0930 = \u0938\u0947 \u0936\u0941\u0930\u0942 \u0939\u094B\u0924\u0947 \u0939\u0948\u0902\u0964\xA6\u0E04\u0E25\u0E34\u0E01\u0E2B\u0E23\u0E37\u0E2D\u0E25\u0E32\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E25\u0E37\u0E2D\u0E01 \u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E2B\u0E23\u0E37\u0E2D\u0E01\u0E14 F2 \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E41\u0E01\u0E49\u0E44\u0E02 Enter \u0E22\u0E37\u0E19\u0E22\u0E31\u0E19 \u0E41\u0E25\u0E30 Esc \u0E22\u0E01\u0E40\u0E25\u0E34\u0E01 \u0E43\u0E0A\u0E49 Shift \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E02\u0E22\u0E32\u0E22\u0E0A\u0E48\u0E27\u0E07\u0E17\u0E35\u0E48\u0E40\u0E25\u0E37\u0E2D\u0E01 \u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E41\u0E25\u0E30\u0E27\u0E32\u0E07\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E1B\u0E47\u0E19 TSV \u0E2A\u0E39\u0E15\u0E23\u0E40\u0E23\u0E34\u0E48\u0E21\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 =
\u091A\u092F\u0928 \u092A\u0930 \u092B\u093C\u094D\u0930\u0940\u091C\u093C \u0915\u0930\u0947\u0902\xA6\u0E15\u0E23\u0E36\u0E07\u0E17\u0E35\u0E48\u0E0A\u0E48\u0E27\u0E07\u0E17\u0E35\u0E48\u0E40\u0E25\u0E37\u0E2D\u0E01
\u092B\u0932\u0915 \u0905\u0928\u092B\u093C\u094D\u0930\u0940\u091C\u093C \u0915\u0930\u0947\u0902\xA6\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E01\u0E32\u0E23\u0E15\u0E23\u0E36\u0E07\u0E41\u0E19\u0E27
\u0926\u093E\u090F\u0901 \u0938\u0947 \u092C\u093E\u090F\u0901 \u0936\u0940\u091F\xA6\u0E41\u0E1C\u0E48\u0E19\u0E07\u0E32\u0E19\u0E08\u0E32\u0E01\u0E02\u0E27\u0E32\u0E44\u0E1B\u0E0B\u0E49\u0E32\u0E22
\u0917\u094D\u0930\u093F\u0921 \u0930\u0947\u0916\u093E\u090F\u0901 \u0926\u093F\u0916\u093E\u090F\u0901\xA6\u0E41\u0E2A\u0E14\u0E07\u0E40\u0E2A\u0E49\u0E19\u0E15\u0E32\u0E23\u0E32\u0E07
\u0915\u093E\u0930\u094D\u092F\u092A\u0941\u0938\u094D\u0924\u093F\u0915\u093E \u0915\u0940 \u0924\u093E\u0930\u0940\u0916 \u092A\u094D\u0930\u0923\u093E\u0932\u0940\xA6\u0E23\u0E30\u0E1A\u0E1A\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01\u0E1A\u0E38\u0E4A\u0E01
\u092E\u0942\u0932 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0916\u0928\u0947 \u0935\u093E\u0932\u093E \u0915\u093E\u0930\u094D\u092F\u092A\u0941\u0938\u094D\u0924\u093F\u0915\u093E \u092A\u0942\u0930\u094D\u0935\u093E\u0935\u0932\u094B\u0915\u0928\xA6\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01\u0E1A\u0E38\u0E4A\u0E01\u0E17\u0E35\u0E48\u0E40\u0E01\u0E47\u0E1A\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E44\u0E27\u0E49
\u0907\u0938 \u0915\u093E\u0930\u094D\u092F\u092A\u0941\u0938\u094D\u0924\u093F\u0915\u093E \u092E\u0947\u0902 \u0938\u0902\u092A\u093E\u0926\u0928 \u0938\u0940\u092E\u093E \u0938\u0947 \u092C\u093E\u0939\u0930 \u0915\u0940 \u0928\u093F\u0930\u094D\u092D\u0930\u0924\u093E\u090F\u0901 \u0939\u0948\u0902\u0964 \u0906\u092A \u0938\u0947\u0932 \u0926\u0947\u0916 \u0938\u0915\u0924\u0947 \u0939\u0948\u0902 \u0914\u0930 \u092E\u0942\u0932 \u092B\u093C\u093E\u0907\u0932 \u0915\u0940 \u0939\u0942\u092C\u0939\u0942 \u092A\u094D\u0930\u0924\u093F \u0938\u0939\u0947\u091C \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\u0964\xA6\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01\u0E1A\u0E38\u0E4A\u0E01\u0E19\u0E35\u0E49\u0E21\u0E35\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E02\u0E49\u0E2D\u0E07\u0E19\u0E2D\u0E01\u0E02\u0E2D\u0E1A\u0E40\u0E02\u0E15\u0E17\u0E35\u0E48\u0E41\u0E01\u0E49\u0E44\u0E02\u0E44\u0E14\u0E49 \u0E04\u0E38\u0E13\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E15\u0E23\u0E27\u0E08\u0E14\u0E39\u0E40\u0E0B\u0E25\u0E25\u0E4C\u0E41\u0E25\u0E30\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E2A\u0E33\u0E40\u0E19\u0E32\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E21\u0E37\u0E2D\u0E19\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E17\u0E38\u0E01\u0E44\u0E1A\u0E15\u0E4C\u0E44\u0E14\u0E49
\u092E\u0942\u0932 \u092B\u093C\u093E\u0907\u0932 \u0915\u0940 \u0928\u093F\u0930\u094D\u092D\u0930\u0924\u093E\u090F\u0901 \u0932\u0915\u094D\u0937\u094D\u092F \u092A\u094D\u0930\u093E\u0930\u0942\u092A \u092E\u0947\u0902 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0930\u0942\u092A \u0938\u0947 \u0935\u094D\u092F\u0915\u094D\u0924 \u0928\u0939\u0940\u0902 \u0939\u094B \u0938\u0915\u0924\u0940\u0902, \u0907\u0938\u0932\u093F\u090F \u0930\u0942\u092A\u093E\u0902\u0924\u0930\u0923 \u0930\u094B\u0915\u093E \u0917\u092F\u093E\u0964\xA6\u0E23\u0E30\u0E07\u0E31\u0E1A\u0E01\u0E32\u0E23\u0E41\u0E1B\u0E25\u0E07\u0E40\u0E19\u0E37\u0E48\u0E2D\u0E07\u0E08\u0E32\u0E01\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E01\u0E47\u0E1A\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E02\u0E49\u0E2D\u0E07\u0E02\u0E2D\u0E07\u0E15\u0E49\u0E19\u0E09\u0E1A\u0E31\u0E1A\u0E43\u0E19\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E44\u0E14\u0E49\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E1B\u0E25\u0E2D\u0E14\u0E20\u0E31\u0E22
\u0917\u0923\u0928\u093E \u0915\u0940 \u092A\u094D\u0930\u0924\u0940\u0915\u094D\u0937\u093E\xA6\u0E01\u0E33\u0E25\u0E31\u0E07\u0E23\u0E2D\u0E01\u0E32\u0E23\u0E04\u0E33\u0E19\u0E27\u0E13
\u091A\u0941\u0928\u0947 \u0917\u090F \u0907\u0928\u092A\u0941\u091F \u092E\u094B\u0921 \u092E\u0947\u0902 \u092F\u0939 \u092E\u093E\u0928 \u092F\u093E \u0938\u0942\u0924\u094D\u0930 \u0928\u0939\u0940\u0902 \u0921\u093E\u0932\u093E \u091C\u093E \u0938\u0915\u0924\u093E\u0964\xA6\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E1B\u0E49\u0E2D\u0E19\u0E04\u0E48\u0E32\u0E2B\u0E23\u0E37\u0E2D\u0E2A\u0E39\u0E15\u0E23\u0E19\u0E35\u0E49\u0E43\u0E19\u0E42\u0E2B\u0E21\u0E14\u0E01\u0E32\u0E23\u0E1B\u0E49\u0E2D\u0E19\u0E17\u0E35\u0E48\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E14\u0E49
\u0926\u0943\u0936\u094D\u092F\xA6\u0E21\u0E38\u0E21\u0E21\u0E2D\u0E07
\u0932\u093E\u0917\u0942 \u0915\u0930\u0947\u0902\xA6\u0E19\u0E33\u0E44\u0E1B\u0E43\u0E0A\u0E49
\u0938\u0947\u0932 \u0938\u094D\u0935\u0930\u0942\u092A\u0923\xA6\u0E01\u0E32\u0E23\u0E08\u0E31\u0E14\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E40\u0E0B\u0E25\u0E25\u0E4C
\u0928\u0940\u091A\u0947 \u092D\u0930\u0947\u0902\xA6\u0E40\u0E15\u0E34\u0E21\u0E25\u0E07
\u0926\u093E\u0908\u0902 \u0913\u0930 \u092D\u0930\u0947\u0902\xA6\u0E40\u0E15\u0E34\u0E21\u0E44\u0E1B\u0E17\u0E32\u0E07\u0E02\u0E27\u0E32
`.trim().split("\n").map((line) => line.split("\xA6"));
if (sheetPairs.some((p) => p.length !== 2)) throw Error("Invalid Hindi/Thai Sheets translation row");
var hindi = { ...hindiBase, ...sheetsCatalog(sheetPairs.map((p) => p[0]).join("\n")) };
var thai = { ...thaiBase, ...sheetsCatalog(sheetPairs.map((p) => p[1]).join("\n")) };

// packages/i18n/src/catalogs-b1.ts
var arabic = { ...baseCatalog(`
\u0641\u062A\u062D \u0645\u0644\u0641
\u0645\u0633\u0648\u062F\u0629 \u062C\u062F\u064A\u062F\u0629
\u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0623\u062E\u064A\u0631\u0629
\u0645\u0633\u0627\u062D\u0629 \u0639\u0645\u0644 \u0645\u062D\u0644\u064A\u0629 \xB7 \u0627\u0644\u0623\u0648\u0644\u0648\u064A\u0629 \u0644\u0644\u0639\u0645\u0644 \u062F\u0648\u0646 \u0627\u062A\u0635\u0627\u0644
\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A
\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0639\u0645\u0644
\u062A\u0631\u0627\u062C\u0639
\u0625\u0639\u0627\u062F\u0629
\u062D\u0641\u0638 \u0628\u0627\u0633\u0645
\u062D\u0641\u0638
\u062C\u0627\u0647\u0632
\u0627\u0644\u0645\u0638\u0647\u0631
\u0627\u0644\u0646\u0638\u0627\u0645
\u0641\u0627\u062A\u062D
\u062F\u0627\u0643\u0646
\u0627\u0644\u0644\u063A\u0629
\u0645\u0633\u062D \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0623\u062E\u064A\u0631\u0629
\u062A\u0628\u0642\u0649 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0648\u0644\u0642\u0637\u0627\u062A \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0643\u0645\u0628\u064A\u0648\u062A\u0631.
\u0645\u0633\u0627\u062D\u0629 \u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A\u0643.
\u062D\u0632\u0645\u0629 \u0645\u0643\u062A\u0628\u064A\u0629 \u0645\u0633\u062A\u0642\u0644\u0629 \u0644\u0633\u0637\u062D \u0627\u0644\u0645\u0643\u062A\u0628. \u062A\u062A\u0636\u0645\u0646 \u0645\u0639\u0627\u064A\u0646\u0629 M3 \u0645\u062D\u0631\u0631 \u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0645\u062D\u062F\u0648\u062F \u0627\u0644\u0646\u0637\u0627\u0642 \u0648\u062C\u062F\u0627\u0648\u0644 \u0628\u064A\u0627\u0646\u0627\u062A \u0648\u0635\u064A\u063A\u064B\u0627 \u0648\u062D\u0641\u0638\u064B\u0627 \u0645\u062D\u0645\u064A\u064B\u0627 \u0644\u0635\u064A\u063A Office \u0627\u0644\u0645\u062F\u0639\u0648\u0645\u0629.
\u0625\u0646\u0634\u0627\u0621 \u0645\u0633\u0648\u062F\u0629 \u0645\u062D\u0644\u064A\u0629
\u0635\u064A\u063A\u0629 \u0627\u0644\u0645\u0633\u0648\u062F\u0629 \u0627\u0644\u062F\u0627\u062E\u0644\u064A\u0629 \xB7 \u200E.oex
\u0645\u0633\u062A\u0646\u062F
\u062C\u062F\u0648\u0644 \u0628\u064A\u0627\u0646\u0627\u062A
\u0639\u0631\u0636 \u062A\u0642\u062F\u064A\u0645\u064A
\u0646\u0645\u0648\u0630\u062C \u0646\u0635 \u0648\u0639\u0645\u0644\u064A\u0627\u062A \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u062A\u0631\u0627\u062C\u0639
\u062E\u0644\u0627\u064A\u0627 \u0645\u062A\u0641\u0631\u0642\u0629 \u0648\u0623\u0648\u0627\u0645\u0631 \u0645\u062C\u0645\u0651\u0639\u0629
\u0646\u0645\u0648\u0630\u062C \u0645\u0634\u0647\u062F \u0648\u0625\u062D\u062F\u0627\u062B\u064A\u0627\u062A
\u0627\u0641\u062A\u062D \u0645\u0644\u0641\u064B\u0627 \u0623\u0648 \u0623\u0641\u0644\u062A\u0647 \u0647\u0646\u0627
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 \u0645\u0633\u0648\u062F\u0627\u062A Office EX
\u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u0644\u0641
\u064A\u0645\u0643\u0646 \u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0648\u062C\u062F\u0627\u0648\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0636\u0645\u0646 \u0627\u0644\u0646\u0637\u0627\u0642 \u0627\u0644\u0645\u062F\u0639\u0648\u0645 \u0648\u062D\u0641\u0638\u0647\u0627. \u062A\u064F\u0641\u062A\u062D \u0627\u0644\u0628\u0646\u0649 \u063A\u064A\u0631 \u0627\u0644\u0645\u062F\u0639\u0648\u0645\u0629 \u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637 \u0645\u0639 \u0625\u0645\u0643\u0627\u0646\u064A\u0629 \u062D\u0641\u0638 \u0646\u0633\u062E\u0629 \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0644\u0623\u0635\u0644\u061B \u0648\u0644\u0627 \u064A\u0632\u0627\u0644 \u0627\u0644\u062A\u0648\u0627\u0641\u0642 \u0627\u0644\u0643\u0627\u0645\u0644 \u0642\u064A\u062F \u0627\u0644\u062A\u0637\u0648\u064A\u0631.
\u0627\u0644\u0628\u0646\u064A\u0629 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629 \u0644\u0644\u0635\u064A\u063A
\u062D\u0627\u0648\u064A\u0629 \u0645\u062A\u0635\u0644\u0629
\u0627\u0644\u0635\u064A\u063A \u0627\u0644\u062D\u062F\u064A\u062B\u0629
\u0627\u0644\u0635\u064A\u063A \u0627\u0644\u0642\u062F\u064A\u0645\u0629
\u0645\u0633\u0648\u062F\u0627\u062A \u0645\u062D\u0644\u064A\u0629
\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0644\u0641\u0627\u062A \u0623\u062E\u064A\u0631\u0629
\u0628\u0644\u0627 \u0639\u0646\u0648\u0627\u0646
\u0645\u0633\u0648\u062F\u0629 Office EX
\u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637 \xB7 \u0641\u062D\u0635 \u0627\u0644\u0628\u0646\u064A\u0629
\u063A\u064A\u0631 \u0645\u062D\u0641\u0648\u0638
\u0645\u062D\u0641\u0648\u0638
\u062C\u0627\u0631\u064D \u0641\u062D\u0635 \u0628\u0646\u064A\u0629 \u0627\u0644\u0645\u0644\u0641\u2026
\u0625\u0644\u063A\u0627\u0621
\u0625\u063A\u0644\u0627\u0642
\u0623\u064F\u0644\u063A\u064A\u062A \u0627\u0644\u0639\u0645\u0644\u064A\u0629
\u0644\u0642\u0637\u0629
\u0645\u0631\u0627\u062C\u0639\u0629
\u062A\u0645 \u0627\u0644\u062D\u0641\u0638 \u0628\u0646\u062C\u0627\u062D
\u0647\u0630\u0647 \u0645\u0633\u0648\u062F\u0629 OEX \u062F\u0627\u062E\u0644\u064A\u0629. \u0627\u0633\u062A\u062E\u062F\u0645 \u0623\u0648\u0627\u0645\u0631 \u0625\u0646\u0634\u0627\u0621 \u0645\u0633\u062A\u0646\u062F \u0623\u0648 \u0645\u0635\u0646\u0641 Office \u0644\u0628\u062F\u0621 \u0645\u0644\u0641 \u0628\u0627\u0644\u0635\u064A\u063A\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u0645\u0629. \u0644\u0627 \u064A\u0632\u0627\u0644 \u0627\u0644\u062A\u0648\u0627\u0641\u0642 \u0627\u0644\u0643\u0627\u0645\u0644 \u0642\u064A\u062F \u0627\u0644\u062A\u0637\u0648\u064A\u0631.
\u0646\u0635 \u0627\u0644\u0645\u0633\u0648\u062F\u0629
\u062E\u0644\u0627\u064A\u0627 \u062C\u062F\u0648\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A
\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u0642\u064A\u0645 \u0648\u0627\u0644\u0635\u064A\u063A \u0648\u0627\u0644\u062A\u0646\u0633\u064A\u0642\u0627\u062A \u0645\u0646 \u062E\u0644\u0627\u0644 \u0634\u0628\u0643\u0629 \u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629. \u062A\u0628\u0642\u0649 \u0627\u0644\u0642\u064A\u0645 \u0627\u0644\u0645\u0635\u062F\u0631\u064A\u0629 \u0645\u0633\u062A\u0642\u0644\u0629 \u0639\u0646 \u0646\u062A\u0627\u0626\u062C \u0627\u0644\u062D\u0633\u0627\u0628.
\u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u0645\u0634\u0647\u062F \u0648\u0627\u062E\u062A\u0628\u0627\u0631 \u0645\u0648\u0636\u0639 \u0627\u0644\u0646\u0642\u0631
\u0625\u0636\u0627\u0641\u0629 \u0645\u0633\u062A\u0637\u064A\u0644
\u0627\u0646\u0642\u0631 \u0639\u0644\u0649 \u0634\u0643\u0644 \u0644\u0627\u062E\u062A\u0628\u0627\u0631 \u0627\u0644\u0625\u062D\u062F\u0627\u062B\u064A\u0627\u062A. \u064A\u062A\u0648\u0641\u0631 \u0627\u0644\u0645\u062D\u0631\u0631 \u0627\u0644\u0643\u0627\u0645\u0644 \u0641\u064A M4.
\u0623\u062C\u0632\u0627\u0621 \u0627\u0644\u062D\u0632\u0645\u0629 / \u0627\u0644\u062A\u062F\u0641\u0642\u0627\u062A
\u0627\u0644\u062C\u0632\u0621
\u0627\u0644\u062D\u062C\u0645
SHA-256
\u0625\u0635\u062F\u0627\u0631 \u0627\u0644\u0635\u064A\u063A\u0629
\u0627\u0644\u0635\u064A\u063A\u0629 \u0627\u0644\u0645\u0643\u062A\u0634\u0641\u0629
\u062D\u0641\u0638 \u0646\u0633\u062E\u0629 \u0645\u0637\u0627\u0628\u0642\u0629
\u0645\u062D\u0648\u0651\u0644 \u0627\u0644\u0645\u0639\u0627\u0646\u064A \u0642\u064A\u062F \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631
\u0645\u0633\u0648\u062F\u0627\u062A \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F
\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0646\u0633\u062E\u0629
\u062A\u062C\u0627\u0647\u0644
\u064A\u0646\u0634\u0626 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0646\u0633\u062E\u0629 \u062C\u062F\u064A\u062F\u0629 \u063A\u064A\u0631 \u0645\u062D\u0641\u0648\u0638\u0629 \u0648\u064A\u062D\u0627\u0641\u0638 \u0639\u0644\u0649 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0645\u0635\u062F\u0631.
\u0639\u064F\u0632\u0644\u062A \u0644\u0642\u0637\u0627\u062A \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0627\u0644\u062A\u0627\u0644\u0641\u0629 \u0648\u0644\u0645 \u062A\u064F\u062D\u0645\u0651\u0644.
\u062A\u0645 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0643\u0645\u0633\u0648\u062F\u0629 \u062C\u062F\u064A\u062F\u0629
\u0642\u064A\u062F \u0627\u0644\u0639\u0645\u0644
\u062A\u0642\u0631\u064A\u0631 \u0627\u0644\u062A\u0648\u0627\u0641\u0642
\u0644\u0627 \u062A\u0648\u062C\u062F \u0623\u062C\u0632\u0627\u0621 \u062D\u0627\u0648\u064A\u0629 \u0644\u0639\u0631\u0636\u0647\u0627.
\u0634\u0631\u064A\u062D\u0629 \u0641\u0627\u0631\u063A\u0629
\u0645\u064F\u0633\u062D \u0633\u062C\u0644 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0623\u062E\u064A\u0631\u0629
\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0633\u062A\u0646\u062F
\u064A\u0645\u0643\u0646 \u0641\u062A\u062D 32 \u0639\u0644\u0627\u0645\u0629 \u062A\u0628\u0648\u064A\u0628 \u0643\u062D\u062F \u0623\u0642\u0635\u0649
\u0645\u062D\u0631\u0643 \u0645\u0633\u062A\u0642\u0644 \xB7 \u062C\u062F\u0627\u0648\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A M3
\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u0645\u0644\u0641\u061B \u0644\u0643\u0646 \u0646\u0638\u0627\u0645 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0647\u0630\u0627 \u0644\u0645 \u064A\u0648\u0641\u0631 \u0636\u0645\u0627\u0646 \u0645\u0632\u0627\u0645\u0646\u0629 \u0627\u0644\u0645\u062C\u0644\u062F.
\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u0645\u0644\u0641\u060C \u0644\u0643\u0646 \u062A\u0639\u0630\u0631 \u062A\u062D\u062F\u064A\u062B \u0633\u062C\u0644\u0627\u062A \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0623\u0648 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0623\u062E\u064A\u0631\u0629.
\u0635\u0641\u062D\u0629 Office EX \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629
\u0627\u0644\u062A\u0646\u0642\u0644 \u0627\u0644\u0631\u0626\u064A\u0633\u064A
\u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A
\u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u0646\u062F
M3 \xB7 \u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u062A\u0637\u0648\u064A\u0631
OFFICE EX / \u0645\u0633\u0627\u062D\u0629 \u0639\u0645\u0644\u0643 \u0627\u0644\u0645\u062D\u0644\u064A\u0629
\u0627\u0644\u062A\u0646\u0633\u064A\u0642\u0627\u062A \u0627\u0644\u0625\u0642\u0644\u064A\u0645\u064A\u0629
\u0644\u063A\u0629 \u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0627\u0644\u062C\u062F\u064A\u062F\u0629 (\u062A\u0641\u0636\u064A\u0644)
\u062A\u0633\u062A\u062E\u062F\u0645 \u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0627\u0644\u0643\u0627\u062A\u0628 \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0644\u063A\u0629 \u0627\u0644\u0646\u0635 \u0647\u0630\u0647. \u062A\u0628\u0642\u0649 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u062D\u0627\u0644\u064A\u0629 \u0643\u0645\u0627 \u0647\u064A\u061B \u0648\u0633\u062A\u0639\u062A\u0645\u062F\u0647\u0627 \u0627\u0644\u0645\u062D\u0631\u0631\u0627\u062A \u0627\u0644\u0623\u062E\u0631\u0649 \u0644\u0627\u062D\u0642\u064B\u0627.
\u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u062A\u0646\u0633\u064A\u0642 \u0627\u0644\u0625\u0642\u0644\u064A\u0645\u064A
\u0627\u0644\u0633\u062C\u0644
\u0644\u0648\u062D\u0629 \u0627\u0644\u0631\u0633\u0645
{count} \u0639\u0646\u0635\u0631\u064B\u0627\u061B \u062A\u064F\u0639\u0631\u0636 \u0623\u0648\u0644 500 \u0641\u0642\u0637.
\u0645\u0644\u0641
\u062A\u062D\u0631\u064A\u0631
\u0639\u0631\u0636
\u0645\u0633\u0648\u062F\u0629 \u0645\u0633\u062A\u0646\u062F \u062C\u062F\u064A\u062F\u0629
\u0645\u0633\u0648\u062F\u0629 \u062C\u062F\u0648\u0644 \u0628\u064A\u0627\u0646\u0627\u062A \u062C\u062F\u064A\u062F\u0629
\u0645\u0633\u0648\u062F\u0629 \u0639\u0631\u0636 \u062A\u0642\u062F\u064A\u0645\u064A \u062C\u062F\u064A\u062F\u0629
\u0641\u062A\u062D\u2026
\u062D\u0641\u0638 \u0628\u0627\u0633\u0645\u2026
\u0625\u063A\u0644\u0627\u0642 \u0639\u0644\u0627\u0645\u0629 \u0627\u0644\u062A\u0628\u0648\u064A\u0628
\u0642\u0635
\u0646\u0633\u062E
\u0644\u0635\u0642
\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0643\u0644
\u062A\u0628\u062F\u064A\u0644 \u0645\u0644\u0621 \u0627\u0644\u0634\u0627\u0634\u0629
\u0625\u0639\u0627\u062F\u0629 \u0636\u0628\u0637 \u0627\u0644\u062A\u0643\u0628\u064A\u0631
\u062A\u0643\u0628\u064A\u0631
\u062A\u0635\u063A\u064A\u0631
\u0645\u0633\u062A\u0646\u062F\u0627\u062A Office / \u0645\u0633\u0648\u062F\u0627\u062A Office EX
\u062C\u0645\u064A\u0639 \u0627\u0644\u0645\u0644\u0641\u0627\u062A
\u0635\u064A\u063A\u0629 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0623\u0635\u0644\u064A\u0629
\u0647\u0644 \u062A\u0631\u064A\u062F \u0627\u0633\u062A\u0628\u062F\u0627\u0644 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0647\u062F\u0641 \u0627\u0644\u0645\u0648\u062C\u0648\u062F\u061F
\u0627\u0633\u062A\u0628\u062F\u0627\u0644
\u0647\u0644 \u062A\u0631\u064A\u062F \u062D\u0641\u0638 \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A \u0642\u0628\u0644 \u0627\u0644\u0625\u063A\u0644\u0627\u0642\u061F
\u062A\u062C\u0627\u0647\u0644 \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A
\u062A\u0639\u0630\u0631 \u0641\u062A\u062D \u0627\u0644\u0645\u0644\u0641
\u062A\u0639\u0630\u0631 \u0641\u062A\u062D \u0627\u0644\u0646\u0627\u0641\u0630\u0629
\u0623\u0643\u0645\u0644 \u0627\u0644\u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u062D\u0627\u0644\u064A \u0642\u0628\u0644 \u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0644\u063A\u0629.
\u0627\u0641\u062A\u062D \u0645\u0644\u0641\u064B\u0627 \u0645\u064F\u0641\u0644\u062A\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u0641\u064A \u0643\u0644 \u0645\u0631\u0629.
\u0627\u0644\u0645\u0644\u0641 \u0623\u0648 \u0627\u0644\u0637\u0644\u0628 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D.
\u0647\u0630\u0647 \u0627\u0644\u0645\u064A\u0632\u0629 \u0623\u0648 \u0627\u0644\u0635\u064A\u063A\u0629 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645\u0629 \u0628\u0639\u062F.
\u062D\u064F\u0638\u0631\u062A \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0644\u0623\u0633\u0628\u0627\u0628 \u062A\u062A\u0639\u0644\u0642 \u0628\u0627\u0644\u0623\u0645\u0627\u0646.
\u062A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u062D\u062F \u0627\u0644\u0645\u0648\u0627\u0631\u062F.
\u062A\u063A\u064A\u0631 \u0627\u0644\u0645\u0633\u062A\u0646\u062F \u0623\u0648 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0647\u062F\u0641.
\u0641\u0634\u0644\u062A \u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u0645\u0644\u0641.
\u062D\u062F\u062B \u062E\u0637\u0623 \u062F\u0627\u062E\u0644\u064A.
\u0648\u0631\u062F \u062A\u0634\u062E\u064A\u0635 \u062A\u0648\u0627\u0641\u0642 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641.
\u0641\u062D\u0635 \u0627\u0644\u062D\u0627\u0648\u064A\u0629 \u0641\u0642\u0637. \u0644\u0645 \u062A\u064F\u0633\u062A\u0648\u0631\u062F \u0645\u0639\u0627\u0646\u064A \u0627\u0644\u0645\u0633\u062A\u0646\u062F \u0627\u0644\u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u062A\u062D\u0631\u064A\u0631.
\u0627\u0643\u062A\u064F\u0634\u0641 \u0645\u062D\u062A\u0648\u0649 \u0645\u062A\u0639\u0644\u0642 \u0628\u0648\u062D\u062F\u0627\u062A \u0627\u0644\u0645\u0627\u0643\u0631\u0648. \u0644\u0627 \u062A\u064F\u0634\u063A\u0651\u0644 \u0648\u062D\u062F\u0627\u062A \u0627\u0644\u0645\u0627\u0643\u0631\u0648\u061B \u0648\u062A\u064F\u062D\u0641\u0638 \u0628\u0627\u064A\u062A\u0627\u062A\u0647\u0627 \u0641\u064A \u0627\u0644\u0646\u0633\u062E \u0627\u0644\u0645\u0637\u0627\u0628\u0642\u0629 \u0641\u0642\u0637.
\u0645\u0644\u0641 \u0645\u0648\u0642\u0651\u0639: \u0644\u0644\u0641\u062D\u0635 \u0641\u0642\u0637. \u0644\u0627 \u064A\u064F\u0624\u0643\u062F \u0635\u0644\u0627\u062D\u064A\u0629 \u0627\u0644\u062A\u0648\u0642\u064A\u0639.
\u062A\u064F\u0633\u062C\u0651\u0644 \u0627\u0644\u0639\u0644\u0627\u0642\u0627\u062A \u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629\u061B \u0648\u0644\u0627 \u064A\u064F\u062D\u0645\u0651\u0644 \u0623\u064A \u0645\u062D\u062A\u0648\u0649 \u062E\u0627\u0631\u062C\u064A.
\u0627\u0643\u062A\u064F\u0634\u0641\u062A \u0635\u064A\u063A\u0629 Strict OOXML\u061B \u0648\u0644\u0645 \u064A\u064F\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u0648\u0627\u0644\u0643\u062A\u0627\u0628\u0629 \u0627\u0644\u062F\u0644\u0627\u0644\u064A\u0629.
\u0627\u0643\u062A\u064F\u0634\u0641\u062A \u062D\u0627\u0648\u064A\u0629 \u0645\u0634\u0641\u0651\u0631\u0629. \u0641\u0643 \u0627\u0644\u062A\u0634\u0641\u064A\u0631 \u0648\u0627\u0644\u062A\u062D\u0631\u064A\u0631 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u064A\u0646.
\u064A\u062E\u062A\u0644\u0641 \u0627\u0645\u062A\u062F\u0627\u062F \u0627\u0644\u0645\u0644\u0641 \u0639\u0646 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0645\u0643\u062A\u0634\u0641.
\u062A\u0646\u0633\u064A\u0642 \u0627\u0644\u0646\u0635
\u062D\u0631\u0651\u0631 \u0627\u0644\u0641\u0642\u0631\u0627\u062A \u0648\u062D\u062F\u062F \u0627\u0644\u0646\u0635 \u0644\u062A\u0646\u0633\u064A\u0642\u0647. \u064A\u0642\u0633\u0645 Enter \u0627\u0644\u0641\u0642\u0631\u0629\u061B \u0648\u064A\u0636\u064A\u0641 Shift+Enter \u0641\u0627\u0635\u0644 \u0633\u0637\u0631.
\u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u0635\u0641\u062D\u0629
\u062A\u062E\u0637\u064A\u0637 \u062A\u0642\u0631\u064A\u0628\u064A \u0644\u0644\u0635\u0641\u062D\u0629. \u0627\u0646\u0642\u0631 \u0639\u0644\u0649 \u0627\u0644\u0635\u0641\u062D\u0629 \u0644\u062A\u062D\u062F\u064A\u062F \u0645\u0648\u0642\u0639 \u0627\u0644\u0646\u0635. \u0644\u0645 \u064A\u064F\u062A\u062D\u0642\u0642 \u0628\u0639\u062F \u0645\u0646 \u062F\u0642\u0629 \u0627\u0644\u0637\u0628\u0627\u0639\u0629.
\u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629
\u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629
\u0627\u0644\u0635\u0641\u062D\u0629 {current} / {total}
\u0628\u0639\u0636 \u062E\u0635\u0627\u0626\u0635 \u0627\u0644\u062E\u0637 \u0623\u0648 \u0627\u0644\u062A\u062E\u0637\u064A\u0637 \u062A\u0642\u0631\u064A\u0628\u064A\u0629.
\u0627\u0644\u0645\u0639\u0627\u064A\u0646\u0629 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0623\u0648 \u0628\u0633\u0628\u0628 \u062D\u062F \u0627\u0644\u062A\u062E\u0637\u064A\u0637. \u064A\u0628\u0642\u0649 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0645\u0635\u062F\u0631 \u0643\u0645\u0627 \u0647\u0648.
\u063A\u0627\u0645\u0642
\u0645\u0627\u0626\u0644
\u062A\u0633\u0637\u064A\u0631
\u0645\u062D\u0627\u0630\u0627\u0629 \u0625\u0644\u0649 \u0627\u0644\u064A\u0633\u0627\u0631
\u062A\u0648\u0633\u064A\u0637
\u0645\u062D\u0627\u0630\u0627\u0629 \u0625\u0644\u0649 \u0627\u0644\u064A\u0645\u064A\u0646
\u062A\u0642\u0633\u064A\u0645 \u0627\u0644\u0641\u0642\u0631\u0629
\u0641\u0627\u0635\u0644 \u0635\u0641\u062D\u0629 \u0628\u0639\u062F \u0627\u0644\u0641\u0642\u0631\u0629
\u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u062D\u0631\u064A\u0631 \u0647\u0630\u0647 \u0627\u0644\u0643\u062A\u0644\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0645\u0639\u0627\u064A\u0646\u0629.
\u0645\u0633\u062A\u0646\u062F DOCX \u062C\u062F\u064A\u062F
\u0645\u0633\u062A\u0646\u062F DOCX
\u0646\u0637\u0627\u0642 DOCX \u0645\u062D\u062F\u0648\u062F: \u0646\u0635 \u0648\u062A\u0646\u0633\u064A\u0642 \u0645\u0628\u0627\u0634\u0631 \u0648\u0623\u0646\u0645\u0627\u0637 \u0645\u0633\u0645\u0627\u0629 \u0645\u062F\u0639\u0648\u0645\u0629 \u0648\u062C\u062F\u0627\u0648\u0644 \u0645\u0633\u062A\u0637\u064A\u0644\u0629 \u062B\u0627\u0628\u062A\u0629 \u0648\u0635\u0648\u0631 PNG/JPEG \u0645\u0636\u0645\u0646\u0629 \u0636\u0645\u0646 \u0627\u0644\u0633\u0637\u0631 \u0648\u062A\u062E\u0637\u064A\u0637 \u0623\u0633\u0627\u0633\u064A. \u062A\u0628\u0642\u0649 \u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0627\u0644\u0645\u0639\u0642\u062F\u0629 \u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637.
\u0627\u0644\u062E\u0637
\u0627\u0644\u062D\u062C\u0645 (\u0646\u0642\u0637\u0629)
\u0644\u0648\u0646 \u0627\u0644\u0646\u0635
\u0646\u0645\u0637 \u0627\u0644\u0641\u0642\u0631\u0629
\u0646\u0645\u0637 \u0627\u0644\u0623\u062D\u0631\u0641
\u0627\u062E\u062A\u064A\u0627\u0631 \u0646\u0645\u0637
\u062C\u062F\u0648\u0644
\u0627\u0644\u0635\u0641\u0648\u0641
\u0627\u0644\u0623\u0639\u0645\u062F\u0629
\u0625\u062F\u0631\u0627\u062C \u062C\u062F\u0648\u0644
\u0625\u0636\u0627\u0641\u0629 \u0635\u0641 \u0623\u0633\u0641\u0644
\u062D\u0630\u0641 \u0627\u0644\u0635\u0641
\u0625\u0636\u0627\u0641\u0629 \u0639\u0645\u0648\u062F \u064A\u0645\u064A\u0646\u064B\u0627
\u062D\u0630\u0641 \u0627\u0644\u0639\u0645\u0648\u062F
\u0639\u0631\u0636 \u0627\u0644\u0639\u0645\u0648\u062F (\u0646\u0642\u0637\u0629)
\u062D\u062F\u0648\u062F \u0627\u0644\u062C\u062F\u0648\u0644
\u062D\u0630\u0641 \u0627\u0644\u062C\u062F\u0648\u0644
\u0627\u0644\u062E\u0644\u064A\u0629 {row}\u060C {column}
\u0625\u062F\u0631\u0627\u062C \u0635\u0648\u0631\u0629
\u0635\u0648\u0631\u0629
\u0639\u0631\u0636 \u0627\u0644\u0635\u0648\u0631\u0629 (\u0646\u0642\u0637\u0629)
\u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0635\u0648\u0631\u0629
\u062D\u062C\u0645 \u0627\u0644\u0648\u0631\u0642
\u0645\u062E\u0635\u0635
A4
Letter
A3
\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0635\u0641\u062D\u0629
\u0639\u0645\u0648\u062F\u064A
\u0623\u0641\u0642\u064A
\u0639\u0631\u0636 \u0627\u0644\u0635\u0641\u062D\u0629 (\u0646\u0642\u0637\u0629)
\u0627\u0631\u062A\u0641\u0627\u0639 \u0627\u0644\u0635\u0641\u062D\u0629 (\u0646\u0642\u0637\u0629)
\u0627\u0644\u0647\u0627\u0645\u0634 \u0627\u0644\u0639\u0644\u0648\u064A (\u0646\u0642\u0637\u0629)
\u0627\u0644\u0647\u0627\u0645\u0634 \u0627\u0644\u0623\u064A\u0645\u0646 (\u0646\u0642\u0637\u0629)
\u0627\u0644\u0647\u0627\u0645\u0634 \u0627\u0644\u0633\u0641\u0644\u064A (\u0646\u0642\u0637\u0629)
\u0627\u0644\u0647\u0627\u0645\u0634 \u0627\u0644\u0623\u064A\u0633\u0631 (\u0646\u0642\u0637\u0629)
\u062A\u0637\u0628\u064A\u0642 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0635\u0641\u062D\u0629
\u0627\u0644\u0645\u0633\u0627\u0641\u0629 \u0627\u0644\u0628\u0627\u062F\u0626\u0629 (\u0646\u0642\u0637\u0629)
\u0642\u0628\u0644 (\u0646\u0642\u0637\u0629)
\u0628\u0639\u062F (\u0646\u0642\u0637\u0629)
\u0627\u0631\u062A\u0641\u0627\u0639 \u0627\u0644\u0633\u0637\u0631 (\u0646\u0642\u0637\u0629\u061B 0 = \u062A\u0644\u0642\u0627\u0626\u064A)
\u0625\u062F\u0631\u0627\u062C \u0635\u0648\u0631\u0629 \u0639\u0646\u062F \u0627\u0644\u0645\u0624\u0634\u0631
\u062A\u0645\u062B\u0644 \u0639\u0644\u0627\u0645\u0629 \u0627\u0644\u0643\u0627\u0626\u0646 \u0635\u0648\u0631\u0629 \u0636\u0645\u0646 \u0627\u0644\u0633\u0637\u0631. \u0627\u0633\u062A\u062E\u062F\u0645 \u0639\u0646\u0627\u0635\u0631 \u0627\u0644\u062A\u062D\u0643\u0645 \u0628\u0627\u0644\u0635\u0648\u0631\u0629 \u0644\u062A\u063A\u064A\u064A\u0631 \u062D\u062C\u0645\u0647\u0627 \u0623\u0648 \u0625\u0632\u0627\u0644\u062A\u0647\u0627.
\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u0646\u0635 \u0627\u0644\u0645\u062A\u0635\u0644
\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0645\u062D\u0631\u0631 \u0627\u0644\u0641\u0642\u0631\u0627\u062A
\u062D\u062F\u062F \u0627\u0644\u0646\u0635 \u0623\u0648 \u0627\u0646\u0633\u062E\u0647 \u0623\u0648 \u0642\u0635\u0647 \u0623\u0648 \u0627\u0644\u0635\u0642\u0647 \u0623\u0648 \u0646\u0633\u0642\u0647 \u0639\u0628\u0631 \u0641\u0642\u0631\u0627\u062A \u0646\u0635\u064A\u0629 \u0645\u062A\u062C\u0627\u0648\u0631\u0629. \u062A\u062D\u062F \u0627\u0644\u062C\u062F\u0627\u0648\u0644 \u0648\u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0635\u0641\u062D\u0627\u062A \u0648\u0627\u0644\u0645\u0642\u0627\u0637\u0639 \u0648\u0641\u0642\u0631\u0627\u062A \u0627\u0644\u0635\u0648\u0631 \u0646\u0637\u0627\u0642 \u0627\u0644\u062A\u062D\u062F\u064A\u062F. \u062A\u0635\u0628\u062D \u0627\u0644\u0623\u0633\u0637\u0631 \u0627\u0644\u0645\u0644\u0635\u0642\u0629 \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0641\u0642\u0631\u0627\u062A.
\u0645\u0642\u0637\u0639
\u0627\u0644\u0645\u0642\u0637\u0639 {number}
\u0641\u0627\u0635\u0644 \u0645\u0642\u0637\u0639 \u0641\u064A \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629
\u0644\u063A\u0629 \u0627\u0644\u0646\u0635 (BCP 47)
\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0641\u0642\u0631\u0629
\u0645\u0646 \u0627\u0644\u064A\u0633\u0627\u0631 \u0625\u0644\u0649 \u0627\u0644\u064A\u0645\u064A\u0646
\u0645\u0646 \u0627\u0644\u064A\u0645\u064A\u0646 \u0625\u0644\u0649 \u0627\u0644\u064A\u0633\u0627\u0631
DOC \u062C\u062F\u064A\u062F
\u0645\u0633\u062A\u0646\u062F Word 97\u20132003
\u062A\u062D\u0631\u064A\u0631 DOC \u0645\u062D\u062F\u0648\u062F: \u0646\u0635 Unicode \u0648\u0623\u0646\u0645\u0627\u0637 \u0623\u0633\u0627\u0633\u064A\u0629 \u0648\u0645\u0642\u0637\u0639 \u0648\u0627\u062D\u062F. \u062A\u0628\u0642\u0649 \u0645\u0644\u0641\u0627\u062A DOC \u063A\u064A\u0631 \u0627\u0644\u0645\u062F\u0639\u0648\u0645\u0629 \u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637\u061B \u0648\u0644\u0627 \u064A\u0645\u0643\u0646 \u062D\u0641\u0638 \u0627\u0644\u062C\u062F\u0627\u0648\u0644 \u0648\u0627\u0644\u0635\u0648\u0631 \u0636\u0645\u0646 \u0647\u0630\u0627 \u0627\u0644\u0646\u0637\u0627\u0642.
\u0645\u0639\u0627\u064A\u0646\u0629 \u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637 \u0644\u0646\u0635 \u0627\u0644\u0645\u062A\u0646 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u060C \u0648\u0644\u064A\u0633\u062A \u062A\u062E\u0637\u064A\u0637 \u0627\u0644\u0645\u0633\u062A\u0646\u062F \u0627\u0644\u0643\u0627\u0645\u0644. \u064A\u062D\u0627\u0641\u0638 \u062D\u0641\u0638 \u0646\u0633\u062E\u0629 \u0639\u0644\u0649 \u0627\u0644\u0628\u0627\u064A\u062A\u0627\u062A \u0627\u0644\u0623\u0635\u0644\u064A\u0629.
\u062A\u062D\u0648\u064A\u0644 \u0625\u0644\u0649 DOC
\u062A\u062D\u0648\u064A\u0644 \u0625\u0644\u0649 DOCX
\u064A\u062A\u0637\u0644\u0628 \u0627\u0644\u062A\u062D\u0648\u064A\u0644 \u0645\u0633\u062A\u0646\u062F\u064B\u0627 \u064A\u062D\u062A\u0648\u064A \u0641\u0642\u0637 \u0639\u0644\u0649 \u0627\u0644\u0628\u0646\u0649 \u0627\u0644\u0645\u062F\u0639\u0648\u0645\u0629\u061B \u0648\u062A\u0628\u0642\u0649 \u0627\u0644\u0623\u062C\u0632\u0627\u0621 \u063A\u064A\u0631 \u0627\u0644\u0645\u0641\u0647\u0648\u0645\u0629 \u0645\u062D\u0641\u0648\u0638\u0629 \u0641\u064A \u0627\u0644\u0645\u0635\u062F\u0631 \u0648\u0644\u0627 \u062A\u064F\u062D\u0630\u0641.
\u0627\u0644\u062A\u062D\u0631\u064A\u0631 \u0639\u0644\u0649 \u0627\u0644\u0635\u0641\u062D\u0629
\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u0623\u062F\u0648\u0627\u062A
\u062D\u0631\u0651\u0631 \u0639\u0644\u0649 \u0627\u0644\u0635\u0641\u062D\u0629 \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u062A\u0634\u0643\u064A\u0644 \u0627\u0644\u0646\u0635 \u0627\u0644\u0623\u0635\u0644\u064A \u0644\u0644\u0645\u062A\u0635\u0641\u062D. \u0627\u0633\u062D\u0628 \u0644\u0644\u062A\u062D\u062F\u064A\u062F\u061B \u0648\u064A\u062D\u0627\u0641\u0638 \u0627\u0644\u0646\u0633\u062E \u0648\u0627\u0644\u0644\u0635\u0642 \u0639\u0644\u0649 \u062A\u0646\u0633\u064A\u0642 Office EX \u0648\u0627\u0644\u0635\u0648\u0631 \u0627\u0644\u0645\u062F\u0639\u0648\u0645\u0629. \u0644\u0645 \u062A\u064F\u062A\u062D\u0642\u0642 \u0628\u0639\u062F \u062F\u0642\u0629 \u0627\u0644\u0635\u0641\u062D\u0629 \u0628\u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629 \u0645\u0639 Word.
`), ...sheetsCatalog(`
\u0645\u0635\u0646\u0641 XLSX \u062C\u062F\u064A\u062F
\u0645\u0635\u0646\u0641 Excel \u200F(.xlsx)
\u062D\u0631\u0651\u0631 \u062E\u0644\u0627\u064A\u0627 \u0627\u0644\u0645\u0635\u0646\u0641 \u0648\u0635\u064A\u063A\u0647 \u0648\u0623\u0646\u0645\u0627\u0637\u0647 \u0627\u0644\u0645\u062F\u0639\u0648\u0645\u0629. \u062A\u064F\u0641\u062A\u062D \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0645\u062D\u0645\u064A\u0629 \u0623\u0648 \u0630\u0627\u062A \u0627\u0644\u062A\u0628\u0639\u064A\u0627\u062A \u063A\u064A\u0631 \u0627\u0644\u0645\u062F\u0639\u0648\u0645\u0629 \u0643\u0645\u0639\u0627\u064A\u0646\u0627\u062A \u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637 \u0645\u0639 \u0627\u0644\u062D\u0641\u0627\u0638 \u0639\u0644\u0649 \u0627\u0644\u0623\u0635\u0644.
\u0645\u0635\u0646\u0641 Excel 97\u20132003 \u062C\u062F\u064A\u062F
\u0645\u0635\u0646\u0641 Excel 97\u20132003 \u200F(.xls)
\u0645\u0635\u0646\u0641 BIFF8: \u062D\u062A\u0649 65,536 \u0635\u0641\u064B\u0627 \u0648256 \u0639\u0645\u0648\u062F\u064B\u0627. \u062A\u064F\u0641\u062D\u0635 \u0627\u0644\u0635\u064A\u063A \u0648\u0627\u0644\u0623\u0646\u0645\u0627\u0637 \u0648\u062A\u0628\u0639\u064A\u0627\u062A \u0627\u0644\u0645\u0635\u062F\u0631 \u0642\u0628\u0644 \u0627\u0644\u062D\u0641\u0638 \u0648\u0627\u0644\u062A\u062D\u0648\u064A\u0644.
\u062A\u062D\u0648\u064A\u0644 \u0625\u0644\u0649 \u0646\u0633\u062E\u0629 XLSX
\u062A\u062D\u0648\u064A\u0644 \u0625\u0644\u0649 \u0646\u0633\u062E\u0629 XLS
\u0634\u0628\u0643\u0629 \u062C\u062F\u0648\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A
\u0642\u064A\u0645\u0629 \u0627\u0644\u062E\u0644\u064A\u0629 \u0623\u0648 \u0635\u064A\u063A\u062A\u0647\u0627
\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062E\u0644\u064A\u0629 \u0623\u0648 \u0627\u0644\u0646\u0637\u0627\u0642
\u0625\u0636\u0627\u0641\u0629 \u0648\u0631\u0642\u0629
\u0625\u0639\u0627\u062F\u0629 \u062A\u0633\u0645\u064A\u0629 \u0627\u0644\u0648\u0631\u0642\u0629
\u062D\u0630\u0641 \u0627\u0644\u0648\u0631\u0642\u0629
\u062A\u0642\u062F\u064A\u0645 \u0627\u0644\u0648\u0631\u0642\u0629
\u062A\u0623\u062E\u064A\u0631 \u0627\u0644\u0648\u0631\u0642\u0629
\u0627\u0633\u0645 \u0627\u0644\u0648\u0631\u0642\u0629
\u0627\u0644\u0623\u0648\u0631\u0627\u0642 \u0648\u0627\u0644\u0635\u0641\u0648\u0641 \u0648\u0627\u0644\u0623\u0639\u0645\u062F\u0629
\u062F\u0645\u062C \u0627\u0644\u062E\u0644\u0627\u064A\u0627
\u0625\u0644\u063A\u0627\u0621 \u062F\u0645\u062C \u0627\u0644\u062E\u0644\u0627\u064A\u0627
\u0645\u0633\u062D \u0627\u0644\u0642\u064A\u0645
\u0625\u062F\u0631\u0627\u062C \u0635\u0641\u0648\u0641
\u062D\u0630\u0641 \u0635\u0641\u0648\u0641
\u0625\u062F\u0631\u0627\u062C \u0623\u0639\u0645\u062F\u0629
\u062D\u0630\u0641 \u0623\u0639\u0645\u062F\u0629
\u0627\u0631\u062A\u0641\u0627\u0639 \u0627\u0644\u0635\u0641 (\u0628\u0643\u0633\u0644)
\u0639\u0631\u0636 \u0627\u0644\u0639\u0645\u0648\u062F (\u0628\u0643\u0633\u0644)
\u062A\u0646\u0633\u064A\u0642 \u0627\u0644\u0623\u0631\u0642\u0627\u0645
\u0639\u0627\u0645
\u0631\u0642\u0645
\u0646\u0633\u0628\u0629 \u0645\u0626\u0648\u064A\u0629
\u0639\u0645\u0644\u0629
\u062A\u0627\u0631\u064A\u062E
\u0648\u0642\u062A
\u0639\u0644\u0645\u064A
\u0631\u0645\u0632 \u062A\u0646\u0633\u064A\u0642 \u0645\u062E\u0635\u0635
\u062A\u0639\u0628\u0626\u0629 \u0627\u0644\u062E\u0644\u064A\u0629
\u0627\u0644\u062A\u0641\u0627\u0641 \u0627\u0644\u0646\u0635
\u062D\u062F\u0648\u062F \u0627\u0644\u062E\u0644\u0627\u064A\u0627
\u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0635\u064A\u063A
\u0623\u0633\u0645\u0627\u0621 \u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629 \xB7 \u0646\u0642\u0637\u0629 \u0639\u0634\u0631\u064A\u0629
\u0623\u0633\u0645\u0627\u0621 \u0648\u0641\u0648\u0627\u0635\u0644 \u0625\u0642\u0644\u064A\u0645\u064A\u0629
\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062D\u0633\u0627\u0628
\u062C\u0627\u0631\u064D \u0627\u0644\u062D\u0633\u0627\u0628\u2026
\u062A\u0645 \u0627\u0644\u062D\u0633\u0627\u0628
\u0644\u0645 \u062A\u064F\u062D\u0633\u0628: \u0635\u064A\u063A\u0629 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645\u0629
\u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629: \u064A\u0644\u0632\u0645 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062D\u0633\u0627\u0628
\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u0635\u064A\u063A\u0629
\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u062D\u0633\u0627\u0628
{count} \u062E\u0644\u0627\u064A\u0627 \u0631\u0642\u0645\u064A\u0629 \xB7 \u0627\u0644\u0645\u062C\u0645\u0648\u0639 {sum}
\u0627\u0644\u062A\u062D\u062F\u064A\u062F {address}
\u0627\u0646\u0642\u0631 \u0623\u0648 \u0627\u0633\u062D\u0628 \u0644\u0644\u062A\u062D\u062F\u064A\u062F. \u0627\u0643\u062A\u0628 \u0623\u0648 \u0627\u0636\u063A\u0637 F2 \u0644\u0644\u062A\u062D\u0631\u064A\u0631\u061B \u064A\u0624\u0643\u062F Enter \u0648\u064A\u0644\u063A\u064A Esc. \u064A\u0648\u0633\u0651\u0639 Shift \u0627\u0644\u062A\u062D\u062F\u064A\u062F. \u0627\u0646\u0633\u062E \u0627\u0644\u0646\u0637\u0627\u0642\u0627\u062A \u0648\u0627\u0644\u0635\u0642\u0647\u0627 \u0628\u0635\u064A\u063A\u0629 TSV. \u062A\u0628\u062F\u0623 \u0627\u0644\u0635\u064A\u063A \u0628\u0639\u0644\u0627\u0645\u0629 =.
\u062A\u062C\u0645\u064A\u062F \u0639\u0646\u062F \u0627\u0644\u062A\u062D\u062F\u064A\u062F
\u0625\u0644\u063A\u0627\u0621 \u062A\u062C\u0645\u064A\u062F \u0627\u0644\u0623\u062C\u0632\u0627\u0621
\u0648\u0631\u0642\u0629 \u0645\u0646 \u0627\u0644\u064A\u0645\u064A\u0646 \u0625\u0644\u0649 \u0627\u0644\u064A\u0633\u0627\u0631
\u0625\u0638\u0647\u0627\u0631 \u062E\u0637\u0648\u0637 \u0627\u0644\u0634\u0628\u0643\u0629
\u0646\u0638\u0627\u0645 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u0635\u0646\u0641
\u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u0645\u0635\u0646\u0641 \u0627\u0644\u0645\u062D\u0641\u0648\u0638 \u0628\u0623\u0635\u0644\u0647
\u064A\u062D\u062A\u0648\u064A \u0647\u0630\u0627 \u0627\u0644\u0645\u0635\u0646\u0641 \u0639\u0644\u0649 \u062A\u0628\u0639\u064A\u0627\u062A \u062E\u0627\u0631\u062C \u0646\u0637\u0627\u0642 \u0627\u0644\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u0645\u062F\u0639\u0648\u0645. \u064A\u0645\u0643\u0646\u0643 \u0641\u062D\u0635 \u0627\u0644\u062E\u0644\u0627\u064A\u0627 \u0648\u062D\u0641\u0638 \u0646\u0633\u062E\u0629 \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0644\u0623\u0635\u0644.
\u062D\u064F\u0638\u0631 \u0627\u0644\u062A\u062D\u0648\u064A\u0644 \u0644\u0623\u0646 \u062A\u0628\u0639\u064A\u0627\u062A \u0627\u0644\u0645\u0635\u062F\u0631 \u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0645\u062B\u064A\u0644\u0647\u0627 \u0628\u0623\u0645\u0627\u0646 \u0641\u064A \u0627\u0644\u0635\u064A\u063A\u0629 \u0627\u0644\u0647\u062F\u0641.
\u0641\u064A \u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062D\u0633\u0627\u0628
\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u062F\u062E\u0627\u0644 \u0647\u0630\u0647 \u0627\u0644\u0642\u064A\u0645\u0629 \u0623\u0648 \u0627\u0644\u0635\u064A\u063A\u0629 \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0648\u0636\u0639 \u0627\u0644\u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0645\u062D\u062F\u062F.
\u0639\u0631\u0636
\u062A\u0637\u0628\u064A\u0642
\u062A\u0646\u0633\u064A\u0642 \u0627\u0644\u062E\u0644\u0627\u064A\u0627
\u062A\u0639\u0628\u0626\u0629 \u0644\u0623\u0633\u0641\u0644
\u062A\u0639\u0628\u0626\u0629 \u0644\u0644\u064A\u0645\u064A\u0646
`) };
var hebrew = { ...baseCatalog(`
\u05E4\u05EA\u05D9\u05D7\u05EA \u05E7\u05D5\u05D1\u05E5
\u05D8\u05D9\u05D5\u05D8\u05D4 \u05D7\u05D3\u05E9\u05D4
\u05E7\u05D1\u05E6\u05D9\u05DD \u05D0\u05D7\u05E8\u05D5\u05E0\u05D9\u05DD
\u05E1\u05D1\u05D9\u05D1\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u05DE\u05E7\u05D5\u05DE\u05D9\u05EA \xB7 \u05E2\u05D1\u05D5\u05D3\u05D4 \u05DC\u05D0 \u05DE\u05E7\u05D5\u05D5\u05E0\u05EA \u05EA\u05D7\u05D9\u05DC\u05D4
\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA
\u05E1\u05D1\u05D9\u05D1\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4
\u05D1\u05D9\u05D8\u05D5\u05DC \u05E4\u05E2\u05D5\u05DC\u05D4
\u05D1\u05D9\u05E6\u05D5\u05E2 \u05D7\u05D5\u05D6\u05E8
\u05E9\u05DE\u05D9\u05E8\u05D4 \u05D1\u05E9\u05DD
\u05E9\u05DE\u05D9\u05E8\u05D4
\u05DE\u05D5\u05DB\u05DF
\u05DE\u05E8\u05D0\u05D4
\u05DE\u05E2\u05E8\u05DB\u05EA
\u05D1\u05D4\u05D9\u05E8
\u05DB\u05D4\u05D4
\u05E9\u05E4\u05D4
\u05E0\u05D9\u05E7\u05D5\u05D9 \u05D4\u05E7\u05D1\u05E6\u05D9\u05DD \u05D4\u05D0\u05D7\u05E8\u05D5\u05E0\u05D9\u05DD
\u05D4\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05D5\u05EA\u05DE\u05D5\u05E0\u05D5\u05EA \u05D4\u05DE\u05E6\u05D1 \u05DC\u05E9\u05D7\u05D6\u05D5\u05E8 \u05E0\u05E9\u05D0\u05E8\u05D5\u05EA \u05D1\u05DE\u05D7\u05E9\u05D1 \u05D6\u05D4.
\u05DE\u05E7\u05D5\u05DD \u05DC\u05DE\u05E1\u05DE\u05DB\u05D9\u05DD \u05E9\u05DC\u05DA.
\u05D7\u05D1\u05D9\u05DC\u05EA \u05D9\u05D9\u05E9\u05D5\u05DE\u05D9\u05DD \u05DE\u05E9\u05E8\u05D3\u05D9\u05D9\u05DD \u05E2\u05E6\u05DE\u05D0\u05D9\u05EA \u05DC\u05E9\u05D5\u05DC\u05D7\u05DF \u05D4\u05E2\u05D1\u05D5\u05D3\u05D4. \u05EA\u05E6\u05D5\u05D2\u05EA M3 \u05DB\u05D5\u05DC\u05DC\u05EA \u05E2\u05D5\u05E8\u05DA \u05DE\u05E1\u05DE\u05DB\u05D9\u05DD \u05DE\u05D5\u05D2\u05D1\u05DC, \u05D2\u05D9\u05DC\u05D9\u05D5\u05E0\u05D5\u05EA \u05D0\u05DC\u05E7\u05D8\u05E8\u05D5\u05E0\u05D9\u05D9\u05DD, \u05E0\u05D5\u05E1\u05D7\u05D0\u05D5\u05EA \u05D5\u05E9\u05DE\u05D9\u05E8\u05D4 \u05DE\u05D1\u05D5\u05E7\u05E8\u05EA \u05D1\u05E4\u05D5\u05E8\u05DE\u05D8\u05D9 Office \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD.
\u05D9\u05E6\u05D9\u05E8\u05EA \u05D8\u05D9\u05D5\u05D8\u05D4 \u05DE\u05E7\u05D5\u05DE\u05D9\u05EA
\u05E4\u05D5\u05E8\u05DE\u05D8 \u05D8\u05D9\u05D5\u05D8\u05D4 \u05E4\u05E0\u05D9\u05DE\u05D9 \xB7 \u200E.oex
\u05DE\u05E1\u05DE\u05DA
\u05D2\u05D9\u05DC\u05D9\u05D5\u05DF \u05D0\u05DC\u05E7\u05D8\u05E8\u05D5\u05E0\u05D9
\u05DE\u05E6\u05D2\u05EA
\u05DE\u05D5\u05D3\u05DC \u05D8\u05E7\u05E1\u05D8 \u05D5\u05E4\u05E2\u05D5\u05DC\u05D5\u05EA \u05D4\u05E0\u05D9\u05EA\u05E0\u05D5\u05EA \u05DC\u05D1\u05D9\u05D8\u05D5\u05DC
\u05EA\u05D0\u05D9\u05DD \u05D3\u05DC\u05D9\u05DC\u05D9\u05DD \u05D5\u05E4\u05E7\u05D5\u05D3\u05D5\u05EA \u05D1\u05D0\u05E6\u05D5\u05D5\u05D4
\u05DE\u05D5\u05D3\u05DC \u05E1\u05E6\u05E0\u05D4 \u05D5\u05E7\u05D5\u05D0\u05D5\u05E8\u05D3\u05D9\u05E0\u05D8\u05D5\u05EA
\u05E4\u05EA\u05D9\u05D7\u05EA \u05E7\u05D5\u05D1\u05E5 \u05D0\u05D5 \u05D2\u05E8\u05D9\u05E8\u05EA\u05D5 \u05DC\u05DB\u05D0\u05DF
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 \u05D8\u05D9\u05D5\u05D8\u05D5\u05EA Office EX
\u05D1\u05D7\u05D9\u05E8\u05EA \u05E7\u05D5\u05D1\u05E5
\u05E0\u05D9\u05EA\u05DF \u05DC\u05E2\u05E8\u05D5\u05DA \u05D5\u05DC\u05E9\u05DE\u05D5\u05E8 \u05DE\u05E1\u05DE\u05DB\u05D9\u05DD \u05D5\u05D7\u05D5\u05D1\u05E8\u05D5\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u05D1\u05D8\u05D5\u05D5\u05D7 \u05D4\u05E0\u05EA\u05DE\u05DA. \u05DE\u05D1\u05E0\u05D9\u05DD \u05E9\u05D0\u05D9\u05E0\u05DD \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD \u05E0\u05E4\u05EA\u05D7\u05D9\u05DD \u05DC\u05E7\u05E8\u05D9\u05D0\u05D4 \u05D1\u05DC\u05D1\u05D3, \u05E2\u05DD \u05D0\u05E4\u05E9\u05E8\u05D5\u05EA \u05DC\u05E9\u05DE\u05D5\u05E8 \u05E2\u05D5\u05EA\u05E7 \u05D6\u05D4\u05D4 \u05DC\u05DE\u05E7\u05D5\u05E8; \u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05DE\u05DC\u05D0\u05D4 \u05E2\u05D3\u05D9\u05D9\u05DF \u05D1\u05E4\u05D9\u05EA\u05D5\u05D7.
\u05EA\u05E9\u05EA\u05D9\u05EA \u05E4\u05D5\u05E8\u05DE\u05D8\u05D9\u05DD
\u05D4\u05DE\u05DB\u05DC \u05DE\u05D7\u05D5\u05D1\u05E8
\u05E4\u05D5\u05E8\u05DE\u05D8\u05D9\u05DD \u05D7\u05D3\u05E9\u05D9\u05DD
\u05E4\u05D5\u05E8\u05DE\u05D8\u05D9\u05DD \u05D9\u05E9\u05E0\u05D9\u05DD
\u05D8\u05D9\u05D5\u05D8\u05D5\u05EA \u05DE\u05E7\u05D5\u05DE\u05D9\u05D5\u05EA
\u05D0\u05D9\u05DF \u05E7\u05D1\u05E6\u05D9\u05DD \u05D0\u05D7\u05E8\u05D5\u05E0\u05D9\u05DD
\u05DC\u05DC\u05D0 \u05DB\u05D5\u05EA\u05E8\u05EA
\u05D8\u05D9\u05D5\u05D8\u05EA Office EX
\u05DC\u05E7\u05E8\u05D9\u05D0\u05D4 \u05D1\u05DC\u05D1\u05D3 \xB7 \u05D1\u05D3\u05D9\u05E7\u05EA \u05DE\u05D1\u05E0\u05D4
\u05DC\u05D0 \u05E0\u05E9\u05DE\u05E8
\u05E0\u05E9\u05DE\u05E8
\u05DE\u05D1\u05E0\u05D4 \u05D4\u05E7\u05D5\u05D1\u05E5 \u05E0\u05D1\u05D3\u05E7\u2026
\u05D1\u05D9\u05D8\u05D5\u05DC
\u05E1\u05D2\u05D9\u05E8\u05D4
\u05D4\u05E4\u05E2\u05D5\u05DC\u05D4 \u05D1\u05D5\u05D8\u05DC\u05D4
\u05EA\u05DE\u05D5\u05E0\u05EA \u05DE\u05E6\u05D1
\u05D2\u05E8\u05E1\u05D4
\u05E0\u05E9\u05DE\u05E8 \u05D1\u05D4\u05E6\u05DC\u05D7\u05D4
\u05D6\u05D5 \u05D8\u05D9\u05D5\u05D8\u05EA OEX \u05E4\u05E0\u05D9\u05DE\u05D9\u05EA. \u05D4\u05E9\u05EA\u05DE\u05E9\u05D5 \u05D1\u05E4\u05E7\u05D5\u05D3\u05D5\u05EA \u05DC\u05D9\u05E6\u05D9\u05E8\u05EA \u05DE\u05E1\u05DE\u05DA \u05D0\u05D5 \u05D7\u05D5\u05D1\u05E8\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u05E9\u05DC Office \u05DB\u05D3\u05D9 \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05E7\u05D5\u05D1\u05E5 \u05D1\u05E4\u05D5\u05E8\u05DE\u05D8 \u05E0\u05EA\u05DE\u05DA. \u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05DE\u05DC\u05D0\u05D4 \u05E2\u05D3\u05D9\u05D9\u05DF \u05D1\u05E4\u05D9\u05EA\u05D5\u05D7.
\u05D8\u05E7\u05E1\u05D8 \u05D4\u05D8\u05D9\u05D5\u05D8\u05D4
\u05EA\u05D0\u05D9 \u05D4\u05D2\u05D9\u05DC\u05D9\u05D5\u05DF \u05D4\u05D0\u05DC\u05E7\u05D8\u05E8\u05D5\u05E0\u05D9
\u05E2\u05E8\u05D9\u05DB\u05EA \u05E2\u05E8\u05DB\u05D9\u05DD, \u05E0\u05D5\u05E1\u05D7\u05D0\u05D5\u05EA \u05D5\u05E2\u05D9\u05E6\u05D5\u05D1 \u05D1\u05E8\u05E9\u05EA \u05D5\u05D9\u05E8\u05D8\u05D5\u05D0\u05DC\u05D9\u05EA. \u05E2\u05E8\u05DB\u05D9 \u05D4\u05DE\u05E7\u05D5\u05E8 \u05E0\u05E9\u05DE\u05E8\u05D9\u05DD \u05D1\u05E0\u05E4\u05E8\u05D3 \u05DE\u05EA\u05D5\u05E6\u05D0\u05D5\u05EA \u05D4\u05D7\u05D9\u05E9\u05D5\u05D1.
\u05EA\u05E6\u05D5\u05D2\u05EA \u05E1\u05E6\u05E0\u05D4 \u05D5\u05D1\u05D3\u05D9\u05E7\u05EA \u05DE\u05D9\u05E7\u05D5\u05DD \u05DC\u05D7\u05D9\u05E6\u05D4
\u05D4\u05D5\u05E1\u05E4\u05EA \u05DE\u05DC\u05D1\u05DF
\u05DC\u05D7\u05E6\u05D5 \u05E2\u05DC \u05E6\u05D5\u05E8\u05D4 \u05DC\u05D1\u05D3\u05D9\u05E7\u05EA \u05D4\u05E7\u05D5\u05D0\u05D5\u05E8\u05D3\u05D9\u05E0\u05D8\u05D5\u05EA. \u05D4\u05E2\u05D5\u05E8\u05DA \u05D4\u05DE\u05DC\u05D0 \u05D9\u05D2\u05D9\u05E2 \u05D1\u05BEM4.
\u05D7\u05DC\u05E7\u05D9 \u05D7\u05D1\u05D9\u05DC\u05D4 / \u05D6\u05E8\u05DE\u05D9\u05DD
\u05D7\u05DC\u05E7
\u05D2\u05D5\u05D3\u05DC
SHA-256
\u05D2\u05E8\u05E1\u05EA \u05D4\u05E4\u05D5\u05E8\u05DE\u05D8
\u05D4\u05E4\u05D5\u05E8\u05DE\u05D8 \u05E9\u05D6\u05D5\u05D4\u05D4
\u05E9\u05DE\u05D9\u05E8\u05EA \u05E2\u05D5\u05EA\u05E7 \u05D6\u05D4\u05D4
\u05DE\u05EA\u05D0\u05DD \u05E1\u05DE\u05E0\u05D8\u05D9 \u05D1\u05D4\u05DE\u05EA\u05E0\u05D4
\u05D8\u05D9\u05D5\u05D8\u05D5\u05EA \u05D4\u05E0\u05D9\u05EA\u05E0\u05D5\u05EA \u05DC\u05E9\u05D7\u05D6\u05D5\u05E8
\u05E9\u05D7\u05D6\u05D5\u05E8 \u05E2\u05D5\u05EA\u05E7
\u05D5\u05D9\u05EA\u05D5\u05E8
\u05D4\u05E9\u05D7\u05D6\u05D5\u05E8 \u05D9\u05D5\u05E6\u05E8 \u05E2\u05D5\u05EA\u05E7 \u05D7\u05D3\u05E9 \u05E9\u05DC\u05D0 \u05E0\u05E9\u05DE\u05E8 \u05D5\u05DE\u05E9\u05D0\u05D9\u05E8 \u05D0\u05EA \u05E7\u05D5\u05D1\u05E5 \u05D4\u05DE\u05E7\u05D5\u05E8 \u05DC\u05DC\u05D0 \u05E9\u05D9\u05E0\u05D5\u05D9.
\u05EA\u05DE\u05D5\u05E0\u05D5\u05EA \u05DE\u05E6\u05D1 \u05E4\u05D2\u05D5\u05DE\u05D5\u05EA \u05DC\u05E9\u05D7\u05D6\u05D5\u05E8 \u05D1\u05D5\u05D3\u05D3\u05D5 \u05D5\u05DC\u05D0 \u05E0\u05D8\u05E2\u05E0\u05D5.
\u05E9\u05D5\u05D7\u05D6\u05E8 \u05DB\u05D8\u05D9\u05D5\u05D8\u05D4 \u05D7\u05D3\u05E9\u05D4
\u05D1\u05E2\u05D1\u05D5\u05D3\u05D4
\u05D3\u05D5\u05D7 \u05EA\u05D0\u05D9\u05DE\u05D5\u05EA
\u05D0\u05D9\u05DF \u05D7\u05DC\u05E7\u05D9 \u05DE\u05DB\u05DC \u05DC\u05D4\u05E6\u05D2\u05D4.
\u05E9\u05E7\u05D5\u05E4\u05D9\u05EA \u05E8\u05D9\u05E7\u05D4
\u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D9\u05EA \u05D4\u05E7\u05D1\u05E6\u05D9\u05DD \u05D4\u05D0\u05D7\u05E8\u05D5\u05E0\u05D9\u05DD \u05E0\u05D5\u05E7\u05EA\u05D4
\u05DB\u05D5\u05EA\u05E8\u05EA \u05D4\u05DE\u05E1\u05DE\u05DA
\u05E0\u05D9\u05EA\u05DF \u05DC\u05E4\u05EA\u05D5\u05D7 \u05E2\u05D3 32 \u05DB\u05E8\u05D8\u05D9\u05E1\u05D9\u05D5\u05EA
\u05DE\u05E0\u05D5\u05E2 \u05E2\u05E6\u05DE\u05D0\u05D9 \xB7 \u05D2\u05D9\u05DC\u05D9\u05D5\u05E0\u05D5\u05EA M3
\u05D4\u05E7\u05D5\u05D1\u05E5 \u05E0\u05E9\u05DE\u05E8; \u05DE\u05E2\u05E8\u05DB\u05EA \u05E7\u05D1\u05E6\u05D9\u05DD \u05D6\u05D5 \u05DC\u05D0 \u05D4\u05D1\u05D8\u05D9\u05D7\u05D4 \u05E1\u05E0\u05DB\u05E8\u05D5\u05DF \u05E9\u05DC \u05D4\u05E1\u05E4\u05E8\u05D9\u05D9\u05D4.
\u05D4\u05E7\u05D5\u05D1\u05E5 \u05E0\u05E9\u05DE\u05E8, \u05D0\u05DA \u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05D4\u05D9\u05D4 \u05DC\u05E2\u05D3\u05DB\u05DF \u05D0\u05EA \u05E8\u05D9\u05E9\u05D5\u05DE\u05D9 \u05D4\u05E9\u05D7\u05D6\u05D5\u05E8 \u05D0\u05D5 \u05D4\u05E7\u05D1\u05E6\u05D9\u05DD \u05D4\u05D0\u05D7\u05E8\u05D5\u05E0\u05D9\u05DD.
\u05D3\u05E3 \u05D4\u05D1\u05D9\u05EA \u05E9\u05DC Office EX
\u05E0\u05D9\u05D5\u05D5\u05D8 \u05E8\u05D0\u05E9\u05D9
\u05DE\u05E1\u05DE\u05DB\u05D9\u05DD
\u05E4\u05E2\u05D5\u05DC\u05D5\u05EA \u05DE\u05E1\u05DE\u05DA
M3 \xB7 \u05EA\u05E6\u05D5\u05D2\u05EA \u05E4\u05D9\u05EA\u05D5\u05D7
OFFICE EX / \u05E1\u05D1\u05D9\u05D1\u05EA \u05D4\u05E2\u05D1\u05D5\u05D3\u05D4 \u05D4\u05DE\u05E7\u05D5\u05DE\u05D9\u05EA \u05E9\u05DC\u05DA
\u05EA\u05D1\u05E0\u05D9\u05D5\u05EA \u05D0\u05D6\u05D5\u05E8\u05D9\u05D5\u05EA
\u05E9\u05E4\u05EA \u05DE\u05E1\u05DE\u05DB\u05D9\u05DD \u05D7\u05D3\u05E9\u05D9\u05DD (\u05D4\u05E2\u05D3\u05E4\u05D4)
\u05DE\u05E1\u05DE\u05DB\u05D9 Writer \u05D7\u05D3\u05E9\u05D9\u05DD \u05DE\u05E9\u05EA\u05DE\u05E9\u05D9\u05DD \u05D1\u05E9\u05E4\u05EA \u05D8\u05E7\u05E1\u05D8 \u05D6\u05D5. \u05E7\u05D1\u05E6\u05D9\u05DD \u05E7\u05D9\u05D9\u05DE\u05D9\u05DD \u05DC\u05D0 \u05D9\u05E9\u05EA\u05E0\u05D5; \u05E2\u05D5\u05E8\u05DB\u05D9\u05DD \u05D0\u05D7\u05E8\u05D9\u05DD \u05D9\u05E9\u05EA\u05DE\u05E9\u05D5 \u05D1\u05D4 \u05D1\u05D4\u05DE\u05E9\u05DA.
\u05EA\u05E6\u05D5\u05D2\u05D4 \u05DE\u05E7\u05D3\u05D9\u05DE\u05D4 \u05E9\u05DC \u05EA\u05D1\u05E0\u05D9\u05EA \u05D0\u05D6\u05D5\u05E8\u05D9\u05EA
\u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D4
\u05DE\u05E9\u05D8\u05D7 \u05E6\u05D9\u05D5\u05E8
{count} \u05E4\u05E8\u05D9\u05D8\u05D9\u05DD; \u05DE\u05D5\u05E6\u05D2\u05D9\u05DD 500 \u05D4\u05E8\u05D0\u05E9\u05D5\u05E0\u05D9\u05DD.
\u05E7\u05D5\u05D1\u05E5
\u05E2\u05E8\u05D9\u05DB\u05D4
\u05EA\u05E6\u05D5\u05D2\u05D4
\u05D8\u05D9\u05D5\u05D8\u05EA \u05DE\u05E1\u05DE\u05DA \u05D7\u05D3\u05E9\u05D4
\u05D8\u05D9\u05D5\u05D8\u05EA \u05D2\u05D9\u05DC\u05D9\u05D5\u05DF \u05D0\u05DC\u05E7\u05D8\u05E8\u05D5\u05E0\u05D9 \u05D7\u05D3\u05E9\u05D4
\u05D8\u05D9\u05D5\u05D8\u05EA \u05DE\u05E6\u05D2\u05EA \u05D7\u05D3\u05E9\u05D4
\u05E4\u05EA\u05D9\u05D7\u05D4\u2026
\u05E9\u05DE\u05D9\u05E8\u05D4 \u05D1\u05E9\u05DD\u2026
\u05E1\u05D2\u05D9\u05E8\u05EA \u05DB\u05E8\u05D8\u05D9\u05E1\u05D9\u05D9\u05D4
\u05D2\u05D6\u05D9\u05E8\u05D4
\u05D4\u05E2\u05EA\u05E7\u05D4
\u05D4\u05D3\u05D1\u05E7\u05D4
\u05D1\u05D7\u05D9\u05E8\u05EA \u05D4\u05DB\u05D5\u05DC
\u05DE\u05E2\u05D1\u05E8 \u05DC\u05DE\u05E1\u05DA \u05DE\u05DC\u05D0 \u05D0\u05D5 \u05D7\u05D6\u05E8\u05D4 \u05DE\u05DE\u05E0\u05D5
\u05D0\u05D9\u05E4\u05D5\u05E1 \u05DE\u05E8\u05D7\u05E7 \u05D4\u05EA\u05E6\u05D5\u05D2\u05D4
\u05D4\u05D2\u05D3\u05DC\u05D4
\u05D4\u05E7\u05D8\u05E0\u05D4
\u05DE\u05E1\u05DE\u05DB\u05D9 Office / \u05D8\u05D9\u05D5\u05D8\u05D5\u05EA Office EX
\u05DB\u05DC \u05D4\u05E7\u05D1\u05E6\u05D9\u05DD
\u05E4\u05D5\u05E8\u05DE\u05D8 \u05D4\u05E7\u05D5\u05D1\u05E5 \u05D4\u05DE\u05E7\u05D5\u05E8\u05D9
\u05DC\u05D4\u05D7\u05DC\u05D9\u05E3 \u05D0\u05EA \u05E7\u05D5\u05D1\u05E5 \u05D4\u05D9\u05E2\u05D3 \u05D4\u05E7\u05D9\u05D9\u05DD?
\u05D4\u05D7\u05DC\u05E4\u05D4
\u05DC\u05E9\u05DE\u05D5\u05E8 \u05E9\u05D9\u05E0\u05D5\u05D9\u05D9\u05DD \u05DC\u05E4\u05E0\u05D9 \u05D4\u05E1\u05D2\u05D9\u05E8\u05D4?
\u05D5\u05D9\u05EA\u05D5\u05E8 \u05E2\u05DC \u05D4\u05E9\u05D9\u05E0\u05D5\u05D9\u05D9\u05DD
\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E4\u05EA\u05D5\u05D7 \u05D0\u05EA \u05D4\u05E7\u05D5\u05D1\u05E5
\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E4\u05EA\u05D5\u05D7 \u05D0\u05EA \u05D4\u05D7\u05DC\u05D5\u05DF
\u05D9\u05E9 \u05DC\u05D4\u05E9\u05DC\u05D9\u05DD \u05D0\u05EA \u05D4\u05E7\u05DC\u05D8 \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9 \u05DC\u05E4\u05E0\u05D9 \u05E9\u05D9\u05E0\u05D5\u05D9 \u05D4\u05E9\u05E4\u05D4.
\u05D9\u05E9 \u05DC\u05E4\u05EA\u05D5\u05D7 \u05E7\u05D5\u05D1\u05E5 \u05E0\u05D2\u05E8\u05E8 \u05D0\u05D7\u05D3 \u05D1\u05DB\u05DC \u05E4\u05E2\u05DD.
\u05D4\u05E7\u05D5\u05D1\u05E5 \u05D0\u05D5 \u05D4\u05D1\u05E7\u05E9\u05D4 \u05D0\u05D9\u05E0\u05DD \u05EA\u05E7\u05D9\u05E0\u05D9\u05DD.
\u05EA\u05DB\u05D5\u05E0\u05D4 \u05D0\u05D5 \u05E4\u05D5\u05E8\u05DE\u05D8 \u05D0\u05DC\u05D4 \u05E2\u05D3\u05D9\u05D9\u05DF \u05D0\u05D9\u05E0\u05DD \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD.
\u05D4\u05E4\u05E2\u05D5\u05DC\u05D4 \u05E0\u05D7\u05E1\u05DE\u05D4 \u05DE\u05D8\u05E2\u05DE\u05D9 \u05D1\u05D8\u05D9\u05D7\u05D5\u05EA.
\u05D4\u05E4\u05E2\u05D5\u05DC\u05D4 \u05D7\u05D5\u05E8\u05D2\u05EA \u05DE\u05DE\u05D2\u05D1\u05DC\u05EA \u05DE\u05E9\u05D0\u05D1\u05D9\u05DD.
\u05D4\u05DE\u05E1\u05DE\u05DA \u05D0\u05D5 \u05E7\u05D5\u05D1\u05E5 \u05D4\u05D9\u05E2\u05D3 \u05D4\u05E9\u05EA\u05E0\u05D5.
\u05E4\u05E2\u05D5\u05DC\u05EA \u05D4\u05E7\u05D5\u05D1\u05E5 \u05E0\u05DB\u05E9\u05DC\u05D4.
\u05D0\u05D9\u05E8\u05E2\u05D4 \u05E9\u05D2\u05D9\u05D0\u05D4 \u05E4\u05E0\u05D9\u05DE\u05D9\u05EA.
\u05D3\u05D5\u05D5\u05D7 \u05D0\u05D1\u05D7\u05D5\u05DF \u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4\u05D4.
\u05D1\u05D3\u05D9\u05E7\u05EA \u05DE\u05DB\u05DC \u05D1\u05DC\u05D1\u05D3. \u05E1\u05DE\u05E0\u05D8\u05D9\u05E7\u05EA \u05D4\u05DE\u05E1\u05DE\u05DA \u05D4\u05E0\u05D9\u05EA\u05E0\u05EA \u05DC\u05E2\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D0 \u05D9\u05D5\u05D1\u05D0\u05D4.
\u05D6\u05D5\u05D4\u05D4 \u05EA\u05D5\u05DB\u05DF \u05D4\u05E7\u05E9\u05D5\u05E8 \u05DC\u05E4\u05E7\u05D5\u05D3\u05D5\u05EA \u05DE\u05D0\u05E7\u05E8\u05D5. \u05E4\u05E7\u05D5\u05D3\u05D5\u05EA \u05DE\u05D0\u05E7\u05E8\u05D5 \u05D0\u05D9\u05E0\u05DF \u05DE\u05D5\u05E4\u05E2\u05DC\u05D5\u05EA; \u05D4\u05D1\u05EA\u05D9\u05DD \u05E9\u05DC\u05D4\u05DF \u05E0\u05E9\u05DE\u05E8\u05D9\u05DD \u05E8\u05E7 \u05D1\u05E2\u05D5\u05EA\u05E7\u05D9\u05DD \u05D6\u05D4\u05D9\u05DD.
\u05E7\u05D5\u05D1\u05E5 \u05D7\u05EA\u05D5\u05DD: \u05DC\u05D1\u05D3\u05D9\u05E7\u05D4 \u05D1\u05DC\u05D1\u05D3. \u05EA\u05D5\u05E7\u05E3 \u05D4\u05D7\u05EA\u05D9\u05DE\u05D4 \u05D0\u05D9\u05E0\u05D5 \u05DE\u05D0\u05D5\u05DE\u05EA.
\u05E7\u05E9\u05E8\u05D9\u05DD \u05D7\u05D9\u05E6\u05D5\u05E0\u05D9\u05D9\u05DD \u05E0\u05E8\u05E9\u05DE\u05D9\u05DD; \u05EA\u05D5\u05DB\u05DF \u05D7\u05D9\u05E6\u05D5\u05E0\u05D9 \u05D0\u05D9\u05E0\u05D5 \u05E0\u05D8\u05E2\u05DF.
\u05D6\u05D5\u05D4\u05D4 Strict OOXML; \u05E7\u05E8\u05D9\u05D0\u05D4 \u05D5\u05DB\u05EA\u05D9\u05D1\u05D4 \u05E1\u05DE\u05E0\u05D8\u05D9\u05D5\u05EA \u05D8\u05E8\u05DD \u05D0\u05D5\u05DE\u05EA\u05D5.
\u05D6\u05D5\u05D4\u05D4 \u05DE\u05DB\u05DC \u05DE\u05D5\u05E6\u05E4\u05DF. \u05E4\u05E2\u05E0\u05D5\u05D7 \u05D5\u05E2\u05E8\u05D9\u05DB\u05D4 \u05D0\u05D9\u05E0\u05DD \u05D6\u05DE\u05D9\u05E0\u05D9\u05DD.
\u05E1\u05D9\u05D5\u05DE\u05EA \u05D4\u05E7\u05D5\u05D1\u05E5 \u05E9\u05D5\u05E0\u05D4 \u05DE\u05D4\u05EA\u05D5\u05DB\u05DF \u05E9\u05D6\u05D5\u05D4\u05D4.
\u05E2\u05D9\u05E6\u05D5\u05D1 \u05D8\u05E7\u05E1\u05D8
\u05E2\u05E8\u05DB\u05D5 \u05E4\u05E1\u05E7\u05D0\u05D5\u05EA \u05D5\u05D1\u05D7\u05E8\u05D5 \u05D8\u05E7\u05E1\u05D8 \u05DC\u05E2\u05D9\u05E6\u05D5\u05D1. Enter \u05DE\u05E4\u05E6\u05DC \u05E4\u05E1\u05E7\u05D4; Shift+Enter \u05DE\u05D5\u05E1\u05D9\u05E3 \u05DE\u05E2\u05D1\u05E8 \u05E9\u05D5\u05E8\u05D4.
\u05EA\u05E6\u05D5\u05D2\u05D4 \u05DE\u05E7\u05D3\u05D9\u05DE\u05D4 \u05E9\u05DC \u05D4\u05E2\u05DE\u05D5\u05D3
\u05E4\u05E8\u05D9\u05E1\u05EA \u05E2\u05DE\u05D5\u05D3 \u05DE\u05E9\u05D5\u05E2\u05E8\u05EA. \u05DC\u05D7\u05E6\u05D5 \u05E2\u05DC \u05D4\u05E2\u05DE\u05D5\u05D3 \u05DB\u05D3\u05D9 \u05DC\u05D0\u05EA\u05E8 \u05D8\u05E7\u05E1\u05D8. \u05D3\u05D9\u05D5\u05E7 \u05D4\u05D4\u05D3\u05E4\u05E1\u05D4 \u05D8\u05E8\u05DD \u05D0\u05D5\u05DE\u05EA.
\u05D4\u05E2\u05DE\u05D5\u05D3 \u05D4\u05E7\u05D5\u05D3\u05DD
\u05D4\u05E2\u05DE\u05D5\u05D3 \u05D4\u05D1\u05D0
\u05E2\u05DE\u05D5\u05D3 {current} / {total}
\u05D7\u05DC\u05E7 \u05DE\u05EA\u05DB\u05D5\u05E0\u05D5\u05EA \u05D4\u05D8\u05D9\u05E4\u05D5\u05D2\u05E8\u05E4\u05D9\u05D4 \u05D0\u05D5 \u05D4\u05E4\u05E8\u05D9\u05E1\u05D4 \u05D4\u05DF \u05D1\u05E7\u05D9\u05E8\u05D5\u05D1.
\u05D0\u05D9\u05DF \u05EA\u05E6\u05D5\u05D2\u05D4 \u05DE\u05E7\u05D3\u05D9\u05DE\u05D4 \u05DC\u05EA\u05D5\u05DB\u05DF \u05D6\u05D4 \u05D0\u05D5 \u05D1\u05D2\u05DC\u05DC \u05DE\u05D2\u05D1\u05DC\u05EA \u05E4\u05E8\u05D9\u05E1\u05D4. \u05EA\u05D5\u05DB\u05DF \u05D4\u05DE\u05E7\u05D5\u05E8 \u05DC\u05D0 \u05D4\u05E9\u05EA\u05E0\u05D4.
\u05DE\u05D5\u05D3\u05D2\u05E9
\u05E0\u05D8\u05D5\u05D9
\u05E7\u05D5 \u05EA\u05D7\u05EA\u05D5\u05DF
\u05D9\u05D9\u05E9\u05D5\u05E8 \u05DC\u05E9\u05DE\u05D0\u05DC
\u05DE\u05E8\u05DB\u05D5\u05D6
\u05D9\u05D9\u05E9\u05D5\u05E8 \u05DC\u05D9\u05DE\u05D9\u05DF
\u05E4\u05D9\u05E6\u05D5\u05DC \u05E4\u05E1\u05E7\u05D4
\u05DE\u05E2\u05D1\u05E8 \u05E2\u05DE\u05D5\u05D3 \u05D0\u05D7\u05E8\u05D9 \u05D4\u05E4\u05E1\u05E7\u05D4
\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E2\u05E8\u05D5\u05DA \u05DE\u05E7\u05D8\u05E2 \u05D6\u05D4 \u05D1\u05EA\u05E6\u05D5\u05D2\u05D4 \u05D4\u05DE\u05E7\u05D3\u05D9\u05DE\u05D4.
\u05DE\u05E1\u05DE\u05DA DOCX \u05D7\u05D3\u05E9
\u05DE\u05E1\u05DE\u05DA DOCX
\u05E4\u05E8\u05D5\u05E4\u05D9\u05DC DOCX \u05DE\u05D5\u05D2\u05D1\u05DC: \u05D8\u05E7\u05E1\u05D8, \u05E2\u05D9\u05E6\u05D5\u05D1 \u05D9\u05E9\u05D9\u05E8, \u05E1\u05D2\u05E0\u05D5\u05E0\u05D5\u05EA \u05D1\u05E2\u05DC\u05D9 \u05E9\u05DD \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD, \u05D8\u05D1\u05DC\u05D0\u05D5\u05EA \u05DE\u05DC\u05D1\u05E0\u05D9\u05D5\u05EA \u05E7\u05D1\u05D5\u05E2\u05D5\u05EA, \u05EA\u05DE\u05D5\u05E0\u05D5\u05EA PNG/JPEG \u05DE\u05D5\u05D8\u05D1\u05E2\u05D5\u05EA \u05D1\u05EA\u05D5\u05DA \u05D4\u05E9\u05D5\u05E8\u05D4 \u05D5\u05E4\u05E8\u05D9\u05E1\u05D4 \u05D1\u05E1\u05D9\u05E1\u05D9\u05EA. \u05DE\u05E1\u05DE\u05DB\u05D9\u05DD \u05DE\u05D5\u05E8\u05DB\u05D1\u05D9\u05DD \u05E0\u05E9\u05D0\u05E8\u05D9\u05DD \u05DC\u05E7\u05E8\u05D9\u05D0\u05D4 \u05D1\u05DC\u05D1\u05D3.
\u05D2\u05D5\u05E4\u05DF
\u05D2\u05D5\u05D3\u05DC (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05E6\u05D1\u05E2 \u05D8\u05E7\u05E1\u05D8
\u05E1\u05D2\u05E0\u05D5\u05DF \u05E4\u05E1\u05E7\u05D4
\u05E1\u05D2\u05E0\u05D5\u05DF \u05EA\u05D5\u05D5\u05D9\u05DD
\u05D1\u05D7\u05D9\u05E8\u05EA \u05E1\u05D2\u05E0\u05D5\u05DF
\u05D8\u05D1\u05DC\u05D4
\u05E9\u05D5\u05E8\u05D5\u05EA
\u05E2\u05DE\u05D5\u05D3\u05D5\u05EA
\u05D4\u05D5\u05E1\u05E4\u05EA \u05D8\u05D1\u05DC\u05D4
\u05D4\u05D5\u05E1\u05E4\u05EA \u05E9\u05D5\u05E8\u05D4 \u05DE\u05EA\u05D7\u05EA
\u05DE\u05D7\u05D9\u05E7\u05EA \u05E9\u05D5\u05E8\u05D4
\u05D4\u05D5\u05E1\u05E4\u05EA \u05E2\u05DE\u05D5\u05D3\u05D4 \u05DE\u05D9\u05DE\u05D9\u05DF
\u05DE\u05D7\u05D9\u05E7\u05EA \u05E2\u05DE\u05D5\u05D3\u05D4
\u05E8\u05D5\u05D7\u05D1 \u05E2\u05DE\u05D5\u05D3\u05D4 (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05D2\u05D1\u05D5\u05DC\u05D5\u05EA \u05D8\u05D1\u05DC\u05D4
\u05DE\u05D7\u05D9\u05E7\u05EA \u05D8\u05D1\u05DC\u05D4
\u05EA\u05D0 {row}, {column}
\u05D4\u05D5\u05E1\u05E4\u05EA \u05EA\u05DE\u05D5\u05E0\u05D4
\u05EA\u05DE\u05D5\u05E0\u05D4
\u05E8\u05D5\u05D7\u05D1 \u05EA\u05DE\u05D5\u05E0\u05D4 (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05D4\u05E1\u05E8\u05EA \u05EA\u05DE\u05D5\u05E0\u05D4
\u05D2\u05D5\u05D3\u05DC \u05E0\u05D9\u05D9\u05E8
\u05DE\u05D5\u05EA\u05D0\u05DD \u05D0\u05D9\u05E9\u05D9\u05EA
A4
Letter
A3
\u05DB\u05D9\u05D5\u05D5\u05DF \u05E2\u05DE\u05D5\u05D3
\u05DC\u05D0\u05D5\u05E8\u05DA
\u05DC\u05E8\u05D5\u05D7\u05D1
\u05E8\u05D5\u05D7\u05D1 \u05E2\u05DE\u05D5\u05D3 (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05D2\u05D5\u05D1\u05D4 \u05E2\u05DE\u05D5\u05D3 (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05E9\u05D5\u05DC\u05D9\u05D9\u05DD \u05E2\u05DC\u05D9\u05D5\u05E0\u05D9\u05DD (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05E9\u05D5\u05DC\u05D9\u05D9\u05DD \u05D9\u05DE\u05E0\u05D9\u05D9\u05DD (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05E9\u05D5\u05DC\u05D9\u05D9\u05DD \u05EA\u05D7\u05EA\u05D5\u05E0\u05D9\u05DD (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05E9\u05D5\u05DC\u05D9\u05D9\u05DD \u05E9\u05DE\u05D0\u05DC\u05D9\u05D9\u05DD (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05D4\u05D7\u05DC\u05EA \u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05E2\u05DE\u05D5\u05D3
\u05DB\u05E0\u05D9\u05E1\u05D4 (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05DC\u05E4\u05E0\u05D9 (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05D0\u05D7\u05E8\u05D9 (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)
\u05D2\u05D5\u05D1\u05D4 \u05E9\u05D5\u05E8\u05D4 (\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA; 0 = \u05D0\u05D5\u05D8\u05D5\u05DE\u05D8\u05D9)
\u05D4\u05D5\u05E1\u05E4\u05EA \u05EA\u05DE\u05D5\u05E0\u05D4 \u05D1\u05DE\u05D9\u05E7\u05D5\u05DD \u05D4\u05E1\u05DE\u05DF
\u05E1\u05DE\u05DF \u05D4\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8 \u05DE\u05D9\u05D9\u05E6\u05D2 \u05EA\u05DE\u05D5\u05E0\u05D4 \u05D1\u05EA\u05D5\u05DA \u05D4\u05E9\u05D5\u05E8\u05D4. \u05D4\u05E9\u05EA\u05DE\u05E9\u05D5 \u05D1\u05E4\u05E7\u05D3\u05D9 \u05D4\u05EA\u05DE\u05D5\u05E0\u05D4 \u05DB\u05D3\u05D9 \u05DC\u05E9\u05E0\u05D5\u05EA \u05D0\u05EA \u05D2\u05D5\u05D3\u05DC\u05D4 \u05D0\u05D5 \u05DC\u05D4\u05E1\u05D9\u05E8\u05D4.
\u05E2\u05E8\u05D9\u05DB\u05EA \u05D8\u05E7\u05E1\u05D8 \u05E8\u05E6\u05D9\u05E3
\u05D7\u05D6\u05E8\u05D4 \u05DC\u05E2\u05D5\u05E8\u05DA \u05D4\u05E4\u05E1\u05E7\u05D0\u05D5\u05EA
\u05D1\u05D7\u05E8\u05D5, \u05D4\u05E2\u05EA\u05D9\u05E7\u05D5, \u05D2\u05D6\u05E8\u05D5, \u05D4\u05D3\u05D1\u05D9\u05E7\u05D5 \u05D0\u05D5 \u05E2\u05E6\u05D1\u05D5 \u05D8\u05E7\u05E1\u05D8 \u05D1\u05D9\u05DF \u05E4\u05E1\u05E7\u05D0\u05D5\u05EA \u05E1\u05DE\u05D5\u05DB\u05D5\u05EA. \u05D8\u05D1\u05DC\u05D0\u05D5\u05EA, \u05DE\u05E2\u05D1\u05E8\u05D9 \u05E2\u05DE\u05D5\u05D3, \u05DE\u05E7\u05D8\u05E2\u05D9\u05DD \u05D5\u05E4\u05E1\u05E7\u05D0\u05D5\u05EA \u05EA\u05DE\u05D5\u05E0\u05D4 \u05DE\u05D2\u05D1\u05D9\u05DC\u05D9\u05DD \u05D0\u05EA \u05D4\u05D1\u05D7\u05D9\u05E8\u05D4. \u05E9\u05D5\u05E8\u05D5\u05EA \u05D7\u05D3\u05E9\u05D5\u05EA \u05D4\u05DE\u05D5\u05D3\u05D1\u05E7\u05D5\u05EA \u05D4\u05D5\u05E4\u05DB\u05D5\u05EA \u05DC\u05E4\u05E1\u05E7\u05D0\u05D5\u05EA.
\u05DE\u05E7\u05D8\u05E2
\u05DE\u05E7\u05D8\u05E2 {number}
\u05DE\u05E2\u05D1\u05E8 \u05DE\u05E7\u05D8\u05E2 \u05DC\u05E2\u05DE\u05D5\u05D3 \u05D4\u05D1\u05D0
\u05E9\u05E4\u05EA \u05D4\u05D8\u05E7\u05E1\u05D8 (BCP 47)
\u05DB\u05D9\u05D5\u05D5\u05DF \u05E4\u05E1\u05E7\u05D4
\u05DE\u05E9\u05DE\u05D0\u05DC \u05DC\u05D9\u05DE\u05D9\u05DF
\u05DE\u05D9\u05DE\u05D9\u05DF \u05DC\u05E9\u05DE\u05D0\u05DC
DOC \u05D7\u05D3\u05E9
\u05DE\u05E1\u05DE\u05DA Word 97\u20132003
\u05E2\u05E8\u05D9\u05DB\u05EA DOC \u05DE\u05D5\u05D2\u05D1\u05DC\u05EA: \u05D8\u05E7\u05E1\u05D8 Unicode, \u05E1\u05D2\u05E0\u05D5\u05E0\u05D5\u05EA \u05D1\u05E1\u05D9\u05E1\u05D9\u05D9\u05DD \u05D5\u05DE\u05E7\u05D8\u05E2 \u05D0\u05D7\u05D3. \u05E7\u05D5\u05D1\u05E6\u05D9 DOC \u05E9\u05D0\u05D9\u05E0\u05DD \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD \u05E0\u05E9\u05D0\u05E8\u05D9\u05DD \u05DC\u05E7\u05E8\u05D9\u05D0\u05D4 \u05D1\u05DC\u05D1\u05D3; \u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E9\u05DE\u05D5\u05E8 \u05D8\u05D1\u05DC\u05D0\u05D5\u05EA \u05D5\u05EA\u05DE\u05D5\u05E0\u05D5\u05EA \u05D1\u05E4\u05E8\u05D5\u05E4\u05D9\u05DC \u05D6\u05D4.
\u05EA\u05E6\u05D5\u05D2\u05D4 \u05DC\u05E7\u05E8\u05D9\u05D0\u05D4 \u05D1\u05DC\u05D1\u05D3 \u05E9\u05DC \u05D4\u05D8\u05E7\u05E1\u05D8 \u05D4\u05E8\u05D0\u05E9\u05D9, \u05E9\u05D0\u05D9\u05E0\u05D4 \u05E4\u05E8\u05D9\u05E1\u05EA \u05D4\u05DE\u05E1\u05DE\u05DA \u05D4\u05DE\u05DC\u05D0\u05D4. \u05E9\u05DE\u05D9\u05E8\u05EA \u05E2\u05D5\u05EA\u05E7 \u05DE\u05E9\u05DE\u05E8\u05EA \u05D0\u05EA \u05D1\u05EA\u05D9 \u05D4\u05DE\u05E7\u05D5\u05E8.
\u05D4\u05DE\u05E8\u05D4 \u05DC\u05BEDOC
\u05D4\u05DE\u05E8\u05D4 \u05DC\u05BEDOCX
\u05D4\u05DE\u05E8\u05D4 \u05D3\u05D5\u05E8\u05E9\u05EA \u05DE\u05E1\u05DE\u05DA \u05D4\u05DE\u05DB\u05D9\u05DC \u05E8\u05E7 \u05DE\u05D1\u05E0\u05D9\u05DD \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD; \u05D7\u05DC\u05E7\u05D9\u05DD \u05E9\u05D0\u05D9\u05E0\u05DD \u05DE\u05E4\u05D5\u05E2\u05E0\u05D7\u05D9\u05DD \u05E0\u05E9\u05DE\u05E8\u05D9\u05DD \u05D1\u05DE\u05E7\u05D5\u05E8 \u05D5\u05D0\u05D9\u05E0\u05DD \u05DE\u05D5\u05E9\u05DC\u05DB\u05D9\u05DD.
\u05E2\u05E8\u05D9\u05DB\u05D4 \u05E2\u05DC \u05D4\u05E2\u05DE\u05D5\u05D3
\u05D7\u05D6\u05E8\u05D4 \u05DC\u05DB\u05DC\u05D9\u05DD
\u05E2\u05E8\u05DB\u05D5 \u05E2\u05DC \u05D4\u05E2\u05DE\u05D5\u05D3 \u05D1\u05D0\u05DE\u05E6\u05E2\u05D5\u05EA \u05E2\u05D9\u05E6\u05D5\u05D1 \u05D4\u05D8\u05E7\u05E1\u05D8 \u05D4\u05DE\u05D5\u05D1\u05E0\u05D4 \u05D1\u05D3\u05E4\u05D3\u05E4\u05DF. \u05D2\u05E8\u05E8\u05D5 \u05DC\u05D1\u05D7\u05D9\u05E8\u05D4; \u05D4\u05E2\u05EA\u05E7\u05D4 \u05D5\u05D4\u05D3\u05D1\u05E7\u05D4 \u05E9\u05D5\u05DE\u05E8\u05D5\u05EA \u05E2\u05DC \u05E2\u05D9\u05E6\u05D5\u05D1 Office EX \u05D5\u05EA\u05DE\u05D5\u05E0\u05D5\u05EA \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD. \u05E0\u05D0\u05DE\u05E0\u05D5\u05EA \u05D4\u05E2\u05DE\u05D5\u05D3 \u05DC\u05BEWord \u05D8\u05E8\u05DD \u05D0\u05D5\u05DE\u05EA\u05D4.
`), ...sheetsCatalog(`
\u05D7\u05D5\u05D1\u05E8\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u05D7\u05D3\u05E9\u05D4 \u05DE\u05E1\u05D5\u05D2 XLSX
\u05D7\u05D5\u05D1\u05E8\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u05E9\u05DC Excel \u200F(.xlsx)
\u05E2\u05E8\u05DB\u05D5 \u05EA\u05D0\u05D9\u05DD, \u05E0\u05D5\u05E1\u05D7\u05D0\u05D5\u05EA \u05D5\u05E1\u05D2\u05E0\u05D5\u05E0\u05D5\u05EA \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD. \u05E7\u05D1\u05E6\u05D9\u05DD \u05DE\u05D5\u05D2\u05E0\u05D9\u05DD \u05D0\u05D5 \u05D1\u05E2\u05DC\u05D9 \u05EA\u05DC\u05D5\u05D9\u05D5\u05EA \u05E9\u05D0\u05D9\u05E0\u05DF \u05E0\u05EA\u05DE\u05DB\u05D5\u05EA \u05E0\u05E4\u05EA\u05D7\u05D9\u05DD \u05DC\u05EA\u05E6\u05D5\u05D2\u05D4 \u05DC\u05E7\u05E8\u05D9\u05D0\u05D4 \u05D1\u05DC\u05D1\u05D3 \u05D4\u05E9\u05D5\u05DE\u05E8\u05EA \u05E2\u05DC \u05D4\u05DE\u05E7\u05D5\u05E8.
\u05D7\u05D5\u05D1\u05E8\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u05D7\u05D3\u05E9\u05D4 \u05E9\u05DC Excel 97\u20132003
\u05D7\u05D5\u05D1\u05E8\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u05E9\u05DC Excel 97\u20132003 \u200F(.xls)
\u05D7\u05D5\u05D1\u05E8\u05EA BIFF8: \u05E2\u05D3 65,536 \u05E9\u05D5\u05E8\u05D5\u05EA \u05D5\u05BE256 \u05E2\u05DE\u05D5\u05D3\u05D5\u05EA. \u05DC\u05E4\u05E0\u05D9 \u05E9\u05DE\u05D9\u05E8\u05D4 \u05D5\u05D4\u05DE\u05E8\u05D4 \u05E0\u05D1\u05D3\u05E7\u05D9\u05DD \u05E0\u05D5\u05E1\u05D7\u05D0\u05D5\u05EA, \u05E1\u05D2\u05E0\u05D5\u05E0\u05D5\u05EA \u05D5\u05EA\u05DC\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05E7\u05D5\u05E8.
\u05D4\u05DE\u05E8\u05D4 \u05DC\u05E2\u05D5\u05EA\u05E7 XLSX
\u05D4\u05DE\u05E8\u05D4 \u05DC\u05E2\u05D5\u05EA\u05E7 XLS
\u05E8\u05E9\u05EA \u05D2\u05D9\u05DC\u05D9\u05D5\u05DF \u05D0\u05DC\u05E7\u05D8\u05E8\u05D5\u05E0\u05D9
\u05E2\u05E8\u05DA \u05EA\u05D0 \u05D0\u05D5 \u05E0\u05D5\u05E1\u05D7\u05D4
\u05DB\u05EA\u05D5\u05D1\u05EA \u05EA\u05D0 \u05D0\u05D5 \u05D8\u05D5\u05D5\u05D7
\u05D4\u05D5\u05E1\u05E4\u05EA \u05D2\u05D9\u05DC\u05D9\u05D5\u05DF
\u05E9\u05D9\u05E0\u05D5\u05D9 \u05E9\u05DD \u05D4\u05D2\u05D9\u05DC\u05D9\u05D5\u05DF
\u05DE\u05D7\u05D9\u05E7\u05EA \u05D2\u05D9\u05DC\u05D9\u05D5\u05DF
\u05D4\u05E2\u05D1\u05E8\u05EA \u05D4\u05D2\u05D9\u05DC\u05D9\u05D5\u05DF \u05DC\u05DE\u05D9\u05E7\u05D5\u05DD \u05DE\u05D5\u05E7\u05D3\u05DD \u05D9\u05D5\u05EA\u05E8
\u05D4\u05E2\u05D1\u05E8\u05EA \u05D4\u05D2\u05D9\u05DC\u05D9\u05D5\u05DF \u05DC\u05DE\u05D9\u05E7\u05D5\u05DD \u05DE\u05D0\u05D5\u05D7\u05E8 \u05D9\u05D5\u05EA\u05E8
\u05E9\u05DD \u05D4\u05D2\u05D9\u05DC\u05D9\u05D5\u05DF
\u05D2\u05D9\u05DC\u05D9\u05D5\u05E0\u05D5\u05EA, \u05E9\u05D5\u05E8\u05D5\u05EA \u05D5\u05E2\u05DE\u05D5\u05D3\u05D5\u05EA
\u05DE\u05D9\u05D6\u05D5\u05D2 \u05EA\u05D0\u05D9\u05DD
\u05D1\u05D9\u05D8\u05D5\u05DC \u05DE\u05D9\u05D6\u05D5\u05D2 \u05EA\u05D0\u05D9\u05DD
\u05E0\u05D9\u05E7\u05D5\u05D9 \u05E2\u05E8\u05DB\u05D9\u05DD
\u05D4\u05D5\u05E1\u05E4\u05EA \u05E9\u05D5\u05E8\u05D5\u05EA
\u05DE\u05D7\u05D9\u05E7\u05EA \u05E9\u05D5\u05E8\u05D5\u05EA
\u05D4\u05D5\u05E1\u05E4\u05EA \u05E2\u05DE\u05D5\u05D3\u05D5\u05EA
\u05DE\u05D7\u05D9\u05E7\u05EA \u05E2\u05DE\u05D5\u05D3\u05D5\u05EA
\u05D2\u05D5\u05D1\u05D4 \u05E9\u05D5\u05E8\u05D4 (\u05E4\u05D9\u05E7\u05E1\u05DC\u05D9\u05DD)
\u05E8\u05D5\u05D7\u05D1 \u05E2\u05DE\u05D5\u05D3\u05D4 (\u05E4\u05D9\u05E7\u05E1\u05DC\u05D9\u05DD)
\u05EA\u05D1\u05E0\u05D9\u05EA \u05DE\u05E1\u05E4\u05E8
\u05DB\u05DC\u05DC\u05D9
\u05DE\u05E1\u05E4\u05E8
\u05D0\u05D7\u05D5\u05D6\u05D9\u05DD
\u05DE\u05D8\u05D1\u05E2
\u05EA\u05D0\u05E8\u05D9\u05DA
\u05E9\u05E2\u05D4
\u05DE\u05D3\u05E2\u05D9
\u05E7\u05D5\u05D3 \u05EA\u05D1\u05E0\u05D9\u05EA \u05DE\u05D5\u05EA\u05D0\u05DD \u05D0\u05D9\u05E9\u05D9\u05EA
\u05DE\u05D9\u05DC\u05D5\u05D9 \u05EA\u05D0
\u05D2\u05DC\u05D9\u05E9\u05EA \u05D8\u05E7\u05E1\u05D8
\u05D2\u05D1\u05D5\u05DC\u05D5\u05EA \u05EA\u05D0\u05D9\u05DD
\u05D4\u05D6\u05E0\u05EA \u05E0\u05D5\u05E1\u05D7\u05D0\u05D5\u05EA
\u05E9\u05DE\u05D5\u05EA \u05D1\u05D0\u05E0\u05D2\u05DC\u05D9\u05EA \xB7 \u05E0\u05E7\u05D5\u05D3\u05D4 \u05E2\u05E9\u05E8\u05D5\u05E0\u05D9\u05EA
\u05E9\u05DE\u05D5\u05EA \u05D5\u05DE\u05E4\u05E8\u05D9\u05D3\u05D9\u05DD \u05D0\u05D6\u05D5\u05E8\u05D9\u05D9\u05DD
\u05D7\u05D9\u05E9\u05D5\u05D1 \u05DE\u05D7\u05D3\u05E9
\u05DE\u05EA\u05D1\u05E6\u05E2 \u05D7\u05D9\u05E9\u05D5\u05D1\u2026
\u05D7\u05D5\u05E9\u05D1
\u05DC\u05D0 \u05D7\u05D5\u05E9\u05D1: \u05E0\u05D5\u05E1\u05D7\u05D4 \u05DC\u05D0 \u05E0\u05EA\u05DE\u05DB\u05EA
\u05EA\u05D5\u05E6\u05D0\u05D4 \u05E7\u05D5\u05D3\u05DE\u05EA: \u05E0\u05D3\u05E8\u05E9 \u05D7\u05D9\u05E9\u05D5\u05D1 \u05DE\u05D7\u05D3\u05E9
\u05E9\u05D2\u05D9\u05D0\u05EA \u05E0\u05D5\u05E1\u05D7\u05D4
\u05D1\u05D9\u05D8\u05D5\u05DC \u05D4\u05D7\u05D9\u05E9\u05D5\u05D1
{count} \u05EA\u05D0\u05D9\u05DD \u05DE\u05E1\u05E4\u05E8\u05D9\u05D9\u05DD \xB7 \u05E1\u05DB\u05D5\u05DD {sum}
\u05D1\u05D7\u05D9\u05E8\u05D4 {address}
\u05DC\u05D7\u05E6\u05D5 \u05D0\u05D5 \u05D2\u05E8\u05E8\u05D5 \u05DC\u05D1\u05D7\u05D9\u05E8\u05D4. \u05D4\u05E7\u05DC\u05D9\u05D3\u05D5 \u05D0\u05D5 \u05DC\u05D7\u05E6\u05D5 F2 \u05DC\u05E2\u05E8\u05D9\u05DB\u05D4; Enter \u05DE\u05D0\u05E9\u05E8 \u05D5\u05BEEsc \u05DE\u05D1\u05D8\u05DC. Shift \u05DE\u05E8\u05D7\u05D9\u05D1 \u05D0\u05EA \u05D4\u05D1\u05D7\u05D9\u05E8\u05D4. \u05D4\u05E2\u05EA\u05D9\u05E7\u05D5 \u05D5\u05D4\u05D3\u05D1\u05D9\u05E7\u05D5 \u05D8\u05D5\u05D5\u05D7\u05D9\u05DD \u05DB\u05BETSV. \u05E0\u05D5\u05E1\u05D7\u05D0\u05D5\u05EA \u05DE\u05EA\u05D7\u05D9\u05DC\u05D5\u05EA \u05D1\u05BE=.
\u05D4\u05E7\u05E4\u05D0\u05D4 \u05D1\u05DE\u05D9\u05E7\u05D5\u05DD \u05D4\u05D1\u05D7\u05D9\u05E8\u05D4
\u05D1\u05D9\u05D8\u05D5\u05DC \u05D4\u05E7\u05E4\u05D0\u05EA \u05D7\u05DC\u05D5\u05E0\u05D9\u05D5\u05EA
\u05D2\u05D9\u05DC\u05D9\u05D5\u05DF \u05DE\u05D9\u05DE\u05D9\u05DF \u05DC\u05E9\u05DE\u05D0\u05DC
\u05D4\u05E6\u05D2\u05EA \u05E7\u05D5\u05D5\u05D9 \u05E8\u05E9\u05EA
\u05DE\u05E2\u05E8\u05DB\u05EA \u05D4\u05EA\u05D0\u05E8\u05D9\u05DB\u05D9\u05DD \u05E9\u05DC \u05D7\u05D5\u05D1\u05E8\u05EA \u05D4\u05E2\u05D1\u05D5\u05D3\u05D4
\u05EA\u05E6\u05D5\u05D2\u05EA \u05D7\u05D5\u05D1\u05E8\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4 \u05D4\u05E9\u05D5\u05DE\u05E8\u05EA \u05E2\u05DC \u05D4\u05DE\u05E7\u05D5\u05E8
\u05D7\u05D5\u05D1\u05E8\u05EA \u05D6\u05D5 \u05DE\u05DB\u05D9\u05DC\u05D4 \u05EA\u05DC\u05D5\u05D9\u05D5\u05EA \u05DE\u05D7\u05D5\u05E5 \u05DC\u05D8\u05D5\u05D5\u05D7 \u05D4\u05E0\u05D9\u05EA\u05DF \u05DC\u05E2\u05E8\u05D9\u05DB\u05D4. \u05E0\u05D9\u05EA\u05DF \u05DC\u05D1\u05D3\u05D5\u05E7 \u05EA\u05D0\u05D9\u05DD \u05D5\u05DC\u05E9\u05DE\u05D5\u05E8 \u05E2\u05D5\u05EA\u05E7 \u05D6\u05D4\u05D4 \u05DC\u05DE\u05E7\u05D5\u05E8.
\u05D4\u05D4\u05DE\u05E8\u05D4 \u05E0\u05D7\u05E1\u05DE\u05D4 \u05DE\u05E9\u05D5\u05DD \u05E9\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D9\u05D9\u05E6\u05D2 \u05D1\u05D1\u05D8\u05D7\u05D4 \u05D0\u05EA \u05EA\u05DC\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05E7\u05D5\u05E8 \u05D1\u05E4\u05D5\u05E8\u05DE\u05D8 \u05D4\u05D9\u05E2\u05D3.
\u05DE\u05DE\u05EA\u05D9\u05DF \u05DC\u05D7\u05D9\u05E9\u05D5\u05D1
\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D4\u05D6\u05D9\u05DF \u05E2\u05E8\u05DA \u05D0\u05D5 \u05E0\u05D5\u05E1\u05D7\u05D4 \u05D0\u05DC\u05D4 \u05D1\u05DE\u05E6\u05D1 \u05D4\u05E7\u05DC\u05D8 \u05E9\u05E0\u05D1\u05D7\u05E8.
\u05EA\u05E6\u05D5\u05D2\u05D4
\u05D4\u05D7\u05DC\u05D4
\u05E2\u05D9\u05E6\u05D5\u05D1 \u05EA\u05D0\u05D9\u05DD
\u05DE\u05D9\u05DC\u05D5\u05D9 \u05DB\u05DC\u05E4\u05D9 \u05DE\u05D8\u05D4
\u05DE\u05D9\u05DC\u05D5\u05D9 \u05D9\u05DE\u05D9\u05E0\u05D4
`) };

// packages/i18n/src/catalogs-b2.ts
var indonesian = { ...baseCatalog(`
Buka berkas
Draf baru
BERKAS TERAKHIR
Ruang kerja lokal \xB7 Utamakan luring
Pengaturan
Ruang kerja
Urungkan
Ulangi
Simpan Sebagai
Simpan
Siap
Tampilan
Sistem
Terang
Gelap
Bahasa
Bersihkan berkas terakhir
Pengaturan dan rekaman pemulihan tetap tersimpan di komputer ini.
Tempat untuk dokumen Anda.
Paket aplikasi perkantoran mandiri. Pratinjau M3 mencakup penyuntingan dokumen dan lembar kerja dengan dukungan format terbatas.
Buat draf lokal
Format draf internal \xB7 .oex
Dokumen
Lembar kerja
Presentasi
Penyuntingan teks dan pengurungan
Sel, rumus, dan pemformatan
Kanvas dan bentuk
Buka berkas atau letakkan di sini
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Draf Office EX
Pilih berkas
Dokumen DOC/DOCX dan buku kerja XLS/XLSX yang didukung dapat diedit dan disimpan. Berkas yang tidak didukung tetap hanya-baca dan dapat disalin persis. Kompatibilitas penuh masih dikembangkan.
Dukungan format
Kontainer terhubung
Format modern
Format lama
Draf lokal
Tidak ada berkas terakhir
Tanpa judul
Draf Office EX
Hanya baca \xB7 Pemeriksaan struktur
Belum disimpan
Disimpan
Memeriksa struktur berkas\u2026
Batal
Tutup
Operasi dibatalkan
Rekaman
Revisi
Berhasil disimpan
Draf OEX memakai format internal. Untuk berkas Office, buat dokumen DOC/DOCX atau buku kerja XLS/XLSX dengan fitur yang didukung.
Teks draf
Sel lembar kerja
Edit sel, rumus, dan format. Jenis nilai serta sistem tanggal tetap dipertahankan saat penyimpanan dalam format yang didukung.
Pratinjau kanvas dan pemilihan
Tambah persegi panjang
Klik bentuk untuk memeriksa posisinya. Penyunting lengkap tersedia pada M4.
Bagian paket / aliran
Bagian
Ukuran
SHA-256
Versi format
Format terdeteksi
Simpan salinan persis
Pemetaan dokumen belum tersedia
Draf yang dapat dipulihkan
Pulihkan salinan
Buang
Pemulihan membuat salinan baru yang belum disimpan dan mempertahankan berkas sumber.
Rekaman pemulihan yang rusak dipisahkan dan tidak dimuat.
Dipulihkan sebagai draf baru
Memproses
Laporan kompatibilitas
Tidak ada bagian kontainer untuk ditampilkan.
Slide kosong
Riwayat berkas terakhir dibersihkan
Judul dokumen
Maksimal 32 tab dapat dibuka
Pengembangan mandiri \xB7 Writer dan Sheets
Berkas disimpan; sistem berkas ini tidak memberikan jaminan sinkronisasi direktori.
Berkas disimpan, tetapi catatan pemulihan atau berkas terakhir tidak dapat diperbarui.
Beranda Office EX
Navigasi utama
Dokumen
Tindakan dokumen
M3 \xB7 PRATINJAU PENGEMBANGAN
OFFICE EX / RUANG KERJA LOKAL ANDA
Format regional
Bahasa dokumen baru (preferensi)
Dokumen Writer baru memakai bahasa teks ini. Berkas yang ada tetap sama; penyunting lain akan mengadopsinya kemudian.
Pratinjau format regional
Riwayat
Kanvas
{count} entri; 500 entri pertama ditampilkan.
Berkas
Edit
Tampilan
Draf dokumen baru
Draf lembar kerja baru
Draf presentasi baru
Buka\u2026
Simpan Sebagai\u2026
Tutup tab
Potong
Salin
Tempel
Pilih Semua
Alihkan Layar Penuh
Atur Ulang Zoom
Perbesar
Perkecil
Dokumen Office / Draf Office EX
Semua berkas
Format berkas asli
Ganti tujuan yang sudah ada?
Ganti
Simpan perubahan sebelum menutup?
Buang perubahan
Tidak dapat membuka berkas
Tidak dapat membuka jendela
Selesaikan masukan saat ini sebelum mengubah bahasa.
Buka satu berkas yang dijatuhkan setiap kali.
Berkas atau permintaan tidak valid.
Fitur atau format ini belum didukung.
Operasi diblokir demi keamanan.
Operasi melebihi batas sumber daya.
Dokumen atau tujuan telah berubah.
Operasi berkas gagal.
Terjadi kesalahan internal.
Diagnostik kompatibilitas yang tidak dikenal telah dilaporkan.
Hanya pemeriksaan kontainer. Konten dokumen yang dapat diedit belum diimpor.
Konten terkait makro terdeteksi. Makro tidak dijalankan; data hanya dipertahankan dalam salinan persis.
Berkas bertanda tangan: hanya pemeriksaan. Keabsahan tanda tangan tidak dinyatakan.
Relasi eksternal dicatat; konten eksternal tidak dimuat.
Strict OOXML terdeteksi; pembacaan dan penulisan dokumen belum diverifikasi.
Kontainer terenkripsi terdeteksi. Dekripsi dan penyuntingan tidak tersedia.
Ekstensi berbeda dari konten yang terdeteksi.
Pemformatan teks
Edit paragraf dan pilih teks untuk memformatnya. Enter membagi paragraf; Shift+Enter menambah pergantian baris.
Pratinjau halaman
Perkiraan tata letak halaman. Klik halaman untuk menemukan teks. Ketepatan cetak belum diverifikasi.
Halaman sebelumnya
Halaman berikutnya
Halaman {current} / {total}
Beberapa fitur tipografi atau tata letak memakai perkiraan.
Pratinjau tidak tersedia untuk konten atau batas tata letak ini. Konten sumber tetap sama.
Tebal
Miring
Garis bawah
Rata kiri
Tengah
Rata kanan
Bagi paragraf
Pemisah halaman setelah paragraf
Blok ini tidak dapat diedit dalam pratinjau ini.
Dokumen DOCX baru
Dokumen DOCX
Dukungan DOCX terbatas: teks, pemformatan langsung, gaya bernama yang didukung, tabel persegi panjang tetap, gambar PNG/JPEG sebaris, dan tata letak dasar. Dokumen kompleks tetap hanya-baca.
Font
Ukuran (pt)
Warna teks
Gaya paragraf
Gaya karakter
Pilih gaya
Tabel
Baris
Kolom
Sisipkan tabel
Tambah baris di bawah
Hapus baris
Tambah kolom di kanan
Hapus kolom
Lebar kolom (pt)
Batas tabel
Hapus tabel
Sel {row}, {column}
Sisipkan gambar
Gambar
Lebar gambar (pt)
Hapus gambar
Ukuran kertas
Kustom
A4
Letter
A3
Orientasi halaman
Potret
Lanskap
Lebar halaman (pt)
Tinggi halaman (pt)
Margin atas (pt)
Margin kanan (pt)
Margin bawah (pt)
Margin kiri (pt)
Terapkan pengaturan halaman
Inden (pt)
Sebelum (pt)
Sesudah (pt)
Tinggi baris (pt; 0 = otomatis)
Sisipkan gambar di kursor
Penanda objek mewakili gambar sebaris. Gunakan kontrol gambar untuk mengubah ukuran atau menghapusnya.
Edit teks berkelanjutan
Kembali ke penyunting paragraf
Pilih, salin, potong, tempel, atau format beberapa paragraf teks berdekatan. Tabel, pemisah halaman, bagian, dan paragraf gambar membatasi pilihan. Baris baru yang ditempel menjadi paragraf.
Bagian
Bagian {number}
Pemisah bagian halaman berikutnya
Bahasa teks (BCP 47)
Arah paragraf
Kiri ke kanan
Kanan ke kiri
DOC baru
Dokumen Word 97\u20132003
Penyuntingan DOC terbatas: teks Unicode, gaya dasar, dan satu bagian. DOC yang tidak didukung tetap hanya-baca; tabel dan gambar tidak dapat disimpan dalam cakupan ini.
Pratinjau teks utama hanya-baca, bukan tata letak dokumen lengkap. Menyimpan salinan mempertahankan data asli.
Konversi ke DOC
Konversi ke DOCX
Konversi memerlukan dokumen yang hanya berisi struktur yang didukung. Bagian yang belum dipahami tetap disimpan dalam sumber, tidak dibuang.
Edit pada halaman
Kembali ke alat
Edit pada halaman dengan pembentukan teks bawaan peramban. Seret untuk memilih; salin dan tempel mempertahankan format dan gambar Office EX yang didukung. Ketepatan halaman belum dibandingkan dengan Word.
`), ...sheetsCatalog(`
Buku kerja XLSX baru
Buku kerja Excel (.xlsx)
Edit sel, rumus, dan gaya yang didukung. Berkas terlindungi atau dengan dependensi yang tidak didukung dibuka sebagai pratinjau hanya-baca yang mempertahankan sumber.
Buku kerja Excel 97\u20132003 baru
Buku kerja Excel 97\u20132003 (.xls)
Buku kerja BIFF8: maksimal 65.536 baris dan 256 kolom. Rumus, gaya, dan dependensi sumber diperiksa sebelum menyimpan atau mengonversi.
Konversi ke salinan XLSX
Konversi ke salinan XLS
Kisi lembar kerja
Nilai atau rumus sel
Alamat sel atau rentang
Tambah lembar
Ganti nama lembar
Hapus lembar
Pindahkan lembar lebih awal
Pindahkan lembar lebih akhir
Nama lembar
Lembar, baris, dan kolom
Gabungkan sel
Pisahkan sel
Bersihkan nilai
Sisipkan baris
Hapus baris
Sisipkan kolom
Hapus kolom
Tinggi baris (px)
Lebar kolom (px)
Format angka
Umum
Angka
Persentase
Mata uang
Tanggal
Waktu
Ilmiah
Kode format kustom
Isian sel
Bungkus teks
Batas sel
Masukan rumus
Nama bahasa Inggris \xB7 titik desimal
Nama dan pemisah regional
Hitung ulang
Menghitung\u2026
Dihitung
Belum dihitung: rumus tidak didukung
Hasil sebelumnya: perlu dihitung ulang
Kesalahan rumus
Batalkan penghitungan
{count} sel numerik \xB7 Jumlah {sum}
Pilihan {address}
Klik atau seret untuk memilih. Ketik atau tekan F2 untuk mengedit; Enter mengonfirmasi, Esc membatalkan. Shift memperluas pilihan. Salin dan tempel rentang sebagai TSV. Rumus dimulai dengan =.
Bekukan pada pilihan
Cairkan panel
Lembar dari kanan ke kiri
Tampilkan garis kisi
Sistem tanggal buku kerja
Pratinjau buku kerja yang dipertahankan
Buku kerja ini memiliki dependensi di luar cakupan penyuntingan. Anda dapat memeriksa sel dan menyimpan salinan persis sumbernya.
Konversi diblokir karena dependensi sumber tidak dapat direpresentasikan dengan aman dalam format tujuan.
Menunggu penghitungan
Nilai atau rumus ini tidak dapat dimasukkan dalam mode masukan yang dipilih.
Tampilan
Terapkan
Pemformatan sel
Isi ke bawah
Isi ke kanan
`) };
var malay = { ...baseCatalog(`
Buka fail
Draf baharu
FAIL TERKINI
Ruang kerja setempat \xB7 Utamakan luar talian
Tetapan
Ruang kerja
Buat asal
Buat semula
Simpan Sebagai
Simpan
Sedia
Penampilan
Sistem
Cerah
Gelap
Bahasa
Kosongkan fail terkini
Tetapan dan petikan pemulihan kekal pada komputer ini.
Ruang untuk dokumen anda.
Suite pejabat desktop yang dibangunkan sendiri. Pratonton M3 merangkumi penyuntingan dokumen dan hamparan dengan sokongan format terhad.
Cipta draf setempat
Format draf dalaman \xB7 .oex
Dokumen
Hamparan
Persembahan
Penyuntingan teks dan buat asal
Sel, formula dan pemformatan
Kanvas dan bentuk
Buka fail atau lepaskannya di sini
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Draf Office EX
Pilih fail
Dokumen DOC/DOCX dan buku kerja XLS/XLSX yang disokong boleh disunting dan disimpan. Fail yang tidak disokong kekal baca sahaja dan boleh disalin tepat. Keserasian penuh masih dalam pembangunan.
Sokongan format
Bekas disambungkan
Format moden
Format lama
Draf setempat
Tiada fail terkini
Tanpa tajuk
Draf Office EX
Baca sahaja \xB7 Pemeriksaan struktur
Belum disimpan
Disimpan
Memeriksa struktur fail\u2026
Batal
Tutup
Operasi dibatalkan
Petikan
Semakan
Berjaya disimpan
Draf OEX menggunakan format dalaman. Untuk fail Office, cipta dokumen DOC/DOCX atau buku kerja XLS/XLSX dengan ciri yang disokong.
Teks draf
Sel hamparan
Sunting sel, formula dan format. Jenis nilai dan sistem tarikh dikekalkan semasa menyimpan dalam format yang disokong.
Pratonton kanvas dan pemilihan
Tambah segi empat tepat
Klik bentuk untuk menyemak kedudukannya. Penyunting penuh akan tersedia pada M4.
Bahagian pakej / aliran
Bahagian
Saiz
SHA-256
Versi format
Format dikesan
Simpan salinan tepat
Pemetaan dokumen belum tersedia
Draf boleh dipulihkan
Pulihkan salinan
Buang
Pemulihan mencipta salinan baharu yang belum disimpan dan mengekalkan fail sumber.
Petikan pemulihan yang rosak diasingkan dan tidak dimuatkan.
Dipulihkan sebagai draf baharu
Sedang diproses
Laporan keserasian
Tiada bahagian bekas untuk dipaparkan.
Slaid kosong
Sejarah fail terkini dikosongkan
Tajuk dokumen
Sehingga 32 tab boleh dibuka
Pembangunan sendiri \xB7 Writer dan Sheets
Fail disimpan; sistem fail ini tidak memberikan jaminan penyegerakan direktori.
Fail disimpan tetapi rekod pemulihan atau fail terkini tidak dapat dikemas kini.
Laman utama Office EX
Navigasi utama
Dokumen
Tindakan dokumen
M3 \xB7 PRATONTON PEMBANGUNAN
OFFICE EX / RUANG KERJA SETEMPAT ANDA
Format rantau
Bahasa dokumen baharu (keutamaan)
Dokumen Writer baharu menggunakan bahasa teks ini. Fail sedia ada tidak berubah; penyunting lain akan menggunakannya kemudian.
Pratonton format rantau
Sejarah
Kanvas
{count} entri; 500 yang pertama dipaparkan.
Fail
Sunting
Paparan
Draf dokumen baharu
Draf hamparan baharu
Draf persembahan baharu
Buka\u2026
Simpan Sebagai\u2026
Tutup tab
Potong
Salin
Tampal
Pilih Semua
Togol Skrin Penuh
Tetapkan Semula Zum
Zum Masuk
Zum Keluar
Dokumen Office / Draf Office EX
Semua fail
Format fail asal
Gantikan sasaran sedia ada?
Gantikan
Simpan perubahan sebelum menutup?
Buang perubahan
Tidak dapat membuka fail
Tidak dapat membuka tetingkap
Selesaikan input semasa sebelum menukar bahasa.
Buka satu fail yang dilepaskan pada satu masa.
Fail atau permintaan tidak sah.
Ciri atau format ini belum disokong.
Operasi disekat atas sebab keselamatan.
Operasi melebihi had sumber.
Dokumen atau sasaran telah berubah.
Operasi fail gagal.
Ralat dalaman berlaku.
Diagnostik keserasian yang tidak dikenali dilaporkan.
Pemeriksaan bekas sahaja. Kandungan dokumen yang boleh disunting belum diimport.
Kandungan berkaitan makro dikesan. Makro tidak dijalankan; data dikekalkan hanya dalam salinan tepat.
Fail bertandatangan: pemeriksaan sahaja. Kesahan tandatangan tidak dinyatakan.
Hubungan luaran direkodkan; kandungan luaran tidak dimuatkan.
Strict OOXML dikesan; pembacaan dan penulisan dokumen belum disahkan.
Bekas disulitkan dikesan. Penyahsulitan dan penyuntingan tidak tersedia.
Sambungan fail berbeza daripada kandungan yang dikesan.
Pemformatan teks
Sunting perenggan dan pilih teks untuk memformatkannya. Enter memisahkan perenggan; Shift+Enter menambah pemisah baris.
Pratonton halaman
Anggaran susun atur halaman. Klik halaman untuk mencari teks. Ketepatan cetakan belum disahkan.
Halaman sebelumnya
Halaman seterusnya
Halaman {current} / {total}
Sesetengah ciri tipografi atau susun atur dianggarkan.
Pratonton tidak tersedia untuk kandungan atau had susun atur ini. Kandungan sumber tidak berubah.
Tebal
Condong
Garis bawah
Jajar kiri
Tengah
Jajar kanan
Pisahkan perenggan
Pemisah halaman selepas perenggan
Blok ini tidak boleh disunting dalam pratonton ini.
Dokumen DOCX baharu
Dokumen DOCX
Sokongan DOCX terhad: teks, pemformatan langsung, gaya bernama yang disokong, jadual segi empat tetap, gambar PNG/JPEG sebaris dan susun atur asas. Dokumen kompleks kekal baca sahaja.
Fon
Saiz (pt)
Warna teks
Gaya perenggan
Gaya aksara
Pilih gaya
Jadual
Baris
Lajur
Sisipkan jadual
Tambah baris di bawah
Padam baris
Tambah lajur di kanan
Padam lajur
Lebar lajur (pt)
Sempadan jadual
Padam jadual
Sel {row}, {column}
Sisipkan imej
Imej
Lebar imej (pt)
Alih keluar imej
Saiz kertas
Tersuai
A4
Letter
A3
Orientasi halaman
Potret
Landskap
Lebar halaman (pt)
Tinggi halaman (pt)
Jidar atas (pt)
Jidar kanan (pt)
Jidar bawah (pt)
Jidar kiri (pt)
Gunakan tetapan halaman
Inden (pt)
Sebelum (pt)
Selepas (pt)
Tinggi baris (pt; 0 = automatik)
Sisipkan imej pada kursor
Penanda objek mewakili imej sebaris. Gunakan kawalan gambar untuk mengubah saiz atau mengalih keluarnya.
Sunting teks berterusan
Kembali ke penyunting perenggan
Pilih, salin, potong, tampal atau format perenggan teks bersebelahan. Jadual, pemisah halaman, seksyen dan perenggan imej menjadi sempadan pilihan. Baris baharu yang ditampal menjadi perenggan.
Seksyen
Seksyen {number}
Pemisah seksyen halaman seterusnya
Bahasa teks (BCP 47)
Arah perenggan
Kiri ke kanan
Kanan ke kiri
DOC baharu
Dokumen Word 97\u20132003
Penyuntingan DOC terhad: teks Unicode, gaya asas dan satu seksyen. DOC yang tidak disokong kekal baca sahaja; jadual dan gambar tidak boleh disimpan dalam skop ini.
Pratonton teks utama baca sahaja, bukan susun atur dokumen penuh. Menyimpan salinan mengekalkan data asal.
Tukar kepada DOC
Tukar kepada DOCX
Penukaran memerlukan dokumen yang hanya mengandungi struktur yang disokong. Bahagian yang belum difahami dikekalkan dalam sumber, bukan dibuang.
Sunting pada halaman
Kembali ke alat
Sunting pada halaman menggunakan pembentukan teks asli pelayar. Seret untuk memilih; salin dan tampal mengekalkan format dan imej Office EX yang disokong. Ketepatan halaman belum dibandingkan dengan Word.
`), ...sheetsCatalog(`
Buku kerja XLSX baharu
Buku kerja Excel (.xlsx)
Sunting sel, formula dan gaya yang disokong. Fail dilindungi atau dengan kebergantungan yang tidak disokong dibuka sebagai pratonton baca sahaja yang mengekalkan sumber.
Buku kerja Excel 97\u20132003 baharu
Buku kerja Excel 97\u20132003 (.xls)
Buku kerja BIFF8: sehingga 65,536 baris dan 256 lajur. Formula, gaya dan kebergantungan sumber diperiksa sebelum penyimpanan atau penukaran.
Tukar kepada salinan XLSX
Tukar kepada salinan XLS
Grid hamparan
Nilai atau formula sel
Alamat sel atau julat
Tambah helaian
Namakan semula helaian
Padam helaian
Alih helaian ke hadapan
Alih helaian ke belakang
Nama helaian
Helaian, baris dan lajur
Cantumkan sel
Nyahcantum sel
Kosongkan nilai
Sisipkan baris
Padam baris
Sisipkan lajur
Padam lajur
Tinggi baris (px)
Lebar lajur (px)
Format nombor
Umum
Nombor
Peratusan
Mata wang
Tarikh
Masa
Saintifik
Kod format tersuai
Isian sel
Balut teks
Sempadan sel
Input formula
Nama bahasa Inggeris \xB7 titik perpuluhan
Nama dan pemisah rantau
Kira semula
Mengira\u2026
Dikira
Belum dikira: formula tidak disokong
Hasil terdahulu: pengiraan semula diperlukan
Ralat formula
Batalkan pengiraan
{count} sel bernombor \xB7 Jumlah {sum}
Pilihan {address}
Klik atau seret untuk memilih. Taip atau tekan F2 untuk menyunting; Enter mengesahkan, Esc membatalkan. Shift meluaskan pilihan. Salin dan tampal julat sebagai TSV. Formula bermula dengan =.
Bekukan pada pilihan
Nyahbekukan anak tetingkap
Helaian kanan ke kiri
Tunjukkan garisan grid
Sistem tarikh buku kerja
Pratonton buku kerja yang dikekalkan
Buku kerja ini mengandungi kebergantungan di luar skop penyuntingan. Anda boleh memeriksa sel dan menyimpan salinan tepat sumber asal.
Penukaran disekat kerana kebergantungan sumber tidak boleh diwakili dengan selamat dalam format sasaran.
Menunggu pengiraan
Nilai atau formula ini tidak boleh dimasukkan dalam mod input yang dipilih.
Paparan
Gunakan
Pemformatan sel
Isi ke bawah
Isi ke kanan
`) };
var vietnamese = { ...baseCatalog(`
M\u1EDF t\u1EC7p
B\u1EA3n nh\xE1p m\u1EDBi
T\u1EC6P G\u1EA6N \u0110\xC2Y
Kh\xF4ng gian l\xE0m vi\u1EC7c c\u1EE5c b\u1ED9 \xB7 \u01AFu ti\xEAn ngo\u1EA1i tuy\u1EBFn
C\xE0i \u0111\u1EB7t
Kh\xF4ng gian l\xE0m vi\u1EC7c
Ho\xE0n t\xE1c
L\xE0m l\u1EA1i
L\u01B0u th\xE0nh
L\u01B0u
S\u1EB5n s\xE0ng
Giao di\u1EC7n
H\u1EC7 th\u1ED1ng
S\xE1ng
T\u1ED1i
Ng\xF4n ng\u1EEF
X\xF3a danh s\xE1ch t\u1EC7p g\u1EA7n \u0111\xE2y
C\xE0i \u0111\u1EB7t v\xE0 \u1EA3nh ch\u1EE5p kh\xF4i ph\u1EE5c \u0111\u01B0\u1EE3c gi\u1EEF tr\xEAn m\xE1y t\xEDnh n\xE0y.
N\u01A1i d\xE0nh cho t\xE0i li\u1EC7u c\u1EE7a b\u1EA1n.
B\u1ED9 \u1EE9ng d\u1EE5ng v\u0103n ph\xF2ng \u0111\u01B0\u1EE3c ph\xE1t tri\u1EC3n \u0111\u1ED9c l\u1EADp. B\u1EA3n xem tr\u01B0\u1EDBc M3 h\u1ED7 tr\u1EE3 ch\u1EC9nh s\u1EEDa t\xE0i li\u1EC7u v\xE0 b\u1EA3ng t\xEDnh trong ph\u1EA1m vi \u0111\u1ECBnh d\u1EA1ng \u0111\xE3 h\u1ED7 tr\u1EE3.
T\u1EA1o b\u1EA3n nh\xE1p c\u1EE5c b\u1ED9
\u0110\u1ECBnh d\u1EA1ng b\u1EA3n nh\xE1p n\u1ED9i b\u1ED9 \xB7 .oex
T\xE0i li\u1EC7u
B\u1EA3ng t\xEDnh
B\u1EA3n tr\xECnh chi\u1EBFu
Ch\u1EC9nh s\u1EEDa v\u0103n b\u1EA3n v\xE0 ho\xE0n t\xE1c
\xD4, c\xF4ng th\u1EE9c v\xE0 \u0111\u1ECBnh d\u1EA1ng
Trang v\u1EBD v\xE0 h\xECnh d\u1EA1ng
M\u1EDF t\u1EC7p ho\u1EB7c th\u1EA3 t\u1EC7p v\xE0o \u0111\xE2y
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 B\u1EA3n nh\xE1p Office EX
Ch\u1ECDn t\u1EC7p
C\xF3 th\u1EC3 ch\u1EC9nh s\u1EEDa v\xE0 l\u01B0u t\xE0i li\u1EC7u DOC/DOCX, s\u1ED5 t\xEDnh XLS/XLSX \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3. T\u1EC7p ngo\xE0i ph\u1EA1m vi h\u1ED7 tr\u1EE3 ch\u1EC9 \u0111\u01B0\u1EE3c \u0111\u1ECDc v\xE0 sao ch\xE9p nguy\xEAn b\u1EA3n. Kh\u1EA3 n\u0103ng t\u01B0\u01A1ng th\xEDch \u0111\u1EA7y \u0111\u1EE7 v\u1EABn \u0111ang ph\xE1t tri\u1EC3n.
H\u1ED7 tr\u1EE3 \u0111\u1ECBnh d\u1EA1ng
\u0110\xE3 k\u1EBFt n\u1ED1i v\xF9ng ch\u1EE9a
\u0110\u1ECBnh d\u1EA1ng hi\u1EC7n \u0111\u1EA1i
\u0110\u1ECBnh d\u1EA1ng c\u0169
B\u1EA3n nh\xE1p c\u1EE5c b\u1ED9
Kh\xF4ng c\xF3 t\u1EC7p g\u1EA7n \u0111\xE2y
Ch\u01B0a c\xF3 ti\xEAu \u0111\u1EC1
B\u1EA3n nh\xE1p Office EX
Ch\u1EC9 \u0111\u1ECDc \xB7 Ki\u1EC3m tra c\u1EA5u tr\xFAc
Ch\u01B0a l\u01B0u
\u0110\xE3 l\u01B0u
\u0110ang ki\u1EC3m tra c\u1EA5u tr\xFAc t\u1EC7p\u2026
H\u1EE7y
\u0110\xF3ng
\u0110\xE3 h\u1EE7y thao t\xE1c
\u1EA2nh ch\u1EE5p
B\u1EA3n s\u1EEDa \u0111\u1ED5i
\u0110\xE3 l\u01B0u th\xE0nh c\xF4ng
B\u1EA3n nh\xE1p OEX d\xF9ng \u0111\u1ECBnh d\u1EA1ng n\u1ED9i b\u1ED9. \u0110\u1EC3 t\u1EA1o t\u1EC7p Office, h\xE3y t\u1EA1o t\xE0i li\u1EC7u DOC/DOCX ho\u1EB7c s\u1ED5 t\xEDnh XLS/XLSX v\u1EDBi c\xE1c t\xEDnh n\u0103ng \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3.
V\u0103n b\u1EA3n b\u1EA3n nh\xE1p
C\xE1c \xF4 b\u1EA3ng t\xEDnh
Ch\u1EC9nh s\u1EEDa \xF4, c\xF4ng th\u1EE9c v\xE0 \u0111\u1ECBnh d\u1EA1ng. Ki\u1EC3u gi\xE1 tr\u1ECB v\xE0 h\u1EC7 ng\xE0y \u0111\u01B0\u1EE3c gi\u1EEF nguy\xEAn khi l\u01B0u b\u1EB1ng \u0111\u1ECBnh d\u1EA1ng \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3.
Xem tr\u01B0\u1EDBc trang v\u1EBD v\xE0 l\u1EF1a ch\u1ECDn
Th\xEAm h\xECnh ch\u1EEF nh\u1EADt
Nh\u1EA5p v\xE0o h\xECnh \u0111\u1EC3 ki\u1EC3m tra v\u1ECB tr\xED. Tr\xECnh ch\u1EC9nh s\u1EEDa \u0111\u1EA7y \u0111\u1EE7 s\u1EBD c\xF3 \u1EDF M4.
C\xE1c ph\u1EA7n / lu\u1ED3ng c\u1EE7a g\xF3i
Ph\u1EA7n
K\xEDch th\u01B0\u1EDBc
SHA-256
Phi\xEAn b\u1EA3n \u0111\u1ECBnh d\u1EA1ng
\u0110\u1ECBnh d\u1EA1ng ph\xE1t hi\u1EC7n \u0111\u01B0\u1EE3c
L\u01B0u b\u1EA3n sao nguy\xEAn v\u1EB9n
Ch\u01B0a c\xF3 \xE1nh x\u1EA1 n\u1ED9i dung t\xE0i li\u1EC7u
B\u1EA3n nh\xE1p c\xF3 th\u1EC3 kh\xF4i ph\u1EE5c
Kh\xF4i ph\u1EE5c b\u1EA3n sao
Lo\u1EA1i b\u1ECF
Kh\xF4i ph\u1EE5c s\u1EBD t\u1EA1o b\u1EA3n sao m\u1EDBi ch\u01B0a l\u01B0u v\xE0 gi\u1EEF nguy\xEAn t\u1EC7p ngu\u1ED3n.
\u1EA2nh ch\u1EE5p kh\xF4i ph\u1EE5c b\u1ECB h\u1ECFng \u0111\xE3 \u0111\u01B0\u1EE3c c\xE1ch ly v\xE0 kh\xF4ng \u0111\u01B0\u1EE3c t\u1EA3i.
\u0110\xE3 kh\xF4i ph\u1EE5c th\xE0nh b\u1EA3n nh\xE1p m\u1EDBi
\u0110ang x\u1EED l\xFD
B\xE1o c\xE1o t\u01B0\u01A1ng th\xEDch
Kh\xF4ng c\xF3 ph\u1EA7n n\xE0o c\u1EE7a v\xF9ng ch\u1EE9a \u0111\u1EC3 hi\u1EC3n th\u1ECB.
Trang chi\u1EBFu tr\u1ED1ng
\u0110\xE3 x\xF3a l\u1ECBch s\u1EED t\u1EC7p g\u1EA7n \u0111\xE2y
Ti\xEAu \u0111\u1EC1 t\xE0i li\u1EC7u
C\xF3 th\u1EC3 m\u1EDF t\u1ED1i \u0111a 32 th\u1EBB
Ph\xE1t tri\u1EC3n \u0111\u1ED9c l\u1EADp \xB7 Writer v\xE0 Sheets
\u0110\xE3 l\u01B0u t\u1EC7p; h\u1EC7 th\u1ED1ng t\u1EC7p n\xE0y kh\xF4ng b\u1EA3o \u0111\u1EA3m \u0111\u1ED3ng b\u1ED9 th\u01B0 m\u1EE5c.
\u0110\xE3 l\u01B0u t\u1EC7p nh\u01B0ng kh\xF4ng th\u1EC3 c\u1EADp nh\u1EADt th\xF4ng tin kh\xF4i ph\u1EE5c ho\u1EB7c t\u1EC7p g\u1EA7n \u0111\xE2y.
Trang ch\u1EE7 Office EX
\u0110i\u1EC1u h\u01B0\u1EDBng ch\xEDnh
T\xE0i li\u1EC7u
Thao t\xE1c t\xE0i li\u1EC7u
M3 \xB7 B\u1EA2N XEM TR\u01AF\u1EDAC PH\xC1T TRI\u1EC2N
OFFICE EX / KH\xD4NG GIAN L\xC0M VI\u1EC6C C\u1EE4C B\u1ED8
\u0110\u1ECBnh d\u1EA1ng theo v\xF9ng
Ng\xF4n ng\u1EEF t\xE0i li\u1EC7u m\u1EDBi (t\xF9y ch\u1ECDn)
T\xE0i li\u1EC7u Writer m\u1EDBi d\xF9ng ng\xF4n ng\u1EEF v\u0103n b\u1EA3n n\xE0y. C\xE1c t\u1EC7p hi\u1EC7n c\xF3 kh\xF4ng thay \u0111\u1ED5i; c\xE1c tr\xECnh ch\u1EC9nh s\u1EEDa kh\xE1c s\u1EBD \xE1p d\u1EE5ng sau.
Xem tr\u01B0\u1EDBc \u0111\u1ECBnh d\u1EA1ng v\xF9ng
L\u1ECBch s\u1EED
Trang v\u1EBD
{count} m\u1EE5c; hi\u1EC3n th\u1ECB 500 m\u1EE5c \u0111\u1EA7u ti\xEAn.
T\u1EC7p
Ch\u1EC9nh s\u1EEDa
Xem
B\u1EA3n nh\xE1p t\xE0i li\u1EC7u m\u1EDBi
B\u1EA3n nh\xE1p b\u1EA3ng t\xEDnh m\u1EDBi
B\u1EA3n nh\xE1p tr\xECnh chi\u1EBFu m\u1EDBi
M\u1EDF\u2026
L\u01B0u th\xE0nh\u2026
\u0110\xF3ng th\u1EBB
C\u1EAFt
Sao ch\xE9p
D\xE1n
Ch\u1ECDn t\u1EA5t c\u1EA3
B\u1EADt/t\u1EAFt to\xE0n m\xE0n h\xECnh
\u0110\u1EB7t l\u1EA1i m\u1EE9c thu ph\xF3ng
Ph\xF3ng to
Thu nh\u1ECF
T\xE0i li\u1EC7u Office / B\u1EA3n nh\xE1p Office EX
T\u1EA5t c\u1EA3 t\u1EC7p
\u0110\u1ECBnh d\u1EA1ng t\u1EC7p g\u1ED1c
Thay th\u1EBF t\u1EC7p \u0111\xEDch hi\u1EC7n c\xF3?
Thay th\u1EBF
L\u01B0u thay \u0111\u1ED5i tr\u01B0\u1EDBc khi \u0111\xF3ng?
B\u1ECF thay \u0111\u1ED5i
Kh\xF4ng th\u1EC3 m\u1EDF t\u1EC7p
Kh\xF4ng th\u1EC3 m\u1EDF c\u1EEDa s\u1ED5
Ho\xE0n t\u1EA5t nh\u1EADp li\u1EC7u hi\u1EC7n t\u1EA1i tr\u01B0\u1EDBc khi \u0111\u1ED5i ng\xF4n ng\u1EEF.
M\u1ED7i l\u1EA7n ch\u1EC9 m\u1EDF m\u1ED9t t\u1EC7p \u0111\u01B0\u1EE3c th\u1EA3.
T\u1EC7p ho\u1EB7c y\xEAu c\u1EA7u kh\xF4ng h\u1EE3p l\u1EC7.
T\xEDnh n\u0103ng ho\u1EB7c \u0111\u1ECBnh d\u1EA1ng n\xE0y ch\u01B0a \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3.
Thao t\xE1c \u0111\xE3 b\u1ECB ch\u1EB7n v\xEC l\xFD do an to\xE0n.
Thao t\xE1c v\u01B0\u1EE3t qu\xE1 gi\u1EDBi h\u1EA1n t\xE0i nguy\xEAn.
T\xE0i li\u1EC7u ho\u1EB7c t\u1EC7p \u0111\xEDch \u0111\xE3 thay \u0111\u1ED5i.
Thao t\xE1c t\u1EC7p th\u1EA5t b\u1EA1i.
\u0110\xE3 x\u1EA3y ra l\u1ED7i n\u1ED9i b\u1ED9.
\u0110\xE3 c\xF3 b\xE1o c\xE1o ch\u1EA9n \u0111o\xE1n t\u01B0\u01A1ng th\xEDch kh\xF4ng x\xE1c \u0111\u1ECBnh.
Ch\u1EC9 ki\u1EC3m tra v\xF9ng ch\u1EE9a. N\u1ED9i dung t\xE0i li\u1EC7u c\xF3 th\u1EC3 ch\u1EC9nh s\u1EEDa ch\u01B0a \u0111\u01B0\u1EE3c nh\u1EADp.
Ph\xE1t hi\u1EC7n n\u1ED9i dung li\xEAn quan \u0111\u1EBFn macro. Macro kh\xF4ng ch\u1EA1y; d\u1EEF li\u1EC7u ch\u1EC9 \u0111\u01B0\u1EE3c gi\u1EEF trong b\u1EA3n sao nguy\xEAn v\u1EB9n.
T\u1EC7p c\xF3 ch\u1EEF k\xFD: ch\u1EC9 ki\u1EC3m tra. Ch\u01B0a x\xE1c nh\u1EADn t\xEDnh h\u1EE3p l\u1EC7 c\u1EE7a ch\u1EEF k\xFD.
C\xE1c quan h\u1EC7 b\xEAn ngo\xE0i \u0111\u01B0\u1EE3c ghi nh\u1EADn; kh\xF4ng t\u1EA3i n\u1ED9i dung b\xEAn ngo\xE0i.
Ph\xE1t hi\u1EC7n Strict OOXML; vi\u1EC7c \u0111\u1ECDc v\xE0 ghi n\u1ED9i dung t\xE0i li\u1EC7u ch\u01B0a \u0111\u01B0\u1EE3c x\xE1c minh.
Ph\xE1t hi\u1EC7n v\xF9ng ch\u1EE9a \u0111\u01B0\u1EE3c m\xE3 h\xF3a. Ch\u01B0a h\u1ED7 tr\u1EE3 gi\u1EA3i m\xE3 v\xE0 ch\u1EC9nh s\u1EEDa.
Ph\u1EA7n m\u1EDF r\u1ED9ng kh\xE1c v\u1EDBi n\u1ED9i dung ph\xE1t hi\u1EC7n \u0111\u01B0\u1EE3c.
\u0110\u1ECBnh d\u1EA1ng v\u0103n b\u1EA3n
Ch\u1EC9nh s\u1EEDa \u0111o\u1EA1n v\xE0 ch\u1ECDn v\u0103n b\u1EA3n \u0111\u1EC3 \u0111\u1ECBnh d\u1EA1ng. Enter t\xE1ch \u0111o\u1EA1n; Shift+Enter th\xEAm ng\u1EAFt d\xF2ng.
Xem tr\u01B0\u1EDBc trang
B\u1ED1 c\u1EE5c trang \u01B0\u1EDBc t\xEDnh. Nh\u1EA5p v\xE0o trang \u0111\u1EC3 t\xECm v\u0103n b\u1EA3n. \u0110\u1ED9 ch\xEDnh x\xE1c khi in ch\u01B0a \u0111\u01B0\u1EE3c x\xE1c minh.
Trang tr\u01B0\u1EDBc
Trang sau
Trang {current} / {total}
M\u1ED9t s\u1ED1 t\xEDnh n\u0103ng ki\u1EC3u ch\u1EEF ho\u1EB7c b\u1ED1 c\u1EE5c \u0111\u01B0\u1EE3c t\xEDnh g\u1EA7n \u0111\xFAng.
Kh\xF4ng c\xF3 b\u1EA3n xem tr\u01B0\u1EDBc cho n\u1ED9i dung ho\u1EB7c gi\u1EDBi h\u1EA1n b\u1ED1 c\u1EE5c n\xE0y. N\u1ED9i dung ngu\u1ED3n kh\xF4ng thay \u0111\u1ED5i.
\u0110\u1EADm
Nghi\xEAng
G\u1EA1ch ch\xE2n
C\u0103n tr\xE1i
C\u0103n gi\u1EEFa
C\u0103n ph\u1EA3i
T\xE1ch \u0111o\u1EA1n
Ng\u1EAFt trang sau \u0111o\u1EA1n
Kh\xF4ng th\u1EC3 ch\u1EC9nh s\u1EEDa kh\u1ED1i n\xE0y trong b\u1EA3n xem tr\u01B0\u1EDBc.
T\xE0i li\u1EC7u DOCX m\u1EDBi
T\xE0i li\u1EC7u DOCX
Ph\u1EA1m vi DOCX gi\u1EDBi h\u1EA1n: v\u0103n b\u1EA3n, \u0111\u1ECBnh d\u1EA1ng tr\u1EF1c ti\u1EBFp, ki\u1EC3u c\xF3 t\xEAn \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3, b\u1EA3ng ch\u1EEF nh\u1EADt c\u1ED1 \u0111\u1ECBnh, \u1EA3nh PNG/JPEG n\u1ED9i tuy\u1EBFn v\xE0 b\u1ED1 c\u1EE5c c\u01A1 b\u1EA3n. T\xE0i li\u1EC7u ph\u1EE9c t\u1EA1p v\u1EABn ch\u1EC9 \u0111\u1ECDc.
Ph\xF4ng ch\u1EEF
C\u1EE1 ch\u1EEF (pt)
M\xE0u ch\u1EEF
Ki\u1EC3u \u0111o\u1EA1n
Ki\u1EC3u k\xFD t\u1EF1
Ch\u1ECDn ki\u1EC3u
B\u1EA3ng
H\xE0ng
C\u1ED9t
Ch\xE8n b\u1EA3ng
Th\xEAm h\xE0ng b\xEAn d\u01B0\u1EDBi
X\xF3a h\xE0ng
Th\xEAm c\u1ED9t b\xEAn ph\u1EA3i
X\xF3a c\u1ED9t
\u0110\u1ED9 r\u1ED9ng c\u1ED9t (pt)
Vi\u1EC1n b\u1EA3ng
X\xF3a b\u1EA3ng
\xD4 {row}, {column}
Ch\xE8n \u1EA3nh
\u1EA2nh
\u0110\u1ED9 r\u1ED9ng \u1EA3nh (pt)
X\xF3a \u1EA3nh
Kh\u1ED5 gi\u1EA5y
T\xF9y ch\u1EC9nh
A4
Letter
A3
H\u01B0\u1EDBng trang
D\u1ECDc
Ngang
\u0110\u1ED9 r\u1ED9ng trang (pt)
Chi\u1EC1u cao trang (pt)
L\u1EC1 tr\xEAn (pt)
L\u1EC1 ph\u1EA3i (pt)
L\u1EC1 d\u01B0\u1EDBi (pt)
L\u1EC1 tr\xE1i (pt)
\xC1p d\u1EE5ng c\xE0i \u0111\u1EB7t trang
Th\u1EE5t l\u1EC1 (pt)
Tr\u01B0\u1EDBc (pt)
Sau (pt)
Chi\u1EC1u cao d\xF2ng (pt; 0 = t\u1EF1 \u0111\u1ED9ng)
Ch\xE8n \u1EA3nh t\u1EA1i con tr\u1ECF
D\u1EA5u \u0111\u1ED1i t\u01B0\u1EE3ng \u0111\u1EA1i di\u1EC7n cho \u1EA3nh n\u1ED9i tuy\u1EBFn. D\xF9ng c\xF4ng c\u1EE5 \u1EA3nh \u0111\u1EC3 \u0111\u1ED5i k\xEDch th\u01B0\u1EDBc ho\u1EB7c x\xF3a \u1EA3nh.
Ch\u1EC9nh s\u1EEDa v\u0103n b\u1EA3n li\xEAn t\u1EE5c
Tr\u1EDF l\u1EA1i tr\xECnh ch\u1EC9nh s\u1EEDa \u0111o\u1EA1n
Ch\u1ECDn, sao ch\xE9p, c\u1EAFt, d\xE1n ho\u1EB7c \u0111\u1ECBnh d\u1EA1ng nhi\u1EC1u \u0111o\u1EA1n v\u0103n b\u1EA3n li\u1EC1n k\u1EC1. B\u1EA3ng, ng\u1EAFt trang, ph\u1EA7n v\xE0 \u0111o\u1EA1n ch\u1EE9a \u1EA3nh l\xE0 ranh gi\u1EDBi l\u1EF1a ch\u1ECDn. D\xF2ng m\u1EDBi \u0111\u01B0\u1EE3c d\xE1n s\u1EBD th\xE0nh \u0111o\u1EA1n m\u1EDBi.
Ph\u1EA7n
Ph\u1EA7n {number}
Ng\u1EAFt ph\u1EA7n sang trang ti\u1EBFp theo
Ng\xF4n ng\u1EEF v\u0103n b\u1EA3n (BCP 47)
H\u01B0\u1EDBng \u0111o\u1EA1n
T\u1EEB tr\xE1i sang ph\u1EA3i
T\u1EEB ph\u1EA3i sang tr\xE1i
DOC m\u1EDBi
T\xE0i li\u1EC7u Word 97\u20132003
Ch\u1EC9nh s\u1EEDa DOC gi\u1EDBi h\u1EA1n: v\u0103n b\u1EA3n Unicode, ki\u1EC3u c\u01A1 b\u1EA3n v\xE0 m\u1ED9t ph\u1EA7n. DOC ch\u01B0a \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3 v\u1EABn ch\u1EC9 \u0111\u1ECDc; kh\xF4ng th\u1EC3 l\u01B0u b\u1EA3ng v\xE0 \u1EA3nh trong ph\u1EA1m vi n\xE0y.
Xem tr\u01B0\u1EDBc v\u0103n b\u1EA3n ch\xEDnh \u1EDF ch\u1EBF \u0111\u1ED9 ch\u1EC9 \u0111\u1ECDc, kh\xF4ng ph\u1EA3i to\xE0n b\u1ED9 b\u1ED1 c\u1EE5c t\xE0i li\u1EC7u. L\u01B0u b\u1EA3n sao s\u1EBD gi\u1EEF nguy\xEAn d\u1EEF li\u1EC7u g\u1ED1c.
Chuy\u1EC3n sang DOC
Chuy\u1EC3n sang DOCX
Chuy\u1EC3n \u0111\u1ED5i y\xEAu c\u1EA7u t\xE0i li\u1EC7u ch\u1EC9 ch\u1EE9a c\u1EA5u tr\xFAc \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3. C\xE1c ph\u1EA7n ch\u01B0a hi\u1EC3u \u0111\u01B0\u1EE3c gi\u1EEF trong ngu\u1ED3n, kh\xF4ng b\u1ECB lo\u1EA1i b\u1ECF.
Ch\u1EC9nh s\u1EEDa tr\xEAn trang
Tr\u1EDF l\u1EA1i c\xF4ng c\u1EE5
Ch\u1EC9nh s\u1EEDa tr\xEAn trang b\u1EB1ng kh\u1EA3 n\u0103ng \u0111\u1ECBnh h\xECnh v\u0103n b\u1EA3n c\u1EE7a tr\xECnh duy\u1EC7t. K\xE9o \u0111\u1EC3 ch\u1ECDn; sao ch\xE9p v\xE0 d\xE1n gi\u1EEF c\xE1c \u0111\u1ECBnh d\u1EA1ng v\xE0 \u1EA3nh Office EX \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3. \u0110\u1ED9 ch\xEDnh x\xE1c trang ch\u01B0a \u0111\u01B0\u1EE3c so s\xE1nh v\u1EDBi Word.
`), ...sheetsCatalog(`
S\u1ED5 t\xEDnh XLSX m\u1EDBi
S\u1ED5 t\xEDnh Excel (.xlsx)
Ch\u1EC9nh s\u1EEDa c\xE1c \xF4, c\xF4ng th\u1EE9c v\xE0 ki\u1EC3u \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3. T\u1EC7p \u0111\u01B0\u1EE3c b\u1EA3o v\u1EC7 ho\u1EB7c c\xF3 quan h\u1EC7 ph\u1EE5 thu\u1ED9c ch\u01B0a h\u1ED7 tr\u1EE3 s\u1EBD m\u1EDF \u1EDF ch\u1EBF \u0111\u1ED9 ch\u1EC9 \u0111\u1ECDc v\xE0 gi\u1EEF nguy\xEAn b\u1EA3n g\u1ED1c.
S\u1ED5 t\xEDnh Excel 97\u20132003 m\u1EDBi
S\u1ED5 t\xEDnh Excel 97\u20132003 (.xls)
S\u1ED5 t\xEDnh BIFF8: t\u1ED1i \u0111a 65.536 h\xE0ng v\xE0 256 c\u1ED9t. C\xF4ng th\u1EE9c, ki\u1EC3u v\xE0 quan h\u1EC7 ph\u1EE5 thu\u1ED9c \u0111\u01B0\u1EE3c ki\u1EC3m tra tr\u01B0\u1EDBc khi l\u01B0u ho\u1EB7c chuy\u1EC3n \u0111\u1ED5i.
Chuy\u1EC3n th\xE0nh b\u1EA3n sao XLSX
Chuy\u1EC3n th\xE0nh b\u1EA3n sao XLS
L\u01B0\u1EDBi b\u1EA3ng t\xEDnh
Gi\xE1 tr\u1ECB ho\u1EB7c c\xF4ng th\u1EE9c \xF4
\u0110\u1ECBa ch\u1EC9 \xF4 ho\u1EB7c ph\u1EA1m vi
Th\xEAm trang t\xEDnh
\u0110\u1ED5i t\xEAn trang t\xEDnh
X\xF3a trang t\xEDnh
Di chuy\u1EC3n trang t\xEDnh l\xEAn tr\u01B0\u1EDBc
Di chuy\u1EC3n trang t\xEDnh ra sau
T\xEAn trang t\xEDnh
Trang t\xEDnh, h\xE0ng v\xE0 c\u1ED9t
G\u1ED9p \xF4
B\u1ECF g\u1ED9p \xF4
X\xF3a gi\xE1 tr\u1ECB
Ch\xE8n h\xE0ng
X\xF3a h\xE0ng
Ch\xE8n c\u1ED9t
X\xF3a c\u1ED9t
Chi\u1EC1u cao h\xE0ng (px)
\u0110\u1ED9 r\u1ED9ng c\u1ED9t (px)
\u0110\u1ECBnh d\u1EA1ng s\u1ED1
Chung
S\u1ED1
Ph\u1EA7n tr\u0103m
Ti\u1EC1n t\u1EC7
Ng\xE0y
Gi\u1EDD
Khoa h\u1ECDc
M\xE3 \u0111\u1ECBnh d\u1EA1ng t\xF9y ch\u1EC9nh
M\xE0u n\u1EC1n \xF4
Ng\u1EAFt d\xF2ng v\u0103n b\u1EA3n
Vi\u1EC1n \xF4
Nh\u1EADp c\xF4ng th\u1EE9c
T\xEAn ti\u1EBFng Anh \xB7 d\u1EA5u ch\u1EA5m th\u1EADp ph\xE2n
T\xEAn v\xE0 d\u1EA5u ph\xE2n c\xE1ch theo v\xF9ng
T\xEDnh l\u1EA1i
\u0110ang t\xEDnh\u2026
\u0110\xE3 t\xEDnh
Ch\u01B0a t\xEDnh: c\xF4ng th\u1EE9c ch\u01B0a \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3
K\u1EBFt qu\u1EA3 c\u0169: c\u1EA7n t\xEDnh l\u1EA1i
L\u1ED7i c\xF4ng th\u1EE9c
H\u1EE7y t\xEDnh to\xE1n
{count} \xF4 s\u1ED1 \xB7 T\u1ED5ng {sum}
V\xF9ng ch\u1ECDn {address}
Nh\u1EA5p ho\u1EB7c k\xE9o \u0111\u1EC3 ch\u1ECDn. Nh\u1EADp ho\u1EB7c nh\u1EA5n F2 \u0111\u1EC3 s\u1EEDa; Enter x\xE1c nh\u1EADn, Esc h\u1EE7y. Shift m\u1EDF r\u1ED9ng v\xF9ng ch\u1ECDn. Sao ch\xE9p v\xE0 d\xE1n ph\u1EA1m vi d\u01B0\u1EDBi d\u1EA1ng TSV. C\xF4ng th\u1EE9c b\u1EAFt \u0111\u1EA7u b\u1EB1ng =.
C\u1ED1 \u0111\u1ECBnh t\u1EA1i v\xF9ng ch\u1ECDn
B\u1ECF c\u1ED1 \u0111\u1ECBnh ng\u0103n
Trang t\xEDnh t\u1EEB ph\u1EA3i sang tr\xE1i
Hi\u1EC3n th\u1ECB \u0111\u01B0\u1EDDng l\u01B0\u1EDBi
H\u1EC7 ng\xE0y c\u1EE7a s\u1ED5 t\xEDnh
Xem tr\u01B0\u1EDBc s\u1ED5 t\xEDnh gi\u1EEF nguy\xEAn g\u1ED1c
S\u1ED5 t\xEDnh n\xE0y ch\u1EE9a quan h\u1EC7 ph\u1EE5 thu\u1ED9c ngo\xE0i ph\u1EA1m vi ch\u1EC9nh s\u1EEDa. B\u1EA1n c\xF3 th\u1EC3 ki\u1EC3m tra \xF4 v\xE0 l\u01B0u b\u1EA3n sao nguy\xEAn v\u1EB9n c\u1EE7a t\u1EC7p g\u1ED1c.
Chuy\u1EC3n \u0111\u1ED5i b\u1ECB ch\u1EB7n v\xEC kh\xF4ng th\u1EC3 bi\u1EC3u di\u1EC5n an to\xE0n quan h\u1EC7 ph\u1EE5 thu\u1ED9c c\u1EE7a ngu\u1ED3n trong \u0111\u1ECBnh d\u1EA1ng \u0111\xEDch.
\u0110ang ch\u1EDD t\xEDnh to\xE1n
Kh\xF4ng th\u1EC3 nh\u1EADp gi\xE1 tr\u1ECB ho\u1EB7c c\xF4ng th\u1EE9c n\xE0y b\u1EB1ng ch\u1EBF \u0111\u1ED9 nh\u1EADp \u0111\xE3 ch\u1ECDn.
Xem
\xC1p d\u1EE5ng
\u0110\u1ECBnh d\u1EA1ng \xF4
\u0110i\u1EC1n xu\u1ED1ng
\u0110i\u1EC1n sang ph\u1EA3i
`) };

// packages/i18n/src/catalogs-b3.ts
var turkish = { ...baseCatalog(`
Dosya a\xE7
Yeni taslak
SON DOSYALAR
Yerel \xE7al\u0131\u015Fma alan\u0131 \xB7 \xD6nce \xE7evrimd\u0131\u015F\u0131
Ayarlar
\xC7al\u0131\u015Fma alan\u0131
Geri al
Yinele
Farkl\u0131 Kaydet
Kaydet
Haz\u0131r
G\xF6r\xFCn\xFCm
Sistem
A\xE7\u0131k
Koyu
Dil
Son dosyalar\u0131 temizle
Ayarlar ve kurtarma anl\u0131k g\xF6r\xFCnt\xFCleri bu bilgisayarda kal\u0131r.
Belgeleriniz i\xE7in bir yer.
Ba\u011F\u0131ms\u0131z geli\u015Ftirilen masa\xFCst\xFC ofis paketi. M3 \xF6nizlemesi, desteklenen bi\xE7im kapsam\u0131 i\xE7inde belge ve hesap tablosu d\xFCzenleme sunar.
Yerel taslak olu\u015Ftur
Dahili taslak bi\xE7imi \xB7 .oex
Belge
Hesap tablosu
Sunu
Metin d\xFCzenleme ve geri alma
H\xFCcreler, form\xFCller ve bi\xE7imlendirme
Tuval ve \u015Fekiller
Dosya a\xE7\u0131n veya buraya b\u0131rak\u0131n
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX taslaklar\u0131
Dosya se\xE7
Desteklenen DOC/DOCX belgeleri ve XLS/XLSX \xE7al\u0131\u015Fma kitaplar\u0131 d\xFCzenlenip kaydedilebilir. Di\u011Fer dosyalar salt okunur kal\u0131r ve birebir kopyalanabilir. Tam uyumluluk geli\u015Ftirilmeye devam ediyor.
Bi\xE7im deste\u011Fi
Kapsay\u0131c\u0131 ba\u011Fland\u0131
Modern bi\xE7imler
Eski bi\xE7imler
Yerel taslaklar
Son dosya yok
Ads\u0131z
Office EX tasla\u011F\u0131
Salt okunur \xB7 Yap\u0131 incelemesi
Kaydedilmedi
Kaydedildi
Dosya yap\u0131s\u0131 inceleniyor\u2026
\u0130ptal
Kapat
\u0130\u015Flem iptal edildi
Anl\u0131k g\xF6r\xFCnt\xFC
Revizyon
Ba\u015Far\u0131yla kaydedildi
OEX taslaklar\u0131 dahili bi\xE7imi kullan\u0131r. Office dosyalar\u0131 i\xE7in desteklenen \xF6zelliklerle DOC/DOCX belgesi veya XLS/XLSX \xE7al\u0131\u015Fma kitab\u0131 olu\u015Fturun.
Taslak metni
Hesap tablosu h\xFCcreleri
H\xFCcreleri, form\xFClleri ve bi\xE7imleri d\xFCzenleyin. Desteklenen bi\xE7imlerde kaydederken de\u011Fer t\xFCrleri ve tarih sistemi korunur.
Tuval ve se\xE7im \xF6nizlemesi
Dikd\xF6rtgen ekle
Konumunu denetlemek i\xE7in \u015Fekle t\u0131klay\u0131n. Tam d\xFCzenleyici M4 a\u015Famas\u0131nda gelecek.
Paket par\xE7alar\u0131 / ak\u0131\u015Flar
Par\xE7a
Boyut
SHA-256
Bi\xE7im s\xFCr\xFCm\xFC
Alg\u0131lanan bi\xE7im
Birebir kopya kaydet
Belge e\u015Flemesi hen\xFCz yok
Kurtar\u0131labilir taslaklar
Bir kopyay\u0131 kurtar
At
Kurtarma, kaydedilmemi\u015F yeni bir kopya olu\u015Fturur ve kaynak dosyay\u0131 korur.
Bozuk kurtarma anl\u0131k g\xF6r\xFCnt\xFCleri ayr\u0131ld\u0131 ve y\xFCklenmedi.
Yeni taslak olarak kurtar\u0131ld\u0131
\xC7al\u0131\u015F\u0131yor
Uyumluluk raporu
G\xF6r\xFCnt\xFClenecek kapsay\u0131c\u0131 par\xE7as\u0131 yok.
Bo\u015F slayt
Son dosya ge\xE7mi\u015Fi temizlendi
Belge ba\u015Fl\u0131\u011F\u0131
En fazla 32 sekme a\xE7\u0131labilir
Ba\u011F\u0131ms\u0131z geli\u015Ftirme \xB7 Writer ve Sheets
Dosya kaydedildi; bu dosya sistemi dizin e\u015Fitleme garantisi sa\u011Flamad\u0131.
Dosya kaydedildi ancak kurtarma veya son dosya kay\u0131tlar\u0131 g\xFCncellenemedi.
Office EX ana sayfas\u0131
Ana gezinme
Belgeler
Belge i\u015Flemleri
M3 \xB7 GEL\u0130\u015ET\u0130RME \xD6N\u0130ZLEMES\u0130
OFFICE EX / YEREL \xC7ALI\u015EMA ALANINIZ
B\xF6lgesel bi\xE7imler
Yeni belge dili (tercih)
Yeni Writer belgeleri bu metin dilini kullan\u0131r. Mevcut dosyalar de\u011Fi\u015Fmez; di\u011Fer d\xFCzenleyiciler daha sonra kullanacak.
B\xF6lgesel bi\xE7im \xF6nizlemesi
Ge\xE7mi\u015F
Tuval
{count} giri\u015F; ilk 500 g\xF6steriliyor.
Dosya
D\xFCzen
G\xF6r\xFCn\xFCm
Yeni belge tasla\u011F\u0131
Yeni hesap tablosu tasla\u011F\u0131
Yeni sunu tasla\u011F\u0131
A\xE7\u2026
Farkl\u0131 Kaydet\u2026
Sekmeyi kapat
Kes
Kopyala
Yap\u0131\u015Ft\u0131r
T\xFCm\xFCn\xFC Se\xE7
Tam Ekran\u0131 A\xE7/Kapat
Yak\u0131nla\u015Ft\u0131rmay\u0131 S\u0131f\u0131rla
Yak\u0131nla\u015Ft\u0131r
Uzakla\u015Ft\u0131r
Office belgeleri / Office EX taslaklar\u0131
T\xFCm dosyalar
\xD6zg\xFCn dosya bi\xE7imi
Mevcut hedef de\u011Fi\u015Ftirilsin mi?
De\u011Fi\u015Ftir
Kapatmadan \xF6nce de\u011Fi\u015Fiklikler kaydedilsin mi?
De\u011Fi\u015Fiklikleri at
Dosya a\xE7\u0131lam\u0131yor
Pencere a\xE7\u0131lam\u0131yor
Dili de\u011Fi\u015Ftirmeden \xF6nce ge\xE7erli giri\u015Fi tamamlay\u0131n.
Her seferinde b\u0131rak\u0131lan tek bir dosyay\u0131 a\xE7\u0131n.
Ge\xE7ersiz dosya veya istek.
Bu \xF6zellik veya bi\xE7im hen\xFCz desteklenmiyor.
\u0130\u015Flem g\xFCvenlik nedeniyle engellendi.
\u0130\u015Flem kaynak s\u0131n\u0131r\u0131n\u0131 a\u015F\u0131yor.
Belge veya hedef de\u011Fi\u015Fti.
Dosya i\u015Flemi ba\u015Far\u0131s\u0131z oldu.
\u0130\xE7 hata olu\u015Ftu.
Tan\u0131nmayan bir uyumluluk tan\u0131s\u0131 bildirildi.
Yaln\u0131zca kapsay\u0131c\u0131 incelemesi. D\xFCzenlenebilir belge i\xE7eri\u011Fi i\xE7e aktar\u0131lmad\u0131.
Makroyla ilgili i\xE7erik alg\u0131land\u0131. Makrolar \xE7al\u0131\u015Ft\u0131r\u0131lmaz; veriler yaln\u0131zca birebir kopyalarda korunur.
\u0130mzal\u0131 dosya: yaln\u0131zca inceleme. \u0130mzan\u0131n ge\xE7erlili\u011Fi do\u011Frulanm\u0131\u015F say\u0131lmaz.
D\u0131\u015F ili\u015Fkiler kaydedilir; d\u0131\u015F i\xE7erik y\xFCklenmez.
Strict OOXML alg\u0131land\u0131; belge okuma ve yazma do\u011Frulanmad\u0131.
\u015Eifreli kapsay\u0131c\u0131 alg\u0131land\u0131. \u015Eifre \xE7\xF6zme ve d\xFCzenleme kullan\u0131lamaz.
Uzant\u0131, alg\u0131lanan i\xE7erikten farkl\u0131.
Metin bi\xE7imlendirme
Paragraflar\u0131 d\xFCzenleyin ve bi\xE7imlendirmek i\xE7in metin se\xE7in. Enter paragraf\u0131 b\xF6ler; Shift+Enter sat\u0131r sonu ekler.
Sayfa \xF6nizlemesi
Tahmini sayfa d\xFCzeni. Metni bulmak i\xE7in sayfaya t\u0131klay\u0131n. Bask\u0131 do\u011Frulu\u011Fu hen\xFCz do\u011Frulanmad\u0131.
\xD6nceki sayfa
Sonraki sayfa
Sayfa {current} / {total}
Baz\u0131 tipografi veya d\xFCzen \xF6zellikleri yakla\u015F\u0131k olarak g\xF6sterilir.
Bu i\xE7erik veya d\xFCzen s\u0131n\u0131r\u0131 i\xE7in \xF6nizleme yok. Kaynak i\xE7erik de\u011Fi\u015Fmedi.
Kal\u0131n
\u0130talik
Alt\u0131 \xE7izili
Sola hizala
Ortala
Sa\u011Fa hizala
Paragraf\u0131 b\xF6l
Paragraftan sonra sayfa sonu
Bu blok bu \xF6nizlemede d\xFCzenlenemez.
Yeni DOCX belgesi
DOCX belgesi
S\u0131n\u0131rl\u0131 DOCX kapsam\u0131: metin, do\u011Frudan bi\xE7imlendirme, desteklenen adland\u0131r\u0131lm\u0131\u015F stiller, sabit dikd\xF6rtgen tablolar, sat\u0131r i\xE7i PNG/JPEG resimler ve temel d\xFCzen. Karma\u015F\u0131k belgeler salt okunur kal\u0131r.
Yaz\u0131 tipi
Boyut (pt)
Metin rengi
Paragraf stili
Karakter stili
Stil se\xE7
Tablo
Sat\u0131rlar
S\xFCtunlar
Tablo ekle
Alta sat\u0131r ekle
Sat\u0131r\u0131 sil
Sa\u011Fa s\xFCtun ekle
S\xFCtunu sil
S\xFCtun geni\u015Fli\u011Fi (pt)
Tablo kenarl\u0131klar\u0131
Tabloyu sil
H\xFCcre {row}, {column}
Resim ekle
Resim
Resim geni\u015Fli\u011Fi (pt)
Resmi kald\u0131r
Ka\u011F\u0131t boyutu
\xD6zel
A4
Letter
A3
Sayfa y\xF6n\xFC
Dikey
Yatay
Sayfa geni\u015Fli\u011Fi (pt)
Sayfa y\xFCksekli\u011Fi (pt)
\xDCst kenar bo\u015Flu\u011Fu (pt)
Sa\u011F kenar bo\u015Flu\u011Fu (pt)
Alt kenar bo\u015Flu\u011Fu (pt)
Sol kenar bo\u015Flu\u011Fu (pt)
Sayfa ayarlar\u0131n\u0131 uygula
Girinti (pt)
\xD6nce (pt)
Sonra (pt)
Sat\u0131r y\xFCksekli\u011Fi (pt; 0 = otomatik)
\u0130mle\xE7 konumuna resim ekle
Nesne i\u015Fareti sat\u0131r i\xE7i resmi temsil eder. Boyutunu de\u011Fi\u015Ftirmek veya kald\u0131rmak i\xE7in resim denetimlerini kullan\u0131n.
Kesintisiz metni d\xFCzenle
Paragraf d\xFCzenleyicisine d\xF6n
Biti\u015Fik metin paragraflar\u0131nda se\xE7im, kopyalama, kesme, yap\u0131\u015Ft\u0131rma veya bi\xE7imlendirme yap\u0131n. Tablolar, sayfa sonlar\u0131, b\xF6l\xFCmler ve resim paragraflar\u0131 se\xE7im s\u0131n\u0131r\u0131d\u0131r. Yap\u0131\u015Ft\u0131r\u0131lan yeni sat\u0131rlar paragrafa d\xF6n\xFC\u015F\xFCr.
B\xF6l\xFCm
B\xF6l\xFCm {number}
Sonraki sayfa b\xF6l\xFCm sonu
Metin dili (BCP 47)
Paragraf y\xF6n\xFC
Soldan sa\u011Fa
Sa\u011Fdan sola
Yeni DOC
Word 97\u20132003 belgesi
S\u0131n\u0131rl\u0131 DOC d\xFCzenleme: Unicode metin, temel stiller ve tek b\xF6l\xFCm. Desteklenmeyen DOC dosyalar\u0131 salt okunur kal\u0131r; bu kapsamda tablo ve resimler kaydedilemez.
Yaln\u0131zca ana metnin salt okunur \xF6nizlemesidir, tam belge d\xFCzeni de\u011Fildir. Kopya kaydetmek \xF6zg\xFCn verileri korur.
DOC bi\xE7imine d\xF6n\xFC\u015Ft\xFCr
DOCX bi\xE7imine d\xF6n\xFC\u015Ft\xFCr
D\xF6n\xFC\u015Ft\xFCrme i\xE7in belge yaln\u0131zca desteklenen yap\u0131lar\u0131 i\xE7ermelidir. Anla\u015F\u0131lamayan par\xE7alar kaynakta korunur, at\u0131lmaz.
Sayfada d\xFCzenle
Ara\xE7lara d\xF6n
Taray\u0131c\u0131n\u0131n yerel metin \u015Fekillendirmesiyle sayfada d\xFCzenleyin. Se\xE7mek i\xE7in s\xFCr\xFCkleyin; kopyalama ve yap\u0131\u015Ft\u0131rma desteklenen Office EX bi\xE7imlerini ve resimlerini korur. Sayfa do\u011Frulu\u011Fu hen\xFCz Word ile kar\u015F\u0131la\u015Ft\u0131r\u0131lmad\u0131.
`), ...sheetsCatalog(`
Yeni XLSX \xE7al\u0131\u015Fma kitab\u0131
Excel \xE7al\u0131\u015Fma kitab\u0131 (.xlsx)
Desteklenen h\xFCcreleri, form\xFClleri ve stilleri d\xFCzenleyin. Korumal\u0131 veya desteklenmeyen ba\u011F\u0131ml\u0131l\u0131klar i\xE7eren dosyalar \xF6zg\xFCn h\xE2li korunarak salt okunur \xF6nizlemede a\xE7\u0131l\u0131r.
Yeni Excel 97\u20132003 \xE7al\u0131\u015Fma kitab\u0131
Excel 97\u20132003 \xE7al\u0131\u015Fma kitab\u0131 (.xls)
BIFF8 \xE7al\u0131\u015Fma kitab\u0131: en fazla 65.536 sat\u0131r ve 256 s\xFCtun. Kaydetme ve d\xF6n\xFC\u015Ft\xFCrme \xF6ncesinde form\xFCller, stiller ve kaynak ba\u011F\u0131ml\u0131l\u0131klar\u0131 denetlenir.
XLSX kopyas\u0131na d\xF6n\xFC\u015Ft\xFCr
XLS kopyas\u0131na d\xF6n\xFC\u015Ft\xFCr
Hesap tablosu \u0131zgaras\u0131
H\xFCcre de\u011Feri veya form\xFCl\xFC
H\xFCcre veya aral\u0131k adresi
Sayfa ekle
Sayfay\u0131 yeniden adland\u0131r
Sayfay\u0131 sil
Sayfay\u0131 \xF6ne ta\u015F\u0131
Sayfay\u0131 arkaya ta\u015F\u0131
Sayfa ad\u0131
Sayfalar, sat\u0131rlar ve s\xFCtunlar
H\xFCcreleri birle\u015Ftir
H\xFCcreleri ay\u0131r
De\u011Ferleri temizle
Sat\u0131r ekle
Sat\u0131r sil
S\xFCtun ekle
S\xFCtun sil
Sat\u0131r y\xFCksekli\u011Fi (px)
S\xFCtun geni\u015Fli\u011Fi (px)
Say\u0131 bi\xE7imi
Genel
Say\u0131
Y\xFCzde
Para birimi
Tarih
Saat
Bilimsel
\xD6zel bi\xE7im kodu
H\xFCcre dolgusu
Metni kayd\u0131r
H\xFCcre kenarl\u0131klar\u0131
Form\xFCl giri\u015Fi
\u0130ngilizce adlar \xB7 ondal\u0131k nokta
B\xF6lgesel adlar ve ay\u0131r\u0131c\u0131lar
Yeniden hesapla
Hesaplan\u0131yor\u2026
Hesapland\u0131
Hesaplanmad\u0131: desteklenmeyen form\xFCl
\xD6nceki sonu\xE7: yeniden hesaplama gerekli
Form\xFCl hatas\u0131
Hesaplamay\u0131 iptal et
{count} say\u0131sal h\xFCcre \xB7 Toplam {sum}
Se\xE7im {address}
Se\xE7mek i\xE7in t\u0131klay\u0131n veya s\xFCr\xFCkleyin. D\xFCzenlemek i\xE7in yaz\u0131n veya F2\u2019ye bas\u0131n; Enter onaylar, Esc iptal eder. Shift se\xE7imi geni\u015Fletir. Aral\u0131klar\u0131 TSV olarak kopyalay\u0131p yap\u0131\u015Ft\u0131r\u0131n. Form\xFCller = ile ba\u015Flar.
Se\xE7imde dondur
B\xF6lmeleri \xE7\xF6z
Sa\u011Fdan sola sayfa
K\u0131lavuz \xE7izgilerini g\xF6ster
\xC7al\u0131\u015Fma kitab\u0131 tarih sistemi
\xD6zg\xFCn \xE7al\u0131\u015Fma kitab\u0131 \xF6nizlemesi
Bu \xE7al\u0131\u015Fma kitab\u0131 d\xFCzenlenebilir kapsam\u0131n d\u0131\u015F\u0131nda ba\u011F\u0131ml\u0131l\u0131klar i\xE7erir. H\xFCcreleri inceleyebilir ve \xF6zg\xFCn dosyan\u0131n birebir kopyas\u0131n\u0131 kaydedebilirsiniz.
Kaynak ba\u011F\u0131ml\u0131l\u0131klar\u0131 hedef bi\xE7imde g\xFCvenli bi\xE7imde temsil edilemedi\u011Fi i\xE7in d\xF6n\xFC\u015Ft\xFCrme engellendi.
Hesaplama bekleniyor
Bu de\u011Fer veya form\xFCl se\xE7ili giri\u015F modunda girilemez.
G\xF6r\xFCn\xFCm
Uygula
H\xFCcre bi\xE7imlendirme
A\u015Fa\u011F\u0131 doldur
Sa\u011Fa doldur
`) };
var dutch = { ...baseCatalog(`
Bestand openen
Nieuw concept
RECENTE BESTANDEN
Lokale werkruimte \xB7 Eerst offline
Instellingen
Werkruimte
Ongedaan maken
Opnieuw
Opslaan als
Opslaan
Gereed
Weergave
Systeem
Licht
Donker
Taal
Recente bestanden wissen
Instellingen en herstelkopie\xEBn blijven op deze computer.
Een plek voor je documenten.
Onafhankelijk ontwikkelde kantoorsoftware. Deze M3-voorvertoning ondersteunt het bewerken van documenten en werkbladen binnen de ondersteunde formaten.
Lokaal concept maken
Intern conceptformaat \xB7 .oex
Document
Spreadsheet
Presentatie
Tekst bewerken en ongedaan maken
Cellen, formules en opmaak
Tekenoppervlak en vormen
Open een bestand of sleep het hierheen
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Office EX-concepten
Bestand kiezen
Ondersteunde DOC/DOCX-documenten en XLS/XLSX-werkmappen kunnen worden bewerkt en opgeslagen. Andere bestanden blijven alleen-lezen en kunnen exact worden gekopieerd. Volledige compatibiliteit is nog in ontwikkeling.
Formaatondersteuning
Container verbonden
Moderne formaten
Oudere formaten
Lokale concepten
Geen recente bestanden
Naamloos
Office EX-concept
Alleen-lezen \xB7 Structuurcontrole
Niet opgeslagen
Opgeslagen
Bestandsstructuur controleren\u2026
Annuleren
Sluiten
Bewerking geannuleerd
Momentopname
Revisie
Opgeslagen
OEX-concepten gebruiken een intern formaat. Maak voor Office-bestanden een DOC/DOCX-document of XLS/XLSX-werkmap met ondersteunde functies.
Concepttekst
Spreadsheetcellen
Bewerk cellen, formules en opmaak. Waardetypen en het datumsysteem blijven behouden bij opslag in ondersteunde formaten.
Voorbeeld van tekenoppervlak en selectie
Rechthoek toevoegen
Klik op een vorm om de positie te controleren. De volledige editor volgt in M4.
Pakketonderdelen / streams
Onderdeel
Grootte
SHA-256
Formaatversie
Gedetecteerd formaat
Exacte kopie opslaan
Documentvertaling nog niet beschikbaar
Herstelbare concepten
Kopie herstellen
Verwijderen
Herstellen maakt een nieuwe, niet-opgeslagen kopie en behoudt het bronbestand.
Beschadigde herstelkopie\xEBn zijn ge\xEFsoleerd en niet geladen.
Hersteld als nieuw concept
Bezig
Compatibiliteitsrapport
Geen containeronderdelen om weer te geven.
Lege dia
Geschiedenis van recente bestanden gewist
Documenttitel
Er kunnen maximaal 32 tabbladen openstaan
Onafhankelijke ontwikkeling \xB7 Writer en Sheets
Bestand opgeslagen; dit bestandssysteem bood geen garantie voor mapsynchronisatie.
Bestand opgeslagen, maar herstelgegevens of recente bestanden konden niet worden bijgewerkt.
Office EX-startpagina
Hoofdnavigatie
Documenten
Documentacties
M3 \xB7 ONTWIKKELVOORBEELD
OFFICE EX / JE LOKALE WERKRUIMTE
Regionale notaties
Taal van nieuwe documenten (voorkeur)
Nieuwe Writer-documenten gebruiken deze teksttaal. Bestaande bestanden blijven ongewijzigd; andere editors volgen later.
Voorbeeld van regionale notatie
Geschiedenis
Tekenoppervlak
{count} vermeldingen; de eerste 500 worden getoond.
Bestand
Bewerken
Beeld
Nieuw documentconcept
Nieuw spreadsheetconcept
Nieuw presentatieconcept
Openen\u2026
Opslaan als\u2026
Tabblad sluiten
Knippen
Kopi\xEBren
Plakken
Alles selecteren
Volledig scherm omschakelen
Zoom herstellen
Inzoomen
Uitzoomen
Office-documenten / Office EX-concepten
Alle bestanden
Oorspronkelijk bestandsformaat
Bestaand doel vervangen?
Vervangen
Wijzigingen opslaan v\xF3\xF3r het sluiten?
Wijzigingen negeren
Bestand kan niet worden geopend
Venster kan niet worden geopend
Rond de huidige invoer af voordat je de taal wijzigt.
Open \xE9\xE9n neergezet bestand tegelijk.
Ongeldig bestand of verzoek.
Deze functie of dit formaat wordt nog niet ondersteund.
De bewerking is om veiligheidsredenen geblokkeerd.
De bewerking overschrijdt een resourcelimiet.
Het document of doel is gewijzigd.
De bestandsbewerking is mislukt.
Er is een interne fout opgetreden.
Er is een onbekende compatibiliteitsmelding gerapporteerd.
Alleen containercontrole. Bewerkbare documentinhoud is niet ge\xEFmporteerd.
Macrogerelateerde inhoud gedetecteerd. Macro\u2019s worden niet uitgevoerd; gegevens blijven alleen behouden in exacte kopie\xEBn.
Ondertekend bestand: alleen controle. De geldigheid van de handtekening wordt niet bevestigd.
Externe relaties worden geregistreerd; externe inhoud wordt niet geladen.
Strict OOXML herkend; het lezen en schrijven van documentinhoud is niet geverifieerd.
Versleutelde container herkend. Ontsleutelen en bewerken zijn niet beschikbaar.
De extensie wijkt af van de gedetecteerde inhoud.
Tekstopmaak
Bewerk alinea\u2019s en selecteer tekst om op te maken. Enter splitst een alinea; Shift+Enter voegt een regeleinde toe.
Paginavoorbeeld
Geschatte pagina-indeling. Klik op de pagina om tekst te vinden. De afdruknauwkeurigheid is nog niet geverifieerd.
Vorige pagina
Volgende pagina
Pagina {current} / {total}
Sommige typografische of indelingsfuncties worden benaderd.
Voorbeeld niet beschikbaar voor deze inhoud of indelingslimiet. De broninhoud blijft ongewijzigd.
Vet
Cursief
Onderstrepen
Links uitlijnen
Centreren
Rechts uitlijnen
Alinea splitsen
Pagina-einde na alinea
Dit blok kan niet worden bewerkt in deze voorvertoning.
Nieuw DOCX-document
DOCX-document
Beperkte DOCX-ondersteuning: tekst, directe opmaak, ondersteunde benoemde stijlen, vaste rechthoekige tabellen, ingesloten PNG/JPEG-afbeeldingen in de tekst en basisindeling. Complexe documenten blijven alleen-lezen.
Lettertype
Grootte (pt)
Tekstkleur
Alineastijl
Tekenstijl
Stijl kiezen
Tabel
Rijen
Kolommen
Tabel invoegen
Rij eronder toevoegen
Rij verwijderen
Kolom rechts toevoegen
Kolom verwijderen
Kolombreedte (pt)
Tabelranden
Tabel verwijderen
Cel {row}, {column}
Afbeelding invoegen
Afbeelding
Afbeeldingsbreedte (pt)
Afbeelding verwijderen
Papierformaat
Aangepast
A4
Letter
A3
Afdrukstand
Staand
Liggend
Paginabreedte (pt)
Paginahoogte (pt)
Bovenmarge (pt)
Rechtermarge (pt)
Ondermarge (pt)
Linkermarge (pt)
Pagina-instellingen toepassen
Inspringing (pt)
Voor (pt)
Na (pt)
Regelhoogte (pt; 0 = automatisch)
Afbeelding bij cursor invoegen
De objectmarkering stelt een afbeelding in de tekst voor. Gebruik de afbeeldingsopties om deze te vergroten, verkleinen of verwijderen.
Doorlopende tekst bewerken
Terug naar alinea-editor
Selecteer, kopieer, knip, plak of maak op over aangrenzende tekstalinea\u2019s. Tabellen, pagina-einden, secties en afbeeldingsalinea\u2019s vormen selectiegrenzen. Geplakte nieuwe regels worden alinea\u2019s.
Sectie
Sectie {number}
Sectie-einde op volgende pagina
Teksttaal (BCP 47)
Alinearichting
Van links naar rechts
Van rechts naar links
Nieuwe DOC
Word 97\u20132003-document
Beperkte DOC-bewerking: Unicode-tekst, basisstijlen en \xE9\xE9n sectie. Niet-ondersteunde DOC-bestanden blijven alleen-lezen; tabellen en afbeeldingen kunnen binnen dit profiel niet worden opgeslagen.
Alleen-lezenvoorbeeld van de hoofdtekst, niet de volledige documentindeling. Een kopie opslaan behoudt de oorspronkelijke gegevens.
Converteren naar DOC
Converteren naar DOCX
Conversie vereist een document met uitsluitend ondersteunde structuren. Onbekende onderdelen blijven in de bron behouden en worden niet weggegooid.
Op de pagina bewerken
Terug naar hulpmiddelen
Bewerk op de pagina met de ingebouwde tekstvorming van de browser. Sleep om te selecteren; kopi\xEBren en plakken behoudt ondersteunde Office EX-opmaak en afbeeldingen. De paginanauwkeurigheid is nog niet met Word vergeleken.
`), ...sheetsCatalog(`
Nieuwe XLSX-werkmap
Excel-werkmap (.xlsx)
Bewerk ondersteunde cellen, formules en stijlen. Beveiligde bestanden of bestanden met niet-ondersteunde afhankelijkheden worden alleen-lezen geopend met behoud van het origineel.
Nieuwe Excel 97\u20132003-werkmap
Excel 97\u20132003-werkmap (.xls)
BIFF8-werkmap: maximaal 65.536 rijen en 256 kolommen. Formules, stijlen en bronafhankelijkheden worden gecontroleerd v\xF3\xF3r opslaan of conversie.
Converteren naar XLSX-kopie
Converteren naar XLS-kopie
Spreadsheetraster
Celwaarde of formule
Cel- of bereikadres
Blad toevoegen
Blad hernoemen
Blad verwijderen
Blad naar voren verplaatsen
Blad naar achteren verplaatsen
Bladnaam
Bladen, rijen en kolommen
Cellen samenvoegen
Samenvoeging opheffen
Waarden wissen
Rijen invoegen
Rijen verwijderen
Kolommen invoegen
Kolommen verwijderen
Rijhoogte (px)
Kolombreedte (px)
Getalnotatie
Standaard
Getal
Percentage
Valuta
Datum
Tijd
Wetenschappelijk
Aangepaste notatiecode
Celopvulling
Tekstterugloop
Celranden
Formule-invoer
Engelse namen \xB7 decimale punt
Regionale namen en scheidingstekens
Herberekenen
Berekenen\u2026
Berekend
Niet berekend: niet-ondersteunde formule
Vorig resultaat: herberekening nodig
Formulefout
Berekening annuleren
{count} numerieke cellen \xB7 Som {sum}
Selectie {address}
Klik of sleep om te selecteren. Typ of druk op F2 om te bewerken; Enter bevestigt en Esc annuleert. Shift vergroot de selectie. Kopieer en plak bereiken als TSV. Formules beginnen met =.
Bij selectie blokkeren
Titels blokkeren opheffen
Blad van rechts naar links
Rasterlijnen weergeven
Datumsysteem van werkmap
Voorbeeld van bewaarde werkmap
Deze werkmap bevat afhankelijkheden buiten het bewerkbare bereik. Je kunt cellen bekijken en een exacte kopie van het origineel opslaan.
Conversie is geblokkeerd omdat bronafhankelijkheden niet veilig in het doelformaat kunnen worden weergegeven.
Wachten op berekening
Deze waarde of formule kan niet in de geselecteerde invoermodus worden ingevoerd.
Beeld
Toepassen
Celopmaak
Omlaag doorvoeren
Naar rechts doorvoeren
`) };

// packages/i18n/src/catalogs-b4.ts
var ukrainian = { ...baseCatalog(`
\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0438 \u0444\u0430\u0439\u043B
\u041D\u043E\u0432\u0430 \u0447\u0435\u0440\u043D\u0435\u0442\u043A\u0430
\u041E\u0421\u0422\u0410\u041D\u041D\u0406 \u0424\u0410\u0419\u041B\u0418
\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0438\u0439 \u0440\u043E\u0431\u043E\u0447\u0438\u0439 \u043F\u0440\u043E\u0441\u0442\u0456\u0440 \xB7 \u041F\u0435\u0440\u0435\u0434\u0443\u0441\u0456\u043C \u043E\u0444\u043B\u0430\u0439\u043D
\u041D\u0430\u043B\u0430\u0448\u0442\u0443\u0432\u0430\u043D\u043D\u044F
\u0420\u043E\u0431\u043E\u0447\u0438\u0439 \u043F\u0440\u043E\u0441\u0442\u0456\u0440
\u0421\u043A\u0430\u0441\u0443\u0432\u0430\u0442\u0438 \u0434\u0456\u044E
\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0438 \u0434\u0456\u044E
\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438 \u044F\u043A
\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438
\u0413\u043E\u0442\u043E\u0432\u043E
\u041E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u043D\u044F
\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u0430
\u0421\u0432\u0456\u0442\u043B\u0430
\u0422\u0435\u043C\u043D\u0430
\u041C\u043E\u0432\u0430
\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u0438 \u043E\u0441\u0442\u0430\u043D\u043D\u0456 \u0444\u0430\u0439\u043B\u0438
\u041D\u0430\u043B\u0430\u0448\u0442\u0443\u0432\u0430\u043D\u043D\u044F \u0442\u0430 \u0437\u043D\u0456\u043C\u043A\u0438 \u0432\u0456\u0434\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044F \u0437\u0430\u043B\u0438\u0448\u0430\u044E\u0442\u044C\u0441\u044F \u043D\u0430 \u0446\u044C\u043E\u043C\u0443 \u043A\u043E\u043C\u043F\u2019\u044E\u0442\u0435\u0440\u0456.
\u041C\u0456\u0441\u0446\u0435 \u0434\u043B\u044F \u0432\u0430\u0448\u0438\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0456\u0432.
\u041D\u0435\u0437\u0430\u043B\u0435\u0436\u043D\u043E \u0440\u043E\u0437\u0440\u043E\u0431\u043B\u0435\u043D\u0438\u0439 \u043E\u0444\u0456\u0441\u043D\u0438\u0439 \u043F\u0430\u043A\u0435\u0442. \u041F\u043E\u043F\u0435\u0440\u0435\u0434\u043D\u044F \u0432\u0435\u0440\u0441\u0456\u044F M3 \u0434\u0430\u0454 \u0437\u043C\u043E\u0433\u0443 \u0440\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u0442\u0438 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0438 \u0439 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0456 \u0442\u0430\u0431\u043B\u0438\u0446\u0456 \u0432 \u043C\u0435\u0436\u0430\u0445 \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0438\u0445 \u0444\u043E\u0440\u043C\u0430\u0442\u0456\u0432.
\u0421\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0443 \u0447\u0435\u0440\u043D\u0435\u0442\u043A\u0443
\u0412\u043D\u0443\u0442\u0440\u0456\u0448\u043D\u0456\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u0447\u0435\u0440\u043D\u0435\u0442\u043E\u043A \xB7 .oex
\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442
\u0415\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430 \u0442\u0430\u0431\u043B\u0438\u0446\u044F
\u041F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0456\u044F
\u0420\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u043D\u043D\u044F \u0442\u0435\u043A\u0441\u0442\u0443 \u0442\u0430 \u0441\u043A\u0430\u0441\u0443\u0432\u0430\u043D\u043D\u044F \u0434\u0456\u0439
\u041A\u043B\u0456\u0442\u0438\u043D\u043A\u0438, \u0444\u043E\u0440\u043C\u0443\u043B\u0438 \u0439 \u0444\u043E\u0440\u043C\u0430\u0442\u0443\u0432\u0430\u043D\u043D\u044F
\u041F\u043E\u043B\u043E\u0442\u043D\u043E \u0442\u0430 \u0444\u0456\u0433\u0443\u0440\u0438
\u0412\u0456\u0434\u043A\u0440\u0438\u0439\u0442\u0435 \u0444\u0430\u0439\u043B \u0430\u0431\u043E \u043F\u0435\u0440\u0435\u0442\u044F\u0433\u043D\u0456\u0442\u044C \u0439\u043E\u0433\u043E \u0441\u044E\u0434\u0438
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 \u0427\u0435\u0440\u043D\u0435\u0442\u043A\u0438 Office EX
\u0412\u0438\u0431\u0440\u0430\u0442\u0438 \u0444\u0430\u0439\u043B
\u041F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0456 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0438 DOC/DOCX \u0456 \u043A\u043D\u0438\u0433\u0438 XLS/XLSX \u043C\u043E\u0436\u043D\u0430 \u0440\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u0442\u0438 \u0442\u0430 \u0437\u0431\u0435\u0440\u0456\u0433\u0430\u0442\u0438. \u0406\u043D\u0448\u0456 \u0444\u0430\u0439\u043B\u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0456 \u043B\u0438\u0448\u0435 \u0434\u043B\u044F \u0447\u0438\u0442\u0430\u043D\u043D\u044F \u0439 \u0442\u043E\u0447\u043D\u043E\u0433\u043E \u043A\u043E\u043F\u0456\u044E\u0432\u0430\u043D\u043D\u044F. \u041F\u043E\u0432\u043D\u0430 \u0441\u0443\u043C\u0456\u0441\u043D\u0456\u0441\u0442\u044C \u0456\u0449\u0435 \u0440\u043E\u0437\u0440\u043E\u0431\u043B\u044F\u0454\u0442\u044C\u0441\u044F.
\u041F\u0456\u0434\u0442\u0440\u0438\u043C\u043A\u0430 \u0444\u043E\u0440\u043C\u0430\u0442\u0456\u0432
\u041A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440 \u043F\u0456\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E
\u0421\u0443\u0447\u0430\u0441\u043D\u0456 \u0444\u043E\u0440\u043C\u0430\u0442\u0438
\u0421\u0442\u0430\u0440\u0456 \u0444\u043E\u0440\u043C\u0430\u0442\u0438
\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0456 \u0447\u0435\u0440\u043D\u0435\u0442\u043A\u0438
\u041D\u0435\u043C\u0430\u0454 \u043E\u0441\u0442\u0430\u043D\u043D\u0456\u0445 \u0444\u0430\u0439\u043B\u0456\u0432
\u0411\u0435\u0437 \u043D\u0430\u0437\u0432\u0438
\u0427\u0435\u0440\u043D\u0435\u0442\u043A\u0430 Office EX
\u041B\u0438\u0448\u0435 \u0447\u0438\u0442\u0430\u043D\u043D\u044F \xB7 \u041F\u0435\u0440\u0435\u0432\u0456\u0440\u043A\u0430 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0438
\u041D\u0435 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E
\u0417\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E
\u041F\u0435\u0440\u0435\u0432\u0456\u0440\u043A\u0430 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0438 \u0444\u0430\u0439\u043B\u0443\u2026
\u0421\u043A\u0430\u0441\u0443\u0432\u0430\u0442\u0438
\u0417\u0430\u043A\u0440\u0438\u0442\u0438
\u041E\u043F\u0435\u0440\u0430\u0446\u0456\u044E \u0441\u043A\u0430\u0441\u043E\u0432\u0430\u043D\u043E
\u0417\u043D\u0456\u043C\u043E\u043A
\u0420\u0435\u0434\u0430\u043A\u0446\u0456\u044F
\u0423\u0441\u043F\u0456\u0448\u043D\u043E \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E
\u0427\u0435\u0440\u043D\u0435\u0442\u043A\u0438 OEX \u0432\u0438\u043A\u043E\u0440\u0438\u0441\u0442\u043E\u0432\u0443\u044E\u0442\u044C \u0432\u043D\u0443\u0442\u0440\u0456\u0448\u043D\u0456\u0439 \u0444\u043E\u0440\u043C\u0430\u0442. \u0414\u043B\u044F \u0444\u0430\u0439\u043B\u0456\u0432 Office \u0441\u0442\u0432\u043E\u0440\u0456\u0442\u044C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 DOC/DOCX \u0430\u0431\u043E \u043A\u043D\u0438\u0433\u0443 XLS/XLSX \u0456\u0437 \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0438\u043C\u0438 \u043C\u043E\u0436\u043B\u0438\u0432\u043E\u0441\u0442\u044F\u043C\u0438.
\u0422\u0435\u043A\u0441\u0442 \u0447\u0435\u0440\u043D\u0435\u0442\u043A\u0438
\u041A\u043B\u0456\u0442\u0438\u043D\u043A\u0438 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u0442\u0430\u0431\u043B\u0438\u0446\u0456
\u0420\u0435\u0434\u0430\u0433\u0443\u0439\u0442\u0435 \u043A\u043B\u0456\u0442\u0438\u043D\u043A\u0438, \u0444\u043E\u0440\u043C\u0443\u043B\u0438 \u0442\u0430 \u0444\u043E\u0440\u043C\u0430\u0442\u0438. \u0422\u0438\u043F\u0438 \u0437\u043D\u0430\u0447\u0435\u043D\u044C \u0456 \u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u0434\u0430\u0442 \u0437\u0431\u0435\u0440\u0456\u0433\u0430\u044E\u0442\u044C\u0441\u044F \u043F\u0456\u0434 \u0447\u0430\u0441 \u0437\u0430\u043F\u0438\u0441\u0443 \u0432 \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0438\u0445 \u0444\u043E\u0440\u043C\u0430\u0442\u0430\u0445.
\u041F\u0435\u0440\u0435\u0433\u043B\u044F\u0434 \u043F\u043E\u043B\u043E\u0442\u043D\u0430 \u0439 \u0432\u0438\u0431\u043E\u0440\u0443
\u0414\u043E\u0434\u0430\u0442\u0438 \u043F\u0440\u044F\u043C\u043E\u043A\u0443\u0442\u043D\u0438\u043A
\u041A\u043B\u0430\u0446\u043D\u0456\u0442\u044C \u0444\u0456\u0433\u0443\u0440\u0443, \u0449\u043E\u0431 \u043F\u0435\u0440\u0435\u0432\u0456\u0440\u0438\u0442\u0438 \u0457\u0457 \u0440\u043E\u0437\u0442\u0430\u0448\u0443\u0432\u0430\u043D\u043D\u044F. \u041F\u043E\u0432\u043D\u0438\u0439 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0437\u2019\u044F\u0432\u0438\u0442\u044C\u0441\u044F \u043D\u0430 \u0435\u0442\u0430\u043F\u0456 M4.
\u0427\u0430\u0441\u0442\u0438\u043D\u0438 \u043F\u0430\u043A\u0435\u0442\u0430 / \u043F\u043E\u0442\u043E\u043A\u0438
\u0427\u0430\u0441\u0442\u0438\u043D\u0430
\u0420\u043E\u0437\u043C\u0456\u0440
SHA-256
\u0412\u0435\u0440\u0441\u0456\u044F \u0444\u043E\u0440\u043C\u0430\u0442\u0443
\u0412\u0438\u044F\u0432\u043B\u0435\u043D\u0438\u0439 \u0444\u043E\u0440\u043C\u0430\u0442
\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438 \u0442\u043E\u0447\u043D\u0443 \u043A\u043E\u043F\u0456\u044E
\u0412\u0456\u0434\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F \u0432\u043C\u0456\u0441\u0442\u0443 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0449\u0435 \u043D\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0435
\u0427\u0435\u0440\u043D\u0435\u0442\u043A\u0438 \u0434\u043B\u044F \u0432\u0456\u0434\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044F
\u0412\u0456\u0434\u043D\u043E\u0432\u0438\u0442\u0438 \u043A\u043E\u043F\u0456\u044E
\u0412\u0456\u0434\u043A\u0438\u043D\u0443\u0442\u0438
\u0412\u0456\u0434\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044F \u0441\u0442\u0432\u043E\u0440\u044E\u0454 \u043D\u043E\u0432\u0443 \u043D\u0435\u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u0443 \u043A\u043E\u043F\u0456\u044E \u0442\u0430 \u0437\u0431\u0435\u0440\u0456\u0433\u0430\u0454 \u0432\u0438\u0445\u0456\u0434\u043D\u0438\u0439 \u0444\u0430\u0439\u043B.
\u041F\u043E\u0448\u043A\u043E\u0434\u0436\u0435\u043D\u0456 \u0437\u043D\u0456\u043C\u043A\u0438 \u0432\u0456\u0434\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044F \u0456\u0437\u043E\u043B\u044C\u043E\u0432\u0430\u043D\u043E \u0439 \u043D\u0435 \u0437\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0435\u043D\u043E.
\u0412\u0456\u0434\u043D\u043E\u0432\u043B\u0435\u043D\u043E \u044F\u043A \u043D\u043E\u0432\u0443 \u0447\u0435\u0440\u043D\u0435\u0442\u043A\u0443
\u0412\u0438\u043A\u043E\u043D\u0443\u0454\u0442\u044C\u0441\u044F
\u0417\u0432\u0456\u0442 \u043F\u0440\u043E \u0441\u0443\u043C\u0456\u0441\u043D\u0456\u0441\u0442\u044C
\u041D\u0435\u043C\u0430\u0454 \u0447\u0430\u0441\u0442\u0438\u043D \u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440\u0430 \u0434\u043B\u044F \u0432\u0456\u0434\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F.
\u041F\u043E\u0440\u043E\u0436\u043D\u0456\u0439 \u0441\u043B\u0430\u0439\u0434
\u0406\u0441\u0442\u043E\u0440\u0456\u044E \u043E\u0441\u0442\u0430\u043D\u043D\u0456\u0445 \u0444\u0430\u0439\u043B\u0456\u0432 \u043E\u0447\u0438\u0449\u0435\u043D\u043E
\u041D\u0430\u0437\u0432\u0430 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430
\u041C\u043E\u0436\u043D\u0430 \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0438 \u0449\u043E\u043D\u0430\u0439\u0431\u0456\u043B\u044C\u0448\u0435 32 \u0432\u043A\u043B\u0430\u0434\u043A\u0438
\u041D\u0435\u0437\u0430\u043B\u0435\u0436\u043D\u0430 \u0440\u043E\u0437\u0440\u043E\u0431\u043A\u0430 \xB7 Writer \u0456 Sheets
\u0424\u0430\u0439\u043B \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E; \u0446\u044F \u0444\u0430\u0439\u043B\u043E\u0432\u0430 \u0441\u0438\u0441\u0442\u0435\u043C\u0430 \u043D\u0435 \u043D\u0430\u0434\u0430\u043B\u0430 \u0433\u0430\u0440\u0430\u043D\u0442\u0456\u0439 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0456\u0437\u0430\u0446\u0456\u0457 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0443.
\u0424\u0430\u0439\u043B \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E, \u0430\u043B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432\u0456\u0434\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044F \u0430\u0431\u043E \u043E\u0441\u0442\u0430\u043D\u043D\u0456\u0445 \u0444\u0430\u0439\u043B\u0456\u0432 \u043D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u043E\u043D\u043E\u0432\u0438\u0442\u0438.
\u0413\u043E\u043B\u043E\u0432\u043D\u0430 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0430 Office EX
\u041E\u0441\u043D\u043E\u0432\u043D\u0430 \u043D\u0430\u0432\u0456\u0433\u0430\u0446\u0456\u044F
\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0438
\u0414\u0456\u0457 \u0437 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u043C
M3 \xB7 \u041F\u041E\u041F\u0415\u0420\u0415\u0414\u041D\u042F \u0412\u0415\u0420\u0421\u0406\u042F \u0420\u041E\u0417\u0420\u041E\u0411\u041A\u0418
OFFICE EX / \u0412\u0410\u0428 \u041B\u041E\u041A\u0410\u041B\u042C\u041D\u0418\u0419 \u0420\u041E\u0411\u041E\u0427\u0418\u0419 \u041F\u0420\u041E\u0421\u0422\u0406\u0420
\u0420\u0435\u0433\u0456\u043E\u043D\u0430\u043B\u044C\u043D\u0456 \u0444\u043E\u0440\u043C\u0430\u0442\u0438
\u041C\u043E\u0432\u0430 \u043D\u043E\u0432\u0438\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0456\u0432 (\u043D\u0430\u043B\u0430\u0448\u0442\u0443\u0432\u0430\u043D\u043D\u044F)
\u041D\u043E\u0432\u0456 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0438 Writer \u0432\u0438\u043A\u043E\u0440\u0438\u0441\u0442\u043E\u0432\u0443\u044E\u0442\u044C \u0446\u044E \u043C\u043E\u0432\u0443 \u0442\u0435\u043A\u0441\u0442\u0443. \u041D\u0430\u044F\u0432\u043D\u0456 \u0444\u0430\u0439\u043B\u0438 \u043D\u0435 \u0437\u043C\u0456\u043D\u044E\u044E\u0442\u044C\u0441\u044F; \u0456\u043D\u0448\u0456 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0438 \u0434\u043E\u043B\u0443\u0447\u0430\u0442\u044C\u0441\u044F \u043F\u0456\u0437\u043D\u0456\u0448\u0435.
\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u043D\u0456\u0439 \u043F\u0435\u0440\u0435\u0433\u043B\u044F\u0434 \u0440\u0435\u0433\u0456\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0444\u043E\u0440\u043C\u0430\u0442\u0443
\u0406\u0441\u0442\u043E\u0440\u0456\u044F
\u041F\u043E\u043B\u043E\u0442\u043D\u043E
\u0417\u0430\u043F\u0438\u0441\u0456\u0432: {count}; \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u043E \u043F\u0435\u0440\u0448\u0456 500.
\u0424\u0430\u0439\u043B
\u0420\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u043D\u043D\u044F
\u0412\u0438\u0433\u043B\u044F\u0434
\u041D\u043E\u0432\u0430 \u0447\u0435\u0440\u043D\u0435\u0442\u043A\u0430 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430
\u041D\u043E\u0432\u0430 \u0447\u0435\u0440\u043D\u0435\u0442\u043A\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u0442\u0430\u0431\u043B\u0438\u0446\u0456
\u041D\u043E\u0432\u0430 \u0447\u0435\u0440\u043D\u0435\u0442\u043A\u0430 \u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0456\u0457
\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0438\u2026
\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438 \u044F\u043A\u2026
\u0417\u0430\u043A\u0440\u0438\u0442\u0438 \u0432\u043A\u043B\u0430\u0434\u043A\u0443
\u0412\u0438\u0440\u0456\u0437\u0430\u0442\u0438
\u041A\u043E\u043F\u0456\u044E\u0432\u0430\u0442\u0438
\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u0438
\u0412\u0438\u0434\u0456\u043B\u0438\u0442\u0438 \u0432\u0441\u0435
\u041F\u0435\u0440\u0435\u043C\u043A\u043D\u0443\u0442\u0438 \u043F\u043E\u0432\u043D\u043E\u0435\u043A\u0440\u0430\u043D\u043D\u0438\u0439 \u0440\u0435\u0436\u0438\u043C
\u0421\u043A\u0438\u043D\u0443\u0442\u0438 \u043C\u0430\u0441\u0448\u0442\u0430\u0431
\u0417\u0431\u0456\u043B\u044C\u0448\u0438\u0442\u0438
\u0417\u043C\u0435\u043D\u0448\u0438\u0442\u0438
\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0438 Office / \u0427\u0435\u0440\u043D\u0435\u0442\u043A\u0438 Office EX
\u0423\u0441\u0456 \u0444\u0430\u0439\u043B\u0438
\u041F\u043E\u0447\u0430\u0442\u043A\u043E\u0432\u0438\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u0444\u0430\u0439\u043B\u0443
\u0417\u0430\u043C\u0456\u043D\u0438\u0442\u0438 \u043D\u0430\u044F\u0432\u043D\u0438\u0439 \u0446\u0456\u043B\u044C\u043E\u0432\u0438\u0439 \u0444\u0430\u0439\u043B?
\u0417\u0430\u043C\u0456\u043D\u0438\u0442\u0438
\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438 \u0437\u043C\u0456\u043D\u0438 \u043F\u0435\u0440\u0435\u0434 \u0437\u0430\u043A\u0440\u0438\u0442\u0442\u044F\u043C?
\u0412\u0456\u0434\u043A\u0438\u043D\u0443\u0442\u0438 \u0437\u043C\u0456\u043D\u0438
\u041D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0438 \u0444\u0430\u0439\u043B
\u041D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0438 \u0432\u0456\u043A\u043D\u043E
\u0417\u0430\u0432\u0435\u0440\u0448\u0456\u0442\u044C \u043F\u043E\u0442\u043E\u0447\u043D\u0435 \u0432\u0432\u0435\u0434\u0435\u043D\u043D\u044F, \u043F\u0435\u0440\u0448 \u043D\u0456\u0436 \u0437\u043C\u0456\u043D\u044E\u0432\u0430\u0442\u0438 \u043C\u043E\u0432\u0443.
\u0412\u0456\u0434\u043A\u0440\u0438\u0432\u0430\u0439\u0442\u0435 \u043F\u043E \u043E\u0434\u043D\u043E\u043C\u0443 \u043F\u0435\u0440\u0435\u0442\u044F\u0433\u043D\u0443\u0442\u043E\u043C\u0443 \u0444\u0430\u0439\u043B\u0443.
\u041D\u0435\u043A\u043E\u0440\u0435\u043A\u0442\u043D\u0438\u0439 \u0444\u0430\u0439\u043B \u0430\u0431\u043E \u0437\u0430\u043F\u0438\u0442.
\u0426\u044F \u043C\u043E\u0436\u043B\u0438\u0432\u0456\u0441\u0442\u044C \u0430\u0431\u043E \u0444\u043E\u0440\u043C\u0430\u0442 \u0456\u0449\u0435 \u043D\u0435 \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0454\u0442\u044C\u0441\u044F.
\u041E\u043F\u0435\u0440\u0430\u0446\u0456\u044E \u0437\u0430\u0431\u043B\u043E\u043A\u043E\u0432\u0430\u043D\u043E \u0437 \u043C\u0456\u0440\u043A\u0443\u0432\u0430\u043D\u044C \u0431\u0435\u0437\u043F\u0435\u043A\u0438.
\u041E\u043F\u0435\u0440\u0430\u0446\u0456\u044F \u043F\u0435\u0440\u0435\u0432\u0438\u0449\u0443\u0454 \u043E\u0431\u043C\u0435\u0436\u0435\u043D\u043D\u044F \u0440\u0435\u0441\u0443\u0440\u0441\u0456\u0432.
\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0430\u0431\u043E \u0446\u0456\u043B\u044C\u043E\u0432\u0438\u0439 \u0444\u0430\u0439\u043B \u0437\u043C\u0456\u043D\u0438\u0432\u0441\u044F.
\u041F\u043E\u043C\u0438\u043B\u043A\u0430 \u0444\u0430\u0439\u043B\u043E\u0432\u043E\u0457 \u043E\u043F\u0435\u0440\u0430\u0446\u0456\u0457.
\u0421\u0442\u0430\u043B\u0430\u0441\u044F \u0432\u043D\u0443\u0442\u0440\u0456\u0448\u043D\u044F \u043F\u043E\u043C\u0438\u043B\u043A\u0430.
\u041D\u0430\u0434\u0456\u0439\u0448\u043B\u043E \u043D\u0435\u0432\u0456\u0434\u043E\u043C\u0435 \u0434\u0456\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u0447\u043D\u0435 \u043F\u043E\u0432\u0456\u0434\u043E\u043C\u043B\u0435\u043D\u043D\u044F \u043F\u0440\u043E \u0441\u0443\u043C\u0456\u0441\u043D\u0456\u0441\u0442\u044C.
\u041B\u0438\u0448\u0435 \u043F\u0435\u0440\u0435\u0432\u0456\u0440\u043A\u0430 \u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440\u0430. \u0420\u0435\u0434\u0430\u0433\u043E\u0432\u0430\u043D\u0438\u0439 \u0432\u043C\u0456\u0441\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043D\u0435 \u0456\u043C\u043F\u043E\u0440\u0442\u043E\u0432\u0430\u043D\u043E.
\u0412\u0438\u044F\u0432\u043B\u0435\u043D\u043E \u0432\u043C\u0456\u0441\u0442, \u043F\u043E\u0432\u2019\u044F\u0437\u0430\u043D\u0438\u0439 \u0456\u0437 \u043C\u0430\u043A\u0440\u043E\u0441\u0430\u043C\u0438. \u041C\u0430\u043A\u0440\u043E\u0441\u0438 \u043D\u0435 \u0432\u0438\u043A\u043E\u043D\u0443\u044E\u0442\u044C\u0441\u044F; \u0434\u0430\u043D\u0456 \u0437\u0431\u0435\u0440\u0456\u0433\u0430\u044E\u0442\u044C\u0441\u044F \u043B\u0438\u0448\u0435 \u0432 \u0442\u043E\u0447\u043D\u0438\u0445 \u043A\u043E\u043F\u0456\u044F\u0445.
\u041F\u0456\u0434\u043F\u0438\u0441\u0430\u043D\u0438\u0439 \u0444\u0430\u0439\u043B: \u043B\u0438\u0448\u0435 \u043F\u0435\u0440\u0435\u0432\u0456\u0440\u043A\u0430. \u0427\u0438\u043D\u043D\u0456\u0441\u0442\u044C \u043F\u0456\u0434\u043F\u0438\u0441\u0443 \u043D\u0435 \u043F\u0456\u0434\u0442\u0432\u0435\u0440\u0434\u0436\u0435\u043D\u043E.
\u0417\u043E\u0432\u043D\u0456\u0448\u043D\u0456 \u0437\u0432\u2019\u044F\u0437\u043A\u0438 \u0437\u0430\u0444\u0456\u043A\u0441\u043E\u0432\u0430\u043D\u043E; \u0437\u043E\u0432\u043D\u0456\u0448\u043D\u0456\u0439 \u0432\u043C\u0456\u0441\u0442 \u043D\u0435 \u0437\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0443\u0454\u0442\u044C\u0441\u044F.
\u0412\u0438\u044F\u0432\u043B\u0435\u043D\u043E Strict OOXML; \u0447\u0438\u0442\u0430\u043D\u043D\u044F \u0439 \u0437\u0430\u043F\u0438\u0441 \u0432\u043C\u0456\u0441\u0442\u0443 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u0456\u0440\u0435\u043D\u0456.
\u0412\u0438\u044F\u0432\u043B\u0435\u043D\u043E \u0437\u0430\u0448\u0438\u0444\u0440\u043E\u0432\u0430\u043D\u0438\u0439 \u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440. \u0420\u043E\u0437\u0448\u0438\u0444\u0440\u0443\u0432\u0430\u043D\u043D\u044F \u0442\u0430 \u0440\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u043D\u043D\u044F \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0456.
\u0420\u043E\u0437\u0448\u0438\u0440\u0435\u043D\u043D\u044F \u0432\u0456\u0434\u0440\u0456\u0437\u043D\u044F\u0454\u0442\u044C\u0441\u044F \u0432\u0456\u0434 \u0432\u0438\u044F\u0432\u043B\u0435\u043D\u043E\u0433\u043E \u0432\u043C\u0456\u0441\u0442\u0443.
\u0424\u043E\u0440\u043C\u0430\u0442\u0443\u0432\u0430\u043D\u043D\u044F \u0442\u0435\u043A\u0441\u0442\u0443
\u0420\u0435\u0434\u0430\u0433\u0443\u0439\u0442\u0435 \u0430\u0431\u0437\u0430\u0446\u0438 \u0439 \u0432\u0438\u0434\u0456\u043B\u044F\u0439\u0442\u0435 \u0442\u0435\u043A\u0441\u0442 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0430\u0442\u0443\u0432\u0430\u043D\u043D\u044F. Enter \u0440\u043E\u0437\u0434\u0456\u043B\u044F\u0454 \u0430\u0431\u0437\u0430\u0446; Shift+Enter \u0434\u043E\u0434\u0430\u0454 \u0440\u043E\u0437\u0440\u0438\u0432 \u0440\u044F\u0434\u043A\u0430.
\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u043D\u0456\u0439 \u043F\u0435\u0440\u0435\u0433\u043B\u044F\u0434 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438
\u041E\u0440\u0456\u0454\u043D\u0442\u043E\u0432\u043D\u0438\u0439 \u043C\u0430\u043A\u0435\u0442 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438. \u041A\u043B\u0430\u0446\u043D\u0456\u0442\u044C \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0443, \u0449\u043E\u0431 \u0437\u043D\u0430\u0439\u0442\u0438 \u0442\u0435\u043A\u0441\u0442. \u0422\u043E\u0447\u043D\u0456\u0441\u0442\u044C \u0434\u0440\u0443\u043A\u0443 \u0449\u0435 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u0456\u0440\u0435\u043D\u043E.
\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u043D\u044F \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0430
\u041D\u0430\u0441\u0442\u0443\u043F\u043D\u0430 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0430
\u0421\u0442\u043E\u0440\u0456\u043D\u043A\u0430 {current} / {total}
\u0414\u0435\u044F\u043A\u0456 \u043C\u043E\u0436\u043B\u0438\u0432\u043E\u0441\u0442\u0456 \u0442\u0438\u043F\u043E\u0433\u0440\u0430\u0444\u0456\u043A\u0438 \u0430\u0431\u043E \u043C\u0430\u043A\u0435\u0442\u0430 \u0432\u0456\u0434\u0442\u0432\u043E\u0440\u044E\u044E\u0442\u044C\u0441\u044F \u043F\u0440\u0438\u0431\u043B\u0438\u0437\u043D\u043E.
\u041F\u0435\u0440\u0435\u0433\u043B\u044F\u0434 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0438\u0439 \u0434\u043B\u044F \u0446\u044C\u043E\u0433\u043E \u0432\u043C\u0456\u0441\u0442\u0443 \u0430\u0431\u043E \u043E\u0431\u043C\u0435\u0436\u0435\u043D\u043D\u044F \u043C\u0430\u043A\u0435\u0442\u0430. \u0412\u0438\u0445\u0456\u0434\u043D\u0438\u0439 \u0432\u043C\u0456\u0441\u0442 \u043D\u0435 \u0437\u043C\u0456\u043D\u0435\u043D\u043E.
\u0416\u0438\u0440\u043D\u0438\u0439
\u041A\u0443\u0440\u0441\u0438\u0432
\u041F\u0456\u0434\u043A\u0440\u0435\u0441\u043B\u0435\u043D\u043D\u044F
\u0412\u0438\u0440\u0456\u0432\u043D\u044F\u0442\u0438 \u043B\u0456\u0432\u043E\u0440\u0443\u0447
\u041F\u043E \u0446\u0435\u043D\u0442\u0440\u0443
\u0412\u0438\u0440\u0456\u0432\u043D\u044F\u0442\u0438 \u043F\u0440\u0430\u0432\u043E\u0440\u0443\u0447
\u0420\u043E\u0437\u0434\u0456\u043B\u0438\u0442\u0438 \u0430\u0431\u0437\u0430\u0446
\u0420\u043E\u0437\u0440\u0438\u0432 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438 \u043F\u0456\u0441\u043B\u044F \u0430\u0431\u0437\u0430\u0446\u0443
\u0426\u0435\u0439 \u0431\u043B\u043E\u043A \u043D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0440\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u0442\u0438 \u0432 \u043F\u043E\u043F\u0435\u0440\u0435\u0434\u043D\u0456\u0439 \u0432\u0435\u0440\u0441\u0456\u0457.
\u041D\u043E\u0432\u0438\u0439 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 DOCX
\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 DOCX
\u041E\u0431\u043C\u0435\u0436\u0435\u043D\u0430 \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u043A\u0430 DOCX: \u0442\u0435\u043A\u0441\u0442, \u043F\u0440\u044F\u043C\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u0443\u0432\u0430\u043D\u043D\u044F, \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0456 \u0456\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0456 \u0441\u0442\u0438\u043B\u0456, \u0444\u0456\u043A\u0441\u043E\u0432\u0430\u043D\u0456 \u043F\u0440\u044F\u043C\u043E\u043A\u0443\u0442\u043D\u0456 \u0442\u0430\u0431\u043B\u0438\u0446\u0456, \u0432\u0431\u0443\u0434\u043E\u0432\u0430\u043D\u0456 PNG/JPEG \u0443 \u0440\u044F\u0434\u043A\u0443 \u0442\u0430 \u0431\u0430\u0437\u043E\u0432\u0438\u0439 \u043C\u0430\u043A\u0435\u0442. \u0421\u043A\u043B\u0430\u0434\u043D\u0456 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0456 \u043B\u0438\u0448\u0435 \u0434\u043B\u044F \u0447\u0438\u0442\u0430\u043D\u043D\u044F.
\u0428\u0440\u0438\u0444\u0442
\u0420\u043E\u0437\u043C\u0456\u0440 (\u043F\u0442)
\u041A\u043E\u043B\u0456\u0440 \u0442\u0435\u043A\u0441\u0442\u0443
\u0421\u0442\u0438\u043B\u044C \u0430\u0431\u0437\u0430\u0446\u0443
\u0421\u0442\u0438\u043B\u044C \u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432
\u0412\u0438\u0431\u0440\u0430\u0442\u0438 \u0441\u0442\u0438\u043B\u044C
\u0422\u0430\u0431\u043B\u0438\u0446\u044F
\u0420\u044F\u0434\u043A\u0438
\u0421\u0442\u043E\u0432\u043F\u0446\u0456
\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u044E
\u0414\u043E\u0434\u0430\u0442\u0438 \u0440\u044F\u0434\u043E\u043A \u0437\u043D\u0438\u0437\u0443
\u0412\u0438\u0434\u0430\u043B\u0438\u0442\u0438 \u0440\u044F\u0434\u043E\u043A
\u0414\u043E\u0434\u0430\u0442\u0438 \u0441\u0442\u043E\u0432\u043F\u0435\u0446\u044C \u043F\u0440\u0430\u0432\u043E\u0440\u0443\u0447
\u0412\u0438\u0434\u0430\u043B\u0438\u0442\u0438 \u0441\u0442\u043E\u0432\u043F\u0435\u0446\u044C
\u0428\u0438\u0440\u0438\u043D\u0430 \u0441\u0442\u043E\u0432\u043F\u0446\u044F (\u043F\u0442)
\u041C\u0435\u0436\u0456 \u0442\u0430\u0431\u043B\u0438\u0446\u0456
\u0412\u0438\u0434\u0430\u043B\u0438\u0442\u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u044E
\u041A\u043B\u0456\u0442\u0438\u043D\u043A\u0430 {row}, {column}
\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u0438 \u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F
\u0417\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F
\u0428\u0438\u0440\u0438\u043D\u0430 \u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F (\u043F\u0442)
\u0412\u0438\u0434\u0430\u043B\u0438\u0442\u0438 \u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F
\u0420\u043E\u0437\u043C\u0456\u0440 \u043F\u0430\u043F\u0435\u0440\u0443
\u0412\u043B\u0430\u0441\u043D\u0438\u0439
A4
Letter
A3
\u041E\u0440\u0456\u0454\u043D\u0442\u0430\u0446\u0456\u044F \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438
\u041A\u043D\u0438\u0436\u043A\u043E\u0432\u0430
\u0410\u043B\u044C\u0431\u043E\u043C\u043D\u0430
\u0428\u0438\u0440\u0438\u043D\u0430 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438 (\u043F\u0442)
\u0412\u0438\u0441\u043E\u0442\u0430 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438 (\u043F\u0442)
\u0412\u0435\u0440\u0445\u043D\u0454 \u043F\u043E\u043B\u0435 (\u043F\u0442)
\u041F\u0440\u0430\u0432\u0435 \u043F\u043E\u043B\u0435 (\u043F\u0442)
\u041D\u0438\u0436\u043D\u0454 \u043F\u043E\u043B\u0435 (\u043F\u0442)
\u041B\u0456\u0432\u0435 \u043F\u043E\u043B\u0435 (\u043F\u0442)
\u0417\u0430\u0441\u0442\u043E\u0441\u0443\u0432\u0430\u0442\u0438 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0438 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438
\u0412\u0456\u0434\u0441\u0442\u0443\u043F (\u043F\u0442)
\u041F\u0435\u0440\u0435\u0434 (\u043F\u0442)
\u041F\u0456\u0441\u043B\u044F (\u043F\u0442)
\u0412\u0438\u0441\u043E\u0442\u0430 \u0440\u044F\u0434\u043A\u0430 (\u043F\u0442; 0 = \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u043D\u043E)
\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u0438 \u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F \u0432 \u043F\u043E\u0437\u0438\u0446\u0456\u0457 \u043A\u0443\u0440\u0441\u043E\u0440\u0430
\u041C\u0430\u0440\u043A\u0435\u0440 \u043E\u0431\u2019\u0454\u043A\u0442\u0430 \u043F\u043E\u0437\u043D\u0430\u0447\u0430\u0454 \u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F \u0432 \u0440\u044F\u0434\u043A\u0443. \u0412\u0438\u043A\u043E\u0440\u0438\u0441\u0442\u043E\u0432\u0443\u0439\u0442\u0435 \u0439\u043E\u0433\u043E \u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438 \u043A\u0435\u0440\u0443\u0432\u0430\u043D\u043D\u044F \u0434\u043B\u044F \u0437\u043C\u0456\u043D\u0438 \u0440\u043E\u0437\u043C\u0456\u0440\u0443 \u0430\u0431\u043E \u0432\u0438\u0434\u0430\u043B\u0435\u043D\u043D\u044F.
\u0420\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u0442\u0438 \u0441\u0443\u0446\u0456\u043B\u044C\u043D\u0438\u0439 \u0442\u0435\u043A\u0441\u0442
\u041F\u043E\u0432\u0435\u0440\u043D\u0443\u0442\u0438\u0441\u044F \u0434\u043E \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430 \u0430\u0431\u0437\u0430\u0446\u0456\u0432
\u0412\u0438\u0434\u0456\u043B\u044F\u0439\u0442\u0435, \u043A\u043E\u043F\u0456\u044E\u0439\u0442\u0435, \u0432\u0438\u0440\u0456\u0437\u0430\u0439\u0442\u0435, \u0432\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0430\u0431\u043E \u0444\u043E\u0440\u043C\u0430\u0442\u0443\u0439\u0442\u0435 \u0441\u0443\u0441\u0456\u0434\u043D\u0456 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u0456 \u0430\u0431\u0437\u0430\u0446\u0438. \u0422\u0430\u0431\u043B\u0438\u0446\u0456, \u0440\u043E\u0437\u0440\u0438\u0432\u0438 \u0441\u0442\u043E\u0440\u0456\u043D\u043E\u043A, \u0440\u043E\u0437\u0434\u0456\u043B\u0438 \u0439 \u0430\u0431\u0437\u0430\u0446\u0438 \u0456\u0437 \u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F\u043C\u0438 \u043E\u0431\u043C\u0435\u0436\u0443\u044E\u0442\u044C \u0432\u0438\u0434\u0456\u043B\u0435\u043D\u043D\u044F. \u041D\u043E\u0432\u0456 \u0432\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0456 \u0440\u044F\u0434\u043A\u0438 \u0441\u0442\u0430\u044E\u0442\u044C \u0430\u0431\u0437\u0430\u0446\u0430\u043C\u0438.
\u0420\u043E\u0437\u0434\u0456\u043B
\u0420\u043E\u0437\u0434\u0456\u043B {number}
\u0420\u043E\u0437\u0440\u0438\u0432 \u0440\u043E\u0437\u0434\u0456\u043B\u0443 \u0437 \u043D\u0430\u0441\u0442\u0443\u043F\u043D\u043E\u0457 \u0441\u0442\u043E\u0440\u0456\u043D\u043A\u0438
\u041C\u043E\u0432\u0430 \u0442\u0435\u043A\u0441\u0442\u0443 (BCP 47)
\u041D\u0430\u043F\u0440\u044F\u043C\u043E\u043A \u0430\u0431\u0437\u0430\u0446\u0443
\u0417\u043B\u0456\u0432\u0430 \u043D\u0430\u043F\u0440\u0430\u0432\u043E
\u0421\u043F\u0440\u0430\u0432\u0430 \u043D\u0430\u043B\u0456\u0432\u043E
\u041D\u043E\u0432\u0438\u0439 DOC
\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 Word 97\u20132003
\u041E\u0431\u043C\u0435\u0436\u0435\u043D\u0435 \u0440\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u043D\u043D\u044F DOC: \u0442\u0435\u043A\u0441\u0442 Unicode, \u0431\u0430\u0437\u043E\u0432\u0456 \u0441\u0442\u0438\u043B\u0456 \u0442\u0430 \u043E\u0434\u0438\u043D \u0440\u043E\u0437\u0434\u0456\u043B. \u041D\u0435\u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0456 DOC \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0456 \u043B\u0438\u0448\u0435 \u0434\u043B\u044F \u0447\u0438\u0442\u0430\u043D\u043D\u044F; \u0443 \u0446\u044C\u043E\u043C\u0443 \u043F\u0440\u043E\u0444\u0456\u043B\u0456 \u043D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0437\u0431\u0435\u0440\u0456\u0433\u0430\u0442\u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u0456 \u0439 \u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F.
\u041F\u0435\u0440\u0435\u0433\u043B\u044F\u0434 \u043E\u0441\u043D\u043E\u0432\u043D\u043E\u0433\u043E \u0442\u0435\u043A\u0441\u0442\u0443 \u043B\u0438\u0448\u0435 \u0434\u043B\u044F \u0447\u0438\u0442\u0430\u043D\u043D\u044F, \u0430 \u043D\u0435 \u043F\u043E\u0432\u043D\u0438\u0439 \u043C\u0430\u043A\u0435\u0442 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430. \u0417\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043D\u044F \u043A\u043E\u043F\u0456\u0457 \u0437\u0430\u043B\u0438\u0448\u0430\u0454 \u043F\u043E\u0447\u0430\u0442\u043A\u043E\u0432\u0456 \u0434\u0430\u043D\u0456 \u0431\u0435\u0437 \u0437\u043C\u0456\u043D.
\u041F\u0435\u0440\u0435\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043D\u0430 DOC
\u041F\u0435\u0440\u0435\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043D\u0430 DOCX
\u0414\u043B\u044F \u043F\u0435\u0440\u0435\u0442\u0432\u043E\u0440\u0435\u043D\u043D\u044F \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u043C\u0430\u0454 \u043C\u0456\u0441\u0442\u0438\u0442\u0438 \u043B\u0438\u0448\u0435 \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0456 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0438. \u041D\u0435\u0432\u0456\u0434\u043E\u043C\u0456 \u0447\u0430\u0441\u0442\u0438\u043D\u0438 \u0437\u0431\u0435\u0440\u0456\u0433\u0430\u044E\u0442\u044C\u0441\u044F \u0443 \u0434\u0436\u0435\u0440\u0435\u043B\u0456, \u0430 \u043D\u0435 \u0432\u0456\u0434\u043A\u0438\u0434\u0430\u044E\u0442\u044C\u0441\u044F.
\u0420\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u0442\u0438 \u043D\u0430 \u0441\u0442\u043E\u0440\u0456\u043D\u0446\u0456
\u041F\u043E\u0432\u0435\u0440\u043D\u0443\u0442\u0438\u0441\u044F \u0434\u043E \u0456\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u0456\u0432
\u0420\u0435\u0434\u0430\u0433\u0443\u0439\u0442\u0435 \u043D\u0430 \u0441\u0442\u043E\u0440\u0456\u043D\u0446\u0456 \u0437\u0430 \u0434\u043E\u043F\u043E\u043C\u043E\u0433\u043E\u044E \u0432\u0431\u0443\u0434\u043E\u0432\u0430\u043D\u043E\u0433\u043E \u0444\u043E\u0440\u043C\u0443\u0432\u0430\u043D\u043D\u044F \u0442\u0435\u043A\u0441\u0442\u0443 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0430. \u041F\u0435\u0440\u0435\u0442\u044F\u0433\u0443\u0439\u0442\u0435 \u0434\u043B\u044F \u0432\u0438\u0434\u0456\u043B\u0435\u043D\u043D\u044F; \u043A\u043E\u043F\u0456\u044E\u0432\u0430\u043D\u043D\u044F \u0439 \u0432\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043D\u044F \u0437\u0431\u0435\u0440\u0456\u0433\u0430\u044E\u0442\u044C \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u0443\u0432\u0430\u043D\u043D\u044F \u0442\u0430 \u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u043D\u044F Office EX. \u0422\u043E\u0447\u043D\u0456\u0441\u0442\u044C \u0441\u0442\u043E\u0440\u0456\u043D\u043E\u043A \u0456\u0449\u0435 \u043D\u0435 \u043F\u043E\u0440\u0456\u0432\u043D\u044E\u0432\u0430\u043B\u0438 \u0437 Word.
`), ...sheetsCatalog(`
\u041D\u043E\u0432\u0430 \u043A\u043D\u0438\u0433\u0430 XLSX
\u041A\u043D\u0438\u0433\u0430 Excel (.xlsx)
\u0420\u0435\u0434\u0430\u0433\u0443\u0439\u0442\u0435 \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0456 \u043A\u043B\u0456\u0442\u0438\u043D\u043A\u0438, \u0444\u043E\u0440\u043C\u0443\u043B\u0438 \u0442\u0430 \u0441\u0442\u0438\u043B\u0456. \u0417\u0430\u0445\u0438\u0449\u0435\u043D\u0456 \u0444\u0430\u0439\u043B\u0438 \u0430\u0431\u043E \u0444\u0430\u0439\u043B\u0438 \u0437 \u043D\u0435\u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0438\u043C\u0438 \u0437\u0430\u043B\u0435\u0436\u043D\u043E\u0441\u0442\u044F\u043C\u0438 \u0432\u0456\u0434\u043A\u0440\u0438\u0432\u0430\u044E\u0442\u044C\u0441\u044F \u043B\u0438\u0448\u0435 \u0434\u043B\u044F \u0447\u0438\u0442\u0430\u043D\u043D\u044F \u0437\u0456 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043D\u044F\u043C \u043E\u0440\u0438\u0433\u0456\u043D\u0430\u043B\u0443.
\u041D\u043E\u0432\u0430 \u043A\u043D\u0438\u0433\u0430 Excel 97\u20132003
\u041A\u043D\u0438\u0433\u0430 Excel 97\u20132003 (.xls)
\u041A\u043D\u0438\u0433\u0430 BIFF8: \u0434\u043E 65 536 \u0440\u044F\u0434\u043A\u0456\u0432 \u0456 256 \u0441\u0442\u043E\u0432\u043F\u0446\u0456\u0432. \u041F\u0435\u0440\u0435\u0434 \u0437\u0430\u043F\u0438\u0441\u043E\u043C \u0456 \u043F\u0435\u0440\u0435\u0442\u0432\u043E\u0440\u0435\u043D\u043D\u044F\u043C \u043F\u0435\u0440\u0435\u0432\u0456\u0440\u044F\u044E\u0442\u044C\u0441\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u0438, \u0441\u0442\u0438\u043B\u0456 \u0439 \u0437\u0430\u043B\u0435\u0436\u043D\u043E\u0441\u0442\u0456 \u0434\u0436\u0435\u0440\u0435\u043B\u0430.
\u041F\u0435\u0440\u0435\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043D\u0430 \u043A\u043E\u043F\u0456\u044E XLSX
\u041F\u0435\u0440\u0435\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043D\u0430 \u043A\u043E\u043F\u0456\u044E XLS
\u0421\u0456\u0442\u043A\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u0442\u0430\u0431\u043B\u0438\u0446\u0456
\u0417\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0430\u0431\u043E \u0444\u043E\u0440\u043C\u0443\u043B\u0430 \u043A\u043B\u0456\u0442\u0438\u043D\u043A\u0438
\u0410\u0434\u0440\u0435\u0441\u0430 \u043A\u043B\u0456\u0442\u0438\u043D\u043A\u0438 \u0430\u0431\u043E \u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D\u0443
\u0414\u043E\u0434\u0430\u0442\u0438 \u0430\u0440\u043A\u0443\u0448
\u041F\u0435\u0440\u0435\u0439\u043C\u0435\u043D\u0443\u0432\u0430\u0442\u0438 \u0430\u0440\u043A\u0443\u0448
\u0412\u0438\u0434\u0430\u043B\u0438\u0442\u0438 \u0430\u0440\u043A\u0443\u0448
\u041F\u0435\u0440\u0435\u043C\u0456\u0441\u0442\u0438\u0442\u0438 \u0430\u0440\u043A\u0443\u0448 \u0440\u0430\u043D\u0456\u0448\u0435
\u041F\u0435\u0440\u0435\u043C\u0456\u0441\u0442\u0438\u0442\u0438 \u0430\u0440\u043A\u0443\u0448 \u043F\u0456\u0437\u043D\u0456\u0448\u0435
\u0406\u043C\u2019\u044F \u0430\u0440\u043A\u0443\u0448\u0430
\u0410\u0440\u043A\u0443\u0448\u0456, \u0440\u044F\u0434\u043A\u0438 \u0442\u0430 \u0441\u0442\u043E\u0432\u043F\u0446\u0456
\u041E\u0431\u2019\u0454\u0434\u043D\u0430\u0442\u0438 \u043A\u043B\u0456\u0442\u0438\u043D\u043A\u0438
\u0421\u043A\u0430\u0441\u0443\u0432\u0430\u0442\u0438 \u043E\u0431\u2019\u0454\u0434\u043D\u0430\u043D\u043D\u044F
\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u0438 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F
\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u0438 \u0440\u044F\u0434\u043A\u0438
\u0412\u0438\u0434\u0430\u043B\u0438\u0442\u0438 \u0440\u044F\u0434\u043A\u0438
\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u0438 \u0441\u0442\u043E\u0432\u043F\u0446\u0456
\u0412\u0438\u0434\u0430\u043B\u0438\u0442\u0438 \u0441\u0442\u043E\u0432\u043F\u0446\u0456
\u0412\u0438\u0441\u043E\u0442\u0430 \u0440\u044F\u0434\u043A\u0430 (\u043F\u043A\u0441)
\u0428\u0438\u0440\u0438\u043D\u0430 \u0441\u0442\u043E\u0432\u043F\u0446\u044F (\u043F\u043A\u0441)
\u0427\u0438\u0441\u043B\u043E\u0432\u0438\u0439 \u0444\u043E\u0440\u043C\u0430\u0442
\u0417\u0430\u0433\u0430\u043B\u044C\u043D\u0438\u0439
\u0427\u0438\u0441\u043B\u043E
\u0412\u0456\u0434\u0441\u043E\u0442\u043E\u043A
\u0413\u0440\u043E\u0448\u043E\u0432\u0438\u0439
\u0414\u0430\u0442\u0430
\u0427\u0430\u0441
\u0415\u043A\u0441\u043F\u043E\u043D\u0435\u043D\u0446\u0456\u0439\u043D\u0438\u0439
\u0412\u043B\u0430\u0441\u043D\u0438\u0439 \u043A\u043E\u0434 \u0444\u043E\u0440\u043C\u0430\u0442\u0443
\u0417\u0430\u043B\u0438\u0432\u043A\u0430 \u043A\u043B\u0456\u0442\u0438\u043D\u043A\u0438
\u041F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u043D\u044F \u0442\u0435\u043A\u0441\u0442\u0443
\u041C\u0435\u0436\u0456 \u043A\u043B\u0456\u0442\u0438\u043D\u043A\u0438
\u0412\u0432\u0435\u0434\u0435\u043D\u043D\u044F \u0444\u043E\u0440\u043C\u0443\u043B
\u0410\u043D\u0433\u043B\u0456\u0439\u0441\u044C\u043A\u0456 \u0456\u043C\u0435\u043D\u0430 \xB7 \u0434\u0435\u0441\u044F\u0442\u043A\u043E\u0432\u0430 \u043A\u0440\u0430\u043F\u043A\u0430
\u0420\u0435\u0433\u0456\u043E\u043D\u0430\u043B\u044C\u043D\u0456 \u0456\u043C\u0435\u043D\u0430 \u0442\u0430 \u0440\u043E\u0437\u0434\u0456\u043B\u044C\u043D\u0438\u043A\u0438
\u041F\u0435\u0440\u0435\u0440\u0430\u0445\u0443\u0432\u0430\u0442\u0438
\u041E\u0431\u0447\u0438\u0441\u043B\u0435\u043D\u043D\u044F\u2026
\u041E\u0431\u0447\u0438\u0441\u043B\u0435\u043D\u043E
\u041D\u0435 \u043E\u0431\u0447\u0438\u0441\u043B\u0435\u043D\u043E: \u043D\u0435\u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u0430 \u0444\u043E\u0440\u043C\u0443\u043B\u0430
\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u043D\u0456\u0439 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: \u043F\u043E\u0442\u0440\u0456\u0431\u0435\u043D \u043F\u0435\u0440\u0435\u0440\u0430\u0445\u0443\u043D\u043E\u043A
\u041F\u043E\u043C\u0438\u043B\u043A\u0430 \u0444\u043E\u0440\u043C\u0443\u043B\u0438
\u0421\u043A\u0430\u0441\u0443\u0432\u0430\u0442\u0438 \u043E\u0431\u0447\u0438\u0441\u043B\u0435\u043D\u043D\u044F
\u0427\u0438\u0441\u043B\u043E\u0432\u0438\u0445 \u043A\u043B\u0456\u0442\u0438\u043D\u043E\u043A: {count} \xB7 \u0421\u0443\u043C\u0430 {sum}
\u0412\u0438\u0434\u0456\u043B\u0435\u043D\u043D\u044F {address}
\u041A\u043B\u0430\u0446\u043D\u0456\u0442\u044C \u0430\u0431\u043E \u043F\u0435\u0440\u0435\u0442\u044F\u0433\u043D\u0456\u0442\u044C \u0434\u043B\u044F \u0432\u0438\u0434\u0456\u043B\u0435\u043D\u043D\u044F. \u0412\u0432\u0435\u0434\u0456\u0442\u044C \u0442\u0435\u043A\u0441\u0442 \u0430\u0431\u043E \u043D\u0430\u0442\u0438\u0441\u043D\u0456\u0442\u044C F2 \u0434\u043B\u044F \u0440\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u043D\u043D\u044F; Enter \u043F\u0456\u0434\u0442\u0432\u0435\u0440\u0434\u0436\u0443\u0454, Esc \u0441\u043A\u0430\u0441\u043E\u0432\u0443\u0454. Shift \u0440\u043E\u0437\u0448\u0438\u0440\u044E\u0454 \u0432\u0438\u0434\u0456\u043B\u0435\u043D\u043D\u044F. \u041A\u043E\u043F\u0456\u044E\u0439\u0442\u0435 \u0439 \u0432\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D\u0438 \u044F\u043A TSV. \u0424\u043E\u0440\u043C\u0443\u043B\u0438 \u043F\u043E\u0447\u0438\u043D\u0430\u044E\u0442\u044C\u0441\u044F \u0437 =.
\u0417\u0430\u043A\u0440\u0456\u043F\u0438\u0442\u0438 \u0431\u0456\u043B\u044F \u0432\u0438\u0434\u0456\u043B\u0435\u043D\u043D\u044F
\u0417\u043D\u044F\u0442\u0438 \u0437\u0430\u043A\u0440\u0456\u043F\u043B\u0435\u043D\u043D\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u0435\u0439
\u0410\u0440\u043A\u0443\u0448 \u0441\u043F\u0440\u0430\u0432\u0430 \u043D\u0430\u043B\u0456\u0432\u043E
\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u0438 \u043B\u0456\u043D\u0456\u0457 \u0441\u0456\u0442\u043A\u0438
\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0434\u0430\u0442 \u043A\u043D\u0438\u0433\u0438
\u041F\u0435\u0440\u0435\u0433\u043B\u044F\u0434 \u0437\u0431\u0435\u0440\u0435\u0436\u0435\u043D\u043E\u0457 \u043A\u043D\u0438\u0433\u0438
\u0426\u044F \u043A\u043D\u0438\u0433\u0430 \u043C\u0456\u0441\u0442\u0438\u0442\u044C \u0437\u0430\u043B\u0435\u0436\u043D\u043E\u0441\u0442\u0456 \u043F\u043E\u0437\u0430 \u043C\u0435\u0436\u0430\u043C\u0438 \u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0443\u0432\u0430\u043D\u043E\u0433\u043E \u0440\u0435\u0434\u0430\u0433\u0443\u0432\u0430\u043D\u043D\u044F. \u041C\u043E\u0436\u043D\u0430 \u043F\u0435\u0440\u0435\u0433\u043B\u044F\u0434\u0430\u0442\u0438 \u043A\u043B\u0456\u0442\u0438\u043D\u043A\u0438 \u0442\u0430 \u0437\u0431\u0435\u0440\u0435\u0433\u0442\u0438 \u0442\u043E\u0447\u043D\u0443 \u043A\u043E\u043F\u0456\u044E \u043E\u0440\u0438\u0433\u0456\u043D\u0430\u043B\u0443.
\u041F\u0435\u0440\u0435\u0442\u0432\u043E\u0440\u0435\u043D\u043D\u044F \u0437\u0430\u0431\u043B\u043E\u043A\u043E\u0432\u0430\u043D\u043E, \u043E\u0441\u043A\u0456\u043B\u044C\u043A\u0438 \u0437\u0430\u043B\u0435\u0436\u043D\u043E\u0441\u0442\u0456 \u0434\u0436\u0435\u0440\u0435\u043B\u0430 \u043D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0431\u0435\u0437\u043F\u0435\u0447\u043D\u043E \u0432\u0456\u0434\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u0432 \u0446\u0456\u043B\u044C\u043E\u0432\u043E\u043C\u0443 \u0444\u043E\u0440\u043C\u0430\u0442\u0456.
\u041E\u0447\u0456\u043A\u0443\u0432\u0430\u043D\u043D\u044F \u043E\u0431\u0447\u0438\u0441\u043B\u0435\u043D\u043D\u044F
\u0426\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0430\u0431\u043E \u0444\u043E\u0440\u043C\u0443\u043B\u0443 \u043D\u0435 \u043C\u043E\u0436\u043D\u0430 \u0432\u0432\u0435\u0441\u0442\u0438 \u0443 \u0432\u0438\u0431\u0440\u0430\u043D\u043E\u043C\u0443 \u0440\u0435\u0436\u0438\u043C\u0456.
\u0412\u0438\u0433\u043B\u044F\u0434
\u0417\u0430\u0441\u0442\u043E\u0441\u0443\u0432\u0430\u0442\u0438
\u0424\u043E\u0440\u043C\u0430\u0442\u0443\u0432\u0430\u043D\u043D\u044F \u043A\u043B\u0456\u0442\u0438\u043D\u043E\u043A
\u0417\u0430\u043F\u043E\u0432\u043D\u0438\u0442\u0438 \u0432\u043D\u0438\u0437
\u0417\u0430\u043F\u043E\u0432\u043D\u0438\u0442\u0438 \u043F\u0440\u0430\u0432\u043E\u0440\u0443\u0447
`) };

// packages/i18n/src/catalogs-b4-polish.ts
var polish = { ...baseCatalog(`
Otw\xF3rz plik
Nowy szkic
OSTATNIE PLIKI
Lokalna przestrze\u0144 robocza \xB7 Najpierw praca offline
Ustawienia
Przestrze\u0144 robocza
Cofnij
Pon\xF3w
Zapisz jako
Zapisz
Gotowe
Wygl\u0105d
Systemowy
Jasny
Ciemny
J\u0119zyk
Wyczy\u015B\u0107 ostatnie pliki
Ustawienia i migawki odzyskiwania pozostaj\u0105 na tym komputerze.
Miejsce na Twoje dokumenty.
Niezale\u017Cny pakiet biurowy na komputer. Podgl\u0105d M3 obejmuje edytor dokument\xF3w w ograniczonym zakresie, arkusze, formu\u0142y oraz kontrolowany zapis obs\u0142ugiwanych format\xF3w Office.
Utw\xF3rz lokalny szkic
Wewn\u0119trzny format szkicu \xB7 .oex
Dokument
Arkusz kalkulacyjny
Prezentacja
Model tekstu i transakcje z cofaniem
Rzadko rozmieszczone kom\xF3rki i polecenia zbiorcze
Model sceny i wsp\xF3\u0142rz\u0119dne
Otw\xF3rz plik lub upu\u015B\u0107 go tutaj
DOC / DOCX \xB7 XLS / XLSX \xB7 PPT / PPTX \xB7 Szkice Office EX
Wybierz plik
Dokumenty i skoroszyty mo\u017Cna edytowa\u0107 i zapisywa\u0107 w obs\u0142ugiwanym zakresie. Nieobs\u0142ugiwane struktury otwieraj\u0105 si\u0119 tylko do odczytu z mo\u017Cliwo\u015Bci\u0105 zapisania dok\u0142adnej kopii; pe\u0142na zgodno\u015B\u0107 jest nadal rozwijana.
Infrastruktura format\xF3w
Kontener po\u0142\u0105czony
Nowoczesne formaty
Starsze formaty
Lokalne szkice
Brak ostatnich plik\xF3w
Bez tytu\u0142u
Szkic Office EX
Tylko do odczytu \xB7 Inspekcja struktury
Niezapisany
Zapisany
Sprawdzanie struktury pliku\u2026
Anuluj
Zamknij
Operacja anulowana
Migawka
Wersja
Zapisano pomy\u015Blnie
To wewn\u0119trzny szkic OEX. U\u017Cyj polece\u0144 tworzenia dokumentu lub skoroszytu Office, aby rozpocz\u0105\u0107 plik w obs\u0142ugiwanym formacie. Pe\u0142na zgodno\u015B\u0107 jest nadal rozwijana.
Tekst szkicu
Kom\xF3rki arkusza kalkulacyjnego
Edytuj warto\u015Bci, formu\u0142y i formaty w wirtualnej siatce. Warto\u015Bci \u017Ar\xF3d\u0142owe s\u0105 oddzielone od wynik\xF3w oblicze\u0144.
Podgl\u0105d sceny i wskazywania obiekt\xF3w
Dodaj prostok\u0105t
Kliknij kszta\u0142t, aby sprawdzi\u0107 wsp\xF3\u0142rz\u0119dne. Pe\u0142ny edytor pojawi si\u0119 w M4.
Cz\u0119\u015Bci pakietu / strumienie
Cz\u0119\u015B\u0107
Rozmiar
SHA-256
Wersja formatu
Wykryty format
Zapisz dok\u0142adn\u0105 kopi\u0119
Adapter semantyczny oczekuje
Szkice do odzyskania
Odzyskaj kopi\u0119
Odrzu\u0107
Odzyskiwanie tworzy now\u0105 niezapisan\u0105 kopi\u0119 i zachowuje plik \u017Ar\xF3d\u0142owy.
Uszkodzone migawki odzyskiwania zosta\u0142y odizolowane i nie zosta\u0142y wczytane.
Odzyskano jako nowy szkic
Praca w toku
Raport zgodno\u015Bci
Brak cz\u0119\u015Bci kontenera do wy\u015Bwietlenia.
Pusty slajd
Wyczyszczono histori\u0119 ostatnich plik\xF3w
Tytu\u0142 dokumentu
Mo\u017Cna otworzy\u0107 maksymalnie 32 karty
Niezale\u017Cny silnik \xB7 Arkusze M3
Plik zapisano; ten system plik\xF3w nie zapewni\u0142 gwarancji synchronizacji katalogu.
Plik zapisano, ale nie uda\u0142o si\u0119 zaktualizowa\u0107 danych odzyskiwania lub ostatnich plik\xF3w.
Strona g\u0142\xF3wna Office EX
Nawigacja g\u0142\xF3wna
Dokumenty
Operacje na dokumencie
M3 \xB7 PODGL\u0104D WERSJI ROZWOJOWEJ
OFFICE EX / TWOJA LOKALNA PRZESTRZE\u0143 ROBOCZA
Formaty regionalne
J\u0119zyk nowych dokument\xF3w (preferencja)
Nowe dokumenty Writer u\u017Cywaj\u0105 tego j\u0119zyka tekstu. Istniej\u0105ce pliki pozostaj\u0105 bez zmian; inne edytory b\u0119d\u0105 go u\u017Cywa\u0107 p\xF3\u017Aniej.
Podgl\u0105d formatu regionalnego
Historia
Obszar rysowania
Liczba wpis\xF3w: {count}; wy\u015Bwietlono pierwsze 500.
Plik
Edycja
Widok
Nowy szkic dokumentu
Nowy szkic arkusza kalkulacyjnego
Nowy szkic prezentacji
Otw\xF3rz\u2026
Zapisz jako\u2026
Zamknij kart\u0119
Wytnij
Kopiuj
Wklej
Zaznacz wszystko
Prze\u0142\u0105cz pe\u0142ny ekran
Resetuj powi\u0119kszenie
Powi\u0119ksz
Pomniejsz
Dokumenty Office / szkice Office EX
Wszystkie pliki
Oryginalny format pliku
Zast\u0105pi\u0107 istniej\u0105cy plik docelowy?
Zast\u0105p
Zapisa\u0107 zmiany przed zamkni\u0119ciem?
Odrzu\u0107 zmiany
Nie mo\u017Cna otworzy\u0107 pliku
Nie mo\u017Cna otworzy\u0107 okna
Zako\u0144cz bie\u017C\u0105ce wprowadzanie tekstu przed zmian\u0105 j\u0119zyka.
Otwieraj po jednym upuszczonym pliku.
Nieprawid\u0142owy plik lub \u017C\u0105danie.
Ta funkcja lub format nie s\u0105 jeszcze obs\u0142ugiwane.
Operacja zosta\u0142a zablokowana ze wzgl\u0119d\xF3w bezpiecze\u0144stwa.
Operacja przekracza limit zasob\xF3w.
Dokument lub plik docelowy uleg\u0142 zmianie.
Operacja na pliku nie powiod\u0142a si\u0119.
Wyst\u0105pi\u0142 b\u0142\u0105d wewn\u0119trzny.
Zg\u0142oszono nierozpoznany komunikat diagnostyczny zgodno\u015Bci.
Tylko inspekcja kontenera. Nie zaimportowano semantyki dokumentu umo\u017Cliwiaj\u0105cej edycj\u0119.
Wykryto zawarto\u015B\u0107 zwi\u0105zan\u0105 z makrami. Makra nie s\u0105 uruchamiane; ich bajty zachowuje si\u0119 tylko w dok\u0142adnych kopiach.
Plik podpisany: tylko inspekcja. Wa\u017Cno\u015B\u0107 podpisu nie jest potwierdzona.
Relacje zewn\u0119trzne s\u0105 rejestrowane; zawarto\u015B\u0107 zewn\u0119trzna nie jest wczytywana.
Wykryto Strict OOXML; odczyt i zapis semantyczny nie zosta\u0142y zweryfikowane.
Wykryto zaszyfrowany kontener. Odszyfrowywanie i edycja s\u0105 niedost\u0119pne.
Rozszerzenie r\xF3\u017Cni si\u0119 od wykrytej zawarto\u015Bci.
Formatowanie tekstu
Edytuj akapity i zaznacz tekst, aby go sformatowa\u0107. Enter dzieli akapit; Shift+Enter wstawia podzia\u0142 wiersza.
Podgl\u0105d strony
Szacowany uk\u0142ad strony. Kliknij stron\u0119, aby zlokalizowa\u0107 tekst. Wierno\u015B\u0107 wydruku nie zosta\u0142a jeszcze zweryfikowana.
Poprzednia strona
Nast\u0119pna strona
Strona {current} / {total}
Niekt\xF3re funkcje typografii lub uk\u0142adu s\u0105 przybli\u017Cone.
Podgl\u0105d jest niedost\u0119pny dla tej zawarto\u015Bci lub z powodu limitu uk\u0142adu. Zawarto\u015B\u0107 \u017Ar\xF3d\u0142owa pozostaje bez zmian.
Pogrubienie
Kursywa
Podkre\u015Blenie
Wyr\xF3wnaj do lewej
Wy\u015Brodkuj
Wyr\xF3wnaj do prawej
Podziel akapit
Podzia\u0142 strony po akapicie
Tego bloku nie mo\u017Cna edytowa\u0107 w tym podgl\u0105dzie.
Nowy dokument DOCX
Dokument DOCX
Ograniczony zakres DOCX: tekst, formatowanie bezpo\u015Brednie, obs\u0142ugiwane nazwane style, sta\u0142e prostok\u0105tne tabele, osadzone obrazy PNG/JPEG w wierszu i podstawowy uk\u0142ad. Z\u0142o\u017Cone dokumenty pozostaj\u0105 tylko do odczytu.
Czcionka
Rozmiar (pkt)
Kolor tekstu
Styl akapitu
Styl znak\xF3w
Wybierz styl
Tabela
Wiersze
Kolumny
Wstaw tabel\u0119
Dodaj wiersz poni\u017Cej
Usu\u0144 wiersz
Dodaj kolumn\u0119 z prawej
Usu\u0144 kolumn\u0119
Szeroko\u015B\u0107 kolumny (pkt)
Obramowanie tabeli
Usu\u0144 tabel\u0119
Kom\xF3rka {row}, {column}
Wstaw obraz
Obraz
Szeroko\u015B\u0107 obrazu (pkt)
Usu\u0144 obraz
Rozmiar papieru
Niestandardowy
A4
Letter
A3
Orientacja strony
Pionowa
Pozioma
Szeroko\u015B\u0107 strony (pkt)
Wysoko\u015B\u0107 strony (pkt)
Margines g\xF3rny (pkt)
Margines prawy (pkt)
Margines dolny (pkt)
Margines lewy (pkt)
Zastosuj ustawienia strony
Wci\u0119cie (pkt)
Przed (pkt)
Po (pkt)
Wysoko\u015B\u0107 wiersza (pkt; 0 = automatycznie)
Wstaw obraz przy kursorze
Znacznik obiektu reprezentuje obraz w wierszu. U\u017Cyj kontrolek obrazu, aby zmieni\u0107 jego rozmiar lub go usun\u0105\u0107.
Edytuj tekst ci\u0105g\u0142y
Wr\xF3\u0107 do edytora akapit\xF3w
Zaznaczaj, kopiuj, wycinaj, wklejaj lub formatuj tekst w s\u0105siednich akapitach. Tabele, podzia\u0142y stron, sekcje i akapity z obrazami wyznaczaj\u0105 granice zaznaczenia. Nowe wklejone wiersze staj\u0105 si\u0119 akapitami.
Sekcja
Sekcja {number}
Podzia\u0142 sekcji na nast\u0119pnej stronie
J\u0119zyk tekstu (BCP 47)
Kierunek akapitu
Od lewej do prawej
Od prawej do lewej
Nowy DOC
Dokument Word 97\u20132003
Ograniczona edycja DOC: tekst Unicode, podstawowe style i jedna sekcja. Nieobs\u0142ugiwane pliki DOC pozostaj\u0105 tylko do odczytu; w tym zakresie nie mo\u017Cna zapisywa\u0107 tabel ani obraz\xF3w.
Podgl\u0105d g\u0142\xF3wnego tekstu tylko do odczytu, a nie pe\u0142ny uk\u0142ad dokumentu. Zapisanie kopii zachowuje oryginalne bajty.
Konwertuj na DOC
Konwertuj na DOCX
Konwersja wymaga dokumentu zawieraj\u0105cego wy\u0142\u0105cznie obs\u0142ugiwane struktury; nierozpoznane cz\u0119\u015Bci s\u0105 zachowane w \u017Ar\xF3dle, a nie usuwane.
Edytuj na stronie
Wr\xF3\u0107 do narz\u0119dzi
Edytuj na stronie, korzystaj\u0105c z natywnego kszta\u0142towania tekstu przegl\u0105darki. Przeci\u0105gnij, aby zaznaczy\u0107; kopiowanie i wklejanie zachowuj\u0105 obs\u0142ugiwane formatowanie Office EX oraz obrazy. Wierno\u015B\u0107 strony wzgl\u0119dem Worda nie zosta\u0142a jeszcze zweryfikowana.
`), ...sheetsCatalog(`
Nowy skoroszyt XLSX
Skoroszyt programu Excel (.xlsx)
Edytuj obs\u0142ugiwane kom\xF3rki, formu\u0142y i style. Pliki chronione lub z nieobs\u0142ugiwanymi zale\u017Cno\u015Bciami otwieraj\u0105 si\u0119 jako podgl\u0105d tylko do odczytu, zachowuj\u0105cy orygina\u0142.
Nowy skoroszyt Excel 97\u20132003
Skoroszyt Excel 97\u20132003 (.xls)
Skoroszyt BIFF8: do 65 536 wierszy i 256 kolumn. Przed zapisem i konwersj\u0105 sprawdzane s\u0105 formu\u0142y, style oraz zale\u017Cno\u015Bci \u017Ar\xF3d\u0142a.
Konwertuj na kopi\u0119 XLSX
Konwertuj na kopi\u0119 XLS
Siatka arkusza kalkulacyjnego
Warto\u015B\u0107 kom\xF3rki lub formu\u0142a
Adres kom\xF3rki lub zakresu
Dodaj arkusz
Zmie\u0144 nazw\u0119 arkusza
Usu\u0144 arkusz
Przesu\u0144 arkusz wcze\u015Bniej
Przesu\u0144 arkusz p\xF3\u017Aniej
Nazwa arkusza
Arkusze, wiersze i kolumny
Scal kom\xF3rki
Rozdziel kom\xF3rki
Wyczy\u015B\u0107 warto\u015Bci
Wstaw wiersze
Usu\u0144 wiersze
Wstaw kolumny
Usu\u0144 kolumny
Wysoko\u015B\u0107 wiersza (px)
Szeroko\u015B\u0107 kolumny (px)
Format liczbowy
Og\xF3lny
Liczba
Procent
Waluta
Data
Czas
Naukowy
Niestandardowy kod formatu
Wype\u0142nienie kom\xF3rki
Zawijaj tekst
Obramowanie kom\xF3rek
Wprowadzanie formu\u0142
Nazwy angielskie \xB7 kropka dziesi\u0119tna
Nazwy i separatory regionalne
Przelicz
Obliczanie\u2026
Obliczono
Nie obliczono: nieobs\u0142ugiwana formu\u0142a
Poprzedni wynik: wymagane przeliczenie
B\u0142\u0105d formu\u0142y
Anuluj obliczenia
Kom\xF3rki liczbowe: {count} \xB7 Suma {sum}
Zaznaczenie {address}
Kliknij lub przeci\u0105gnij, aby zaznaczy\u0107. Wpisz tekst lub naci\u015Bnij F2, aby edytowa\u0107; Enter potwierdza, Esc anuluje. Shift rozszerza zaznaczenie. Kopiuj i wklejaj zakresy jako TSV. Formu\u0142y zaczynaj\u0105 si\u0119 od =.
Zablokuj przy zaznaczeniu
Odblokuj okienka
Arkusz od prawej do lewej
Poka\u017C linie siatki
System dat skoroszytu
Podgl\u0105d zachowanego skoroszytu
Ten skoroszyt zawiera zale\u017Cno\u015Bci wykraczaj\u0105ce poza zakres edycji. Mo\u017Cesz przegl\u0105da\u0107 kom\xF3rki i zapisa\u0107 dok\u0142adn\u0105 kopi\u0119 orygina\u0142u.
Konwersja jest zablokowana, poniewa\u017C zale\u017Cno\u015Bci \u017Ar\xF3d\u0142a nie mog\u0105 by\u0107 bezpiecznie przedstawione w formacie docelowym.
Oczekiwanie na obliczenia
Tej warto\u015Bci lub formu\u0142y nie mo\u017Cna wprowadzi\u0107 w wybranym trybie wprowadzania.
Widok
Zastosuj
Formatowanie kom\xF3rek
Wype\u0142nij w d\xF3\u0142
Wype\u0142nij w prawo
`) };

// packages/i18n/src/index.ts
var english2 = { ...english, ...sheetsEnglish };
var catalogs = {
  "en-US": english2,
  "zh-CN": { ...simplified, ...sheetsSimplified },
  "zh-TW": { ...traditional, ...sheetsTraditional },
  "ja-JP": { ...japanese, ...sheetsJapanese },
  "ko-KR": { ...korean, ...sheetsKorean },
  "fr-FR": { ...french, ...sheetsFrench },
  "de-DE": { ...german, ...sheetsGerman },
  "es-ES": { ...spanish, ...sheetsSpanish },
  "pt-BR": { ...portuguese, ...sheetsPortuguese },
  "ru-RU": { ...russian, ...sheetsRussian },
  "it-IT": { ...italian, ...sheetsItalian },
  "ar": arabic,
  "he-IL": hebrew,
  "hi-IN": hindi,
  "th-TH": thai,
  "vi-VN": vietnamese,
  "id-ID": indonesian,
  "ms-MY": malay,
  "tr-TR": turkish,
  "nl-NL": dutch,
  "pl-PL": polish,
  "uk-UA": ukrainian
};
var TARGET_LOCALES = [
  ["zh-CN", "\u7B80\u4F53\u4E2D\u6587", "ltr", "A"],
  ["zh-TW", "\u7E41\u9AD4\u4E2D\u6587", "ltr", "A"],
  ["en-US", "English", "ltr", "A"],
  ["ja-JP", "\u65E5\u672C\u8A9E", "ltr", "A"],
  ["ko-KR", "\uD55C\uAD6D\uC5B4", "ltr", "A"],
  ["fr-FR", "Fran\xE7ais", "ltr", "A"],
  ["de-DE", "Deutsch", "ltr", "A"],
  ["es-ES", "Espa\xF1ol", "ltr", "A"],
  ["pt-BR", "Portugu\xEAs (Brasil)", "ltr", "A"],
  ["ru-RU", "\u0420\u0443\u0441\u0441\u043A\u0438\u0439", "ltr", "A"],
  ["it-IT", "Italiano", "ltr", "A"],
  ["ar", "\u0627\u0644\u0639\u0631\u0628\u064A\u0629", "rtl", "B"],
  ["he-IL", "\u05E2\u05D1\u05E8\u05D9\u05EA", "rtl", "B"],
  ["hi-IN", "\u0939\u093F\u0928\u094D\u0926\u0940", "ltr", "B"],
  ["th-TH", "\u0E44\u0E17\u0E22", "ltr", "B"],
  ["vi-VN", "Ti\u1EBFng Vi\u1EC7t", "ltr", "B"],
  ["id-ID", "Bahasa Indonesia", "ltr", "B"],
  ["ms-MY", "Bahasa Melayu", "ltr", "B"],
  ["tr-TR", "T\xFCrk\xE7e", "ltr", "B"],
  ["nl-NL", "Nederlands", "ltr", "B"],
  ["pl-PL", "Polski", "ltr", "B"],
  ["uk-UA", "\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430", "ltr", "B"]
];
var REGIONAL_LOCALES = [...TARGET_LOCALES.map((x) => x[0]), "en-GB", "en-AU", "es-419", "pt-PT", "zh-HK"];
function isUiLocale(value) {
  return typeof value === "string" && Object.hasOwn(catalogs, value);
}
function canonical(value) {
  try {
    return Intl.getCanonicalLocales(value)[0];
  } catch {
    return void 0;
  }
}
function localeDirection(locale) {
  const c = canonical(locale);
  if (!c) return "ltr";
  return ["ar", "he", "fa", "ur"].includes(new Intl.Locale(c).language) ? "rtl" : "ltr";
}
function isMessageKey(key) {
  return typeof key === "string" && Object.hasOwn(english2, key);
}
function message(locale, key, args = {}) {
  if (!isMessageKey(key)) throw new Error("Unknown message key");
  const value = isUiLocale(locale) ? catalogs[locale][key] : english2[key];
  const template = localeDirection(locale) === "rtl" ? value.replace(/\{[A-Za-z][A-Za-z0-9_]*\}/g, (token) => "\u2068" + token + "\u2069") : value;
  return formatTemplate(template, args);
}

// tests/sheets-browser-entry.ts
var session;
var state;
var composing = false;
var region = "en-US";
var rejectEdits = false;
var readOnly = false;
var errors = [];
var root = document.querySelector("#test-root");
function render() {
  root.replaceChildren(sheetsWorkspace({ snapshot: () => session.snapshot(), execute: (command) => {
    if (rejectEdits) return false;
    try {
      session.execute(command);
      return true;
    } catch (e) {
      errors.push(String(e));
      return false;
    }
  }, render, error: (e) => errors.push(String(e)), t: (key, args) => message("en-US", key, args), locale: () => region, composing: () => composing, setComposing: (value) => {
    composing = value;
  }, isCurrent: () => true, format: "xlsx", readOnly }, state));
}
function load(document2) {
  releaseSheetCalculation();
  session = new DocumentSession(document2);
  readOnly = false;
  state = { row: 1, column: 1, anchorRow: 1, anchorColumn: 1, scrollTop: 0, scrollLeft: 0, inputMode: "canonical" };
  render();
}
var controls = { load, snapshot: () => session.snapshot(), errors, setRegion: (value) => {
  region = value;
  render();
}, reject: (value) => {
  rejectEdits = value;
}, opaquePreview: () => {
  releaseSheetCalculation();
  const model = createDocument("sheets", "opaque-preview"), sheet = model.sheets[0];
  sheet.cells["1:2"] = { value: { kind: "formula", source: "=A1+1" } };
  session = new DocumentSession(model, { capabilities: { canEdit: false, allowedFeatures: [], diagnostics: [] } });
  readOnly = true;
  state = { row: 1, column: 1, anchorRow: 1, anchorColumn: 1, scrollTop: 0, scrollLeft: 0, inputMode: "canonical", unsupportedFormulas: [sheet.id + "!1:1"], cachedValues: [[sheet.id + "!1:1", { kind: "number", value: 3 }], [sheet.id + "!1:2", { kind: "number", value: 4 }]] };
  render();
}, undo: () => {
  session.undo();
  render();
}, redo: () => {
  session.redo();
  render();
}, fixture: (size) => {
  const model = createDocument("sheets", "browser-book");
  model.defaultTextStyle = { fontFamily: "Arial", fontSize: 139700 };
  for (let i = 0; i < size; i++) model.sheets[0].cells[`${Math.floor(i / 10) + 1}:${i % 10 + 1}`] = { value: { kind: "number", value: i + 1 } };
  return model;
} };
Object.assign(window, { testSheets: controls });
load(createDocument("sheets", "browser-book"));
