// packages/contracts/src/index.ts
var OfficeError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "OfficeError";
  }
  code;
};
function assert(condition, code, message) {
  if (!condition) throw new OfficeError(code, message);
}
function asFailure(error2) {
  return error2 instanceof OfficeError ? { code: error2.code, message: error2.message } : { code: "internal", message: "Internal operation failed" };
}
var CELL_LIMITS = Object.freeze({ xls: Object.freeze({ rows: 65536, columns: 256 }), xlsx: Object.freeze({ rows: 1048576, columns: 16384 }) });
function assertCellAddress(row, column, format = "xlsx") {
  assert(Number.isInteger(row) && row > 0 && row <= CELL_LIMITS[format].rows && Number.isInteger(column) && column > 0 && column <= CELL_LIMITS[format].columns, "invalid", "Cell address is outside format limits");
}

// packages/sheets/src/intl-cache.ts
var formatters = /* @__PURE__ */ new Map();
var limit = 128;
function cached(key, create) {
  const existing = formatters.get(key);
  if (existing) {
    formatters.delete(key);
    formatters.set(key, existing);
    return existing;
  }
  const formatter = create();
  if (formatters.size >= limit) formatters.delete(formatters.keys().next().value);
  formatters.set(key, formatter);
  return formatter;
}
function numberFormatter(locale, options = {}) {
  return cached(`number:${locale}:${JSON.stringify(options)}`, () => new Intl.NumberFormat(locale, options));
}

// packages/sheets/src/formula.ts
var SUPPORTED_FUNCTIONS = Object.freeze(["SUM", "AVERAGE", "MIN", "MAX", "COUNT", "COUNTA", "IF", "AND", "OR", "NOT", "ROUND", "ABS"]);
var functions = new Set(SUPPORTED_FUNCTIONS);
function isSupportedFunction(name) {
  return functions.has(name.toUpperCase());
}
var FORMULA_ALIASES = Object.freeze({
  de: Object.freeze({ SUMME: "SUM", MITTELWERT: "AVERAGE", ANZAHL: "COUNT", ANZAHL2: "COUNTA", WENN: "IF", UND: "AND", ODER: "OR", NICHT: "NOT", RUNDEN: "ROUND" }),
  fr: Object.freeze({ SOMME: "SUM", MOYENNE: "AVERAGE", NB: "COUNT", NBVAL: "COUNTA", SI: "IF", ET: "AND", OU: "OR", NON: "NOT", ARRONDI: "ROUND" })
});
function columnNumber(name) {
  assert(/^[A-Za-z]{1,3}$/.test(name), "invalid", "Invalid column label");
  let result = 0;
  for (const ch of name.toUpperCase()) result = result * 26 + ch.charCodeAt(0) - 64;
  assertCellAddress(1, result);
  return result;
}
var separatorsCache = /* @__PURE__ */ new Map();
function formulaSeparators(locale) {
  const found = separatorsCache.get(locale);
  if (found) return found;
  const decimal = numberFormatter(locale, { useGrouping: false }).formatToParts(1.1).find((p) => p.type === "decimal")?.value ?? ".";
  const result = Object.freeze({ decimal, argument: decimal === "," ? ";" : "," });
  if (separatorsCache.size >= 128) separatorsCache.delete(separatorsCache.keys().next().value);
  separatorsCache.set(locale, result);
  return result;
}
var errorPattern = /^(?:#NULL!|#DIV\/0!|#VALUE!|#REF!|#NAME\?|#NUM!|#N\/A)/i;
function lex(source, options) {
  assert(source.startsWith("=") && source.length > 1 && source.length <= 8192, "invalid", "Invalid formula length or prefix");
  const separators = options.mode === "regional" ? formulaSeparators(options.locale ?? "en-US") : { decimal: ".", argument: "," };
  const tokens = [];
  const max = options.maxTokens ?? 8192;
  assert(Number.isInteger(max) && max > 0 && max <= 32768, "invalid", "Invalid token budget");
  const push = (kind, text) => {
    assert(tokens.length < max, "limit", "Formula token budget exceeded");
    tokens.push({ kind, text });
  };
  for (let index = 1; index < source.length; ) {
    options.cancellation?.throwIfCancelled();
    const ch = source[index];
    if (/\s/u.test(ch)) {
      index++;
      continue;
    }
    if (ch === '"' || ch === "'") {
      const quote = ch;
      index++;
      let text = "";
      let closed = false;
      while (index < source.length) {
        const c = source[index++];
        if (c === quote) {
          if (source[index] === quote) {
            text += quote;
            index++;
          } else {
            closed = true;
            break;
          }
        } else text += c;
      }
      assert(closed, "invalid", "Unterminated formula literal");
      push(quote === '"' ? "string" : "quoted", text);
      continue;
    }
    if (ch === "#") {
      const match = errorPattern.exec(source.slice(index));
      assert(match, "unsupported", "Unsupported error or spilled reference");
      push("error", match[0].toUpperCase());
      index += match[0].length;
      continue;
    }
    if (/[0-9]/.test(ch) || ch === separators.decimal && /[0-9]/.test(source[index + 1] ?? "")) {
      const start = index;
      let decimal = false;
      while (index < source.length && (/[0-9]/.test(source[index]) || !decimal && source[index] === separators.decimal)) {
        if (source[index] === separators.decimal) decimal = true;
        index++;
      }
      if (/[Ee]/.test(source[index] ?? "") && /^[Ee][+-]?\d/.test(source.slice(index))) {
        index++;
        if (/[+-]/.test(source[index] ?? "")) index++;
        while (/\d/.test(source[index] ?? "")) index++;
      }
      const text = source.slice(start, index).replace(separators.decimal, ".");
      assert(Number.isFinite(Number(text)), "invalid", "Non-finite formula literal");
      push("number", text);
      continue;
    }
    if (/[\p{L}_$\\]/u.test(ch)) {
      const start = index++;
      while (index < source.length && /[\p{L}\p{N}_.$\\]/u.test(source[index])) index++;
      push("word", source.slice(start, index));
      continue;
    }
    const pair = source.slice(index, index + 2);
    if (["<>", "<=", ">="].includes(pair)) {
      push("symbol", pair);
      index += 2;
      continue;
    }
    if (ch === separators.argument) {
      push("symbol", ",");
      index++;
      continue;
    }
    assert("+-*/^&=<>%():!".includes(ch), "unsupported", "Unsupported formula syntax");
    push("symbol", ch);
    index++;
  }
  tokens.push({ kind: "end", text: "" });
  return tokens;
}
var precedence = { "=": 1, "<>": 1, "<": 1, ">": 1, "<=": 1, ">=": 1, "&": 2, "+": 3, "-": 3, "*": 4, "/": 4, "^": 5 };
function parseFormula(source, options = {}) {
  const tokens = lex(source, options);
  let cursor = 0;
  const maxDepth = options.maxDepth ?? 128;
  assert(Number.isInteger(maxDepth) && maxDepth >= 1 && maxDepth <= 256, "invalid", "Invalid formula depth budget");
  const peek = () => tokens[cursor];
  const take = () => tokens[cursor++];
  const expect = (text) => {
    assert(take().text === text, "invalid", "Unexpected formula token");
  };
  const reference = (token, sheet) => {
    const match = /^(\$?)([A-Za-z]{1,3})(\$?)([1-9]\d*)$/.exec(token.text);
    if (!match) return void 0;
    const row = Number(match[4]), column = columnNumber(match[2]);
    assertCellAddress(row, column);
    return { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row, column, rowAbsolute: !!match[3], columnAbsolute: !!match[1] };
  };
  const parseReference = (first, sheet) => {
    const start = reference(first, sheet);
    if (start) {
      if (peek().text !== ":") return start;
      take();
      let endToken2 = take();
      let endSheet = sheet;
      if (peek().text === "!") {
        assert(endToken2.kind === "word" || endToken2.kind === "quoted", "invalid", "Invalid range sheet");
        endSheet = endToken2.text;
        take();
        endToken2 = take();
      }
      const end = reference(endToken2, endSheet);
      assert(end, "unsupported", "Unsupported range endpoint");
      assert((end.sheet ?? sheet) === sheet, "unsupported", "Three-dimensional range is unsupported");
      return { kind: "range", start, end };
    }
    if (peek().text !== ":") return void 0;
    const col = /^(\$?)([A-Za-z]{1,3})$/.exec(first.text), row = /^(\$?)([1-9]\d*)$/.exec(first.text);
    assert(col || row, "unsupported", "Unsupported reference range");
    take();
    const endToken = take();
    if (col) {
      const other2 = /^(\$?)([A-Za-z]{1,3})$/.exec(endToken.text);
      assert(other2, "invalid", "Invalid whole column range");
      return { kind: "range", axis: "columns", start: { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row: 1, column: columnNumber(col[2]), rowAbsolute: false, columnAbsolute: !!col[1] }, end: { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row: 1048576, column: columnNumber(other2[2]), rowAbsolute: false, columnAbsolute: !!other2[1] } };
    }
    const other = /^(\$?)([1-9]\d*)$/.exec(endToken.text);
    assert(other, "invalid", "Invalid whole row range");
    const firstRow = Number(row[2]), lastRow = Number(other[2]);
    assertCellAddress(firstRow, 1);
    assertCellAddress(lastRow, 1);
    return { kind: "range", axis: "rows", start: { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row: firstRow, column: 1, rowAbsolute: !!row[1], columnAbsolute: false }, end: { kind: "reference", ...sheet !== void 0 ? { sheet } : {}, row: lastRow, column: 16384, rowAbsolute: !!other[1], columnAbsolute: false } };
  };
  const primary = (depth) => {
    assert(depth <= maxDepth, "limit", "Formula AST depth exceeded");
    options.cancellation?.throwIfCancelled();
    const token = take();
    if (token.text === "+" || token.text === "-") return { kind: "unary", operator: token.text, operand: primary(depth + 1) };
    if (token.text === "(") {
      const value = expression(1, depth + 1);
      expect(")");
      return value;
    }
    if (token.kind === "string") return { kind: "string", value: token.text };
    if (token.kind === "error") return { kind: "error", value: token.text };
    if ((token.kind === "word" || token.kind === "quoted") && peek().text === "!") {
      take();
      const ref2 = parseReference(take(), token.text);
      assert(ref2, "unsupported", "Only cell and range sheet references are supported");
      return ref2;
    }
    if (token.kind === "word" && peek().text === "(") {
      take();
      const args = [];
      if (peek().text !== ")") {
        while (true) {
          assert(args.length < 255, "limit", "Function argument budget exceeded");
          args.push(peek().text === "," || peek().text === ")" ? { kind: "missing" } : expression(1, depth + 1));
          if (peek().text !== ",") break;
          take();
        }
      }
      expect(")");
      const upper = token.text.toUpperCase();
      const name = options.mode === "regional" ? FORMULA_ALIASES[(options.locale ?? "en-US").split("-")[0]]?.[upper] ?? upper : upper;
      return { kind: "call", name, args };
    }
    const ref = parseReference(token);
    if (ref) return ref;
    if (token.kind === "number") return { kind: "number", value: Number(token.text) };
    if (token.kind === "word" && /^(TRUE|FALSE)$/i.test(token.text)) return { kind: "boolean", value: token.text.toUpperCase() === "TRUE" };
    throw new OfficeError("unsupported", "Unsupported named reference or formula token");
  };
  const expression = (minimum, depth) => {
    assert(depth <= maxDepth, "limit", "Formula AST depth exceeded");
    let left = primary(depth);
    while (peek().text === "%") {
      take();
      left = { kind: "unary", operator: "%", operand: left };
    }
    while (peek().kind === "symbol" && (precedence[peek().text] ?? 0) >= minimum) {
      const operator = take().text;
      const right = expression(precedence[operator] + 1, depth + 1);
      left = { kind: "binary", operator, left, right };
    }
    return left;
  };
  const ast = expression(1, 1);
  assert(peek().kind === "end", "unsupported", "Unsupported trailing formula syntax");
  walkFormula(ast, () => {
  }, maxDepth);
  return ast;
}
function walkFormula(ast, visit, maxDepth = 128) {
  const stack = [{ node: ast, depth: 1 }];
  let count = 0;
  while (stack.length) {
    const { node, depth } = stack.pop();
    assert(depth <= maxDepth && ++count <= 8192, "limit", "Formula AST budget exceeded");
    visit(node);
    if (node.kind === "binary") stack.push({ node: node.right, depth: depth + 1 }, { node: node.left, depth: depth + 1 });
    else if (node.kind === "unary") stack.push({ node: node.operand, depth: depth + 1 });
    else if (node.kind === "call") for (let i = node.args.length - 1; i >= 0; i--) stack.push({ node: node.args[i], depth: depth + 1 });
  }
}

// packages/sheets/src/calculation.ts
function calculationKey(sheetId, row, column) {
  return `${sheetId}!${row}:${column}`;
}
var SparseSheetIndex = class {
  rows;
  #byRow = /* @__PURE__ */ new Map();
  constructor(sheet, formulasOnly = false) {
    for (const [key, cell] of Object.entries(sheet.cells)) {
      if (formulasOnly && cell.value.kind !== "formula") continue;
      const [row, column] = key.split(":").map(Number);
      const entries = this.#byRow.get(row) ?? [];
      entries.push({ key, row, column, cell });
      this.#byRow.set(row, entries);
    }
    this.rows = [...this.#byRow.keys()].sort((a, b) => a - b);
    for (const entries of this.#byRow.values()) entries.sort((a, b) => a.column - b.column);
  }
  *range(firstRow, firstColumn, lastRow, lastColumn) {
    for (let r = lowerBound(this.rows, firstRow); r < this.rows.length && this.rows[r] <= lastRow; r++) {
      const entries = this.#byRow.get(this.rows[r]);
      let lo = 0, hi = entries.length;
      while (lo < hi) {
        const mid = lo + hi >>> 1;
        if (entries[mid].column < firstColumn) lo = mid + 1;
        else hi = mid;
      }
      for (let c = lo; c < entries.length && entries[c].column <= lastColumn; c++) yield entries[c];
    }
  }
};
function lowerBound(values, target) {
  let lo = 0, hi = values.length;
  while (lo < hi) {
    const mid = lo + hi >>> 1;
    if (values[mid] < target) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
var RangeDependencyIndex = class {
  #sheets = /* @__PURE__ */ new Map();
  constructor(ranges) {
    const groups = /* @__PURE__ */ new Map();
    for (const range of ranges) {
      const group = groups.get(range.sheetId) ?? [];
      group.push(range);
      groups.set(range.sheetId, group);
    }
    const build = (items) => {
      if (!items.length) return void 0;
      const ends = items.flatMap((i) => [i.row1, i.row2]).sort((a, b) => a - b), center = ends[Math.floor(ends.length / 2)];
      const left = [], right = [], crossing = [];
      for (const item of items) {
        if (item.row2 < center) left.push(item);
        else if (item.row1 > center) right.push(item);
        else crossing.push(item);
      }
      return { center, crossing, ...left.length ? { left: build(left) } : {}, ...right.length ? { right: build(right) } : {} };
    };
    for (const [id, ranges2] of groups) this.#sheets.set(id, build(ranges2));
  }
  query(sheetId, row, column, tick) {
    let node = this.#sheets.get(sheetId);
    const owners = [];
    while (node) {
      for (const range of node.crossing) {
        tick?.();
        if (row >= range.row1 && row <= range.row2 && column >= range.column1 && column <= range.column2) owners.push(range.owner);
      }
      node = row < node.center ? node.left : row > node.center ? node.right : void 0;
    }
    return owners;
  }
};
var blank = Object.freeze({ kind: "blank" });
var num = (value) => Number.isFinite(value) ? { kind: "number", value: Object.is(value, -0) ? 0 : value } : error("#NUM!");
var error = (value) => ({ kind: "error", value });
var bool = (value) => ({ kind: "boolean", value });
var pending = (reason = "dependency", state = "stale") => ({ kind: "pending", reason, state });
function scalar(value) {
  return value.kind === "range-value" ? pending("unsupported-syntax", "unsupported") : value;
}
function numeric(value) {
  if (value.kind === "number") return value.value;
  if (value.kind === "blank") return 0;
  if (value.kind === "boolean") return Number(value.value);
  if (value.kind === "error") return value;
  const text = value.value.trim();
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(text)) return error("#VALUE!");
  const number = Number(text);
  return Number.isFinite(number) ? number : error("#NUM!");
}
function logical(value) {
  if (value.kind === "boolean") return value.value;
  if (value.kind === "blank") return false;
  if (value.kind === "number") return value.value !== 0;
  if (value.kind === "error") return value;
  if (value.value.toUpperCase() === "TRUE") return true;
  if (value.value.toUpperCase() === "FALSE") return false;
  return error("#VALUE!");
}
function textValue(value) {
  return value.kind === "blank" ? "" : value.kind === "boolean" ? value.value ? "TRUE" : "FALSE" : String(value.value);
}
function comparison(a, b) {
  if (a.kind === "blank") a = b.kind === "string" ? { kind: "string", value: "" } : b.kind === "boolean" ? bool(false) : num(0);
  if (b.kind === "blank") b = a.kind === "string" ? { kind: "string", value: "" } : a.kind === "boolean" ? bool(false) : num(0);
  const rank = (v) => v.kind === "number" ? 0 : v.kind === "string" ? 1 : 2;
  if (a.kind !== b.kind) return rank(a) - rank(b);
  const av = a.kind === "string" ? a.value.toUpperCase() : "value" in a ? a.value : 0;
  const bv = b.kind === "string" ? b.value.toUpperCase() : "value" in b ? b.value : 0;
  return av === bv ? 0 : av < bv ? -1 : 1;
}
function decimalRound(value, digits) {
  const precision = Math.trunc(digits);
  if (precision > 308) return num(value);
  if (precision < -308) return num(0);
  const shift = (n, exponent) => {
    const [base, exp = "0"] = String(n).split("e");
    return Number(`${base}e${Number(exp) + exponent}`);
  };
  const shifted = shift(Math.abs(value), precision);
  if (!Number.isFinite(shifted)) return num(value);
  return num(Math.sign(value) * shift(Math.floor(shifted + 0.5), -precision));
}
function sameValue(a, b) {
  if (a === b) return true;
  if (!a || !b || a.kind !== b.kind) return false;
  return a.kind === "blank" || (a.kind === "formula" && b.kind === "formula" ? a.source === b.source : "value" in a && "value" in b && a.value === b.value);
}
var WorkbookCalculator = class {
  #previous;
  #results = /* @__PURE__ */ new Map();
  #parsed = /* @__PURE__ */ new Map();
  #index = new RangeDependencyIndex([]);
  #sheetIndexes = /* @__PURE__ */ new Map();
  #dependencies = /* @__PURE__ */ new Map();
  #reverse = /* @__PURE__ */ new Map();
  calculate(document, options = {}) {
    assert(document.kind === "sheets", "invalid", "Expected workbook");
    let steps = 0, computedCells = 0;
    const maximum = options.maxSteps ?? 1e6, maxDepth = options.maxDepth ?? 256;
    assert(Number.isSafeInteger(maximum) && maximum > 0 && maximum <= 1e8, "invalid", "Invalid calculation budget");
    assert(Number.isInteger(maxDepth) && maxDepth >= 1 && maxDepth <= 512, "invalid", "Invalid calculation depth budget");
    const tick = () => {
      assert(++steps <= maximum, "limit", "Formula calculation step budget exceeded");
      if ((steps & 127) === 1) {
        options.cancellation?.throwIfCancelled();
        if (options.deadline !== void 0 && options.now) assert(options.now() <= options.deadline, "limit", "Calculation deadline exceeded");
      }
    };
    options.cancellation?.throwIfCancelled();
    const sheets = new Map(document.sheets.map((sheet) => [sheet.id, sheet]));
    const names = new Map(document.sheets.map((sheet) => [sheet.name.toLowerCase(), sheet.id]));
    const structureChanged = !this.#previous || this.#previous.documentId !== document.documentId || this.#previous.sheets.length !== document.sheets.length || this.#previous.sheets.some((s, i) => s.id !== document.sheets[i]?.id || s.name !== document.sheets[i]?.name);
    const changed = /* @__PURE__ */ new Set();
    const formulaEntries = /* @__PURE__ */ new Map();
    const parsed = /* @__PURE__ */ new Map(), sheetIndexes = /* @__PURE__ */ new Map();
    const indexes = /* @__PURE__ */ new Map(), formulaIndexes = /* @__PURE__ */ new Map();
    let formulasChanged = structureChanged;
    for (const sheet of document.sheets) {
      const before = this.#previous?.sheets.find((s) => s.id === sheet.id), prior = this.#sheetIndexes.get(sheet.id);
      let state;
      if (prior && before?.cells === sheet.cells) state = prior;
      else {
        const keys = Object.keys(sheet.cells), formulaKeys = [];
        let coordinatesChanged = !prior || keys.length !== prior.keys.length, formulaCoordinatesChanged = !prior;
        for (let index = 0; index < keys.length; index++) {
          if ((index & 1023) === 0) tick();
          const key = keys[index], cell = sheet.cells[key], old = before?.cells[key];
          if (!old) coordinatesChanged = true;
          if (!sameValue(old?.value, cell.value)) changed.add(`${sheet.id}!${key}`);
          if (cell.value.kind === "formula") formulaKeys.push(key);
          if (cell.value.kind === "formula" !== (old?.value.kind === "formula")) formulaCoordinatesChanged = true;
        }
        if (before && coordinatesChanged) for (const key of prior?.keys ?? Object.keys(before.cells)) {
          if (Object.hasOwn(sheet.cells, key)) continue;
          changed.add(`${sheet.id}!${key}`);
          if (before.cells[key].value.kind === "formula") formulaCoordinatesChanged = true;
        }
        const all = !coordinatesChanged && prior ? prior.all : new SparseSheetIndex(sheet);
        const formulaCells = {};
        if (formulaCoordinatesChanged) for (const key of formulaKeys) formulaCells[key] = sheet.cells[key];
        const formulas = !formulaCoordinatesChanged && prior ? prior.formulas : new SparseSheetIndex({ ...sheet, cells: formulaCells });
        state = { keys, formulaKeys, all, formulas };
      }
      sheetIndexes.set(sheet.id, state);
      indexes.set(sheet.id, state.all);
      formulaIndexes.set(sheet.id, state.formulas);
      for (const cellKey of state.formulaKeys) {
        const value = sheet.cells[cellKey].value;
        assert(value.kind === "formula", "invalid", "Stale formula index");
        tick();
        const key = `${sheet.id}!${cellKey}`;
        let item = this.#parsed.get(key);
        if (!item || item.source !== value.source) {
          formulasChanged = true;
          item = { source: value.source };
          try {
            item.ast = parseFormula(value.source, { cancellation: options.cancellation });
          } catch (failure) {
            if (!(failure instanceof OfficeError) || !["unsupported", "invalid"].includes(failure.code)) throw failure;
            item.unsupported = true;
          }
        }
        parsed.set(key, item);
        const [row, column] = cellKey.split(":").map(Number);
        formulaEntries.set(key, { sheetId: sheet.id, row, column, parsed: item });
      }
    }
    if (parsed.size !== this.#parsed.size) formulasChanged = true;
    const resolve = (reference, current) => reference.sheet === void 0 ? current : names.get(reference.sheet.toLowerCase());
    const rectangle = (node, current, owner) => {
      const a = node.kind === "range" ? node.start : node, b = node.kind === "range" ? node.end : node;
      const sheetId = resolve(a, current), endId = resolve(b, sheetId ?? current);
      if (!sheetId || endId !== sheetId) return void 0;
      return { sheetId, row1: Math.min(a.row, b.row), column1: Math.min(a.column, b.column), row2: Math.max(a.row, b.row), column2: Math.max(a.column, b.column), owner };
    };
    const ranges = [];
    const deps = formulasChanged ? /* @__PURE__ */ new Map() : this.#dependencies;
    const reverse = formulasChanged ? /* @__PURE__ */ new Map() : this.#reverse;
    if (formulasChanged) for (const [key, entry] of formulaEntries) {
      const dependencies = /* @__PURE__ */ new Set();
      deps.set(key, dependencies);
      if (entry.parsed.ast) walkFormula(entry.parsed.ast, (node) => {
        if (node.kind !== "reference" && node.kind !== "range") return;
        tick();
        const range = rectangle(node, entry.sheetId, key);
        if (!range) return;
        ranges.push(range);
        for (const item of formulaIndexes.get(range.sheetId).range(range.row1, range.column1, range.row2, range.column2)) {
          tick();
          const dependency = `${range.sheetId}!${item.key}`;
          dependencies.add(dependency);
          const dependents = reverse.get(dependency) ?? /* @__PURE__ */ new Set();
          dependents.add(key);
          reverse.set(dependency, dependents);
        }
      });
    }
    const rangeIndex = formulasChanged ? new RangeDependencyIndex(ranges) : this.#index, dirty = /* @__PURE__ */ new Set();
    if (structureChanged) for (const key of formulaEntries.keys()) dirty.add(key);
    else {
      for (const key of changed) {
        if (formulaEntries.has(key)) dirty.add(key);
        const [sheetId, coordinate] = key.split("!"), [row, col] = coordinate.split(":").map(Number);
        for (const owner of this.#index === rangeIndex ? rangeIndex.query(sheetId, row, col, tick) : [...this.#index.query(sheetId, row, col, tick), ...rangeIndex.query(sheetId, row, col, tick)]) if (formulaEntries.has(owner)) dirty.add(owner);
      }
      for (const key of formulaEntries.keys()) if (!this.#results.has(key)) dirty.add(key);
    }
    const queue = [...dirty];
    for (let head = 0; head < queue.length; head++) for (const owner of reverse.get(queue[head]) ?? []) if (!dirty.has(owner)) {
      dirty.add(owner);
      queue.push(owner);
    }
    const results = /* @__PURE__ */ new Map();
    for (const key of formulaEntries.keys()) if (!dirty.has(key) && this.#results.has(key)) results.set(key, this.#results.get(key));
    const active = /* @__PURE__ */ new Set();
    const cycles = /* @__PURE__ */ new Set();
    const fromResult = (result) => result.state === "valid" || result.state === "error" ? result.value ?? blank : pending();
    const getCell = (sheetId, row, column, depth) => {
      tick();
      const cell = sheets.get(sheetId)?.cells[`${row}:${column}`];
      if (!cell) return blank;
      if (cell.value.kind !== "formula") return cell.value;
      return fromResult(calculateCell(calculationKey(sheetId, row, column), depth + 1));
    };
    const evaluate = (node, sheetId, owner, depth) => {
      tick();
      assert(depth <= maxDepth, "limit", "Formula evaluation depth exceeded");
      if (node.kind === "number" || node.kind === "string" || node.kind === "boolean" || node.kind === "error") return node;
      if (node.kind === "missing") return num(0);
      if (node.kind === "reference") {
        const target = resolve(node, sheetId);
        return target ? getCell(target, node.row, node.column, depth) : error("#REF!");
      }
      if (node.kind === "range") {
        const range = rectangle(node, sheetId, owner);
        return range ? { kind: "range-value", range } : error("#REF!");
      }
      if (node.kind === "unary") {
        const value = scalar(evaluate(node.operand, sheetId, owner, depth + 1));
        if (value.kind === "pending") return value;
        const number = numeric(value);
        if (typeof number !== "number") return number;
        return num(node.operator === "-" ? -number : node.operator === "%" ? number / 100 : number);
      }
      if (node.kind === "binary") {
        const left = scalar(evaluate(node.left, sheetId, owner, depth + 1));
        if (left.kind === "pending" || left.kind === "error") return left;
        const right = scalar(evaluate(node.right, sheetId, owner, depth + 1));
        if (right.kind === "pending" || right.kind === "error") return right;
        if (node.operator === "&") {
          const text = textValue(left) + textValue(right);
          return text.length > 32767 ? error("#VALUE!") : { kind: "string", value: text };
        }
        if (["=", "<>", "<", ">", "<=", ">="].includes(node.operator)) {
          const c = comparison(left, right);
          return bool(node.operator === "=" ? c === 0 : node.operator === "<>" ? c !== 0 : node.operator === "<" ? c < 0 : node.operator === ">" ? c > 0 : node.operator === "<=" ? c <= 0 : c >= 0);
        }
        const a = numeric(left), b = numeric(right);
        if (typeof a !== "number") return a;
        if (typeof b !== "number") return b;
        if (node.operator === "/" && b === 0) return error("#DIV/0!");
        if (node.operator === "^" && a === 0 && b < 0) return error("#DIV/0!");
        if (node.operator === "^" && a === 0 && b === 0) return error("#NUM!");
        return num(node.operator === "+" ? a + b : node.operator === "-" ? a - b : node.operator === "*" ? a * b : node.operator === "/" ? a / b : a ** b);
      }
      const name = node.name.toUpperCase();
      if (!isSupportedFunction(name)) return pending("unknown-function", "unsupported");
      if (node.args.length === 0 || node.args.length > 255) return error("#VALUE!");
      if (name === "IF") {
        if (node.args.length < 2 || node.args.length > 3) return error("#VALUE!");
        const condition = scalar(evaluate(node.args[0], sheetId, owner, depth + 1));
        if (condition.kind === "pending") return condition;
        const logicalValue = logical(condition);
        if (typeof logicalValue !== "boolean") return logicalValue;
        const chosen = logicalValue ? node.args[1] : node.args[2];
        return chosen ? evaluate(chosen, sheetId, owner, depth + 1) : bool(false);
      }
      if (name === "ABS" || name === "ROUND" || name === "NOT") {
        if (node.args.length !== (name === "ROUND" ? 2 : 1)) return error("#VALUE!");
        const first = scalar(evaluate(node.args[0], sheetId, owner, depth + 1));
        if (first.kind === "pending") return first;
        if (name === "NOT") {
          const value = logical(first);
          return typeof value === "boolean" ? bool(!value) : value;
        }
        const n = numeric(first);
        if (typeof n !== "number") return n;
        if (name === "ABS") return num(Math.abs(n));
        const second = scalar(evaluate(node.args[1], sheetId, owner, depth + 1));
        if (second.kind === "pending") return second;
        const places = numeric(second);
        return typeof places === "number" ? decimalRound(n, places) : places;
      }
      let count = 0, sum = 0, minimum = Infinity, maximumValue = -Infinity, logicalCount = 0, and = true, or = false;
      const accept = (value, reference) => {
        tick();
        if (value.kind === "pending") return value;
        if (name === "COUNTA") {
          if (value.kind !== "blank") count++;
          return;
        }
        if (name === "COUNT") {
          if (value.kind === "number" || !reference && (value.kind === "boolean" || value.kind === "string" && typeof numeric(value) === "number")) count++;
          return;
        }
        if (value.kind === "error") return value;
        if (name === "AND" || name === "OR") {
          if (reference && (value.kind === "blank" || value.kind === "string")) return;
          const v = logical(value);
          if (typeof v !== "boolean") return v;
          logicalCount++;
          and = and && v;
          or = or || v;
          return;
        }
        if (reference && value.kind !== "number") return;
        const n = numeric(value);
        if (typeof n !== "number") return n;
        count++;
        sum += n;
        minimum = Math.min(minimum, n);
        maximumValue = Math.max(maximumValue, n);
        return;
      };
      for (const argument of node.args) {
        const result = evaluate(argument, sheetId, owner, depth + 1);
        if (result.kind === "range-value") {
          const r = result.range;
          for (const entry of indexes.get(r.sheetId).range(r.row1, r.column1, r.row2, r.column2)) {
            const failure = accept(getCell(r.sheetId, entry.row, entry.column, depth + 1), true);
            if (failure) return failure;
          }
        } else {
          const failure = accept(result, argument.kind === "reference");
          if (failure) return failure;
        }
      }
      if (name === "COUNT" || name === "COUNTA") return num(count);
      if (name === "AND" || name === "OR") return logicalCount ? bool(name === "AND" ? and : or) : error("#VALUE!");
      if (name === "AVERAGE") return count ? num(sum / count) : error("#DIV/0!");
      if (name === "MIN") return num(count ? minimum : 0);
      if (name === "MAX") return num(count ? maximumValue : 0);
      return num(sum);
    };
    const calculateCell = (key, depth = 0) => {
      const found = results.get(key);
      if (found) return found;
      if (active.has(key)) {
        cycles.add(key);
        return { state: "error", value: error("#REF!"), reason: "cycle" };
      }
      assert(depth <= maxDepth, "limit", "Calculation dependency depth exceeded");
      const entry = formulaEntries.get(key);
      active.add(key);
      computedCells++;
      let result;
      if (!entry.parsed.ast) result = { state: "unsupported", reason: "unsupported-syntax" };
      else {
        const value = scalar(evaluate(entry.parsed.ast, entry.sheetId, key, depth));
        result = value.kind === "pending" ? { state: value.state, reason: value.reason } : { state: value.kind === "error" ? "error" : "valid", value: value.kind === "blank" ? num(0) : value };
        if (cycles.has(key)) result = { state: "error", value: error("#REF!"), reason: "cycle" };
      }
      if (result.state === "unsupported" || result.state === "stale") {
        const importedCache = !options.cachedSources || options.cachedSources.get(key) === entry.parsed.source ? options.cachedValues?.get(key) : void 0;
        const retainedCache = this.#previous?.documentId === document.documentId && this.#parsed.get(key)?.source === entry.parsed.source ? this.#results.get(key)?.value : void 0;
        const cache = importedCache ?? retainedCache;
        if (cache !== void 0) result.value = cache;
      }
      if (result.value) result.value = Object.freeze({ ...result.value });
      active.delete(key);
      results.set(key, Object.freeze(result));
      return result;
    };
    const counts = /* @__PURE__ */ new Map(), ready = [];
    for (const key of dirty) {
      const count = [...deps.get(key) ?? []].filter((d) => dirty.has(d)).length;
      counts.set(key, count);
      if (count === 0) ready.push(key);
    }
    for (let head = 0; head < ready.length; head++) {
      const key = ready[head];
      calculateCell(key);
      for (const next of reverse.get(key) ?? []) {
        if (!counts.has(next)) continue;
        const count = counts.get(next) - 1;
        counts.set(next, count);
        if (count === 0) ready.push(next);
      }
    }
    for (const key of dirty) if (!results.has(key)) calculateCell(key);
    options.cancellation?.throwIfCancelled();
    this.#previous = document;
    this.#parsed = parsed;
    this.#results = new Map(results);
    this.#index = rangeIndex;
    this.#sheetIndexes = sheetIndexes;
    this.#dependencies = deps;
    this.#reverse = reverse;
    return Object.freeze({ cells: results, computedCells, steps, get(sheetId, row, column) {
      const key = calculationKey(sheetId, row, column);
      if (results.has(key)) return results.get(key);
      const value = sheets.get(sheetId)?.cells[`${row}:${column}`]?.value ?? blank;
      return value.kind === "formula" ? { state: "stale" } : { state: value.kind === "error" ? "error" : "valid", value };
    } });
  }
  clear() {
    this.#previous = void 0;
    this.#results.clear();
    this.#parsed.clear();
    this.#index = new RangeDependencyIndex([]);
    this.#sheetIndexes.clear();
    this.#dependencies.clear();
    this.#reverse.clear();
  }
};

// packages/core/src/resources.ts
var ROUND_CONSTANTS = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);

// packages/core/src/images.ts
var MAX_BYTES = 8 * 1024 * 1024;
var crcTable = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let j = 0; j < 8; j++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
  crcTable[i] = c >>> 0;
}

// packages/core/src/session.ts
var EDITABLE_CAPABILITIES = Object.freeze({ canEdit: true, allowedFeatures: Object.freeze(["MOD-01", "MOD-03", "WRT-02", "WRT-03", "SHT-02", "SLD-02"]), diagnostics: Object.freeze([]) });

// packages/ui/src/sheets-recalc-worker.ts
var calculator = new WorkbookCalculator();
self.onmessage = (event) => {
  const job = event.data;
  try {
    const result = calculator.calculate(job.document, { maxSteps: 1e6, maxDepth: 128, now: () => performance.now(), deadline: performance.now() + 1e4, cachedValues: new Map(job.cachedValues ?? []), cachedSources: new Map(job.cachedSources ?? []) });
    self.postMessage({ id: job.id, revision: job.revision, ok: true, cells: [...result.cells], computedCells: result.computedCells, steps: result.steps });
  } catch (error2) {
    self.postMessage({ id: job.id, revision: job.revision, ok: false, error: asFailure(error2) });
  }
};
